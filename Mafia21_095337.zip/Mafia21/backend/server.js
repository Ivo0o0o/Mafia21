// ===============================================
// MAFIA 21st CENTURY — BACKEND SERVER (PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================

const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const path = require("path");

// ===============================================
// CORE LAYER
// ===============================================
const { connectDB } = require("./core/db");
const loadRoutes = require("./core/routeLoader");

// ===============================================
// AI / NPC / WORLD SYSTEMS
// ===============================================
const npcWorldTick = require("./modules/NPC/NPCWorldTick");                     // Legacy world tick
const { startAILoop } = require("./modules/ai/loop.scheduler");                 // AI decision loop
const { startAutoIncomeJob } = require("./modules/economy/autoIncome.job");     // Passive player income
const NpcActionEngine = require("./modules/NPC/npc.action.engine");             // NPC Action Engine PRO
const WorldSimulation = require("./modules/npc/worldSimulation/world.engine");  // Full world simulation
const CitySimulation = require("./modules/npc/citySimulation/citySim.engine");  // City simulation
const MissionEngine = require("./modules/npc/missionEngine/mission.engine");    // NPC missions
const DialogueEngine = require("./modules/npc/dialogueEngine/dialogue.engine"); // NPC dialogue

// ===============================================
// CONFIG
// ===============================================
dotenv.config();
const app = express();
const PORT = process.env.PORT || 4000;

// ===============================================
// MIDDLEWARES
// ===============================================
app.use(cors());
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true }));

// ===============================================
// STATIC ADMIN PANEL
// ===============================================
app.use("/admin", express.static(path.join(__dirname, "admin-panel")));

// ===============================================
// CONNECT DATABASE
// ===============================================
connectDB();

// ===============================================
// LOAD ALL ROUTES
// ===============================================
loadRoutes(app);

// ===============================================
// HEALTH CHECK
// ===============================================
app.get("/health", (req, res) => {
  res.json({
    ok: true,
    server: "running",
    mongo: "connected",
    ai: "active",
    npc: "active",
    world: "active"
  });
});

// ===============================================
// START SERVER + ALL ENGINES
// ===============================================
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`🌍 http://localhost:${PORT}`);

  // -----------------------------------------------
  // ECONOMY ENGINE
  // -----------------------------------------------
  startAutoIncomeJob();

  // -----------------------------------------------
  // AI DECISION LOOP
  // -----------------------------------------------
  startAILoop();

  // -----------------------------------------------
  // NPC ACTION ENGINE (PRO)
  // -----------------------------------------------
  setInterval(() => NpcActionEngine.tick(), 30_000);

  // -----------------------------------------------
  // WORLD SIMULATION ENGINE
  // -----------------------------------------------
  setInterval(() => WorldSimulation.tick(), 60_000);

  // -----------------------------------------------
  // CITY SIMULATION ENGINE
  // -----------------------------------------------
  setInterval(() => CitySimulation.tick(), 45_000);

  // -----------------------------------------------
  // NPC MISSIONS ENGINE
  // -----------------------------------------------
  setInterval(() => MissionEngine.tick(), 20_000);

  // -----------------------------------------------
  // NPC DIALOGUE ENGINE
  // -----------------------------------------------
  setInterval(() => DialogueEngine.tick(), 15_000);

  // -----------------------------------------------
  // LEGACY NPC WORLD TICK (sandboxed)
  // -----------------------------------------------
  setInterval(() => npcWorldTick(), 30_000);
});

// ===============================================
// GLOBAL ERROR HANDLER (PRO)
// ===============================================
app.use((err, req, res, next) => {
  console.error("🔥 GLOBAL ERROR:", err);
  res.status(500).json({
    ok: false,
    error: "Internal server error",
    details: err.message
  });
});

// ===============================================
// GRACEFUL SHUTDOWN
// ===============================================
process.on("SIGTERM", () => {
  console.log("🛑 Server shutting down...");
  process.exit(0);
});

process.on("SIGINT", () => {
  console.log("🛑 Server interrupted...");
  process.exit(0);
});