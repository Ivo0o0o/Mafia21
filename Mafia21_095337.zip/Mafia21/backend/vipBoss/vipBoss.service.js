const VIPBoss = require('./vipBoss.model');
const User = require('../user/user.model');
const { addCrimeReward, addLootReward, getVipEffects } = require('../playerState/playerState.engine');

module.exports = {
  fight: async (userId) => {
    const user = await User.findById(userId);
    if (!user) throw new Error("User not found");

    const vip = await getVipEffects(userId);
    if (!vip) return { success: false, message: "VIP only content" };

    const boss = await VIPBoss.findOne();
    if (!boss) throw new Error("Boss not found");

    // Cooldown check
    let cooldownMs = boss.cooldown * 1000;
    if (vip.cooldownBoost) cooldownMs = Math.floor(cooldownMs * vip.cooldownBoost);

    if (user.bossCooldown && user.bossCooldown > Date.now()) {
      const remaining = Math.floor((user.bossCooldown - Date.now()) / 1000);
      return { success: false, message: `Cooldown: ${remaining}s remaining` };
    }

    // Damage calculation
    const playerDamage = user.damage * (vip.damageBoost || 1);
    const bossDamage = boss.damage;

    // Fight result
    const playerWins = playerDamage >= boss.hp;

    if (!playerWins) {
      user.bossCooldown = Date.now() + cooldownMs;
      await user.save();
      return { success: false, message: "Boss defeated you", cooldown: cooldownMs / 1000 };
    }

    // Rewards
    const money = boss.rewardMoney;
    const xp = boss.rewardXP;

    const boosted = await addCrimeReward(userId, money, xp);

    // Loot
    let loot = [...boss.loot.common];

    if (Math.random() < 0.3) {
      loot.push(boss.loot.rare[Math.floor(Math.random() * boss.loot.rare.length)]);
    }

    if (vip.lootBoost && Math.random() < vip.lootBoost) {
      loot.push(boss.loot.ultra[Math.floor(Math.random() * boss.loot.ultra.length)]);
    }

    const finalLoot = await addLootReward(userId, loot);

    user.bossCooldown = Date.now() + cooldownMs;
    await user.save();

    return {
      success: true,
      message: "Boss defeated!",
      reward: {
        money: boosted.money,
        xp: boosted.xp,
        loot: finalLoot
      },
      cooldown: cooldownMs / 1000
    };
  }
};