const vipBossService = require('./vipBoss.service');

module.exports = {
  fight: async (req, res) => {
    try {
      const result = await vipBossService.fight(req.user.id);
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};