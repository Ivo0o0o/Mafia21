const express = require('express');
const router = express.Router();
const controller = require('./vipBoss.controller');

router.post('/fight', controller.fight);

module.exports = router;