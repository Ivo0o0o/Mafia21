const mongoose = require('mongoose');

const vipBossSchema = new mongoose.Schema({
  name: { type: String, default: "VIP Boss" },

  hp: { type: Number, default: 5000 },
  damage: { type: Number, default: 150 },
  defense: { type: Number, default: 50 },

  loot: {
    common:   { type: Array, default: ["cash_bundle", "ammo_box"] },
    rare:     { type: Array, default: ["gold_chain", "pistol_upgrade"] },
    ultra:    { type: Array, default: ["diamond_ring", "rare_car_part"] }
  },

  rewardMoney: { type: Number, default: 5000 },
  rewardXP: { type: Number, default: 1500 },

  cooldown: { type: Number, default: 3600 } // 1 hour
});

module.exports = mongoose.model("VIPBoss", vipBossSchema);