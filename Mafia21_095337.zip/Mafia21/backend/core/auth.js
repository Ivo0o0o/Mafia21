// core/auth.js

const jwt = require("jsonwebtoken");
const { jwtSecret } = require("./config");

const auth = (req, res, next) => {
  // Взимаме токена от Authorization header
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res.status(401).json({ error: "Няма токен" });
  }

  try {
    // Проверяваме токена
    const decoded = jwt.verify(token, jwtSecret);

    // Записваме user данните в req.user
    req.user = decoded;

    next();
  } catch (err) {
    return res.status(403).json({ error: "Невалиден токен" });
  }
};

module.exports = auth;