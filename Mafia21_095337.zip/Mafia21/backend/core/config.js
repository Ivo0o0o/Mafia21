// core/config.js

module.exports = {
  // JWT Secret Key
  jwtSecret: process.env.JWT_SECRET || "mafia21_secret_key",

  // Server Port
  port: process.env.PORT || 4000,

  // MongoDB URI
  mongoURI: process.env.MONGO_URI || "mongodb://localhost:27017/mafia21",

  // Име на базата (ако искаш да го променяш централизирано)
  dbName: process.env.DB_NAME || "mafia21"
};