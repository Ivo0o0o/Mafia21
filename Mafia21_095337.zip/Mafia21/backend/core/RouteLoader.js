// ===============================================
// MAFIA 21st CENTURY — ROUTE LOADER (PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Зарежда всички API маршрути на проекта
// Loads all API routes for the entire project
// ===============================================

const path = require("path");
const express = require("express");

module.exports = function loadRoutes(app) {

  // ===============================================
  // ROOT TEST ROUTE
  // ===============================================
  app.get("/", (req, res) => {
    res.json({ message: "Мафия от 21ви век backend работи." });
  });

  // ===============================================
  // ADMIN PANEL (STATIC)
  // ===============================================
  app.use("/admin", express.static(path.join(__dirname, "../admin-panel")));
  app.get("/admin", (req, res) => {
    res.sendFile(path.join(__dirname, "../admin-panel/index.html"));
  });

  // ===============================================
  // DISTRICT SYSTEM (NEW PRO)
  // ===============================================
  app.use("/api/districts", require("../modules/districts/district.routes"));
  app.use("/api/influence", require("../modules/districts/Influence.routes"));

  // ===============================================
  // PLAYER MODULES
  // ===============================================
  app.use("/api/playerRank", require("../modules/player/progression/rank.routes"));
  app.use("/api/player/economy", require("../modules/player/economy/economy.routes"));
  app.use("/api/player/assets", require("../modules/player/assets/assets.routes"));
  app.use("/api/player/blackmarket", require("../modules/player/blackmarket/blackmarket.routes"));
  app.use("/api/player/crime", require("../modules/player/crime/crime.routes"));
  app.use("/api/player/court", require("../modules/player/justice/court.routes"));
  app.use("/api/player/prison", require("../modules/player/prison/prison.routes"));
  app.use("/api/player/territory", require("../modules/player/territory/territory.routes"));
  app.use("/api/playerActions", require("../modules/player/player.actions.routes"));

  // ===============================================
  // GAME MODULES
  // ===============================================
  app.use("/api/gameSession", require("../modules/game/session/session.routes"));
  app.use("/api/playerState", require("../modules/game/playerState/playerState.routes"));
  app.use("/api/actions", require("../modules/game/actions/actions.routes"));

  // ===============================================
  // WORLD MODULES
  // ===============================================
  app.use("/api/world/districts", require("../modules/world/districts/district.routes"));
  app.use("/api/districtDetails", require("../modules/world/districts/district.details.routes"));
  app.use("/api/worldEvents", require("../modules/worldEvent/event.routes"));

  // ===============================================
  // SKILLS MODULE
  // ===============================================
  app.use("/api/skills", require("../modules/skills/skills.routes"));

  // ===============================================
  // NPC MODULES (FULL AI SYSTEM)
  // ===============================================
  app.use("/api/npcAI", require("../modules/npc/npcAI.routes"));
  app.use("/api/npcThreat", require("../modules/npc/npcThreat.routes"));
  app.use("/api/npcCombat", require("../modules/npc/combat/combat.routes"));
  app.use("/api/npcCombat/player", require("../modules/npc/combat/playerCombat.routes"));
  app.use("/api/npcPersonality", require("../modules/npc/personality.routes"));
  app.use("/api/npcLife", require("../modules/npc/life.routes"));
  app.use("/api/npcSocial", require("../modules/npc/social.routes"));
  app.use("/api/npcEconomy", require("../modules/npc/economy.routes"));
  app.use("/api/npc/territory", require("../modules/npc/territoryControl/territory.routes"));
  app.use("/api/npc/territorySimple", require("../modules/npc/territory/territory.routes"));
  app.use("/api/npc/blackMarket", require("../modules/npc/blackMarket/blackMarket.routes"));
  app.use("/api/npc/underworldEconomy", require("../modules/npc/underworldEconomy/economy.routes"));
  app.use("/api/npc/warfare", require("../modules/npc/warfare/warfare.routes"));
  app.use("/api/npc/diplomacy", require("../modules/npc/diplomacy/diplomacy.routes"));
  app.use("/api/npc/strategy", require("../modules/npc/strategy/strategy.routes"));
  app.use("/api/npc/action", require("../modules/npc/action/action.routes"));
  app.use("/api/worldSim", require("../modules/npc/worldSimulation/world.routes"));
  app.use("/api/npc/worldEvents", require("../modules/npc/worldEvents/worldEvents.routes"));
  app.use("/api/citySim", require("../modules/npc/citySimulation/citySim.routes"));
  app.use("/api/playerInteraction", require("../modules/npc/playerInteraction/playerInteraction.routes"));
  app.use("/api/overseer", require("../modules/npc/overseer/overseer.routes"));
  app.use("/api/missions", require("../modules/npc/missionEngine/mission.routes"));
  app.use("/api/dialogue", require("../modules/npc/dialogueEngine/dialogue.routes"));
  app.use("/api/npc/behavior", require("../modules/npc/behaviorEngine/behavior.routes"));

  // ===============================================
  // ORGANIZATION MODULES (NPC FACTIONS)
  // ===============================================
  app.use("/api/organizations", require("../modules/organizations/organization.routes"));
  app.use("/api/orgControl", require("../modules/npc/organizationControl/orgControl.routes"));
  app.use("/api/orgEconomy", require("../modules/npc/organizationEconomy/orgEconomy.routes"));
  app.use("/api/orgWarfare", require("../modules/npc/organizationWarfare/warfare.routes"));
  app.use("/api/orgDiplomacy", require("../modules/npc/organizationDiplomacy/diplomacy.routes"));
  app.use("/api/orgIntel", require("../modules/npc/organizationIntelligence/intelligence.routes"));
  app.use("/api/orgLogistics", require("../modules/npc/organizationLogistics/logistics.routes"));
  app.use("/api/orgOperations", require("../modules/npc/organizationOperations/operations.routes"));
  app.use("/api/orgRelations", require("../modules/npc/organizationRelations/relations.routes"));
  app.use("/api/orgTerritory", require("../modules/npc/organizationTerritory/territory.routes"));

  // ===============================================
  // AI MODULES
  // ===============================================
  app.use("/api/ai/behavior", require("../modules/ai/behavior.routes"));
  app.use("/api/ai", require("../modules/ai/decision.routes"));
  app.use("/api/personality", require("../modules/ai/personality.routes"));

  // ===============================================
  // ADMIN / GOD / SYSTEM MODULES
  // ===============================================
  app.use("/api/admin", require("../modules/admin/admin.routes"));
  app.use("/api/god", require("../modules/adminGod/god.routes"));
  app.use("/api/users", require("../modules/user/user.routes"));
  app.use("/api/profile", require("../modules/profile/profile.routes"));
  app.use("/api/vehicles", require("../modules/vehicles/vehicle.routes"));
  app.use("/api/movement", require("../modules/movement/movement.routes"));
  app.use("/api/level", require("../modules/Level/level.routes"));

  // ===============================================
  // VIP MODULE
  // ===============================================
  app.use("/api/vip", require("../modules/vip/vip.routes"));
  app.use("/api/vip/boss", require("../modules/vip/vipBoss.routes"));
};