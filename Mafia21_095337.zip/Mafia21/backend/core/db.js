// ===============================================
// MAFIA 21st CENTURY — DATABASE CONNECTOR (PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Свързва се към MongoDB базата данни
// Connects to the MongoDB database
// ===============================================

const mongoose = require("mongoose");

const connectDB = async () => {
  try {
    await mongoose.connect(
      process.env.MONGO_URI || "mongodb://localhost:27017/mafia21",
      { dbName: "mafia21" }
    );

    console.log("📡 MongoDB connected (Мафия от 21ви век)");
  } catch (err) {
    console.error("❌ DB error:", err.message);
    process.exit(1); // Спира сървъра при критична грешка
  }
};

module.exports = { connectDB };