export const godAccess = (req, res, next) => {
  const key = req.headers['x-god-key'];

  if (key === process.env.GOD_SECRET) {
    req.user = { role: "god", id: "IVO" };
    return next();
  }

  return res.status(403).json({ error: "Access denied" });
};