const router = require("express").Router();
const OrganizationController = require("./organization.controller");

router.post("/", OrganizationController.create);
router.post("/:id/member", OrganizationController.addMember);
router.post("/:id/relation", OrganizationController.setRelation);

module.exports = router;