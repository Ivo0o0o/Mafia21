const OrganizationService = require("./organization.service");

module.exports = {

  async create(req, res) {
    try {
      const org = await OrganizationService.create(req.body);
      res.json({ success: true, org });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  async addMember(req, res) {
    try {
      const org = await OrganizationService.addMember(req.params.id, req.body.npcId);
      res.json({ success: true, org });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  async setRelation(req, res) {
    try {
      const org = await OrganizationService.setRelation(
        req.params.id,
        req.body.targetOrgId,
        req.body.relation
      );
      res.json({ success: true, org });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};