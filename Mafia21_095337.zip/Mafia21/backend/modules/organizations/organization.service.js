const Organization = require("./organization.model");
const NPC = require("../NPC/npc.model");
const District = require("../Districts/District.model");

module.exports = {

  async addMember(orgId, npcId) {
    const org = await Organization.findById(orgId);
    if (!org) return null;

    org.members.push(npcId);
    await org.save();

    const npc = await NPC.findById(npcId);
    npc.organizationId = orgId;
    await npc.save();

    return org;
  },

  async updateInfluence(orgId) {
    const org = await Organization.findById(orgId);
    if (!org) return null;

    // влияние = членове + контролирани райони
    const memberPower = org.members.length * 5;
    const districtPower = org.districts.length * 20;

    org.influence = memberPower + districtPower;
    await org.save();

    return org.influence;
  },

  async updateDistrictOwnership() {
    const districts = await District.find();
    const orgs = await Organization.find();

    for (const district of districts) {
      if (district.npcOwner) {
        const org = orgs.find(o => o._id.toString() === district.npcOwner);
        if (org && !org.districts.includes(district.name)) {
          org.districts.push(district.name);
          await org.save();
        }
      }
    }
  },

  async setRelation(orgId, targetOrgId, relation) {
    const org = await Organization.findById(orgId);
    if (!org) return null;

    org.relations.set(targetOrgId, relation);
    await org.save();

    return org;
  }
};