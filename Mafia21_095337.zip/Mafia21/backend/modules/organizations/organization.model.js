const mongoose = require("mongoose");

const organizationSchema = new mongoose.Schema({
  // Име на организацията
  name: { type: String, required: true, unique: true },

  // Тип (мафия, картел, банда, корпорация)
  type: { 
    type: String,
    enum: ["mafia", "cartel", "gang", "syndicate", "corporation"],
    default: "mafia"
  },

  // Лидер (NPC ID)
  leader: { type: mongoose.Schema.Types.ObjectId, ref: "NPC", default: null },

  // Членове (NPC IDs)
  members: [{ type: mongoose.Schema.Types.ObjectId, ref: "NPC" }],

  // Влияние върху града (0–1000)
  influence: { type: Number, default: 10 },

  // Богатство (за рекет, бизнеси, мисии)
  wealth: { type: Number, default: 1000 },

  // Контролирани райони
  districts: [{ type: String }], // district.name

  // Отношения с други организации
  relations: {
    type: Map,
    of: String, // ally / neutral / enemy
    default: {}
  },

  // Бонуси към NPC
  missionBonus: { type: Number, default: 0 },
  attackBonus: { type: Number, default: 0 },
  defenseBonus: { type: Number, default: 0 },

}, { timestamps: true });

module.exports = mongoose.model("Organization", organizationSchema);