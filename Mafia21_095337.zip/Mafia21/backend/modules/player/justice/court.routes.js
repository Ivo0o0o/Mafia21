const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./court.engine");

// GOD: виж дело
router.get("/:playerId", godAccess, async (req, res) => {
  res.json(await engine.getCase(req.params.playerId));
});

// GOD: следващ етап
router.post("/nextStage", godAccess, async (req, res) => {
  res.json(await engine.nextStage(req.body.playerId));
});

// GOD: присъда
router.post("/verdict", godAccess, async (req, res) => {
  res.json(await engine.calculateVerdict(req.body.playerId));
});

// GOD: обжалване
router.post("/appeal", godAccess, async (req, res) => {
  res.json(await engine.appeal(req.body.playerId));
});

// GOD: затваряне на дело
router.post("/close", godAccess, async (req, res) => {
  res.json(await engine.closeCase(req.body.playerId));
});

module.exports = router;