const CourtCase = require("./court.model");
const { v4: uuidv4 } = require("uuid");

// 1. Създай или вземи дело
async function getCase(playerId) {
  let c = await CourtCase.findOne({ playerId, status: { $ne: "closed" } });
  if (!c) {
    c = await CourtCase.create({
      playerId,
      caseId: uuidv4(),
      status: "investigation"
    });
  }
  return c;
}

// 2. Преходи между етапи
async function nextStage(playerId) {
  const c = await getCase(playerId);

  const order = ["investigation", "charges", "trial", "verdict", "appeal", "closed"];
  const idx = order.indexOf(c.status);

  if (idx < order.length - 1) {
    c.status = order[idx + 1];
  }

  c.lastUpdate = new Date();
  await c.save();
  return c;
}

// 3. Изчисляване на присъда
async function calculateVerdict(playerId) {
  const c = await getCase(playerId);

  const score =
    c.prosecutorStrength -
    c.defenseStrength +
    c.evidenceWeight -
    c.corruptionLevel;

  if (score > 40) {
    c.verdict = "guilty";
    c.sentence.prisonYears = Math.floor(score / 10);
    c.sentence.fineAmount = Math.floor(score * 50);
  } else if (score < -20) {
    c.verdict = "not_guilty";
  } else {
    c.verdict = "mistrial";
  }

  c.status = "verdict";
  await c.save();
  return c;
}

// 4. Обжалване
async function appeal(playerId) {
  const c = await getCase(playerId);

  if (c.status !== "verdict") return { error: "No verdict to appeal" };

  c.status = "appeal";

  // шанс за намаляване на присъдата
  if (Math.random() < 0.4) {
    c.sentence.prisonYears = Math.max(0, c.sentence.prisonYears - 2);
    c.sentence.fineAmount = Math.max(0, c.sentence.fineAmount - 500);
  }

  await c.save();
  return c;
}

// 5. Затваряне на дело
async function closeCase(playerId) {
  const c = await getCase(playerId);
  c.status = "closed";
  await c.save();
  return c;
}

module.exports = {
  getCase,
  nextStage,
  calculateVerdict,
  appeal,
  closeCase
};