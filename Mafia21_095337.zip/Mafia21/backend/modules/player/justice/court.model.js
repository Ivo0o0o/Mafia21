const mongoose = require("mongoose");

const courtCaseSchema = new mongoose.Schema({
  playerId: { type: String, required: true },

  caseId: { type: String, required: true },
  status: {
    type: String,
    enum: ["investigation", "charges", "trial", "verdict", "appeal", "closed"],
    default: "investigation"
  },

  prosecutorStrength: { type: Number, default: 50 },
  defenseStrength: { type: Number, default: 50 },
  evidenceWeight: { type: Number, default: 50 },
  corruptionLevel: { type: Number, default: 0 },

  verdict: {
    type: String,
    enum: ["none", "guilty", "not_guilty", "mistrial"],
    default: "none"
  },

  sentence: {
    prisonYears: { type: Number, default: 0 },
    fineAmount: { type: Number, default: 0 }
  },

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("CourtCase", courtCaseSchema);