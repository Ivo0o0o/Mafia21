const PlayerTerritory = require("./territory.model");
const { v4: uuidv4 } = require("uuid");

// 1. Вземи или създай профил
async function getTerritory(playerId) {
  let t = await PlayerTerritory.findOne({ playerId });
  if (!t) t = await PlayerTerritory.create({ playerId });
  return t;
}

// 2. Добавяне на район
async function addDistrict(playerId, name) {
  const t = await getTerritory(playerId);

  t.districts.push({
    districtId: uuidv4(),
    name,
    controlLevel: 10,
    crimeInfluence: 5,
    economyInfluence: 5,
    npcInfluence: 5
  });

  await recalcTotalControl(t);
  await t.save();
  return t;
}

// 3. Повишаване на контрол
async function increaseControl(playerId, districtId, amount) {
  const t = await getTerritory(playerId);

  const d = t.districts.find(x => x.districtId === districtId);
  if (!d) return { error: "District not found" };

  d.controlLevel = Math.min(100, d.controlLevel + amount);
  d.crimeInfluence += Math.floor(amount * 0.3);
  d.economyInfluence += Math.floor(amount * 0.2);
  d.npcInfluence += Math.floor(amount * 0.2);

  await recalcTotalControl(t);
  await t.save();
  return t;
}

// 4. Намаляване на контрол
async function decreaseControl(playerId, districtId, amount) {
  const t = await getTerritory(playerId);

  const d = t.districts.find(x => x.districtId === districtId);
  if (!d) return { error: "District not found" };

  d.controlLevel = Math.max(0, d.controlLevel - amount);
  d.crimeInfluence = Math.max(0, d.crimeInfluence - Math.floor(amount * 0.3));
  d.economyInfluence = Math.max(0, d.economyInfluence - Math.floor(amount * 0.2));
  d.npcInfluence = Math.max(0, d.npcInfluence - Math.floor(amount * 0.2));

  await recalcTotalControl(t);
  await t.save();
  return t;
}

// 5. Пресмятане на общ контрол
async function recalcTotalControl(t) {
  if (!t.districts.length) {
    t.totalControl = 0;
    return;
  }

  t.totalControl =
    t.districts.reduce((sum, d) => sum + d.controlLevel, 0) /
    t.districts.length;
}

module.exports = {
  getTerritory,
  addDistrict,
  increaseControl,
  decreaseControl
};