const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./territory.engine");

// GOD: view territory
router.get("/:playerId", godAccess, async (req, res) => {
  res.json(await engine.getTerritory(req.params.playerId));
});

// GOD: add district
router.post("/addDistrict", godAccess, async (req, res) => {
  const { playerId, name } = req.body;
  res.json(await engine.addDistrict(playerId, name));
});

// GOD: increase control
router.post("/increaseControl", godAccess, async (req, res) => {
  const { playerId, districtId, amount } = req.body;
  res.json(await engine.increaseControl(playerId, districtId, amount));
});

// GOD: decrease control
router.post("/decreaseControl", godAccess, async (req, res) => {
  const { playerId, districtId, amount } = req.body;
  res.json(await engine.decreaseControl(playerId, districtId, amount));
});

module.exports = router;