const mongoose = require("mongoose");

const territorySchema = new mongoose.Schema({
  playerId: { type: String, required: true },

  districts: [
    {
      districtId: String,
      name: String,
      controlLevel: { type: Number, default: 0 }, // 0–100
      crimeInfluence: { type: Number, default: 0 },
      economyInfluence: { type: Number, default: 0 },
      npcInfluence: { type: Number, default: 0 }
    }
  ],

  totalControl: { type: Number, default: 0 }, // общ контрол над града

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("PlayerTerritory", territorySchema);