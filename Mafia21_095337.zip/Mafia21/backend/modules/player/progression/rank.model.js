const mongoose = require("mongoose");

const rankSchema = new mongoose.Schema({
  playerId: { type: String, required: true },

  respect: { type: Number, default: 10 },     // уважение
  fear: { type: Number, default: 5 },         // страх
  reputation: { type: Number, default: 10 },  // репутация
  influence: { type: Number, default: 5 },    // влияние

  rank: {
    type: String,
    enum: [
      "Street Rookie",
      "Local Name",
      "Neighborhood Figure",
      "District Shadow",
      "City Ghost",
      "Underworld Known",
      "Underworld Feared",
      "Underworld Respected",
      "Underworld Legend",
      "Underworld Myth"
    ],
    default: "Street Rookie"
  },

  unlocks: {
    missions: [String],
    npcReactions: [String],
    clanActions: [String],
    worldEffects: [String]
  },

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("PlayerRank", rankSchema);