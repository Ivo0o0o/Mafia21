const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./rank.engine");

// GOD: виж ранга
router.get("/:playerId", godAccess, async (req, res) => {
  res.json(await engine.getRank(req.params.playerId));
});

// GOD: progression tick
router.post("/tick", godAccess, async (req, res) => {
  const { playerId } = req.body;
  res.json(await engine.progressionTick(playerId));
});

module.exports = router;