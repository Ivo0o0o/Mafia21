const PlayerRank = require("./rank.model");
const PlayerInteraction = require("../../npc/playerInteraction/playerInteraction.model");
const Overseer = require("../../npc/overseer/overseer.model");

// 1. Вземи или създай профил
async function getRank(playerId) {
  let r = await PlayerRank.findOne({ playerId });
  if (!r) r = await PlayerRank.create({ playerId });
  return r;
}

// 2. Изчисляване на ранга
function calculateRank(score) {
  if (score < 20) return "Street Rookie";
  if (score < 40) return "Local Name";
  if (score < 60) return "Neighborhood Figure";
  if (score < 80) return "District Shadow";
  if (score < 100) return "City Ghost";
  if (score < 130) return "Underworld Known";
  if (score < 160) return "Underworld Feared";
  if (score < 200) return "Underworld Respected";
  if (score < 250) return "Underworld Legend";
  return "Underworld Myth";
}

// 3. Основна логика за прогресия
async function progressionTick(playerId) {
  const r = await getRank(playerId);
  const pi = await PlayerInteraction.findOne({ playerId });
  const overseer = await Overseer.findOne({ worldId: "default" });

  // базов score
  let score = 0;

  score += r.respect * 1.5;
  score += r.fear * 1.2;
  score += r.reputation * 1.3;
  score += r.influence * 2;

  // влияние от NPC отношения
  if (pi) {
    score += pi.respect * 1.5;
    score += pi.fear * 1.2;
    score += pi.reputation * 1.3;
  }

  // влияние от Overseer (световно напрежение)
  if (overseer.metrics.worldTension > 60) {
    score += 10;
  }

  // нов ранг
  const newRank = calculateRank(score);

  // ако има промяна
  if (newRank !== r.rank) {
    r.rank = newRank;
    r.unlocks = generateUnlocks(newRank);
  }

  r.lastUpdate = new Date();
  await r.save();

  return r;
}

// 4. Unlock система
function generateUnlocks(rank) {
  const unlocks = {
    missions: [],
    npcReactions: [],
    clanActions: [],
    worldEffects: []
  };

  switch (rank) {
    case "Local Name":
      unlocks.missions.push("small_investigation");
      unlocks.npcReactions.push("respectful");
      break;

    case "Neighborhood Figure":
      unlocks.missions.push("district_job");
      unlocks.clanActions.push("negotiate");
      break;

    case "District Shadow":
      unlocks.missions.push("high_risk_operation");
      unlocks.npcReactions.push("fearful");
      break;

    case "City Ghost":
      unlocks.worldEffects.push("reduced_police_presence");
      break;

    case "Underworld Known":
      unlocks.clanActions.push("request_backup");
      break;

    case "Underworld Feared":
      unlocks.npcReactions.push("terrified");
      break;

    case "Underworld Respected":
      unlocks.missions.push("elite_contract");
      break;

    case "Underworld Legend":
      unlocks.worldEffects.push("district_control_shift");
      break;

    case "Underworld Myth":
      unlocks.worldEffects.push("world_event_trigger");
      unlocks.missions.push("mythic_operation");
      break;
  }

  return unlocks;
}

module.exports = {
  getRank,
  progressionTick
};