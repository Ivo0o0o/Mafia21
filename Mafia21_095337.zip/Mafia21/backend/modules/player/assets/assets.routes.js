const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./assets.engine");

// GOD: виж активите
router.get("/:playerId", godAccess, async (req, res) => {
  res.json(await engine.getAssets(req.params.playerId));
});

// GOD: assets tick
router.post("/tick", godAccess, async (req, res) => {
  const { playerId } = req.body;
  res.json(await engine.assetsTick(playerId));
});

module.exports = router;