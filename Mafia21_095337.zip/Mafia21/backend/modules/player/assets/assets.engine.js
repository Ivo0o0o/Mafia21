const Assets = require("./assets.model");

// Вземи или създай профил
async function getAssets(playerId) {
  let a = await Assets.findOne({ playerId });
  if (!a) a = await Assets.create({ playerId });
  return a;
}

// Основна логика за активи
async function assetsTick(playerId) {
  const a = await getAssets(playerId);

  let totalIncome = 0;
  let totalUpkeep = 0;

  // имоти
  a.properties.forEach(p => {
    totalIncome += p.income;
    totalUpkeep += p.upkeep;
  });

  // бизнеси
  a.businesses.forEach(b => {
    totalIncome += b.income;
    if (b.illegal) {
      totalUpkeep += b.risk * 2; // нелегалните бизнеси имат скрити разходи
    }
  });

  // амортизация на ценности
  a.valuables.forEach(v => {
    v.value *= 0.999; // минимална амортизация
  });

  a.lastUpdate = new Date();
  await a.save();

  return {
    assets: a,
    income: totalIncome,
    upkeep: totalUpkeep
  };
}

module.exports = {
  getAssets,
  assetsTick
};