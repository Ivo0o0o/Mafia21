const mongoose = require("mongoose");

const assetSchema = new mongoose.Schema({
  playerId: { type: String, required: true },

  properties: [
    {
      name: String,
      value: Number,
      income: Number,        // доход от имота
      upkeep: Number,        // поддръжка
      risk: Number           // риск от полиция/кланове
    }
  ],

  businesses: [
    {
      name: String,
      investment: Number,
      income: Number,
      risk: Number,
      illegal: Boolean
    }
  ],

  valuables: [
    {
      type: String,          // злато, крипто, оръжия, коли
      value: Number
    }
  ],

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("PlayerAssets", assetSchema);