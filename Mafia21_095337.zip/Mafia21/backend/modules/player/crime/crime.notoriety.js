const notorietyStore = new Map();

async function apply(playerId, amount) {
  const current = notorietyStore.get(playerId) || 0;
  const newValue = current + amount;

  notorietyStore.set(playerId, newValue);

  return {
    playerId,
    added: amount,
    total: newValue
  };
}

async function get(playerId) {
  return notorietyStore.get(playerId) || 0;
}

module.exports = {
  apply,
  get
};