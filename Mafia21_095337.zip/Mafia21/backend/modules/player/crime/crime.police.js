async function react(policeChance, success) {
  const roll = Math.random();
  const triggered = roll <= policeChance;

  if (!triggered) {
    return {
      triggered: false,
      caught: false,
      chasing: false
    };
  }

  const caughtChance = success ? 0.10 : 0.40;
  const chaseChance = success ? 0.20 : 0.60;

  const caught = Math.random() <= caughtChance;
  const chasing = !caught && Math.random() <= chaseChance;

  return {
    triggered: true,
    caught,
    chasing
  };
}

module.exports = {
  react
};