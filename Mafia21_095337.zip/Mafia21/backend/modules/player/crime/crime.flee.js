async function attempt(playerId) {
  const successChance = 0.5;
  const chaseIntensity = Math.floor(Math.random() * 100) + 1;

  const success = Math.random() <= successChance;

  if (success) {
    return {
      playerId,
      success: true,
      chaseIntensity,
      outcome: "escaped"
    };
  }

  const injuryChance = 0.3;
  const injured = Math.random() <= injuryChance;

  return {
    playerId,
    success: false,
    chaseIntensity,
    injured,
    outcome: injured ? "caught_injured" : "caught"
  };
}

module.exports = {
  attempt
};