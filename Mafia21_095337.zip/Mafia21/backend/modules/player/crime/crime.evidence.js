async function generate(chance) {
  const roll = Math.random();
  const triggered = roll <= chance;

  if (!triggered) {
    return {
      triggered: false,
      items: []
    };
  }

  const types = [
    "fingerprints",
    "dna",
    "camera_footage",
    "weapon_trace",
    "digital_logs",
    "witness_statement"
  ];

  const count = Math.floor(Math.random() * 3) + 1;
  const items = [];

  for (let i = 0; i < count; i++) {
    items.push({
      id: `evidence_${Date.now()}_${i}`,
      type: types[Math.floor(Math.random() * types.length)],
      strength: Math.floor(Math.random() * 100) + 1
    });
  }

  return {
    triggered: true,
    items
  };
}

module.exports = {
  generate
};