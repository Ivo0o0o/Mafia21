async function generate(chance) {
  const roll = Math.random();
  const triggered = roll <= chance;

  if (!triggered) {
    return {
      triggered: false,
      count: 0,
      statements: []
    };
  }

  const count = Math.floor(Math.random() * 3) + 1;

  const statements = [];
  for (let i = 0; i < count; i++) {
    statements.push({
      id: `witness_${Date.now()}_${i}`,
      sawPlayer: Math.random() <= 0.6,
      description: Math.random() <= 0.5 ? "partial" : "clear",
      fearLevel: Math.floor(Math.random() * 5) + 1
    });
  }

  return {
    triggered: true,
    count,
    statements
  };
}

module.exports = {
  generate
};