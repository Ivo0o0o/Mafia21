const heatStore = new Map();

async function apply(playerId, amount) {
  const current = heatStore.get(playerId) || 0;
  const newHeat = current + amount;

  heatStore.set(playerId, newHeat);

  return {
    playerId,
    added: amount,
    total: newHeat
  };
}

async function get(playerId) {
  return heatStore.get(playerId) || 0;
}

module.exports = {
  apply,
  get
};