const actions = require("./crime.actions.json");
const CrimePolice = require("./crime.police");
const CrimeWitness = require("./crime.witness");
const CrimeEvidence = require("./crime.evidence");
const CrimePunishments = require("./crime.punishments");
const CrimeFlee = require("./crime.flee");
const CrimeHeat = require("./crime.heat");
const CrimeNotoriety = require("./crime.notoriety");

async function getAction(actionId) {
  return actions.find(a => a.id === actionId);
}

async function performCrime(playerId, actionId) {
  const act = await getAction(actionId);
  if (!act) return { error: "Unknown crime action" };

  const result = {
    playerId,
    actionId,
    success: false,
    reward: 0,
    heat: act.heat,
    notoriety: act.notoriety,
    police: null,
    witnesses: null,
    evidence: null,
    punishment: null,
    flee: null
  };

  const roll = Math.random();
  const successChance = 1 - act.risk;

  if (roll <= successChance) {
    result.success = true;
    result.reward = act.reward;
  } else {
    result.success = false;
  }

  result.witnesses = await CrimeWitness.generate(act.witnessChance);
  result.evidence = await CrimeEvidence.generate(act.evidenceChance);
  result.police = await CrimePolice.react(act.policeChance, result.success);
  result.heat = await CrimeHeat.apply(playerId, act.heat);
  result.notoriety = await CrimeNotoriety.apply(playerId, act.notoriety);

  if (!result.success && result.police?.caught) {
    result.punishment = await CrimePunishments.apply(playerId, act);
  }

  if (!result.success && result.police?.chasing) {
    result.flee = await CrimeFlee.attempt(playerId);
  }

  return result;
}

module.exports = {
  performCrime
};