const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./crime.engine");

// GOD: извърши престъпление
router.post("/do", godAccess, async (req, res) => {
  const { playerId, actionId } = req.body;
  res.json(await engine.performCrime(playerId, actionId));
});

// GOD: тестови crime ping
router.get("/ping", godAccess, async (req, res) => {
  res.json({ ok: true, module: "crime" });
});

module.exports = router;