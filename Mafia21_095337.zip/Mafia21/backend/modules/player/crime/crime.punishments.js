async function apply(playerId, action) {
  const punishments = [];

  const fine = Math.floor(action.reward * (Math.random() * 0.5 + 0.5));
  punishments.push({
    type: "fine",
    amount: fine
  });

  const jailChance = action.risk * 0.8;
  const jail = Math.random() <= jailChance;

  if (jail) {
    const jailTime = Math.floor(Math.random() * 24) + 6;
    punishments.push({
      type: "jail",
      hours: jailTime
    });
  }

  const assetLossChance = action.risk * 0.4;
  const assetLoss = Math.random() <= assetLossChance;

  if (assetLoss) {
    punishments.push({
      type: "asset_loss",
      value: Math.floor(Math.random() * 5000) + 1000
    });
  }

  const reputationLoss = Math.floor(action.risk * 10);
  punishments.push({
    type: "reputation_loss",
    amount: reputationLoss
  });

  return {
    playerId,
    punishments
  };
}

module.exports = {
  apply
};