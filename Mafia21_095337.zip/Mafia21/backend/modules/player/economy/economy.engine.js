const Economy = require("./economy.model");

// Вземи или създай икономически профил
async function getEconomy(playerId) {
  let eco = await Economy.findOne({ playerId });
  if (!eco) eco = await Economy.create({ playerId });
  return eco;
}

// Основна логика за икономически тик
async function economyTick(playerId) {
  const eco = await getEconomy(playerId);

  let incomeTotal = 0;
  let expenseTotal = 0;

  // доходи
  eco.incomeStreams.forEach(stream => {
    incomeTotal += stream.amount;
  });

  // разходи
  eco.expenses.forEach(exp => {
    expenseTotal += exp.amount;
  });

  // чист резултат
  const net = incomeTotal - expenseTotal;

  // пране на пари
  const launderingBoost = eco.launderingLevel * 0.05;
  const laundered = net * launderingBoost;

  eco.cash += net + laundered;

  // риск от разследване
  eco.incomeStreams.forEach(stream => {
    if (stream.illegal) {
      eco.investigationRisk += stream.risk * 0.5;
    }
  });

  eco.lastUpdate = new Date();
  await eco.save();

  return eco;
}

module.exports = {
  getEconomy,
  economyTick
};