const mongoose = require("mongoose");

const economySchema = new mongoose.Schema({
  playerId: { type: String, required: true },

  cash: { type: Number, default: 500 },        // пари в брой
  bank: { type: Number, default: 0 },          // банкови пари

  incomeStreams: [
    {
      name: String,
      amount: Number,       // доход на тик
      risk: Number,         // риск от полиция
      illegal: Boolean
    }
  ],

  expenses: [
    {
      name: String,
      amount: Number        // разход на тик
    }
  ],

  launderingLevel: { type: Number, default: 0 }, // ниво на пране на пари
  investigationRisk: { type: Number, default: 0 }, // риск от разследване

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("PlayerEconomy", economySchema);