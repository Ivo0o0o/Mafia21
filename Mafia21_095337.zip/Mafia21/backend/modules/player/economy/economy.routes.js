const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./economy.engine");

// GOD: виж икономиката
router.get("/:playerId", godAccess, async (req, res) => {
  res.json(await engine.getEconomy(req.params.playerId));
});

// GOD: economy tick
router.post("/tick", godAccess, async (req, res) => {
  const { playerId } = req.body;
  res.json(await engine.economyTick(playerId));
});

module.exports = router;