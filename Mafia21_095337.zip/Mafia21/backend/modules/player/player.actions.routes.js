const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const Player = require("./player.model");

// POST /api/playerActions/startMission
router.post("/startMission", godAccess, async (req, res) => {
  const { playerId, missionId } = req.body;

  const p = await Player.findOne({ playerId });
  if (!p) return res.json({ error: "Player not found" });

  // проста логика – добавя мисия в activeMissions
  p.activeMissions = p.activeMissions || [];
  p.activeMissions.push({
    missionId,
    startedAt: new Date(),
    status: "active",
  });

  await p.save();
  res.json({ ok: true, player: p });
});

// POST /api/playerActions/dayTick
router.post("/dayTick", godAccess, async (req, res) => {
  const { playerId } = req.body;

  const p = await Player.findOne({ playerId });
  if (!p) return res.json({ error: "Player not found" });

  // примерна логика за „ден“
  p.timeOfDay = "day";
  p.energy = Math.min((p.energy || 0) + 10, 100);
  p.crimeAwareness = (p.crimeAwareness || 0) + 1;

  await p.save();
  res.json({ ok: true, player: p });
});

// POST /api/playerActions/nightTick
router.post("/nightTick", godAccess, async (req, res) => {
  const { playerId } = req.body;

  const p = await Player.findOne({ playerId });
  if (!p) return res.json({ error: "Player not found" });

  // примерна логика за „нощ“
  p.timeOfDay = "night";
  p.energy = Math.max((p.energy || 0) - 5, 0);
  p.crimeAwareness = Math.max((p.crimeAwareness || 0) - 1, 0);

  await p.save();
  res.json({ ok: true, player: p });
});

module.exports = router;