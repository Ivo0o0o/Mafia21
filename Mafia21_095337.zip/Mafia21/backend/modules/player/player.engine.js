// player.engine.js
const Player = require("./player.model");

// Heal player fully
async function healPlayer(id) {
  const p = await Player.findById(id);
  p.hp = p.maxHp;
  await p.save();
  return p;
}

// Damage player by fixed amount
async function damagePlayer(id, amount = 10) {
  const p = await Player.findById(id);
  p.hp -= amount;
  if (p.hp < 0) p.hp = 0;
  await p.save();
  return p;
}

// Give money
async function giveMoney(id, amount) {
  const p = await Player.findById(id);
  p.money += amount;
  await p.save();
  return p;
}

// Take money
async function takeMoney(id, amount) {
  const p = await Player.findById(id);
  p.money -= amount;
  if (p.money < 0) p.money = 0;
  await p.save();
  return p;
}

// Set any stat dynamically
async function setStat(id, stat, value) {
  const p = await Player.findById(id);
  p[stat] = value;
  await p.save();
  return p;
}

// Get player
async function getPlayer(id) {
  return await Player.findById(id);
}

module.exports = {
  healPlayer,
  damagePlayer,
  giveMoney,
  takeMoney,
  setStat,
  getPlayer
};