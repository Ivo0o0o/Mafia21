const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./blackmarket.engine");

// GOD: виж черния пазар
router.get("/:playerId", godAccess, async (req, res) => {
  res.json(await engine.getBlackMarket(req.params.playerId));
});

// GOD: blackmarket tick
router.post("/tick", godAccess, async (req, res) => {
  const { playerId } = req.body;
  res.json(await engine.blackMarketTick(playerId));
});

module.exports = router;