const mongoose = require("mongoose");

const blackMarketSchema = new mongoose.Schema({
  playerId: { type: String, required: true },

  deals: [
    {
      item: String,
      buyPrice: Number,
      sellPrice: Number,
      successChance: Number,   // шанс за успешна сделка
      risk: Number,            // риск от полиция/кланове
      status: {
        type: String,
        enum: ["pending", "success", "failed"],
        default: "pending"
      }
    }
  ],

  connections: [
    {
      npcId: String,
      trust: Number,
      hostility: Number
    }
  ],

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("BlackMarket", blackMarketSchema);