const BlackMarket = require("./blackmarket.model");

// Вземи или създай профил
async function getBlackMarket(playerId) {
  let bm = await BlackMarket.findOne({ playerId });
  if (!bm) bm = await BlackMarket.create({ playerId });
  return bm;
}

// Основна логика за черния пазар
async function blackMarketTick(playerId) {
  const bm = await getBlackMarket(playerId);

  bm.deals.forEach(deal => {
    if (deal.status === "pending") {
      const roll = Math.random() * 100;

      if (roll <= deal.successChance) {
        deal.status = "success";
      } else {
        deal.status = "failed";
      }
    }
  });

  bm.lastUpdate = new Date();
  await bm.save();

  return bm;
}

module.exports = {
  getBlackMarket,
  blackMarketTick
};