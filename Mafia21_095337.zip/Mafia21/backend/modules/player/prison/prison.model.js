const mongoose = require("mongoose");

const prisonSchema = new mongoose.Schema({
  playerId: { type: String, required: true },

  isInPrison: { type: Boolean, default: false },
  prisonYearsRemaining: { type: Number, default: 0 },

  prisonReputation: { type: Number, default: 0 }, // уважение вътре
  prisonViolence: { type: Number, default: 0 },   // участие в насилие
  corruptionInfluence: { type: Number, default: 0 }, // връзки с охрана

  escapeAttempts: { type: Number, default: 0 },
  successfulEscape: { type: Boolean, default: false },

  lastTick: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("PrisonProfile", prisonSchema);