const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./prison.engine");

// GOD: view prison profile
router.get("/:playerId", godAccess, async (req, res) => {
  res.json(await engine.getPrisonProfile(req.params.playerId));
});

// GOD: apply sentence from court
router.post("/applySentence", godAccess, async (req, res) => {
  res.json(await engine.applySentenceFromCourt(req.body.playerId));
});

// GOD: prison tick
router.post("/tick", godAccess, async (req, res) => {
  res.json(await engine.prisonTick(req.body.playerId));
});

// GOD: attempt escape
router.post("/escape", godAccess, async (req, res) => {
  res.json(await engine.attemptEscape(req.body.playerId));
});

// GOD: release player
router.post("/release", godAccess, async (req, res) => {
  res.json(await engine.releasePlayer(req.body.playerId));
});

module.exports = router;