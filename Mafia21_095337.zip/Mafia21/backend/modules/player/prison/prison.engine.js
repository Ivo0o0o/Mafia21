const PrisonProfile = require("./prison.model");
const CourtCase = require("../justice/court.model");

// 1. Вземи или създай профил
async function getPrisonProfile(playerId) {
  let p = await PrisonProfile.findOne({ playerId });
  if (!p) p = await PrisonProfile.create({ playerId });
  return p;
}

// 2. Вкарване в затвора от съдебно дело
async function applySentenceFromCourt(playerId) {
  const p = await getPrisonProfile(playerId);
  const c = await CourtCase.findOne({ playerId, status: "verdict" });

  if (!c || c.verdict !== "guilty") {
    return { error: "No guilty verdict found" };
  }

  p.isInPrison = true;
  p.prisonYearsRemaining = c.sentence.prisonYears;
  p.lastTick = new Date();

  await p.save();
  return p;
}

// 3. Prison Tick – една „година“ в затвора
async function prisonTick(playerId) {
  const p = await getPrisonProfile(playerId);

  if (!p.isInPrison || p.prisonYearsRemaining <= 0) {
    return p;
  }

  p.prisonYearsRemaining = Math.max(0, p.prisonYearsRemaining - 1);

  // динамика вътре
  p.prisonReputation += Math.floor(Math.random() * 5); // малко уважение
  p.prisonViolence += Math.floor(Math.random() * 3);   // участие в конфликти
  p.corruptionInfluence += Math.floor(Math.random() * 2); // връзки

  if (p.prisonYearsRemaining === 0) {
    p.isInPrison = false;
  }

  p.lastTick = new Date();
  await p.save();
  return p;
}

// 4. Опит за бягство
async function attemptEscape(playerId) {
  const p = await getPrisonProfile(playerId);

  if (!p.isInPrison) return { error: "Player is not in prison" };

  p.escapeAttempts += 1;

  const baseChance = 0.1;
  const repBonus = p.prisonReputation * 0.002;
  const corrBonus = p.corruptionInfluence * 0.003;
  const violencePenalty = p.prisonViolence * 0.002;

  const chance = baseChance + repBonus + corrBonus - violencePenalty;

  if (Math.random() < chance) {
    p.successfulEscape = true;
    p.isInPrison = false;
    p.prisonYearsRemaining = 0;
  }

  await p.save();
  return p;
}

// 5. Освобождаване (ръчно)
async function releasePlayer(playerId) {
  const p = await getPrisonProfile(playerId);

  p.isInPrison = false;
  p.prisonYearsRemaining = 0;

  await p.save();
  return p;
}

module.exports = {
  getPrisonProfile,
  applySentenceFromCourt,
  prisonTick,
  attemptEscape,
  releasePlayer
};