const User = require("../player/player.model");
const Vehicle = require("../vehicles/Vehicle.model");
const District = require("../world/districts/District.model");

module.exports = {
  move: async (userId, fromDistrict, toDistrict) => {
    const user = await User.findById(userId);
    if (!user) {
      return { error: "Player not found" };
    }

    const vehicle = await Vehicle.findOne({ owner: userId });

    const from = await District.findOne({ name: fromDistrict });
    const to = await District.findOne({ name: toDistrict });

    if (!from || !to) {
      return { error: "Invalid district" };
    }

    // Distance logic
    const distance = Math.abs(to.position - from.position);

    // Speed logic
    const speed = vehicle ? vehicle.speed : 5; // пеша = 5 км/ч

    // Time needed (hours)
    const timeNeeded = distance / speed;

    // Update player
    user.location = toDistrict;
    user.travelTime = timeNeeded;
    user.isTraveling = true;

    await user.save();

    return {
      success: true,
      message: "Player moved",
      distance,
      speed,
      timeNeeded,
      newLocation: toDistrict
    };
  }
};