const express = require("express");
const router = express.Router();

const engine = require("./movement.engine");
const auth = require("../core/auth"); // FIXED PATH

router.post("/move", auth, async (req, res) => {
  try {
    const { userId, fromDistrict, toDistrict } = req.body;

    if (!userId || !fromDistrict || !toDistrict) {
      return res.status(400).json({
        success: false,
        error: "Missing parameters"
      });
    }

    const result = await engine.move(userId, fromDistrict, toDistrict);

    res.json(result);

  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
});

module.exports = router;