const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const engine = require("./skills.engine");

// Всички тези са само за GOD панела
router.post("/add", godAccess, async (req, res) => {
  try {
    const { userId, skill, amount } = req.body;
    const user = await engine.addSkill(userId, skill, Number(amount));
    res.json(user);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.post("/set", godAccess, async (req, res) => {
  try {
    const { userId, skill, value } = req.body;
    const user = await engine.setSkill(userId, skill, Number(value));
    res.json(user);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;