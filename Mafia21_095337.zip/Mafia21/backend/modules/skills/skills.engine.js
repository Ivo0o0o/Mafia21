const User = require("../users/user.model");

const SKILL_MAX = 100;

async function addSkill(userId, skillName, amount) {
  const user = await User.findById(userId);
  if (!user) throw new Error("User not found");

  if (!user.skills[skillName] && user.skills[skillName] !== 0) {
    throw new Error("Invalid skill name");
  }

  user.skills[skillName] += amount;

  if (user.skills[skillName] < 0) user.skills[skillName] = 0;
  if (user.skills[skillName] > SKILL_MAX) user.skills[skillName] = SKILL_MAX;

  await user.save();
  return user;
}

async function setSkill(userId, skillName, value) {
  const user = await User.findById(userId);
  if (!user) throw new Error("User not found");

  if (!user.skills[skillName] && user.skills[skillName] !== 0) {
    throw new Error("Invalid skill name");
  }

  user.skills[skillName] = Math.max(0, Math.min(SKILL_MAX, value));
  await user.save();
  return user;
}

module.exports = {
  addSkill,
  setSkill
};