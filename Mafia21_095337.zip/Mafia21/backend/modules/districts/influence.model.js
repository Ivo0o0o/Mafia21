const mongoose = require("mongoose");

const influenceSchema = new mongoose.Schema({

  // Кой играч има влияние
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },

  // В кой район
  districtName: { type: String, required: true },

  // Колко влияние има (0–100)
  amount: { type: Number, default: 0 },

  // Причина за последната промяна (логове)
  lastAction: { type: String, default: "" }

}, { timestamps: true });

module.exports = mongoose.model("Influence", influenceSchema);