const Influence = require("./Influence.model");
const InfluenceService = require("./Influence.service");
const DistrictService = require("./district.service");
const User = require("../users/user.model");

/**
 * Връща състоянието на район:
 * - всички играчи с влияние
 * - общо влияние
 * - топ играч
 */
async function getDistrictState(districtName) {
  const influences = await Influence.find({ districtName }).populate("userId");

  if (!influences || influences.length === 0) {
    return {
      district: districtName,
      totalInfluence: 0,
      players: [],
      topPlayer: null
    };
  }

  const totalInfluence = influences.reduce((sum, inf) => sum + inf.amount, 0);

  const sorted = [...influences].sort((a, b) => b.amount - a.amount);
  const top = sorted[0];

  return {
    district: districtName,
    totalInfluence,
    players: influences,
    topPlayer: top
  };
}

/**
 * Прилага ефект от мисия върху влиянието на играч
 * Мисията влияе само на amount (0–100)
 */
async function applyMissionEffect(districtName, mission, userId) {
  let delta = 0;

  // Трудност
  if (mission.difficulty === "hard") delta += 15;
  if (mission.difficulty === "medium") delta += 8;
  if (mission.difficulty === "easy") delta += 3;

  // Награда
  if (mission.reward) delta += mission.reward / 50;

  // XP награда
  if (mission.rewardXP) delta += mission.rewardXP / 100;

  // Риск
  if (mission.risk >= 50) delta -= 5;

  // Приложи промяната
  const updated = await InfluenceService.addInfluence(
    userId,
    districtName,
    delta
  );

  // Обнови общото влияние в District
  await DistrictService.applyPlayerInfluence(districtName);

  return {
    ok: true,
    district: districtName,
    userId,
    delta,
    newAmount: updated.amount
  };
}

module.exports = {
  getDistrictState,
  applyMissionEffect
};