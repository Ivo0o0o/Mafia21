const mongoose = require("mongoose");

const districtSchema = new mongoose.Schema({

  // Основна информация
  name: { type: String, required: true, unique: true },
  description: { type: String, default: "" },

  // Икономика
  baseIncome: { type: Number, default: 100 },

  // Влияние от играчи (0–100)
  playerInfluence: { type: Number, default: 0 },

  // Влияние от NPC (0–100)
  npcInfluence: { type: Number, default: 0 },

  // Престъпност (0–1)
  crimeRate: { type: Number, default: 0 },

  // Heat (полицейско внимание) 0–100
  heat: { type: Number, default: 0 },

  // Контрол от играч
  ownerPlayer: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },

  // Контрол от NPC
  ownerNPC: { type: mongoose.Schema.Types.ObjectId, ref: "NPC", default: null },

  // География (ако решиш да правиш карта)
  coordinates: {
    x: { type: Number, default: 0 },
    y: { type: Number, default: 0 }
  },

  active: { type: Boolean, default: true }

}, { timestamps: true });

module.exports = mongoose.model("District", districtSchema);