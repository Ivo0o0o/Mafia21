const Influence = require("./Influence.model");

module.exports = {

  // ======================================================
  // GET influence of a player in a district
  // ======================================================
  async getInfluence(userId, districtName) {
    return Influence.findOne({ userId, districtName });
  },

  // ======================================================
  // GET all influence entries for a player
  // ======================================================
  async getInfluenceByUser(userId) {
    return Influence.find({ userId });
  },

  // ======================================================
  // GET all influence entries in a district
  // ======================================================
  async getInfluenceByDistrict(districtName) {
    return Influence.find({ districtName });
  },

  // ======================================================
  // SET influence (absolute value)
  // ======================================================
  async setInfluence(userId, districtName, amount, lastAction = "") {
    if (amount < 0) amount = 0;
    if (amount > 100) amount = 100;

    const influence = await Influence.findOneAndUpdate(
      { userId, districtName },
      {
        amount,
        lastAction
      },
      { new: true, upsert: true }
    );

    return influence;
  },

  // ======================================================
  // ADD influence (delta)
  // ======================================================
  async addInfluence(userId, districtName, delta, lastAction = "") {
    let existing = await Influence.findOne({ userId, districtName });

    let newAmount = delta;
    if (existing) {
      newAmount = existing.amount + delta;
    }

    if (newAmount < 0) newAmount = 0;
    if (newAmount > 100) newAmount = 100;

    const influence = await Influence.findOneAndUpdate(
      { userId, districtName },
      {
        amount: newAmount,
        lastAction
      },
      { new: true, upsert: true }
    );

    return influence;
  },

  // ======================================================
  // RESET influence (0)
  // ======================================================
  async resetInfluence(userId, districtName) {
    return Influence.findOneAndUpdate(
      { userId, districtName },
      {
        amount: 0,
        lastAction: "reset"
      },
      { new: true }
    );
  },

  // ======================================================
  // DELETE influence entry
  // ======================================================
  async deleteInfluence(userId, districtName) {
    return Influence.deleteOne({ userId, districtName });
  },

  // ======================================================
  // LIST influence entries (admin/debug)
  // ======================================================
  async listInfluence(filters = {}) {
    const query = {};

    if (filters.userId) query.userId = filters.userId;
    if (filters.districtName) query.districtName = filters.districtName;

    return Influence.find(query);
  }
};