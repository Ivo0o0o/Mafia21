const InfluenceEngine = require("./influence.engine");

module.exports = {

  // ======================================================
  // GET: състояние на район (влияние на играчи)
  // ======================================================
  async getState(req, res) {
    try {
      const district = req.params.district;
      const state = await InfluenceEngine.getDistrictState(district);

      res.json({
        ok: true,
        district,
        state
      });
    } catch (err) {
      console.error("Influence GET error:", err);
      res.status(500).json({
        ok: false,
        error: "Failed to fetch district influence state"
      });
    }
  },

  // ======================================================
  // POST: приложи ефект от мисия върху влияние
  // ======================================================
  async applyMission(req, res) {
    try {
      const { district, mission, userId } = req.body;

      if (!district || !mission || !userId) {
        return res.status(400).json({
          ok: false,
          error: "Missing required fields: district, mission, userId"
        });
      }

      const result = await InfluenceEngine.applyMissionEffect(
        district,
        mission,
        userId
      );

      res.json({
        ok: true,
        district,
        mission,
        userId,
        result
      });
    } catch (err) {
      console.error("Influence APPLY error:", err);
      res.status(500).json({
        ok: false,
        error: "Failed to apply mission influence effect"
      });
    }
  }
};