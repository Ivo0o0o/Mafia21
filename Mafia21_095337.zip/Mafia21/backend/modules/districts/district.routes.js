const router = require("express").Router();
const DistrictController = require("./district.controller");

// GET all districts
router.get("/", DistrictController.getAll);

// GET single district by ID
router.get("/:id", DistrictController.get);

// NPC influence + crime tick
router.post("/tick/:name", DistrictController.tick);

module.exports = router;