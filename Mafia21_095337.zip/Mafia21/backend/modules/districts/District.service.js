const District = require("./district.model");
const NPC = require("../npc/npc.model");
const Influence = require("./Influence.model");

module.exports = {

  // ======================================================
  // GET ALL DISTRICTS
  // ======================================================
  async getAll() {
    return District.find({ active: true })
      .populate("ownerPlayer ownerNPC");
  },

  // ======================================================
  // GET DISTRICT BY ID
  // ======================================================
  async getById(id) {
    return District.findById(id)
      .populate("ownerPlayer ownerNPC");
  },

  // ======================================================
  // GET DISTRICT BY NAME
  // ======================================================
  async getByName(name) {
    return District.findOne({ name })
      .populate("ownerPlayer ownerNPC");
  },

  // ======================================================
  // APPLY PLAYER INFLUENCE
  // ======================================================
  async applyPlayerInfluence(districtName) {
    const district = await District.findOne({ name: districtName });
    if (!district) return null;

    const influences = await Influence.find({ districtName });

    let total = 0;
    for (const inf of influences) {
      total += inf.amount;
    }

    district.playerInfluence = Math.min(100, total);
    await district.save();

    return district;
  },

  // ======================================================
  // APPLY NPC INFLUENCE
  // ======================================================
  async applyNPCInfluence(districtName) {
    const district = await District.findOne({ name: districtName });
    if (!district) return null;

    const npcs = await NPC.find({ district: districtName });

    let total = 0;
    for (const npc of npcs) {
      total += npc.influence || 0;
    }

    district.npcInfluence = Math.min(100, total);
    await district.save();

    return district;
  },

  // ======================================================
  // CRIME + HEAT TICK
  // ======================================================
  async npcInfluenceTick(districtName) {
    const district = await District.findOne({ name: districtName });
    if (!district) return null;

    const npcs = await NPC.find({ district: districtName });

    let aggression = 0;
    for (const npc of npcs) {
      aggression += npc.aggression || 0;
    }

    // Crime rises from NPC aggression
    district.crimeRate = Math.min(1, district.crimeRate + aggression * 0.02);

    // Heat rises from crime
    district.heat = Math.min(100, district.heat + district.crimeRate * 2);

    await district.save();
    return district;
  }
};