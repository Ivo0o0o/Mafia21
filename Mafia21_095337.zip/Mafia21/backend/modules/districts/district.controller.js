const DistrictService = require("./district.service");

module.exports = {

  // ======================================================
  // GET ALL DISTRICTS
  // ======================================================
  async getAll(req, res) {
    try {
      const districts = await DistrictService.getAll();
      res.json({ success: true, districts });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // GET ONE DISTRICT
  // ======================================================
  async get(req, res) {
    try {
      const district = await DistrictService.getById(req.params.id);
      if (!district) return res.status(404).json({ error: "District not found" });
      res.json({ success: true, district });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // NPC INFLUENCE TICK
  // ======================================================
  async tick(req, res) {
    try {
      const district = await DistrictService.npcInfluenceTick(req.params.name);
      res.json({ success: true, district });
    } catch (err) {
      if (err.type === "NOT_FOUND") return res.status(404).json({ error: err.message });
      res.status(500).json({ error: err.message });
    }
  }
};