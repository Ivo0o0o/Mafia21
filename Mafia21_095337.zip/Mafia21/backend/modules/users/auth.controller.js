// backend/modules/user/auth.controller.js

const User = require('./user.model');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { jwtSecret } = require('../../core/config');

// =====================================================
// REGISTER (username + password)
// =====================================================
module.exports.register = async (req, res) => {
  try {
    const { username, password } = req.body;

    // Проверка дали потребителят съществува
    const exists = await User.findOne({ username });
    if (exists) {
      return res.status(400).json({ error: "Потребителят вече съществува" });
    }

    // Хеширане на паролата
    const passwordHash = await bcrypt.hash(password, 10);

    // Създаване на нов потребител
    const user = await User.create({
      username,
      passwordHash,
      role: "player",
      permissions: []
    });

    res.json({
      message: "Регистрация успешна",
      user: {
        id: user._id,
        username: user.username,
        role: user.role
      }
    });

  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// =====================================================
// LOGIN (username + password)
// =====================================================
module.exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;

    // Търсим по username
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(400).json({ error: "Невалиден потребител" });
    }

    // Проверка на паролата
    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) {
      return res.status(400).json({ error: "Грешна парола" });
    }

    // Генериране на JWT токен
    const token = jwt.sign(
      { id: user._id, role: user.role },
      jwtSecret,
      { expiresIn: "7d" }
    );

    res.json({
      message: "Успешен вход",
      token,
      user: {
        id: user._id,
        username: user.username,
        role: user.role,
        permissions: user.permissions
      }
    });

  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};