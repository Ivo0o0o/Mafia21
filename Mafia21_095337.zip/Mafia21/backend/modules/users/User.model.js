const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({

  // Основни данни
  username: { type: String, required: true, unique: true },
  passwordHash: { type: String, required: true },

  // Роли
  role: {
    type: String,
    enum: ['player', 'moderator', 'admin', 'god'],
    default: 'player'
  },

  // Permissions за admin/god
  permissions: {
    type: Array,
    default: []
  },

  // Икономика
  money: { type: Number, default: 0 },
  reputation: { type: Number, default: 0 },

  // Локация
  district: { type: String, default: 'Младост' },

  // Умения (skills)
  skills: {
    shooting:      { type: Number, default: 0 },
    hacking:       { type: Number, default: 0 },
    negotiation:   { type: Number, default: 0 },
    intimidation:  { type: Number, default: 0 },
    deception:     { type: Number, default: 0 },
    driving:       { type: Number, default: 0 }
  },

  // Crime системи
  crimeCooldown: { type: Number, default: 0 },
  missionCooldown: { type: Number, default: 0 },
  battleCooldown: { type: Number, default: 0 },
  jailUntil: { type: Number, default: 0 },

  // XP и Level
  xp: { type: Number, default: 0 },
  level: { type: Number, default: 1 },
  points: { type: Number, default: 0 },

  // Combat stats
  damage: { type: Number, default: 10 },
  defense: { type: Number, default: 5 },

  // Inventory за loot
  inventory: {
    type: Array,
    default: []
  },

  // VIP системи
  vipLevel: { type: Number, default: 0 },
  vipExpires: { type: Number, default: 0 }

}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);