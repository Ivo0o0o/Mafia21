// backend/modules/user/user.routes.js

const express = require('express');
const router = express.Router();

const userController = require('./user.controller');
const authController = require('./auth.controller');

const { protect } = require('../../core/middleware/auth');

// ============================
// AUTH ROUTES
// ============================
router.post('/register', authController.register);
router.post('/login', authController.login);

// ============================
// USER PROFILE (requires auth)
// ============================
router.get('/profile', protect, userController.getProfile);

// ============================
// UPDATE SKILLS (requires auth)
// ============================
router.post('/skills/update', protect, userController.updateSkills);

// ============================
// SET ROLE (requires auth)
// ============================
router.post('/role/set', protect, userController.setRole);

// ============================
// ADD PERMISSION (requires auth)
// ============================
router.post('/permissions/add', protect, userController.addPermission);

// ============================
// REMOVE PERMISSION (requires auth)
// ============================
router.post('/permissions/remove', protect, userController.removePermission);

module.exports = router;