// backend/modules/user/user.controller.js

const User = require('./user.model');   // FIXED: правилен импорт
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { jwtSecret } = require('../../core/config');

// =====================================================
// CREATE USER (старият ти код)
// =====================================================
module.exports.createUser = async (req, res) => {
  try {
    const user = await User.create(req.body);
    res.json(user);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// =====================================================
// REGISTER
// =====================================================
module.exports.register = async (req, res) => {
  try {
    const { username, password } = req.body;

    const exists = await User.findOne({ username });
    if (exists) return res.status(400).json({ error: 'Потребителят вече съществува' });

    const passwordHash = await bcrypt.hash(password, 10);

    const user = await User.create({
      username,
      passwordHash,

      // Gameplay stats
      level: 1,
      xp: 0,
      money: 0,
      reputation: 0,

      damage: 10,
      defense: 5,

      district: "Младост",

      inventory: [],

      // Cooldowns
      crimeCooldown: 0,
      missionCooldown: 0,
      battleCooldown: 0,

      // VIP system
      vipLevel: 0,
      vipExpires: 0,

      // Skills
      skills: {
        shooting: 0,
        hacking: 0,
        negotiation: 0,
        intimidation: 0,
        deception: 0,
        driving: 0
      },

      // Role system
      role: "player",
      permissions: []
    });

    res.json({
      message: 'Регистрация успешна',
      user: {
        id: user._id,
        username: user.username,
        level: user.level,
        damage: user.damage,
        defense: user.defense
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// =====================================================
// LOGIN
// =====================================================
module.exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;

    const user = await User.findOne({ username });
    if (!user) return res.status(400).json({ error: 'Невалиден потребител' });

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) return res.status(400).json({ error: 'Грешна парола' });

    const token = jwt.sign(
      { id: user._id, role: user.role },
      jwtSecret,
      { expiresIn: '7d' }
    );

    res.json({
      message: 'Успешен вход',
      token,
      user: {
        id: user._id,
        username: user.username,
        level: user.level,
        xp: user.xp,
        money: user.money,
        damage: user.damage,
        defense: user.defense,
        inventory: user.inventory,
        vipLevel: user.vipLevel,
        vipExpires: user.vipExpires,
        skills: user.skills,
        role: user.role,
        permissions: user.permissions
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// =====================================================
// GET PROFILE
// =====================================================
module.exports.getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ error: "User not found" });

    res.json({
      id: user._id,
      username: user.username,
      level: user.level,
      xp: user.xp,
      money: user.money,
      reputation: user.reputation,
      district: user.district,
      inventory: user.inventory,
      skills: user.skills,
      role: user.role,
      permissions: user.permissions,
      vipLevel: user.vipLevel,
      vipExpires: user.vipExpires,
      cooldowns: {
        crime: user.crimeCooldown,
        mission: user.missionCooldown,
        battle: user.battleCooldown
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// =====================================================
// UPDATE SKILLS
// =====================================================
module.exports.updateSkills = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ error: "User not found" });

    const { skills } = req.body;

    user.skills = {
      ...user.skills,
      ...skills
    };

    await user.save();

    res.json({ message: "Skills updated", skills: user.skills });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// =====================================================
// SET ROLE
// =====================================================
module.exports.setRole = async (req, res) => {
  try {
    const { userId, role } = req.body;

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ error: "User not found" });

    user.role = role;
    await user.save();

    res.json({ message: "Role updated", role });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// =====================================================
// ADD PERMISSION
// =====================================================
module.exports.addPermission = async (req, res) => {
  try {
    const { userId, permission } = req.body;

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ error: "User not found" });

    if (!user.permissions.includes(permission)) {
      user.permissions.push(permission);
    }

    await user.save();

    res.json({ message: "Permission added", permissions: user.permissions });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// =====================================================
// REMOVE PERMISSION
// =====================================================
module.exports.removePermission = async (req, res) => {
  try {
    const { userId, permission } = req.body;

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ error: "User not found" });

    user.permissions = user.permissions.filter(p => p !== permission);
    await user.save();

    res.json({ message: "Permission removed", permissions: user.permissions });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};