const tickEngine = require('./tickEngine');

module.exports = {
  runTick: async (req, res) => {
    try {
      const results = await tickEngine.runGameTick();
      res.json({
        message: 'Game tick executed',
        results
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};