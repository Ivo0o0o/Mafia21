const express = require('express');
const router = express.Router();
const controller = require('./tick.controller');
const auth = require('../../core/auth');

// Само админ може да пуска тик
router.post('/run', auth, controller.runTick);

module.exports = router;