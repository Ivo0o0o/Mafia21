const { runIncomeTick } = require('../economy/autoIncome.service');
const { runBusinessTick } = require('../businesses/businessEngine');
const { runEventTick } = require('../events/eventEngine');
const NPC = require('../npc/NPC.model');
const npcEngine = require('../npc/npcEngine');
const User = require('../users/User.model');

module.exports = {
  runGameTick: async () => {
    const results = {
      income: [],
      business: [],
      events: [],
      npc: []
    };

    // 1. Автоматични приходи от райони
    try {
      results.income = await runIncomeTick();
    } catch (err) {
      results.incomeError = err.message;
    }

    // 2. Автоматични приходи от бизнеси
    try {
      results.business = await runBusinessTick();
    } catch (err) {
      results.businessError = err.message;
    }

    // 3. Глобални събития
    try {
      results.events = await runEventTick();
    } catch (err) {
      results.eventsError = err.message;
    }

    // 4. NPC действия
    try {
      const npcs = await NPC.find({});
      const players = await User.find({});

      for (const npc of npcs) {
        // NPC влияе на района
        await npcEngine.applyInfluence(npc);

        // NPC може да атакува играчи
        for (const player of players) {
          const attack = await npcEngine.tryAttackPlayer(npc, player);
          if (attack.attacked) {
            results.npc.push({
              npc: npc.name,
              district: npc.district,
              player: player.username,
              penalty: attack.penalty
            });
          }
        }
      }
    } catch (err) {
      results.npcError = err.message;
    }

    return results;
  }
};