const Item = require('./item.model');

// Rarity multipliers
const RARITY_MULTIPLIER = {
  common: 1,
  uncommon: 1.2,
  rare: 1.5,
  epic: 2,
  legendary: 3
};

// Base loot tables
const LOOT_TABLE = {
  npc: {
    common: 70,
    uncommon: 20,
    rare: 7,
    epic: 2,
    legendary: 1
  },
  world: {
    common: 60,
    uncommon: 25,
    rare: 10,
    epic: 4,
    legendary: 1
  }
};

module.exports = {

  // ======================================================
  // CREATE ITEM
  // ======================================================
  async create(data) {
    return await Item.create(data);
  },

  // ======================================================
  // GET ITEM BY ID
  // ======================================================
  async get(id) {
    return await Item.findById(id);
  },

  // ======================================================
  // LIST ALL ITEMS
  // ======================================================
  async list() {
    return await Item.find().sort({ createdAt: -1 });
  },

  // ======================================================
  // UPDATE ITEM
  // ======================================================
  async update(id, data) {
    return await Item.findByIdAndUpdate(id, data, { new: true });
  },

  // ======================================================
  // DELETE ITEM
  // ======================================================
  async remove(id) {
    return await Item.findByIdAndDelete(id);
  },

  // ======================================================
  // SEARCH ITEMS
  // ======================================================
  async search(query) {
    const mongoQuery = {};

    if (query.name) {
      mongoQuery.name = { $regex: query.name, $options: 'i' };
    }

    if (query.type) {
      mongoQuery.type = query.type;
    }

    if (query.rarity) {
      mongoQuery.rarity = query.rarity;
    }

    return await Item.find(mongoQuery);
  },

  // ======================================================
  // AUTO VALUE ENGINE (based on rarity, stats, durability)
  // ======================================================
  calculateValue(item) {
    const rarityMultiplier = RARITY_MULTIPLIER[item.rarity] || 1;

    const statValue =
      (item.stats.damage || 0) * 2 +
      (item.stats.defense || 0) * 1.5;

    const durabilityFactor = item.durability / 100;

    const finalValue = Math.floor((statValue * rarityMultiplier) * durabilityFactor);

    return finalValue;
  },

  // ======================================================
  // DURABILITY DECAY (use, combat, crafting)
  // ======================================================
  applyDurability(item, amount) {
    item.durability -= amount;
    if (item.durability < 0) item.durability = 0;
    return item.save();
  },

  // ======================================================
  // REPAIR ITEM
  // ======================================================
  async repair(id, amount = 20) {
    const item = await Item.findById(id);
    if (!item) return null;

    item.durability += amount;
    if (item.durability > 100) item.durability = 100;

    return await item.save();
  },

  // ======================================================
  // UPGRADE ITEM (quality + rarity chance)
  // ======================================================
  async upgrade(id) {
    const item = await Item.findById(id);
    if (!item) return null;

    item.quality += 10;
    if (item.quality > 100) item.quality = 100;

    // Chance to increase rarity
    const roll = Math.random() * 100;

    if (roll < 5 && item.rarity === 'common') item.rarity = 'uncommon';
    else if (roll < 4 && item.rarity === 'uncommon') item.rarity = 'rare';
    else if (roll < 3 && item.rarity === 'rare') item.rarity = 'epic';
    else if (roll < 2 && item.rarity === 'epic') item.rarity = 'legendary';

    return await item.save();
  },

  // ======================================================
  // CLONE ITEM (for loot, crafting, NPC inventory)
  // ======================================================
  clone(item) {
    const cloneData = item.toObject();
    delete cloneData._id;
    return Item.create(cloneData);
  },

  // ======================================================
  // NPC LOOT GENERATOR
  // ======================================================
  async generateNpcLoot() {
    const roll = Math.random() * 100;

    let rarity = 'common';
    if (roll < LOOT_TABLE.npc.legendary) rarity = 'legendary';
    else if (roll < LOOT_TABLE.npc.epic) rarity = 'epic';
    else if (roll < LOOT_TABLE.npc.rare) rarity = 'rare';
    else if (roll < LOOT_TABLE.npc.uncommon) rarity = 'uncommon';

    const items = await Item.find({ rarity }).limit(10);
    if (items.length === 0) return null;

    const randomItem = items[Math.floor(Math.random() * items.length)];
    return this.clone(randomItem);
  },

  // ======================================================
  // WORLD LOOT GENERATOR
  // ======================================================
  async generateWorldLoot() {
    const roll = Math.random() * 100;

    let rarity = 'common';
    if (roll < LOOT_TABLE.world.legendary) rarity = 'legendary';
    else if (roll < LOOT_TABLE.world.epic) rarity = 'epic';
    else if (roll < LOOT_TABLE.world.rare) rarity = 'rare';
    else if (roll < LOOT_TABLE.world.uncommon) rarity = 'uncommon';

    const items = await Item.find({ rarity }).limit(10);
    if (items.length === 0) return null;

    const randomItem = items[Math.floor(Math.random() * items.length)];
    return this.clone(randomItem);
  },

  // ======================================================
  // ILLEGAL ITEM HEAT ENGINE
  // ======================================================
  calculateHeat(item) {
    if (!item.metadata || !item.metadata.illegal) return 0;

    const baseHeat = item.metadata.heat || 5;
    const rarityBonus = RARITY_MULTIPLIER[item.rarity] * 2;

    return baseHeat + rarityBonus;
  },

  // ======================================================
  // STACKABLE LOGIC
  // ======================================================
  canStack(itemA, itemB) {
    return (
      itemA.stackable &&
      itemB.stackable &&
      itemA.name === itemB.name &&
      itemA.rarity === itemB.rarity
    );
  }
};