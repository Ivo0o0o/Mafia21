const mongoose = require('mongoose');

const itemSchema = new mongoose.Schema({

  // Основни данни
  name: { type: String, required: true },
  type: { type: String, required: true }, 
  // weapon, armor, drug, resource, tool, key, material, consumable

  // Икономика
  price: { type: Number, default: 0 },
  value: { type: Number, default: 0 }, // вътрешна стойност (за NPC/Org economy)

  // Качество и състояние
  rarity: { 
    type: String, 
    enum: ['common', 'uncommon', 'rare', 'epic', 'legendary'], 
    default: 'common' 
  },
  quality: { type: Number, default: 100 },     // 0–100
  durability: { type: Number, default: 100 },  // 0–100

  // Тегло и стакване
  weight: { type: Number, default: 1 },
  stackable: { type: Boolean, default: true },
  maxStack: { type: Number, default: 99 },

  // Статистики (за оръжия, броня, предмети)
  stats: {
    damage: { type: Number, default: 0 },
    defense: { type: Number, default: 0 },
    effect: { type: String, default: '' } // пример: "+10% exp за 10 мин"
  },

  // Ефекти (за наркотици, стимуланти, устройства)
  effects: {
    type: Object,
    default: {} 
    // пример: { heal: 20, stamina: +5, stealth: +10 }
  },

  // Допълнителни данни (за мисии, crafting, NPC AI)
  metadata: {
    type: Object,
    default: {}
    // пример: { craftingLevel: 3, illegal: true, heat: 5 }
  }

}, { timestamps: true });

module.exports = mongoose.model('Item', itemSchema);