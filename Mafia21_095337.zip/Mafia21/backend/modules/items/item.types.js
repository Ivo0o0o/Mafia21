module.exports = {

  // ======================================================
  // WEAPONS
  // ======================================================
  weapons: [
    {
      name: "Pistol",
      type: "weapon",
      rarity: "common",
      stats: { damage: 15, defense: 0 },
      weight: 2,
      price: 500
    },
    {
      name: "SMG",
      type: "weapon",
      rarity: "uncommon",
      stats: { damage: 25, defense: 0 },
      weight: 3,
      price: 1200
    },
    {
      name: "Assault Rifle",
      type: "weapon",
      rarity: "rare",
      stats: { damage: 40, defense: 0 },
      weight: 4,
      price: 2500
    },
    {
      name: "Sniper Rifle",
      type: "weapon",
      rarity: "epic",
      stats: { damage: 80, defense: 0 },
      weight: 6,
      price: 5000
    },
    {
      name: "Golden Desert Eagle",
      type: "weapon",
      rarity: "legendary",
      stats: { damage: 100, defense: 0 },
      weight: 5,
      price: 15000
    }
  ],

  // ======================================================
  // ARMOR
  // ======================================================
  armor: [
    {
      name: "Kevlar Vest",
      type: "armor",
      rarity: "common",
      stats: { damage: 0, defense: 20 },
      weight: 4,
      price: 800
    },
    {
      name: "Reinforced Kevlar",
      type: "armor",
      rarity: "rare",
      stats: { damage: 0, defense: 40 },
      weight: 5,
      price: 2000
    },
    {
      name: "Titanium Armor",
      type: "armor",
      rarity: "epic",
      stats: { damage: 0, defense: 70 },
      weight: 7,
      price: 5000
    }
  ],

  // ======================================================
  // DRUGS
  // ======================================================
  drugs: [
    {
      name: "Weed",
      type: "drug",
      rarity: "common",
      effects: { stamina: +5 },
      metadata: { illegal: true, heat: 3 },
      weight: 1,
      price: 50
    },
    {
      name: "Cocaine",
      type: "drug",
      rarity: "rare",
      effects: { stamina: +20, speed: +10 },
      metadata: { illegal: true, heat: 10 },
      weight: 1,
      price: 300
    },
    {
      name: "Meth",
      type: "drug",
      rarity: "epic",
      effects: { stamina: +40, speed: +20 },
      metadata: { illegal: true, heat: 15 },
      weight: 1,
      price: 600
    }
  ],

  // ======================================================
  // MATERIALS
  // ======================================================
  materials: [
    { name: "Metal", type: "material", rarity: "common", weight: 2, price: 20 },
    { name: "Electronics", type: "material", rarity: "uncommon", weight: 1, price: 50 },
    { name: "Chemicals", type: "material", rarity: "rare", weight: 1, price: 80 },
    { name: "Plastics", type: "material", rarity: "common", weight: 1, price: 10 },
    { name: "Rare Components", type: "material", rarity: "epic", weight: 1, price: 200 }
  ],

  // ======================================================
  // TOOLS
  // ======================================================
  tools: [
    {
      name: "Lockpick",
      type: "tool",
      rarity: "common",
      effects: { unlock: 10 },
      weight: 1,
      price: 100
    },
    {
      name: "Hacking Device",
      type: "tool",
      rarity: "rare",
      effects: { hack: 25 },
      weight: 2,
      price: 1500
    },
    {
      name: "Signal Jammer",
      type: "tool",
      rarity: "epic",
      effects: { jam: 40 },
      weight: 3,
      price: 3000
    }
  ],

  // ======================================================
  // CONSUMABLES
  // ======================================================
  consumables: [
    {
      name: "Medkit",
      type: "consumable",
      rarity: "common",
      effects: { heal: 50 },
      weight: 1,
      price: 150
    },
    {
      name: "Energy Drink",
      type: "consumable",
      rarity: "common",
      effects: { stamina: +10 },
      weight: 1,
      price: 20
    },
    {
      name: "Combat Stimulant",
      type: "consumable",
      rarity: "rare",
      effects: { damage: +10, speed: +10 },
      weight: 1,
      price: 300
    }
  ],

  // ======================================================
  // SPECIAL ITEMS
  // ======================================================
  special: [
    {
      name: "VIP Token",
      type: "special",
      rarity: "legendary",
      effects: { vip: true },
      weight: 0,
      price: 0
    },
    {
      name: "Clan Artifact",
      type: "special",
      rarity: "epic",
      metadata: { clanPower: 50 },
      weight: 2,
      price: 5000
    }
  ]
};