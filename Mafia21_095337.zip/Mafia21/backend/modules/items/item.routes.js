const router = require('express').Router();
const ItemController = require('./item.controller');

// CRUD
router.post('/create', ItemController.create);
router.get('/get/:id', ItemController.get);
router.get('/list', ItemController.list);
router.post('/update/:id', ItemController.update);
router.post('/delete/:id', ItemController.delete);

// Search
router.get('/search', ItemController.search);

// Item mechanics
router.post('/repair/:id', ItemController.repair);
router.post('/upgrade/:id', ItemController.upgrade);

// Loot generators
router.get('/loot/npc', ItemController.generateNpcLoot);
router.get('/loot/world', ItemController.generateWorldLoot);

// Value & heat
router.get('/value/:id', ItemController.calculateValue);
router.get('/heat/:id', ItemController.calculateHeat);

// Stack check
router.post('/stack', ItemController.canStack);

module.exports = router;