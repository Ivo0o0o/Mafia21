const ItemService = require('./item.service');

module.exports = {

  // ======================================================
  // CREATE ITEM
  // ======================================================
  async create(req, res) {
    try {
      const item = await ItemService.create(req.body);
      res.json({ success: true, item });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // GET ITEM
  // ======================================================
  async get(req, res) {
    try {
      const item = await ItemService.get(req.params.id);
      if (!item) return res.status(404).json({ error: "Item not found" });

      res.json({ success: true, item });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // LIST ITEMS
  // ======================================================
  async list(req, res) {
    try {
      const items = await ItemService.list();
      res.json({ success: true, items });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // UPDATE ITEM
  // ======================================================
  async update(req, res) {
    try {
      const item = await ItemService.update(req.params.id, req.body);
      res.json({ success: true, item });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // DELETE ITEM
  // ======================================================
  async delete(req, res) {
    try {
      const item = await ItemService.remove(req.params.id);
      res.json({ success: true, item });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // SEARCH ITEMS
  // ======================================================
  async search(req, res) {
    try {
      const items = await ItemService.search(req.query);
      res.json({ success: true, items });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // REPAIR ITEM
  // ======================================================
  async repair(req, res) {
    try {
      const item = await ItemService.repair(req.params.id);
      res.json({ success: true, item });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // UPGRADE ITEM
  // ======================================================
  async upgrade(req, res) {
    try {
      const item = await ItemService.upgrade(req.params.id);
      res.json({ success: true, item });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // NPC LOOT
  // ======================================================
  async generateNpcLoot(req, res) {
    try {
      const item = await ItemService.generateNpcLoot();
      res.json({ success: true, item });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // WORLD LOOT
  // ======================================================
  async generateWorldLoot(req, res) {
    try {
      const item = await ItemService.generateWorldLoot();
      res.json({ success: true, item });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // VALUE ENGINE
  // ======================================================
  async calculateValue(req, res) {
    try {
      const item = await ItemService.get(req.params.id);
      if (!item) return res.status(404).json({ error: "Item not found" });

      const value = ItemService.calculateValue(item);
      res.json({ success: true, value });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // HEAT ENGINE
  // ======================================================
  async calculateHeat(req, res) {
    try {
      const item = await ItemService.get(req.params.id);
      if (!item) return res.status(404).json({ error: "Item not found" });

      const heat = ItemService.calculateHeat(item);
      res.json({ success: true, heat });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // STACK CHECK
  // ======================================================
  async canStack(req, res) {
    try {
      const { itemA, itemB } = req.body;

      const a = await ItemService.get(itemA);
      const b = await ItemService.get(itemB);

      if (!a || !b) {
        return res.status(404).json({ error: "One or both items not found" });
      }

      const canStack = ItemService.canStack(a, b);

      res.json({ success: true, canStack });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};