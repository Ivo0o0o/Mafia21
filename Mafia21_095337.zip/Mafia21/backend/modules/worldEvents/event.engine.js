const WorldEvent = require("./event.model");
const Influence = require("../districts/influence.model");

async function triggerEvent(eventData) {
  const event = await WorldEvent.create(eventData);

  // Влияние върху района
  let inf = await Influence.findOne({ district: event.district });
  if (!inf) inf = await Influence.create({ district: event.district });

  inf.crimeLevel += event.impact.crime;
  inf.clanInfluence += event.impact.clanInfluence;
  inf.npcAggression += event.impact.npcAggression;
  inf.npcFear += event.impact.npcFear;

  // Ограничения
  inf.crimeLevel = Math.min(100, Math.max(0, inf.crimeLevel));
  inf.clanInfluence = Math.min(100, Math.max(0, inf.clanInfluence));
  inf.npcAggression = Math.min(100, Math.max(0, inf.npcAggression));
  inf.npcFear = Math.min(100, Math.max(0, inf.npcFear));

  await inf.save();

  return event;
}

async function getEvents(district) {
  return await WorldEvent.find({ district }).sort({ timestamp: -1 });
}

module.exports = {
  triggerEvent,
  getEvents
};