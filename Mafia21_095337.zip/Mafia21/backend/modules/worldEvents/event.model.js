const mongoose = require("mongoose");

const eventSchema = new mongoose.Schema({
  type: { type: String, required: true }, // crime, clan, police, random
  district: { type: String, required: true },

  description: String,

  impact: {
    crime: { type: Number, default: 0 },
    clanInfluence: { type: Number, default: 0 },
    npcAggression: { type: Number, default: 0 },
    npcFear: { type: Number, default: 0 }
  },

  triggeredBy: { type: String, default: "system" }, // npcId, clanId, system
  timestamp: { type: Date, default: Date.now }
});

module.exports = mongoose.model("WorldEvent", eventSchema);