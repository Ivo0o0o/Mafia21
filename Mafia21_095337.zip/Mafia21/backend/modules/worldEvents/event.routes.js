const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const engine = require("./event.engine");

// GOD: създай събитие
router.post("/create", godAccess, async (req, res) => {
  const event = await engine.triggerEvent(req.body);
  res.json(event);
});

// GOD: виж събития в район
router.get("/:district", godAccess, async (req, res) => {
  const events = await engine.getEvents(req.params.district);
  res.json(events);
});

module.exports = router;