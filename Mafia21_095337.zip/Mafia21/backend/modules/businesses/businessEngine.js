// =========================
// BUSINESS ENGINE (PRO)
// =========================
//
// Този модул:
// - пуска автоматичен бизнес тик
// - изчислява приходи (District + VIP + Clan + PoliceHeat + Racket)
// - прилага типови бонуси (Business.types.js)
// - записва приходи в WalletService
// =========================

const Business = require("./Business.model");
const WalletService = require("../economy/Wallet.service");
const District = require("../world/districts/District.model");
const VIP = require("../vip/VIP.model");
const Clan = require("../clan/Clan.model");
const TYPES = require("./Business.types");

// =========================
// CALCULATE BUSINESS INCOME (PRO)
// =========================
async function calculateBusinessIncome(business, district) {
  const typeData = TYPES[business.type];

  // Base income from type + business baseIncome
  let income = (typeData?.baseIncome || business.baseIncome) + business.level * 20;

  // District influence
  if (district) {
    income *= 1 + district.influence * 0.05;
    income *= 1 - Math.min(district.crimeRate * 0.5, 0.8);
  }

  // VIP bonuses
  const vip = await VIP.findOne({ userId: business.owner });
  if (vip) {
    income *= vip.rank.businessIncomeBoost + 1;
  }

  // Clan control bonus
  if (business.clanControl) {
    const clan = await Clan.findById(business.clanControl);
    if (clan) {
      income *= 1 + (clan.businessBoost || 0);
    }
  }

  // Police heat penalty
  if (business.policeHeat > 0) {
    income *= 1 - Math.min(business.policeHeat / 100, 0.5);
  }

  // Type-specific notoriety & heat
  if (typeData?.notorietyGain) {
    business.notoriety += typeData.notorietyGain;
  }

  if (typeData?.policeHeatGain) {
    business.policeHeat += typeData.policeHeatGain;
  }

  // Racket
  let racketIncome = 0;
  if (business.racketOwner) {
    racketIncome = Math.round(income * (business.racketTax / 100));
    income -= racketIncome;
  }

  income = Math.max(0, Math.round(income));

  return {
    ownerIncome: income,
    racketIncome,
    totalIncome: income + racketIncome
  };
}

// =========================
// RUN BUSINESS TICK (PRO)
// =========================
module.exports = {
  runBusinessTick: async () => {
    const businesses = await Business.find({ isActive: true });
    const results = [];

    for (const biz of businesses) {
      const district = await District.findOne({ name: biz.district });
      if (!district) continue;

      const { ownerIncome, racketIncome, totalIncome } =
        await calculateBusinessIncome(biz, district);

      if (totalIncome <= 0) continue;

      // Owner income
      const wallet = await WalletService.addMoney(
        biz.owner,
        ownerIncome,
        `Business income: ${biz.name}`
      );

      // Racket income
      if (biz.racketOwner && racketIncome > 0) {
        await WalletService.addMoney(
          biz.racketOwner,
          racketIncome,
          `Racket income from business: ${biz.name}`
        );
      }

      // Save business changes
      biz.dailyIncome = ownerIncome;
      await biz.save();

      results.push({
        business: biz._id,
        name: biz.name,
        owner: biz.owner,
        income: totalIncome,
        ownerIncome,
        racketIncome,
        balanceAfter: wallet.balance
      });
    }

    return results;
  }
};