// =========================
// BUSINESS ROUTES (PRO)
// =========================
//
// Този файл:
// - връзва всички бизнес endpoints
// - използва auth middleware
// - поддържа create / upgrade / collectIncome / tick
// =========================

const express = require("express");
const router = express.Router();

const controller = require("./Business.controller");
const auth = require("../core/auth"); // FIXED PATH

// Взимане на всички бизнеси на играча
router.get("/", auth, controller.getAll);

// Създаване на бизнес
router.post("/", auth, controller.create);

// Ъпгрейд на бизнес
router.post("/upgrade/:businessId", auth, controller.upgrade);

// Събиране на приходи
router.post("/collect/:businessId", auth, controller.collectIncome);

// Ръчно пускане на бизнес тик (ADMIN)
router.post("/tick", auth, controller.runTick);

module.exports = router;