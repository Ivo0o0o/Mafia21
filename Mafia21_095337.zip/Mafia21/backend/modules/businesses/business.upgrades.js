// =========================
// BUSINESS UPGRADES (PRO)
// =========================
//
// Тази таблица:
// - дефинира бонусите за нива 1–10
// - income = допълнителен доход
// - security = допълнителна защита
// - notoriety = колко известност добавя
// - policeHeat = колко heat добавя
// - special = уникален ефект
//
// Използва се от:
// Business.service.js
// Business.engine.js
// =========================

module.exports = {
  1: { 
    income: 0,   
    security: 0,  
    notoriety: 0,
    policeHeat: 0,
    special: null,
    description: "Начално ниво"
  },

  2: { 
    income: 50,  
    security: 1,  
    notoriety: 1,
    policeHeat: 0,
    special: "advertisingBoost",
    description: "Подобрена реклама (+5% доход)"
  },

  3: { 
    income: 100, 
    security: 1,  
    notoriety: 1,
    policeHeat: 1,
    special: "staffEfficiency",
    description: "По-добър персонал (+10% доход)"
  },

  4: { 
    income: 150, 
    security: 2,  
    notoriety: 2,
    policeHeat: 1,
    special: "expandedArea",
    description: "Разширение на обекта (+15% доход)"
  },

  5: { 
    income: 200, 
    security: 2,  
    notoriety: 2,
    policeHeat: 2,
    special: "proEquipment",
    description: "Професионално оборудване (+20% доход)"
  },

  6: { 
    income: 250, 
    security: 3,  
    notoriety: 3,
    policeHeat: 2,
    special: "entrySecurity",
    description: "Охрана на входа (+1 защита)"
  },

  7: { 
    income: 300, 
    security: 3,  
    notoriety: 3,
    policeHeat: 3,
    special: "vipZone",
    description: "VIP зона / склад (+25% доход)"
  },

  8: { 
    income: 350, 
    security: 4,  
    notoriety: 4,
    policeHeat: 3,
    special: "surveillanceSystem",
    description: "Система за наблюдение (+2 защита)"
  },

  9: { 
    income: 400, 
    security: 4,  
    notoriety: 4,
    policeHeat: 4,
    special: "managementTeam",
    description: "Мениджърски екип (+30% доход)"
  },

  10:{ 
    income: 500, 
    security: 5,  
    notoriety: 5,
    policeHeat: 5,
    special: "premiumBusiness",
    description: "Премиум бизнес ниво (+40% доход)"
  }
};