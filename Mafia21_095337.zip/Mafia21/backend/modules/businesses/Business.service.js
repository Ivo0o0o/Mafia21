// =========================
// BUSINESS SERVICE (PRO)
// =========================
//
// Този модул:
// - създава бизнеси
// - изчислява приходи (District + VIP + Clan + PoliceHeat + Racket)
// - поддържа ъпгрейди
// - поддържа рекет
// - работи с Districts PRO
// - работи с VIP PRO
// - работи с Clan PRO
// - работи с BusinessEngine PRO
// =========================

const Business = require("./Business.model");
const User = require("../player/player.model");
const VIP = require("../vip/vip.model");
const District = require("../world/districts/District.model");
const Clan = require("../clan/Clan.model");

// =========================
// CREATE BUSINESS
// =========================
async function createBusiness(ownerId, data) {
  const user = await User.findById(ownerId);
  if (!user) throw new Error("User not found");

  const business = new Business({
    owner: ownerId,
    name: data.name,
    type: data.type,
    district: data.district,
    baseIncome: data.baseIncome || 100,
    level: 1,
    security: 1,
    notoriety: 0,
    riskLevel: 0,
    upgradePoints: 0
  });

  await business.save();
  return business;
}

// =========================
// GET ALL BUSINESSES FOR USER
// =========================
async function getUserBusinesses(ownerId) {
  return Business.find({ owner: ownerId });
}

// =========================
// UPGRADE BUSINESS
// =========================
async function upgradeBusiness(businessId) {
  const business = await Business.findById(businessId);
  if (!business) throw new Error("Business not found");

  if (business.level >= 10) {
    throw new Error("Business is max level");
  }

  business.level += 1;
  business.baseIncome += 50;     
  business.security += 1;        
  business.upgradePoints += 1;

  await business.save();
  return business;
}

// =========================
// CALCULATE INCOME (PRO)
// =========================
async function calculateIncome(business) {
  let income = business.baseIncome + business.level * 20;

  // District influence
  const district = await District.findOne({ name: business.district });
  if (district) {
    income *= 1 + district.influence * 0.05;
    income *= 1 - Math.min(district.crimeRate * 0.5, 0.8);
  }

  // VIP бонуси
  const vip = await VIP.findOne({ userId: business.owner });
  if (vip) {
    income *= vip.rank.businessIncomeBoost + 1;
  }

  // Clan control
  if (business.clanControl) {
    const clan = await Clan.findById(business.clanControl);
    if (clan) {
      income *= 1 + (clan.businessBoost || 0);
    }
  }

  // Police heat penalty
  if (business.policeHeat > 0) {
    income *= 1 - Math.min(business.policeHeat / 100, 0.5);
  }

  // Racket
  if (business.racketOwner) {
    const tax = income * (business.racketTax / 100);
    income -= tax;

    const racketUser = await User.findById(business.racketOwner);
    if (racketUser) {
      racketUser.money += tax;
      await racketUser.save();
    }
  }

  return Math.floor(income);
}

// =========================
// COLLECT INCOME (PRO)
// =========================
async function collectIncome(businessId) {
  const business = await Business.findById(businessId);
  if (!business) throw new Error("Business not found");

  const now = Date.now();

  if (!business.lastIncomeTick) {
    business.lastIncomeTick = now;
    await business.save();
    return { income: 0 };
  }

  const diff = now - business.lastIncomeTick;
  const hours = diff / 3600000;

  if (hours < 1) {
    return { income: 0 };
  }

  const incomePerHour = await calculateIncome(business);
  const totalIncome = Math.floor(incomePerHour * hours);

  const owner = await User.findById(business.owner);
  owner.money += totalIncome;
  await owner.save();

  business.lastIncomeTick = now;
  business.dailyIncome = totalIncome;
  await business.save();

  return { income: totalIncome, hours };
}

// =========================
// SET RACKET
// =========================
async function setRacket(businessId, racketOwnerId, taxPercent) {
  const business = await Business.findById(businessId);
  if (!business) throw new Error("Business not found");

  business.racketOwner = racketOwnerId;
  business.racketTax = taxPercent;

  await business.save();
  return business;
}

// =========================
// REMOVE RACKET
// =========================
async function removeRacket(businessId) {
  const business = await Business.findById(businessId);
  if (!business) throw new Error("Business not found");

  business.racketOwner = null;
  business.racketTax = 0;

  await business.save();
  return business;
}

// =========================
// EXPORTS
// =========================
module.exports = {
  createBusiness,
  getUserBusinesses,
  upgradeBusiness,
  calculateIncome,
  collectIncome,
  setRacket,
  removeRacket
};