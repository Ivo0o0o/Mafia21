// =========================
// BUSINESS CONTROLLER (PRO)
// =========================
//
// Този контролер:
// - връща бизнесите на играча
// - създава бизнес
// - ъпгрейдва бизнес
// - събира приходи
// - пуска автоматичния тик (ADMIN)
// =========================

const Business = require("./Business.model");
const businessService = require("./Business.service");
const businessEngine = require("./Business.engine");
const District = require("../world/districts/District.model");

module.exports = {

  // =========================
  // GET ALL BUSINESSES FOR USER
  // =========================
  getAll: async (req, res) => {
    try {
      const ownerId = req.user.id;
      const businesses = await businessService.getUserBusinesses(ownerId);

      res.json({
        success: true,
        businesses
      });

    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // CREATE BUSINESS
  // =========================
  create: async (req, res) => {
    try {
      const ownerId = req.user.id;
      const { name, type, district } = req.body;

      // Validate district
      const districtExists = await District.findOne({ name: district });
      if (!districtExists) {
        return res.status(400).json({
          success: false,
          error: "District does not exist"
        });
      }

      const business = await businessService.createBusiness(ownerId, {
        name,
        type,
        district
      });

      res.json({
        success: true,
        message: "Бизнесът е създаден успешно.",
        business
      });

    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // UPGRADE BUSINESS
  // =========================
  upgrade: async (req, res) => {
    try {
      const { businessId } = req.params;

      const business = await Business.findById(businessId);
      if (!business) {
        return res.status(404).json({ success: false, error: "Бизнесът не е намерен" });
      }

      if (String(business.owner) !== String(req.user.id)) {
        return res.status(403).json({ success: false, error: "Това не е твой бизнес" });
      }

      const upgraded = await businessService.upgradeBusiness(businessId);

      res.json({
        success: true,
        message: "Бизнесът е надграден успешно.",
        business: upgraded
      });

    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // COLLECT INCOME
  // =========================
  collectIncome: async (req, res) => {
    try {
      const { businessId } = req.params;

      const business = await Business.findById(businessId);
      if (!business) {
        return res.status(404).json({ success: false, error: "Бизнесът не е намерен" });
      }

      if (String(business.owner) !== String(req.user.id)) {
        return res.status(403).json({ success: false, error: "Това не е твой бизнес" });
      }

      const result = await businessService.collectIncome(businessId);

      res.json({
        success: true,
        message: "Приходите са събрани.",
        result
      });

    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // RUN BUSINESS TICK (ADMIN ONLY)
  // =========================
  runTick: async (req, res) => {
    try {
      // Only admins
      if (!req.user.isAdmin) {
        return res.status(403).json({
          success: false,
          error: "Admin only"
        });
      }

      const results = await businessEngine.runBusinessTick();

      res.json({
        success: true,
        message: "Business tick executed",
        results
      });

    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
};