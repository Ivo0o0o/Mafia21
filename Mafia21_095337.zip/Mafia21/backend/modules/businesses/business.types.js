// =========================
// BUSINESS TYPES (PRO)
// =========================
//
// Тази таблица:
// - дефинира всички типове бизнеси
// - задава базови приходи
// - задава базова защита
// - задава риск
// - задава специални ефекти (notoriety, policeHeat, clanBonus)
// =========================

module.exports = {
  bar: {
    name: "Bar",
    baseIncome: 120,
    baseSecurity: 1,
    risk: 10,
    notorietyGain: 1,
    policeHeatGain: 0,
    clanBonus: 0,
    description: "Малък бар, стабилен доход, нисък риск."
  },

  club: {
    name: "Club",
    baseIncome: 200,
    baseSecurity: 2,
    risk: 20,
    notorietyGain: 3,
    policeHeatGain: 2,
    clanBonus: 0,
    description: "Нощен клуб с добър доход, но по-висок риск."
  },

  casino: {
    name: "Casino",
    baseIncome: 400,
    baseSecurity: 3,
    risk: 35,
    notorietyGain: 5,
    policeHeatGain: 5,
    clanBonus: 0,
    description: "Казино с големи приходи, но привлича внимание."
  },

  shop: {
    name: "Shop",
    baseIncome: 100,
    baseSecurity: 1,
    risk: 5,
    notorietyGain: 0,
    policeHeatGain: 0,
    clanBonus: 0,
    description: "Магазин с постоянен доход и минимален риск."
  },

  garage: {
    name: "Garage",
    baseIncome: 150,
    baseSecurity: 2,
    risk: 15,
    notorietyGain: 1,
    policeHeatGain: 1,
    clanBonus: 2, // клановете печелят повече от гаражи
    description: "Гараж за ремонти, стабилен доход и среден риск."
  },

  warehouse: {
    name: "Warehouse",
    baseIncome: 250,
    baseSecurity: 3,
    risk: 25,
    notorietyGain: 2,
    policeHeatGain: 3,
    clanBonus: 1,
    description: "Склад с добър доход, но податлив на кражби."
  }
};