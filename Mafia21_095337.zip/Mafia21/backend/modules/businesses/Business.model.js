const mongoose = require('mongoose');

const businessSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },

    type: {
      type: String,
      enum: ['bar', 'club', 'casino', 'shop', 'garage', 'warehouse'],
      default: 'shop'
    },

    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },

    district: { type: String, required: true },

    level: { type: Number, default: 1 },          
    baseIncome: { type: Number, default: 100 },   
    security: { type: Number, default: 1 },       
    notoriety: { type: Number, default: 0 },      

    isActive: { type: Boolean, default: true },

    // Автоматични приходи (последен тик)
    lastIncomeTick: { type: Date, default: null },

    // Риск от полиция / конкуренти
    riskLevel: { type: Number, default: 0 }, // 0–100

    // Рекет (ако друг играч го държи)
    racketOwner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    racketTax: { type: Number, default: 0 }, // % от дохода

    // Нови PRO полета
    upgradePoints: { type: Number, default: 0 }, // точки за подобрения
    dailyIncome: { type: Number, default: 0 },   // последно изчислен доход
    policeHeat: { type: Number, default: 0 },    // колко полиция следи бизнеса
    clanControl: { type: mongoose.Schema.Types.ObjectId, ref: 'Clan', default: null }, // контрол от клан

    createdAt: { type: Date, default: Date.now }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Business', businessSchema);