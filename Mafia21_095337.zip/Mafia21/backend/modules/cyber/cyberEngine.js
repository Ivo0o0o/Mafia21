const CyberOp = require('./CyberOp.model');
const WalletService = require('../economy/wallet.service');
const User = require('../users/User.model');

function calculateOutcome(op, player) {
  const baseChance = op.baseChance;

  const difficultyPenalty = op.difficulty * 0.07; // трудност намалява шанса
  const firewallPenalty = op.firewallLevel * 0.05; // firewall намалява шанса
  const repBonus = (player.reputation || 0) * 0.01; // репутация дава бонус

  // Финален шанс за успех
  let successChance = baseChance - difficultyPenalty - firewallPenalty + repBonus;

  // Ограничаваме между 5% и 95%
  successChance = Math.max(0.05, Math.min(successChance, 0.95));

  // Награда
  const reward = Math.round(
    op.baseReward * (1 + op.difficulty * 0.3) * (1 + op.risk)
  );

  return { successChance, reward };
}

module.exports = {
  runCyberOp: async (op, userId) => {
    const player = await User.findById(userId);
    if (!player) return { error: 'Играчът не е намерен' };

    const { successChance, reward } = calculateOutcome(op, player);
    const success = Math.random() <= successChance;

    if (success) {
      const wallet = await WalletService.addMoney(
        userId,
        reward,
        `Cyber operation: ${op.name}`
      );

      player.reputation += 2;
      await player.save();

      return {
        success: true,
        reward,
        balanceAfter: wallet.balance,
        message: `Успешна кибер операция: ${op.name}`
      };
    }

    // Провал → глоба
    const penalty = Math.round(reward * 0.4);
    const wallet = await WalletService.removeMoney(
        userId,
        penalty,
        `Cyber fail: ${op.name}`
    );

    // Шанс да те проследят
    const traced = Math.random() <= op.traceChance;

    if (traced) {
      player.reputation = Math.max(0, player.reputation - 5);
      await player.save();
    }

    return {
      success: false,
      penalty,
      traced,
      balanceAfter: wallet.balance,
      message: traced
        ? `Провал и проследяване! ${op.name}`
        : `Провалена операция: ${op.name}`
    };
  }
};