const CyberOp = require('./CyberOp.model');
const cyberEngine = require('./cyberEngine');

module.exports = {
  getAll: async (req, res) => {
    try {
      const ops = await CyberOp.find();
      res.json(ops);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  create: async (req, res) => {
    try {
      const op = await CyberOp.create(req.body);
      res.json(op);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  run: async (req, res) => {
    try {
      const { opId } = req.params;
      const op = await CyberOp.findById(opId);

      if (!op) return res.status(404).json({ error: 'Операцията не е намерена' });

      const result = await cyberEngine.runCyberOp(op, req.user.id);
      res.json(result);

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};