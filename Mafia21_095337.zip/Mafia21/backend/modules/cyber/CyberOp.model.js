const mongoose = require('mongoose');

const cyberOpSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String, default: '' },

  type: {
    type: String,
    enum: ['hack', 'ddos', 'crypto_heist', 'breach', 'darknet'],
    default: 'hack'
  },

  difficulty: { type: Number, default: 1 },   // 1–5
  risk: { type: Number, default: 0.2 },       // 0–1
  baseReward: { type: Number, default: 150 },
  baseChance: { type: Number, default: 0.75 }, // 75% шанс за успех

  firewallLevel: { type: Number, default: 1 }, // защита на целта
  traceChance: { type: Number, default: 0.1 }, // шанс да те проследят

}, { timestamps: true });

module.exports = mongoose.model('CyberOp', cyberOpSchema);