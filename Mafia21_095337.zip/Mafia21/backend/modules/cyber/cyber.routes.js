const express = require('express');
const router = express.Router();
const controller = require('./cyber.controller');
const auth = require('../../core/auth');

router.get('/', controller.getAll);
router.post('/', auth, controller.create);
router.post('/run/:opId', auth, controller.run);

module.exports = router;