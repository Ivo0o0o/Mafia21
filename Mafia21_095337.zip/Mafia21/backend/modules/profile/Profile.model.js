const mongoose = require('mongoose');

const profileSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },

  rank: { type: Number, default: 1 },          // 1–100
  xp: { type: Number, default: 0 },            // опит
  level: { type: Number, default: 1 },         // ниво

  skills: {
    hacking: { type: Number, default: 1 },
    combat: { type: Number, default: 1 },
    stealth: { type: Number, default: 1 },
    business: { type: Number, default: 1 },
    leadership: { type: Number, default: 1 }
  },

  achievements: [{ type: String }],            // списък с постижения

  stats: {
    missionsCompleted: { type: Number, default: 0 },
    cyberOpsCompleted: { type: Number, default: 0 },
    npcDefeated: { type: Number, default: 0 },
    territoriesCaptured: { type: Number, default: 0 },
    moneyEarned: { type: Number, default: 0 }
  }

}, { timestamps: true });

module.exports = mongoose.model('Profile', profileSchema);