const Profile = require('./Profile.model');
const profileEngine = require('./profileEngine');

module.exports = {
  getProfile: async (req, res) => {
    try {
      const profile = await Profile.findOne({ userId: req.user.id });
      if (!profile) return res.status(404).json({ error: 'Профилът не е намерен' });

      res.json(profile);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  createProfile: async (req, res) => {
    try {
      const profile = await Profile.create({ userId: req.user.id });
      res.json(profile);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  addXP: async (req, res) => {
    try {
      const { amount } = req.body;
      const profile = await profileEngine.addXP(req.user.id, amount);
      res.json(profile);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};