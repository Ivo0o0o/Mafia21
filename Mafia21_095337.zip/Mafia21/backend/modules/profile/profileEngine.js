const Profile = require('./Profile.model');

module.exports = {
  addXP: async (userId, amount) => {
    const profile = await Profile.findOne({ userId });
    if (!profile) return null;

    profile.xp += amount;

    // автоматично качване на ниво
    while (profile.xp >= profile.level * 100) {
      profile.xp -= profile.level * 100;
      profile.level += 1;
      profile.rank += 1;
    }

    await profile.save();
    return profile;
  },

  addAchievement: async (userId, achievement) => {
    const profile = await Profile.findOne({ userId });
    if (!profile) return null;

    if (!profile.achievements.includes(achievement)) {
      profile.achievements.push(achievement);
      await profile.save();
    }

    return profile;
  },

  increaseSkill: async (userId, skillName, amount = 1) => {
    const profile = await Profile.findOne({ userId });
    if (!profile) return null;

    if (profile.skills[skillName] !== undefined) {
      profile.skills[skillName] += amount;
      await profile.save();
    }

    return profile;
  }
};