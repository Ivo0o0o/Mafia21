const express = require('express');
const router = express.Router();
const controller = require('./profile.controller');
const auth = require('../../core/auth');

router.get('/', auth, controller.getProfile);
router.post('/create', auth, controller.createProfile);
router.post('/xp', auth, controller.addXP);

module.exports = router;