const express = require('express');
const router = express.Router();
const controller = require('./event.controller');
const auth = require('../../core/auth');

router.get('/', controller.getAll);
router.post('/', auth, controller.create);
router.post('/tick', auth, controller.runTick);

module.exports = router;