const Event = require('./Event.model');
const eventEngine = require('./eventEngine');

module.exports = {
  getAll: async (req, res) => {
    try {
      const events = await Event.find();
      res.json(events);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  create: async (req, res) => {
    try {
      const ev = await Event.create(req.body);
      res.json(ev);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  runTick: async (req, res) => {
    try {
      const results = await eventEngine.runEventTick();
      res.json({
        message: 'Global event tick executed',
        results
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};