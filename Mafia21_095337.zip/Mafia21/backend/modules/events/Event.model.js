const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String, default: '' },

  type: {
    type: String,
    enum: [
      'police_raid',
      'blackout',
      'cyber_attack',
      'district_war',
      'economy_crash',
      'crypto_crash',
      'npc_riot',
      'special_event'
    ],
    default: 'special_event'
  },

  targetDistrict: { type: String, default: null },
  impactCrime: { type: Number, default: 0 },      // +/- престъпност
  impactEconomy: { type: Number, default: 0 },    // +/- влияние/икономика
  impactIncome: { type: Number, default: 0 },     // +/- доходи

  isGlobal: { type: Boolean, default: false },    // ако е за целия град
  active: { type: Boolean, default: true },

  durationMinutes: { type: Number, default: 60 }  // колко време държи ефекта

}, { timestamps: true });

module.exports = mongoose.model('Event', eventSchema);