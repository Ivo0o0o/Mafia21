const Event = require('./Event.model');
const District = require('../districts/District.model');
const Business = require('../businesses/Business.model');

async function applyEventToDistrict(event, district) {
  if (!district) return;

  if (event.impactCrime) {
    district.crimeRate = Math.min(
      1,
      Math.max(0, district.crimeRate + event.impactCrime)
    );
  }

  if (event.impactEconomy) {
    district.influence += event.impactEconomy;
  }

  await district.save();
}

async function applyEventToBusinesses(event, districtName) {
  const businesses = await Business.find({ district: districtName });

  for (const biz of businesses) {
    if (event.impactIncome) {
      biz.baseIncome = Math.max(
        0,
        biz.baseIncome + event.impactIncome
      );
      await biz.save();
    }
  }
}

module.exports = {
  runEventTick: async () => {
    const events = await Event.find({ active: true });
    const results = [];

    for (const ev of events) {
      if (ev.isGlobal) {
        const districts = await District.find({});
        for (const d of districts) {
          await applyEventToDistrict(ev, d);
          await applyEventToBusinesses(ev, d.name);
        }
      } else if (ev.targetDistrict) {
        const district = await District.findOne({ name: ev.targetDistrict });
        await applyEventToDistrict(ev, district);
        await applyEventToBusinesses(ev, ev.targetDistrict);
      }

      results.push({
        event: ev._id,
        name: ev.name,
        type: ev.type,
        targetDistrict: ev.targetDistrict || 'GLOBAL'
      });
    }

    return results;
  }
};