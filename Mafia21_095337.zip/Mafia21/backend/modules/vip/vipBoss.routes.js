const express = require('express');
const router = express.Router();
const controller = require('./vipBoss.controller');

// Middleware: ensure user is authenticated
const auth = require('../middleware/auth');

// VIP Boss Fight Route
router.post('/fight', auth, controller.fight);

module.exports = router;