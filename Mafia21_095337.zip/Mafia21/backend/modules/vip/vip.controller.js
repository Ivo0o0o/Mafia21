// =========================
// VIP CONTROLLER (FINAL)
// =========================
//
// Този файл:
// - обработва HTTP заявки
// - извиква vip.service.js
// - извиква vip.daily.js
// - извиква vip.loot.js
// - връща JSON към клиента
//
// Напълно подреден и готов за работа.
// =========================

const { buyPack } = require("./vip.service");
const { generateVipLoot } = require("./vip.loot");
const { openDailyChest } = require("./vip.daily");
const User = require("../../models/User");

// =========================
// BUY VIP PACK
// =========================
exports.buyPack = async (req, res) => {
  try {
    const { userId, pack } = req.body;

    // 1) Извикваме VIP service логиката
    const result = await buyPack(userId, pack);

    // 2) Ако пакетът е невалиден
    if (result.error) {
      return res.status(400).json({ error: result.error });
    }

    // 3) Генерираме loot от пакета
    const loot = generateVipLoot(pack);

    // 4) Добавяме loot в инвентара на играча
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    if (!user.vipInventory) user.vipInventory = [];

    user.vipInventory.push({
      item: loot.item,
      rarity: loot.rarity,
      receivedAt: loot.timestamp
    });

    await user.save();

    // 5) Финален отговор
    res.json({
      success: true,
      message: `VIP пакет '${pack}' е активиран успешно.`,
      items: result.items,
      loot
    });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// =========================
// OPEN DAILY VIP CHEST
// =========================
exports.openDailyChest = async (req, res) => {
  try {
    const { userId } = req.body;

    const loot = await openDailyChest(userId);

    res.json({
      success: true,
      message: "Дневният VIP сандък е отворен успешно.",
      loot
    });

  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};