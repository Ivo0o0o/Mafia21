// =========================
// VIP LOOT GENERATOR (FINAL)
// =========================
//
// Този модул:
// - генерира VIP loot според rarity
// - работи с VIP packs
// - работи с VIP random
// - работи с VIP items
// - връща пълен loot обект
//
// Използва се от:
// - vip.service.js (buyPack)
// - vip.daily.js (daily chest)
// - vipBoss.service.js (boss rewards)
// =========================

const VIP_ITEMS = require("./vip.items");
const { randomItem, randomRarity } = require("./vip.random");

function generateVipLoot(packName) {
  // 1) Генерираме rarity според пакета
  const rarity = randomRarity(packName);

  // 2) Генерираме предмет според rarity
  const item = randomItem(rarity);

  // 3) Финален loot обект
  return {
    rarity,
    item,
    timestamp: Date.now(),
    source: packName
  };
}

module.exports = { generateVipLoot };