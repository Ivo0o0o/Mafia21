const VIP = require("./vip.model");
const vipEffects = require("./vip.effects");
const packs = require("./vip.packs");
const { randomItem, randomRarity } = require("./vip.random");
const { generateVipLoot } = require("./vip.loot");

// =========================
// GET VIP PROFILE
// =========================
async function getVipProfile(userId) {
  let vip = await VIP.findOne({ userId });

  if (!vip) {
    vip = new VIP({
      userId,
      rank: vipEffects.getRankEffects("Bronze"),
      diamonds: 0,
      items: []
    });
    await vip.save();
  }

  return vip;
}

// =========================
// BUY DIAMONDS
// =========================
async function buyDiamonds(userId, amount) {
  const vip = await getVipProfile(userId);

  vip.diamonds += amount;
  await vip.save();

  return {
    success: true,
    diamonds: vip.diamonds
  };
}

// =========================
// SPEND DIAMONDS
// =========================
async function spendDiamonds(userId, amount) {
  const vip = await getVipProfile(userId);

  if (vip.diamonds < amount) {
    return { error: "Not enough diamonds" };
  }

  vip.diamonds -= amount;
  await vip.save();

  return {
    success: true,
    diamonds: vip.diamonds
  };
}

// =========================
// UPGRADE VIP RANK
// =========================
async function upgradeRank(userId, newRankName) {
  const vip = await getVipProfile(userId);

  const newRank = vipEffects.getRankEffects(newRankName);
  if (!newRank) return { error: "Invalid rank" };

  vip.rank = newRank;
  await vip.save();

  return {
    success: true,
    rank: vip.rank
  };
}

// =========================
// BUY VIP PACK
// =========================
async function buyPack(userId, packName) {
  const pack = packs[packName];
  if (!pack) return { error: "Invalid pack" };

  const vip = await getVipProfile(userId);

  // Проверка за диаманти
  if (vip.diamonds < pack.priceEUR) {
    return { error: "Not enough diamonds" };
  }

  vip.diamonds -= pack.priceEUR;

  // Генерираме предметите
  const items = [];
  for (let i = 0; i < pack.items; i++) {
    const rarity = randomRarity(packName);
    const item = randomItem(rarity);
    items.push({ rarity, item });
  }

  vip.items.push(...items);
  await vip.save();

  return {
    success: true,
    pack: packName,
    items,
    diamonds: vip.diamonds
  };
}

// =========================
// DAILY CHEST
// =========================
async function claimDaily(userId) {
  const vip = await getVipProfile(userId);

  const now = Date.now();
  const last = vip.lastDailyClaimAt;

  // Проверка за 24 часа
  if (last && now - last < 24 * 60 * 60 * 1000) {
    return { error: "Already claimed today" };
  }

  // Streak
  if (last && now - last < 48 * 60 * 60 * 1000) {
    vip.dailyStreak += 1;
  } else {
    vip.dailyStreak = 1;
  }

  vip.lastDailyClaimAt = now;

  // Chest tier
  const tier = vip.rank.dailyChestTier;

  // Генерираме loot според ранга
  const loot = generateVipLoot(vip.rank.name);

  vip.items.push(loot);
  await vip.save();

  return {
    success: true,
    streak: vip.dailyStreak,
    loot,
    tier
  };
}

// =========================
// APPLY VIP EFFECT
// =========================
async function applyVipEffect(userId, effectName, value) {
  const vip = await getVipProfile(userId);

  vip.activeEffects.set(effectName, value);
  await vip.save();

  return { success: true, activeEffects: vip.activeEffects };
}

// =========================
// REMOVE VIP EFFECT
// =========================
async function removeVipEffect(userId, effectName) {
  const vip = await getVipProfile(userId);

  vip.activeEffects.delete(effectName);
  await vip.save();

  return { success: true };
}

// =========================
async function clearVipEffects(userId) {
  const vip = await getVipProfile(userId);

  vip.activeEffects = new Map();
  await vip.save();

  return { success: true };
}

// =========================
// EXPORTS
// =========================
module.exports = {
  getVipProfile,
  buyDiamonds,
  spendDiamonds,
  upgradeRank,
  buyPack,
  claimDaily,
  applyVipEffect,
  removeVipEffect,
  clearVipEffects
};