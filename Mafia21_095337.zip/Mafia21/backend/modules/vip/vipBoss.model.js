// =========================
// VIP BOSS MODEL (FINAL)
// =========================
//
// Този модел:
// - дефинира VIP Boss статистики
// - поддържа loot таблици
// - поддържа cooldown
// - работи с vipBoss.service.js
// - работи с vip.effects.js (boss boost)
// - работи с vip.model.js (user stats)
// =========================

const mongoose = require("mongoose");

const vipBossSchema = new mongoose.Schema(
  {
    name: { type: String, default: "VIP Boss" },

    // Основни статистики
    hp: { type: Number, default: 5000 },
    damage: { type: Number, default: 150 },
    defense: { type: Number, default: 50 },

    // Loot таблица
    loot: {
      common: {
        type: [String],
        default: ["cash_bundle", "ammo_box"]
      },
      rare: {
        type: [String],
        default: ["gold_chain", "pistol_upgrade"]
      },
      ultra: {
        type: [String],
        default: ["diamond_ring", "rare_car_part"]
      }
    },

    // Награди
    rewardMoney: { type: Number, default: 5000 },
    rewardXP: { type: Number, default: 1500 },

    // Cooldown (в секунди)
    cooldown: { type: Number, default: 3600 }, // 1 hour

    // Метаданни
    createdAt: { type: Date, default: Date.now }
  },
  { timestamps: true }
);

module.exports = mongoose.model("VIPBoss", vipBossSchema);