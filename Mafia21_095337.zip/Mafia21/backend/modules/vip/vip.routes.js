// =========================
// VIP ROUTES (FINAL)
// =========================
//
// Този файл:
// - дефинира всички VIP API endpoints
// - свързва ги с vip.controller.js
//
// Напълно подреден и готов за работа.
// =========================

const router = require("express").Router();
const vipController = require("./vip.controller");

// BUY VIP PACK
router.post("/buyPack", vipController.buyPack);

// OPEN DAILY VIP CHEST
router.post("/openDailyChest", vipController.openDailyChest);

// UPGRADE VIP RANK
router.post("/upgradeRank", vipController.upgradeRank);

// BUY DIAMONDS
router.post("/buyDiamonds", vipController.buyDiamonds);

// SPEND DIAMONDS
router.post("/spendDiamonds", vipController.spendDiamonds);

// GET VIP PROFILE
router.post("/vipProfile", vipController.getVipProfile);

// APPLY VIP EFFECT
router.post("/applyEffect", vipController.applyVipEffect);

// REMOVE VIP EFFECT
router.post("/removeEffect", vipController.removeVipEffect);

module.exports = router;