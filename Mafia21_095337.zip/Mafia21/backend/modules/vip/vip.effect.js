// =========================
// VIP EFFECTS MODULE (FINAL)
// =========================
//
// Този модул:
// - съдържа ранговите ефекти
// - връща ефектите според ранга
// - работи с vip.model.js
// - работи с vip.service.js
// - работи с vip.daily.js
// - работи с vipBoss.service.js
// - НЕ дублира нищо
// =========================

const vipRanks = {
  Bronze: {
    level: 1,
    xpBoost: 1.05,
    moneyBoost: 1.05,
    respectBoost: 1.00,
    lootBoost: 1.00,
    crimeSuccessBoost: 0.02,
    escapeBoost: 0.02,
    courtInfluence: 0.00,
    territoryBoost: 0.00,
    npcLoyaltyBoost: 0.00,
    businessIncomeBoost: 0.00,
    dailyChestTier: 1,
    hasVipChatAccess: false,
    hasVipExclusiveItems: false,
    hasVipBossBoost: false
  },

  Silver: {
    level: 2,
    xpBoost: 1.10,
    moneyBoost: 1.10,
    respectBoost: 1.05,
    lootBoost: 1.05,
    crimeSuccessBoost: 0.04,
    escapeBoost: 0.03,
    courtInfluence: 0.01,
    territoryBoost: 0.01,
    npcLoyaltyBoost: 0.01,
    businessIncomeBoost: 0.01,
    dailyChestTier: 2,
    hasVipChatAccess: true,
    hasVipExclusiveItems: false,
    hasVipBossBoost: false
  },

  Gold: {
    level: 3,
    xpBoost: 1.20,
    moneyBoost: 1.20,
    respectBoost: 1.10,
    lootBoost: 1.10,
    crimeSuccessBoost: 0.06,
    escapeBoost: 0.04,
    courtInfluence: 0.02,
    territoryBoost: 0.02,
    npcLoyaltyBoost: 0.02,
    businessIncomeBoost: 0.02,
    dailyChestTier: 3,
    hasVipChatAccess: true,
    hasVipExclusiveItems: true,
    hasVipBossBoost: false
  },

  Platinum: {
    level: 4,
    xpBoost: 1.30,
    moneyBoost: 1.30,
    respectBoost: 1.20,
    lootBoost: 1.20,
    crimeSuccessBoost: 0.08,
    escapeBoost: 0.06,
    courtInfluence: 0.03,
    territoryBoost: 0.03,
    npcLoyaltyBoost: 0.03,
    businessIncomeBoost: 0.03,
    dailyChestTier: 4,
    hasVipChatAccess: true,
    hasVipExclusiveItems: true,
    hasVipBossBoost: true
  },

  Diamond: {
    level: 5,
    xpBoost: 1.50,
    moneyBoost: 1.50,
    respectBoost: 1.30,
    lootBoost: 1.30,
    crimeSuccessBoost: 0.10,
    escapeBoost: 0.08,
    courtInfluence: 0.05,
    territoryBoost: 0.05,
    npcLoyaltyBoost: 0.05,
    businessIncomeBoost: 0.05,
    dailyChestTier: 5,
    hasVipChatAccess: true,
    hasVipExclusiveItems: true,
    hasVipBossBoost: true
  },

  Godfather: {
    level: 6,
    xpBoost: 2.00,
    moneyBoost: 2.00,
    respectBoost: 1.50,
    lootBoost: 1.50,
    crimeSuccessBoost: 0.15,
    escapeBoost: 0.10,
    courtInfluence: 0.10,
    territoryBoost: 0.10,
    npcLoyaltyBoost: 0.10,
    businessIncomeBoost: 0.10,
    dailyChestTier: 6,
    hasVipChatAccess: true,
    hasVipExclusiveItems: true,
    hasVipBossBoost: true
  }
};

// =========================
// PUBLIC API
// =========================

module.exports = {
  getRankEffects(rankName) {
    return vipRanks[rankName] || vipRanks["Bronze"];
  },

  getAllRanks() {
    return vipRanks;
  }
};