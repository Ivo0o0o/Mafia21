// =========================
// VIP DAILY CHEST (FINAL)
// =========================
//
// Този модул:
// - отваря дневния VIP сандък
// - работи с VIP рангове (dailyChestTier)
// - работи с VIP loot generator
// - поддържа streak система
// - записва инвентар в User модела
//
// Напълно съвместим с твоята структура.
// =========================

const { generateVipLoot } = require("./vip.loot");
const VIP = require("./vip.model");
const User = require("../../models/User");

async function openDailyChest(userId) {
  // Взимаме User
  const user = await User.findById(userId);
  if (!user) throw new Error("User not found");

  // Взимаме VIP профила
  let vip = await VIP.findOne({ userId });
  if (!vip) {
    vip = new VIP({
      userId,
      items: [],
      diamonds: 0
    });
    await vip.save();
  }

  const now = Date.now();
  const cooldown = 24 * 60 * 60 * 1000; // 24 часа

  // Проверка за cooldown
  if (vip.lastDailyClaimAt && now - vip.lastDailyClaimAt < cooldown) {
    throw new Error("Chest already opened today");
  }

  // Streak логика
  if (vip.lastDailyClaimAt && now - vip.lastDailyClaimAt < 48 * 60 * 60 * 1000) {
    vip.dailyStreak += 1;
  } else {
    vip.dailyStreak = 1;
  }

  vip.lastDailyClaimAt = now;

  // Chest tier според VIP ранга
  const tier = vip.rank.dailyChestTier || 1;

  // Генерираме loot според tier
  const loot = generateVipLoot(vip.rank.name);

  // Добавяме в User инвентара
  if (!user.vipInventory) user.vipInventory = [];

  user.vipInventory.push({
    item: loot.item,
    rarity: loot.rarity,
    tier,
    receivedAt: loot.timestamp
  });

  await user.save();
  await vip.save();

  return {
    success: true,
    streak: vip.dailyStreak,
    tier,
    loot
  };
}

module.exports = { openDailyChest };