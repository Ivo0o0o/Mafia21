const VIPBoss = require('./vipBoss.model');
const User = require('../user/user.model');
const { addCrimeReward, addLootReward, getVipEffects } = require('../playerState/playerState.engine');

module.exports = {
  fight: async (userId) => {
    // Load user
    const user = await User.findById(userId);
    if (!user) throw new Error("User not found");

    // Load VIP effects
    const vip = await getVipEffects(userId);
    if (!vip) return { success: false, message: "VIP only content" };

    // Load boss
    const boss = await VIPBoss.findOne();
    if (!boss) throw new Error("Boss not found");

    // ============================
    // COOLDOWN CHECK
    // ============================
    let cooldownMs = boss.cooldown * 1000;

    // VIP cooldown multiplier (clamped)
    if (vip.cooldownBoost) {
      const multiplier = Math.max(0.1, Math.min(vip.cooldownBoost, 2));
      cooldownMs = Math.floor(cooldownMs * multiplier);
    }

    if (user.bossCooldown && user.bossCooldown > Date.now()) {
      const remaining = Math.floor((user.bossCooldown - Date.now()) / 1000);
      return { success: false, message: `Cooldown: ${remaining}s remaining` };
    }

    // ============================
    // DAMAGE CALCULATION
    // ============================
    const playerDamage = user.damage * (vip.damageBoost || 1);

    // Boss defense reduces damage
    const effectiveDamage = Math.max(0, playerDamage - boss.defense);

    const playerWins = effectiveDamage >= boss.hp;

    // ============================
    // PLAYER LOSES
    // ============================
    if (!playerWins) {
      user.bossCooldown = Date.now() + cooldownMs;
      await user.save();

      return {
        success: false,
        message: "Boss defeated you",
        cooldown: cooldownMs / 1000
      };
    }

    // ============================
    // REWARDS (MONEY + XP)
    // ============================
    const money = boss.rewardMoney;
    const xp = boss.rewardXP;

    const boosted = await addCrimeReward(userId, money, xp);

    // ============================
    // LOOT GENERATION
    // ============================
    let loot = [...boss.loot.common];

    // Rare loot chance (default 30%)
    const rareChance = boss.lootRareChance || 0.3;
    if (Math.random() < rareChance) {
      const rareItem = boss.loot.rare[Math.floor(Math.random() * boss.loot.rare.length)];
      loot.push(rareItem);
    }

    // VIP ultra loot chance (clamped)
    const vipLootChance = Math.min(vip.lootBoost || 0, 1);
    if (Math.random() < vipLootChance) {
      const ultraItem = boss.loot.ultra[Math.floor(Math.random() * boss.loot.ultra.length)];
      loot.push(ultraItem);
    }

    // Remove duplicates
    loot = [...new Set(loot)];

    const finalLoot = await addLootReward(userId, loot);

    // ============================
    // APPLY COOLDOWN
    // ============================
    user.bossCooldown = Date.now() + cooldownMs;
    await user.save();

    // ============================
    // FINAL RESPONSE
    // ============================
    return {
      success: true,
      message: "Boss defeated!",
      reward: {
        money: boosted.money,
        xp: boosted.xp,
        loot: finalLoot
      },
      cooldown: cooldownMs / 1000
    };
  }
};