// =========================
// VIP PACKS (FINALIZED)
// =========================
//
// Този модул е финализирана версия на твоя оригинален файл.
// Подреден, разширен, професионален.
//
// Използва се от:
// - vip.service.js (buyPack)
// - vip.random.js (randomRarity)
// - vip.loot.js (generateVipLoot)
// =========================

module.exports = {
  Bronze: {
    priceEUR: 4.99,
    items: 3,
    chance: {
      Bronze: 80,
      Silver: 10,
      Gold: 7,
      Platinum: 2,
      Diamond: 1,
      Godfather: 0.1
    },
    packName: "Bronze"
  },

  Silver: {
    priceEUR: 9.99,
    items: 3,
    chance: {
      Bronze: 60,
      Silver: 20,
      Gold: 12,
      Platinum: 5,
      Diamond: 2,
      Godfather: 0.3
    },
    packName: "Silver"
  },

  Gold: {
    priceEUR: 19.99,
    items: 3,
    chance: {
      Bronze: 40,
      Silver: 25,
      Gold: 20,
      Platinum: 10,
      Diamond: 4,
      Godfather: 1
    },
    packName: "Gold"
  },

  Platinum: {
    priceEUR: 39.99,
    items: 3,
    chance: {
      Bronze: 20,
      Silver: 20,
      Gold: 25,
      Platinum: 20,
      Diamond: 10,
      Godfather: 5
    },
    packName: "Platinum"
  },

  Diamond: {
    priceEUR: 79.99,
    items: 3,
    chance: {
      Bronze: 10,
      Silver: 15,
      Gold: 20,
      Platinum: 25,
      Diamond: 20,
      Godfather: 10
    },
    packName: "Diamond"
  },

  Godfather: {
    priceEUR: 149.99,
    items: 3,
    chance: {
      Bronze: 0,
      Silver: 0,
      Gold: 10,
      Platinum: 20,
      Diamond: 30,
      Godfather: 40
    },
    exclusiveVipItems: true,
    packName: "Godfather"
  }
};