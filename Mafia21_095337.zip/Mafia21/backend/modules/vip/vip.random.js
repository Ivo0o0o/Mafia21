// =========================
// VIP RANDOM ENGINE (FINAL)
// =========================
//
// Този модул:
// - генерира rarity според шанс
// - генерира предмет според rarity
// - работи с vip.items.js
// - работи с vip.packs.js
// - работи с vip.loot.js
//
// Напълно съвместим с твоята структура.
// =========================

const items = require("./vip.items");
const packs = require("./vip.packs");

// =========================
// RANDOM RARITY
// =========================
//
// Пример:
// packName = "Gold"
// packs[packName].chance = { Bronze: 40, Silver: 25, Gold: 20, Platinum: 10, Diamond: 4, Godfather: 1 }
// =========================

function randomRarity(packName) {
  const pack = packs[packName];
  if (!pack || !pack.chance) return "Bronze";

  const chanceTable = pack.chance;
  const roll = Math.random() * 100;
  let sum = 0;

  for (const rarity in chanceTable) {
    sum += chanceTable[rarity];
    if (roll <= sum) {
      return rarity;
    }
  }

  return "Bronze"; // fallback
}

// =========================
// RANDOM ITEM BY RARITY
// =========================
//
// rarity = "Gold"
// items.filter(i => i.level === "Gold")
// =========================

function randomItem(rarity) {
  const pool = items.filter(i => i.level === rarity);

  if (!pool.length) {
    // fallback: ако няма предмети за този rarity
    const fallback = items.filter(i => i.level === "Bronze");
    return fallback[Math.floor(Math.random() * fallback.length)];
  }

  return pool[Math.floor(Math.random() * pool.length)];
}

// =========================
// EXPORTS
// =========================

module.exports = {
  randomRarity,
  randomItem
};