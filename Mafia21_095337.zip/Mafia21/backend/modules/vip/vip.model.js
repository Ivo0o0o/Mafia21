const mongoose = require("mongoose");

// =========================
// VIP RANKS SCHEMA
// =========================
const vipRankSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },          // Bronze, Silver, Gold, Platinum, Diamond, Godfather
    level: { type: Number, required: true },         // 1–6

    // Рангови бонуси
    xpBoost: { type: Number, default: 1.0 },
    moneyBoost: { type: Number, default: 1.0 },
    respectBoost: { type: Number, default: 1.0 },
    lootBoost: { type: Number, default: 1.0 },
    crimeSuccessBoost: { type: Number, default: 0 },
    escapeBoost: { type: Number, default: 0 },
    courtInfluence: { type: Number, default: 0 },
    territoryBoost: { type: Number, default: 0 },
    npcLoyaltyBoost: { type: Number, default: 0 },
    businessIncomeBoost: { type: Number, default: 0 },

    // Daily chest tier (1–6)
    dailyChestTier: { type: Number, default: 1 },

    // VIP ексклузивни права
    hasVipChatAccess: { type: Boolean, default: false },
    hasVipExclusiveItems: { type: Boolean, default: false },
    hasVipBossBoost: { type: Boolean, default: false }
  },
  { _id: false }
);

// =========================
// VIP MAIN SCHEMA
// =========================
const VIPSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, unique: true },

    // Текущ VIP ранг
    rank: {
      type: vipRankSchema,
      default: {
        name: "Bronze",
        level: 1,
        xpBoost: 1.05,
        moneyBoost: 1.05,
        respectBoost: 1.0,
        lootBoost: 1.0,
        crimeSuccessBoost: 2,
        escapeBoost: 2,
        courtInfluence: 0,
        territoryBoost: 0,
        npcLoyaltyBoost: 0,
        businessIncomeBoost: 0,
        dailyChestTier: 1,
        hasVipChatAccess: false,
        hasVipExclusiveItems: false,
        hasVipBossBoost: false
      }
    },

    // VIP валута (диаманти)
    diamonds: { type: Number, default: 0 },

    // VIP предмети
    items: { type: Array, default: [] },

    // Активни VIP ефекти
    activeEffects: {
      type: Map,
      of: Number,
      default: {}
    },

    // VIP абонамент
    subscription: {
      type: String,
      enum: ["none", "weekly", "monthly", "yearly", "lifetime"],
      default: "none"
    },

    expiresAt: { type: Date, default: null },

    // Daily chest / streak
    lastDailyClaimAt: { type: Date, default: null },
    dailyStreak: { type: Number, default: 0 },

    // Метаданни
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
  },
  { timestamps: true }
);

module.exports = mongoose.model("VIP", VIPSchema);