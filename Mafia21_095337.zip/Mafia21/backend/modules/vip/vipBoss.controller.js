const vipBossService = require('./vipBoss.service');

module.exports = {
  fight: async (req, res) => {
    try {
      // Safety: ensure user exists in request
      if (!req.user || !req.user.id) {
        return res.status(401).json({ success: false, message: "Unauthorized" });
      }

      const result = await vipBossService.fight(req.user.id);

      // Unified response format
      return res.status(200).json(result);

    } catch (err) {
      console.error("VIP Boss Fight Error:", err);

      return res.status(500).json({
        success: false,
        message: "Internal server error",
        error: err.message
      });
    }
  }
};