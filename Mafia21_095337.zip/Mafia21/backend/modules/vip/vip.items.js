// modules/vip/vip.items.js

/**
 * VIP Item Definitions
 * Подредени по VIP рангове:
 * Bronze → Silver → Gold → Platinum → Diamond → Godfather
 *
 * Всеки предмет има:
 * - id
 * - name
 * - tier (ранг)
 * - rarity
 * - type
 * - power
 */

const vipItems = [
  // =========================
  // BRONZE (6)
  // =========================
  {
    id: 1,
    name: "Pocket Knife",
    tier: "Bronze",
    rarity: "common",
    type: "weapon",
    power: 5
  },
  {
    id: 2,
    name: "Cheap Phone",
    tier: "Bronze",
    rarity: "common",
    type: "device",
    power: 3
  },
  {
    id: 3,
    name: "Basic SIM Card",
    tier: "Bronze",
    rarity: "common",
    type: "utility",
    power: 2
  },
  {
    id: 4,
    name: "Old Jacket",
    tier: "Bronze",
    rarity: "common",
    type: "armor",
    power: 4
  },
  {
    id: 5,
    name: "Rusty Pistol",
    tier: "Bronze",
    rarity: "common",
    type: "weapon",
    power: 6
  },
  {
    id: 6,
    name: "Small Toolkit",
    tier: "Bronze",
    rarity: "common",
    type: "tool",
    power: 5
  },

  // =========================
  // SILVER (4)
  // =========================
  {
    id: 7,
    name: "Combat Knife",
    tier: "Silver",
    rarity: "uncommon",
    type: "weapon",
    power: 12
  },
  {
    id: 8,
    name: "Encrypted Phone",
    tier: "Silver",
    rarity: "uncommon",
    type: "device",
    power: 10
  },
  {
    id: 9,
    name: "Kevlar Vest",
    tier: "Silver",
    rarity: "uncommon",
    type: "armor",
    power: 15
  },
  {
    id: 10,
    name: "Hacking USB",
    tier: "Silver",
    rarity: "uncommon",
    type: "device",
    power: 14
  },

  // =========================
  // GOLD (3)
  // =========================
  {
    id: 11,
    name: "Gold Pistol",
    tier: "Gold",
    rarity: "rare",
    type: "weapon",
    power: 25
  },
  {
    id: 12,
    name: "Spy Drone",
    tier: "Gold",
    rarity: "rare",
    type: "device",
    power: 28
  },
  {
    id: 13,
    name: "Encrypted SIM Pro",
    tier: "Gold",
    rarity: "rare",
    type: "utility",
    power: 22
  },

  // =========================
  // PLATINUM (3)
  // =========================
  {
    id: 14,
    name: "Platinum Rifle",
    tier: "Platinum",
    rarity: "epic",
    type: "weapon",
    power: 40
  },
  {
    id: 15,
    name: "Cyberdeck Pro",
    tier: "Platinum",
    rarity: "epic",
    type: "device",
    power: 45
  },
  {
    id: 16,
    name: "VIP Car Key",
    tier: "Platinum",
    rarity: "epic",
    type: "vehicle",
    power: 50
  },

  // =========================
  // DIAMOND (2)
  // =========================
  {
    id: 17,
    name: "Diamond Sniper",
    tier: "Diamond",
    rarity: "legendary",
    type: "weapon",
    power: 65
  },
  {
    id: 18,
    name: "Quantum Phone",
    tier: "Diamond",
    rarity: "legendary",
    type: "device",
    power: 70
  },

  // =========================
  // GODFATHER (1)
  // =========================
  {
    id: 19,
    name: "Godfather Signature Weapon",
    tier: "Godfather",
    rarity: "mythic",
    type: "weapon",
    power: 100
  }
];

/**
 * Utility functions
 */
function getVipItemById(id) {
  return vipItems.find(item => item.id === id) || null;
}

function getItemsByTier(tier) {
  return vipItems.filter(item => item.tier === tier);
}

function getAllVipItems() {
  return vipItems;
}

module.exports = {
  vipItems,
  getVipItemById,
  getItemsByTier,
  getAllVipItems
};