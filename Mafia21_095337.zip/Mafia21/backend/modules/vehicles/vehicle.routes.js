const express = require("express");
const router = express.Router();
const engine = require("./vehicleEngine");
const auth = require("../../src/middleware/authMiddleware");

router.post("/give", auth, async (req, res) => {
  const v = await engine.giveVehicle(req.body.userId, req.body.vehicle);
  res.json(v);
});

router.post("/setSpeed", auth, async (req, res) => {
  const v = await engine.setVehicleSpeed(req.body.vehicleId, req.body.speed);
  res.json(v);
});

router.delete("/:id", auth, async (req, res) => {
  const v = await engine.removeVehicle(req.params.id);
  res.json({ deleted: v });
});

module.exports = router;