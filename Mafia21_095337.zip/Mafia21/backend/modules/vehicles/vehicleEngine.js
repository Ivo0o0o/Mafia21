const Vehicle = require("./Vehicle.model");

module.exports = {
  giveVehicle: async (userId, vehicleData) => {
    const vehicle = await Vehicle.create({ ...vehicleData, owner: userId });
    return vehicle;
  },

  setVehicleSpeed: async (vehicleId, speed) => {
    const v = await Vehicle.findById(vehicleId);
    v.speed = speed;
    await v.save();
    return v;
  },

  removeVehicle: async (vehicleId) => {
    return await Vehicle.findByIdAndDelete(vehicleId);
  }
};