const mongoose = require("mongoose");

const vehicleSchema = new mongoose.Schema({
  name: String,
  type: { type: String, enum: ["car", "motorcycle", "truck"] },
  speed: Number,        // км/ч
  fuelUsage: Number,    // литри на км
  durability: Number,   // здравина
  owner: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null }
});

module.exports = mongoose.model("Vehicle", vehicleSchema);