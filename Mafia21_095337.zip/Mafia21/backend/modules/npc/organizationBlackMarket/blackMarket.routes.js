const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./blackMarket.engine");

// GOD: виж черния пазар
router.get("/:orgId", godAccess, async (req, res) => {
  const market = await engine.getMarket(req.params.orgId);
  res.json(market);
});

// GOD: добави стока
router.post("/addItem", godAccess, async (req, res) => {
  const { orgId, item } = req.body;
  const market = await engine.addItem(orgId, item);
  res.json(market);
});

// GOD: купи стока
router.post("/buy", godAccess, async (req, res) => {
  const { orgId, itemName, quantity } = req.body;
  const result = await engine.buyItem(orgId, itemName, quantity);
  res.json(result);
});

// GOD: продай стока
router.post("/sell", godAccess, async (req, res) => {
  const { orgId, itemName, quantity } = req.body;
  const result = await engine.sellItem(orgId, itemName, quantity);
  res.json(result);
});

// GOD: списък със стоки
router.get("/:orgId/items", godAccess, async (req, res) => {
  const items = await engine.listItems(req.params.orgId);
  res.json(items);
});

// GOD: транзакции
router.get("/:orgId/transactions", godAccess, async (req, res) => {
  const tx = await engine.listTransactions(req.params.orgId);
  res.json(tx);
});

module.exports = router;