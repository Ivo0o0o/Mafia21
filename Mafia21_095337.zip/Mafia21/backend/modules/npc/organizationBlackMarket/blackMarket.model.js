const mongoose = require("mongoose");

const blackMarketSchema = new mongoose.Schema({
  orgId: { type: String, required: true },

  items: [
    {
      name: { type: String, required: true },
      category: {
        type: String,
        enum: ["weapon", "drug", "info", "resource", "service"],
        required: true
      },
      price: { type: Number, required: true },
      quantity: { type: Number, default: 1 }
    }
  ],

  transactions: [
    {
      itemName: String,
      type: { type: String, enum: ["buy", "sell"], required: true },
      amount: Number,
      timestamp: { type: Date, default: Date.now }
    }
  ],

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("BlackMarket", blackMarketSchema);