const BlackMarket = require("./blackMarket.model");
const OrgEconomy = require("../organizationEconomy/orgEconomy.model");

async function getMarket(orgId) {
  let market = await BlackMarket.findOne({ orgId });
  if (!market) market = await BlackMarket.create({ orgId });
  return market;
}

async function addItem(orgId, item) {
  const market = await getMarket(orgId);
  market.items.push(item);
  market.lastUpdate = new Date();
  await market.save();
  return market;
}

async function buyItem(orgId, itemName, quantity = 1) {
  const market = await getMarket(orgId);
  const eco = await OrgEconomy.findOne({ orgId });

  const item = market.items.find(i => i.name === itemName);
  if (!item) throw new Error("Item not found");

  const totalPrice = item.price * quantity;

  if (eco.wallet.money < totalPrice) throw new Error("Not enough money");

  eco.wallet.money -= totalPrice;
  eco.wallet.expenses += totalPrice;

  item.quantity -= quantity;
  if (item.quantity < 0) item.quantity = 0;

  market.transactions.push({
    itemName,
    type: "buy",
    amount: totalPrice
  });

  await eco.save();
  await market.save();

  return { eco, market };
}

async function sellItem(orgId, itemName, quantity = 1) {
  const market = await getMarket(orgId);
  const eco = await OrgEconomy.findOne({ orgId });

  const item = market.items.find(i => i.name === itemName);
  if (!item) throw new Error("Item not found");

  const totalPrice = item.price * quantity;

  eco.wallet.money += totalPrice;
  eco.wallet.income += totalPrice;

  item.quantity += quantity;

  market.transactions.push({
    itemName,
    type: "sell",
    amount: totalPrice
  });

  await eco.save();
  await market.save();

  return { eco, market };
}

async function listItems(orgId) {
  const market = await getMarket(orgId);
  return market.items;
}

async function listTransactions(orgId) {
  const market = await getMarket(orgId);
  return market.transactions.sort((a, b) => b.timestamp - a.timestamp);
}

module.exports = {
  getMarket,
  addItem,
  buyItem,
  sellItem,
  listItems,
  listTransactions
};