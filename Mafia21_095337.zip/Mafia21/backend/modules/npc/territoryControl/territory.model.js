const mongoose = require("mongoose");

const territorySchema = new mongoose.Schema({
  territoryId: { type: String, required: true },   // уникален квартал/зона
  ownerOrg: { type: String, default: null },       // кой клан го държи

  controlLevel: { type: Number, default: 0 },      // 0–100 контрол
  defenseLevel: { type: Number, default: 0 },      // 0–100 защита
  unrestLevel: { type: Number, default: 0 },        // 0–100 напрежение

  income: { type: Number, default: 0 },             // приход от територията
  lastAction: { type: String, default: "" },

  timestamp: { type: Date, default: Date.now }
}, { timestamps: true });

module.exports = mongoose.model("Territory", territorySchema);