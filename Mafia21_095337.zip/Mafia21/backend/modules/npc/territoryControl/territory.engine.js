const Territory = require("./territory.model");

async function getTerritory(territoryId) {
  let t = await Territory.findOne({ territoryId });
  if (!t) t = await Territory.create({ territoryId });
  return t;
}

async function captureTerritory(orgId, territoryId) {
  const t = await getTerritory(territoryId);

  t.ownerOrg = orgId;
  t.controlLevel = 100;
  t.defenseLevel = 50;
  t.unrestLevel = 20;
  t.lastAction = "Captured";

  await t.save();
  return t;
}

async function loseTerritory(territoryId) {
  const t = await getTerritory(territoryId);

  t.ownerOrg = null;
  t.controlLevel = 0;
  t.defenseLevel = 0;
  t.unrestLevel = 50;
  t.lastAction = "Lost";

  await t.save();
  return t;
}

async function reinforceTerritory(orgId, territoryId) {
  const t = await getTerritory(territoryId);

  if (t.ownerOrg !== orgId) return null;

  t.defenseLevel += 15;
  t.controlLevel += 5;
  t.unrestLevel -= 10;
  t.lastAction = "Reinforced";

  t.defenseLevel = Math.min(100, t.defenseLevel);
  t.controlLevel = Math.min(100, t.controlLevel);
  t.unrestLevel = Math.max(0, t.unrestLevel);

  await t.save();
  return t;
}

async function weakenTerritory(territoryId) {
  const t = await getTerritory(territoryId);

  t.defenseLevel -= 20;
  t.controlLevel -= 10;
  t.unrestLevel += 20;
  t.lastAction = "Weakened";

  t.defenseLevel = Math.max(0, t.defenseLevel);
  t.controlLevel = Math.max(0, t.controlLevel);
  t.unrestLevel = Math.min(100, t.unrestLevel);

  await t.save();
  return t;
}

async function territoryTick() {
  const territories = await Territory.find();

  for (const t of territories) {
    if (t.ownerOrg) {
      t.income += Math.floor(t.controlLevel / 10);
      t.unrestLevel += Math.floor(Math.random() * 5);
      t.defenseLevel -= Math.floor(Math.random() * 3);
    } else {
      t.unrestLevel += Math.floor(Math.random() * 10);
    }

    t.unrestLevel = Math.max(0, Math.min(100, t.unrestLevel));
    t.defenseLevel = Math.max(0, Math.min(100, t.defenseLevel));

    t.lastAction = "Territory tick";
    t.timestamp = new Date();

    await t.save();
  }

  return territories;
}

module.exports = {
  getTerritory,
  captureTerritory,
  loseTerritory,
  reinforceTerritory,
  weakenTerritory,
  territoryTick
};