const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./territory.engine");

// GOD: виж територия
router.get("/:territoryId", godAccess, async (req, res) => {
  res.json(await engine.getTerritory(req.params.territoryId));
});

// GOD: завземане
router.post("/capture", godAccess, async (req, res) => {
  const { orgId, territoryId } = req.body;
  res.json(await engine.captureTerritory(orgId, territoryId));
});

// GOD: загуба
router.post("/lose", godAccess, async (req, res) => {
  const { territoryId } = req.body;
  res.json(await engine.loseTerritory(territoryId));
});

// GOD: подсилване
router.post("/reinforce", godAccess, async (req, res) => {
  const { orgId, territoryId } = req.body;
  res.json(await engine.reinforceTerritory(orgId, territoryId));
});

// GOD: отслабване
router.post("/weaken", godAccess, async (req, res) => {
  const { territoryId } = req.body;
  res.json(await engine.weakenTerritory(territoryId));
});

// GOD: тик
router.post("/tick", godAccess, async (req, res) => {
  res.json(await engine.territoryTick());
});

module.exports = router;