const District = require("../Districts/District.model");
const NPC = require("./npc.model");

module.exports = {

  async updateDistrictControl() {
    const districts = await District.find();
    const npcs = await NPC.find();

    for (const district of districts) {
      const districtNPCs = npcs.filter(n => n.district === district.name);

      if (districtNPCs.length === 0) continue;

      // Сила на NPC в района
      const totalInfluence = districtNPCs
        .map(n => n.influence)
        .reduce((a, b) => a + b, 0);

      // Колко държат района (0–100)
      const control = Math.min(100, Math.floor(totalInfluence / 10));

      district.npcControl = control;

      // Кой го държи (най-силната организация)
      const orgMap = {};
      for (const npc of districtNPCs) {
        if (!npc.organizationId) continue;
        orgMap[npc.organizationId] = (orgMap[npc.organizationId] || 0) + npc.influence;
      }

      let topOrg = null;
      let topPower = 0;

      for (const [orgId, power] of Object.entries(orgMap)) {
        if (power > topPower) {
          topPower = power;
          topOrg = orgId;
        }
      }

      district.npcOwner = topOrg || district.npcOwner || null;

      await district.save();
    }
  }
};