const NPC = require("../npc.model");
const District = require("../../world/districts/District.model");

module.exports = {

  async processAI(npc) {
    if (!npc) return;

    // Personality-driven behavior
    const aggression = npc.aggression;
    const fear = npc.fear;
    const loyalty = npc.loyalty;

    // Decision: attack, flee, patrol, idle
    let action = "idle";

    if (aggression > 0.7 && fear < 0.4) {
      action = "attack";
    } else if (fear > 0.7) {
      action = "flee";
    } else if (loyalty > 0.6) {
      action = "patrol";
    }

    // District influence effect
    const district = await District.findOne({ name: npc.district });
    const influence = district ? district.influence : 0;

    // AI modifiers
    npc.aiState = {
      action,
      influence,
      mood: aggression - fear + loyalty
    };

    await npc.save();
    return npc.aiState;
  },

  async runAll() {
    const npcs = await NPC.find();
    const results = [];

    for (const npc of npcs) {
      const state = await this.processAI(npc);
      results.push({ npc: npc.name, state });
    }

    return results;
  }
};