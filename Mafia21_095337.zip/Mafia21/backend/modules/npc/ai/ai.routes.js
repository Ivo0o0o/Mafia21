const router = require("express").Router();
const AIController = require("./ai.controller");

// Run NPC AI tick
router.get("/run", AIController.run);

// Debug / Health check
router.get("/status", (req, res) => {
  res.json({
    success: true,
    message: "NPC AI module is active"
  });
});

module.exports = router;