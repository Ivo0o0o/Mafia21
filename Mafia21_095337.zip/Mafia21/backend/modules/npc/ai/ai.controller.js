const AIEngine = require("./ai.engine");

module.exports = {

  async run(req, res) {
    try {
      const result = await AIEngine.runAll();
      res.json({
        success: true,
        message: "NPC AI tick executed",
        result
      });
    } catch (err) {
      res.status(500).json({
        success: false,
        error: err.message
      });
    }
  }
};