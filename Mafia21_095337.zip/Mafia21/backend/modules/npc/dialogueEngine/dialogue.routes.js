const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const engine = require("./dialogue.engine");

// GOD: генерирай диалог
router.post("/generate", godAccess, async (req, res) => {
  const { npcId, playerId } = req.body;
  res.json(await engine.generateDialogue(npcId, playerId));
});

// GOD: промени отношение
router.post("/relationship", godAccess, async (req, res) => {
  const { npcId, relation } = req.body;
  res.json(await engine.updateRelationship(npcId, relation));
});

// GOD: промени личност
router.post("/personality", godAccess, async (req, res) => {
  const { npcId, personalityType } = req.body;
  res.json(await engine.updatePersonality(npcId, personalityType));
});

// GOD: виж NPC диалог профил
router.get("/:npcId", godAccess, async (req, res) => {
  res.json(await engine.getDialogue(req.params.npcId));
});

module.exports = router;