const mongoose = require("mongoose");

const dialogueSchema = new mongoose.Schema({
  npcId: { type: String, required: true },

  personalityType: {
    type: String,
    enum: ["aggressive", "calm", "fearful", "loyal", "chaotic"],
    default: "calm"
  },

  relationshipToPlayer: {
    type: String,
    enum: ["friendly", "neutral", "afraid", "hostile"],
    default: "neutral"
  },

  clanAffiliation: { type: String, default: null },

  lastDialogue: { type: String, default: "" },
  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("NPCDialogue", dialogueSchema);