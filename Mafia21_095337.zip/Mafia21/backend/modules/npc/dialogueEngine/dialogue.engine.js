const NPCDialogue = require("./dialogue.model");
const PlayerInteraction = require("../playerInteraction/playerInteraction.model");
const Overseer = require("../overseer/overseer.model");
const Mission = require("../missionEngine/mission.model");

// 1. Вземи или създай NPC диалог профил
async function getDialogue(npcId) {
  let d = await NPCDialogue.findOne({ npcId });
  if (!d) d = await NPCDialogue.create({ npcId });
  return d;
}

// 2. Генериране на диалог според контекст
async function generateDialogue(npcId, playerId) {
  const d = await getDialogue(npcId);
  const pi = await PlayerInteraction.findOne({ playerId });
  const overseer = await Overseer.findOne({ worldId: "default" });

  const activeMission = await Mission.findOne({ status: "active" });

  let line = "";

  // Личност
  switch (d.personalityType) {
    case "aggressive":
      line += "Какво искаш пак, а? ";
      break;
    case "calm":
      line += "Спокойно… да видим какво става. ";
      break;
    case "fearful":
      line += "Моля те… не ме наранявай… ";
      break;
    case "loyal":
      line += "За теб — винаги. ";
      break;
    case "chaotic":
      line += "Ха! Светът гори, нали го виждаш? ";
      break;
  }

  // Отношение към играча
  if (pi) {
    switch (pi.fear) {
      case pi.fear > 60:
        line += "Ти… ти си легенда на улиците. ";
        break;
    }

    switch (d.relationshipToPlayer) {
      case "friendly":
        line += "Добре че дойде, имам нещо за теб. ";
        break;
      case "afraid":
        line += "Не ме докосвай… ще кажа всичко! ";
        break;
      case "hostile":
        line += "Ако не беше тук, щях да те сваля. ";
        break;
    }
  }

  // Overseer метрики
  if (overseer.metrics.worldTension > 70) {
    line += "Напрежението в града е нетърпимо… ";
  }

  if (overseer.metrics.crimePressure > 60) {
    line += "Улиците са по-опасни от всякога. ";
  }

  if (overseer.metrics.economicStability < 30) {
    line += "Парите не стигат никъде… ";
  }

  // Мисии
  if (activeMission) {
    line += `Има слухове за мисия: "${activeMission.title}". `;
  }

  d.lastDialogue = line.trim();
  d.lastUpdate = new Date();
  await d.save();

  return d.lastDialogue;
}

// 3. Промяна на отношение към играча
async function updateRelationship(npcId, relation) {
  const d = await getDialogue(npcId);
  d.relationshipToPlayer = relation;
  await d.save();
  return d;
}

// 4. Промяна на личност
async function updatePersonality(npcId, personalityType) {
  const d = await getDialogue(npcId);
  d.personalityType = personalityType;
  await d.save();
  return d;
}

module.exports = {
  getDialogue,
  generateDialogue,
  updateRelationship,
  updatePersonality
};