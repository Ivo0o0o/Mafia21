const Action = require("./action.model");
const Strategy = require("../strategy/strategy.model");
const Diplomacy = require("../diplomacy/diplomacy.model");
const Territory = require("../territory/territory.model");

async function getAction(orgId) {
  let act = await Action.findOne({ orgId });
  if (!act) act = await Action.create({ orgId });
  return act;
}

function logAction(act, action, targetId = "", zoneId = "") {
  act.lastAction = action;
  act.lastTarget = targetId;
  act.lastZone = zoneId;
  act.timestamp = new Date();

  act.history.push({
    action,
    targetId,
    zoneId,
    timestamp: new Date()
  });
}

// NPC ACTIONS
async function performWarAction(orgId) {
  const act = await getAction(orgId);
  const dip = await Diplomacy.findOne({ orgId });

  // избира най-враждебния враг
  let target = null;
  let maxHost = 0;

  for (const [tid, host] of dip.hostility.entries()) {
    if (host > maxHost) {
      maxHost = host;
      target = tid;
    }
  }

  logAction(act, "Attack", target);
  await act.save();
  return act;
}

async function performExpandAction(orgId) {
  const act = await getAction(orgId);
  const terr = await Territory.findOne({ orgId });

  // избира зона с висок потенциал
  let bestZone = null;
  let bestScore = -1;

  for (const zone of terr.zones) {
    const score = zone.influence - zone.control;
    if (score > bestScore) {
      bestScore = score;
      bestZone = zone.zoneId;
    }
  }

  logAction(act, "Expand", "", bestZone);
  await act.save();
  return act;
}

async function performRetreatAction(orgId) {
  const act = await getAction(orgId);
  const terr = await Territory.findOne({ orgId });

  // избира зона с най-нисък контрол
  let worstZone = null;
  let minControl = 999;

  for (const zone of terr.zones) {
    if (zone.control < minControl) {
      minControl = zone.control;
      worstZone = zone.zoneId;
    }
  }

  logAction(act, "Retreat", "", worstZone);
  await act.save();
  return act;
}

async function performDefendAction(orgId) {
  const act = await getAction(orgId);
  const terr = await Territory.findOne({ orgId });

  // избира зона с най-висока доминация (за защита)
  let defendZone = null;
  let maxDom = -1;

  for (const zone of terr.zones) {
    if (zone.dominance > maxDom) {
      maxDom = zone.dominance;
      defendZone = zone.zoneId;
    }
  }

  logAction(act, "Defend", "", defendZone);
  await act.save();
  return act;
}

async function performOpportunisticAction(orgId) {
  const act = await getAction(orgId);
  const dip = await Diplomacy.findOne({ orgId });

  // избира цел с най-високи отношения (за да се възползва)
  let target = null;
  let bestRel = -999;

  for (const [tid, rel] of dip.relations.entries()) {
    if (rel > bestRel) {
      bestRel = rel;
      target = tid;
    }
  }

  logAction(act, "Trade / Opportunistic Move", target);
  await act.save();
  return act;
}

// MAIN DECISION EXECUTION
async function executeStrategy(orgId) {
  const strat = await Strategy.findOne({ orgId });
  if (!strat) return null;

  switch (strat.currentStrategy) {
    case "war":
      return await performWarAction(orgId);

    case "expand":
      return await performExpandAction(orgId);

    case "retreat":
      return await performRetreatAction(orgId);

    case "defend":
      return await performDefendAction(orgId);

    case "opportunistic":
      return await performOpportunisticAction(orgId);

    default:
      const act = await getAction(orgId);
      logAction(act, "Idle");
      await act.save();
      return act;
  }
}

// ACTION TICK
async function actionTick() {
  const all = await Strategy.find();
  const results = [];

  for (const strat of all) {
    const result = await executeStrategy(strat.orgId);
    results.push(result);
  }

  return results;
}

module.exports = {
  getAction,
  executeStrategy,
  actionTick
};