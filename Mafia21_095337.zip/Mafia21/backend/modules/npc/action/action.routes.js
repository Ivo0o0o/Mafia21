const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./action.engine");

// GOD: виж действия
router.get("/:orgId", godAccess, async (req, res) => {
  res.json(await engine.getAction(req.params.orgId));
});

// GOD: изпълни стратегия
router.post("/execute", godAccess, async (req, res) => {
  const { orgId } = req.body;
  res.json(await engine.executeStrategy(orgId));
});

// GOD: тик
router.post("/tick", godAccess, async (req, res) => {
  res.json(await engine.actionTick());
});

module.exports = router;