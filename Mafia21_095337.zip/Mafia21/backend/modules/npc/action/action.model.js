const mongoose = require("mongoose");

const actionSchema = new mongoose.Schema({
  orgId: { type: String, required: true },

  // последно действие
  lastAction: { type: String, default: "" },
  lastTarget: { type: String, default: "" },
  lastZone: { type: String, default: "" },

  // история
  history: {
    type: [
      {
        action: String,
        targetId: String,
        zoneId: String,
        timestamp: Date
      }
    ],
    default: []
  },

  timestamp: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("Action", actionSchema);