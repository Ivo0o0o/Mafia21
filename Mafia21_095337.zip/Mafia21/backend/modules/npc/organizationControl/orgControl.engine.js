const OrgControl = require("./orgControl.model");
const NPCOrganization = require("../organization/organization.model");
const Influence = require("../../districts/influence.model");

class DistrictControlEngine {

  // -----------------------------------------
  // CAPTURE DISTRICT (Territory Capture PRO)
  // -----------------------------------------
  async captureDistrict(orgId, district, amount = 20) {
    let control = await OrgControl.findOne({ district });

    // If district is neutral → create control
    if (!control) {
      control = await OrgControl.create({
        district,
        orgId,
        controlLevel: amount,
        influence: amount * 1.5,
        crimeBoost: 5,
        incomeBoost: 3,
        influenceBoost: 5
      });
      return control;
    }

    // If district belongs to another organization → reduce their control
    if (control.orgId && control.orgId.toString() !== orgId.toString()) {
      control.controlLevel -= amount;

      // If defender loses control → attacker takes over
      if (control.controlLevel <= 0) {
        control.orgId = orgId;
        control.controlLevel = amount;
      }

    } else {
      // If attacker already owns the district → strengthen control
      control.orgId = orgId;
      control.controlLevel += amount;
    }

    // Influence recalculation
    control.influence = Math.floor(control.controlLevel * 1.5);
    control.influenceBoost = Math.floor(control.controlLevel * 0.3);
    control.crimeBoost = Math.floor(control.controlLevel * 0.2);
    control.incomeBoost = Math.floor(control.controlLevel * 0.15);

    control.lastUpdate = Date.now();
    await control.save();

    // -----------------------------------------
    // Influence System PRO
    // -----------------------------------------
    let inf = await Influence.findOne({ district });
    if (!inf) {
      inf = await Influence.create({
        district,
        clanInfluence: control.influence,
        crimeLevel: control.crimeBoost
      });
    } else {
      inf.clanInfluence = control.influence;
      inf.crimeLevel = control.crimeBoost;
      await inf.save();
    }

    return control;
  }

  // -----------------------------------------
  // LOSE CONTROL (Decay / Warfare Loss)
  // -----------------------------------------
  async loseControl(orgId, district, amount = 20) {
    const control = await OrgControl.findOne({ district });

    if (!control) throw new Error("District not found");

    // Only reduce if the same org owns it
    if (control.orgId && control.orgId.toString() === orgId.toString()) {
      control.controlLevel -= amount;

      if (control.controlLevel < 0) control.controlLevel = 0;

      control.influence = Math.floor(control.controlLevel * 1.5);
      control.influenceBoost = Math.floor(control.controlLevel * 0.3);
      control.crimeBoost = Math.floor(control.controlLevel * 0.2);
      control.incomeBoost = Math.floor(control.controlLevel * 0.15);

      control.lastUpdate = Date.now();
      await control.save();
    }

    return control;
  }

  // -----------------------------------------
  // GET DISTRICT INFO
  // -----------------------------------------
  async getControl(orgId, district) {
    return await OrgControl.findOne({ orgId, district }).populate("orgId");
  }

  // -----------------------------------------
  // GET DISTRICT BY NAME
  // -----------------------------------------
  async getDistrict(district) {
    return await OrgControl.findOne({ district }).populate("orgId");
  }

  // -----------------------------------------
  // LIST ALL DISTRICTS FOR ORGANIZATION
  // -----------------------------------------
  async listDistricts(orgId) {
    return await OrgControl.find({ orgId }).sort({ controlLevel: -1 }).populate("orgId");
  }

  // -----------------------------------------
  // LIST ALL DISTRICTS (MAP VIEW)
  // -----------------------------------------
  async getAllDistricts() {
    return await OrgControl.find().populate("orgId");
  }
}

module.exports = new DistrictControlEngine();