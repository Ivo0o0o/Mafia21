const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./orgControl.engine");

// ---------------------------------------------
// GOD: Capture district (Territory Capture PRO)
// ---------------------------------------------
router.post("/capture", godAccess, async (req, res) => {
  try {
    const { orgId, district, amount } = req.body;

    if (!orgId || !district) {
      return res.status(400).json({ error: "Missing orgId or district" });
    }

    const result = await engine.captureDistrict(orgId, district, amount || 20);
    res.json(result);

  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ---------------------------------------------
// GOD: Lose control of district
// ---------------------------------------------
router.post("/lose", godAccess, async (req, res) => {
  try {
    const { orgId, district, amount } = req.body;

    if (!orgId || !district) {
      return res.status(400).json({ error: "Missing orgId or district" });
    }

    const result = await engine.loseControl(orgId, district, amount || 20);
    res.json(result);

  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ---------------------------------------------
// GOD: Get district info by name
// ---------------------------------------------
router.get("/district/:district", godAccess, async (req, res) => {
  try {
    const result = await engine.getDistrict(req.params.district);
    res.json(result);

  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ---------------------------------------------
// GOD: Get control for org + district
// ---------------------------------------------
router.get("/control/:orgId/:district", godAccess, async (req, res) => {
  try {
    const result = await engine.getControl(req.params.orgId, req.params.district);
    res.json(result);

  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ---------------------------------------------
// GOD: List all districts controlled by org
// ---------------------------------------------
router.get("/list/:orgId", godAccess, async (req, res) => {
  try {
    const result = await engine.listDistricts(req.params.orgId);
    res.json(result);

  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ---------------------------------------------
// GOD: List ALL districts (Map View PRO)
// ---------------------------------------------
router.get("/", godAccess, async (req, res) => {
  try {
    const result = await engine.getAllDistricts();
    res.json(result);

  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;