const mongoose = require("mongoose");

const orgControlSchema = new mongoose.Schema({

  // Районът
  district: { type: String, required: true },

  // Коя организация държи района
  orgId: { type: mongoose.Schema.Types.ObjectId, ref: "Organization", default: null },

  // Ниво на контрол (0–100)
  controlLevel: { type: Number, default: 0 },

  // Influence в района (автоматично се изчислява)
  influence: { type: Number, default: 0 },

  // Бонуси от района
  crimeBoost: { type: Number, default: 0 },
  incomeBoost: { type: Number, default: 0 },
  influenceBoost: { type: Number, default: 0 },

  // Последна промяна
  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("OrgControl", orgControlSchema);