const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const engine = require("./npcThreat.engine");

// GOD: проверка на NPC реакция
router.post("/check", godAccess, async (req, res) => {
  try {
    const { npcId, userId } = req.body;
    const result = await engine.npcThreatCheck(npcId, userId);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;