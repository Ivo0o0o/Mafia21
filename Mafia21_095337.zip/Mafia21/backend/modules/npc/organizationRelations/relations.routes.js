const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./relations.engine");

// GOD: виж отношения
router.get("/:orgId", godAccess, async (req, res) => {
  res.json(await engine.getRelations(req.params.orgId));
});

// GOD: промени отношения
router.post("/change", godAccess, async (req, res) => {
  const { orgId, targetOrgId, amount } = req.body;
  res.json(await engine.changeRelation(orgId, targetOrgId, amount));
});

// GOD: създай дипломатическо действие
router.post("/diplomacy", godAccess, async (req, res) => {
  const { orgId, payload } = req.body;
  res.json(await engine.createDiplomacy(orgId, payload));
});

// GOD: тик на дипломация
router.post("/tick", godAccess, async (req, res) => {
  const { orgId } = req.body;
  res.json(await engine.diplomacyTick(orgId));
});

module.exports = router;