const mongoose = require("mongoose");

const relationsSchema = new mongoose.Schema({
  orgId: { type: String, required: true },

  relations: [
    {
      targetOrgId: String,
      value: { type: Number, default: 0 }, // -100 до +100
      status: {
        type: String,
        enum: ["neutral", "ally", "enemy", "hostile", "friendly"],
        default: "neutral"
      },
      lastChange: { type: Date, default: Date.now }
    }
  ],

  diplomacy: [
    {
      dipId: String,
      type: {
        type: String,
        enum: ["truce", "alliance", "trade", "nonAggression", "ceasefire"],
        required: true
      },
      targetOrgId: String,
      duration: Number,
      status: {
        type: String,
        enum: ["active", "expired"],
        default: "active"
      },
      timestamp: { type: Date, default: Date.now }
    }
  ],

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("OrgRelations", relationsSchema);