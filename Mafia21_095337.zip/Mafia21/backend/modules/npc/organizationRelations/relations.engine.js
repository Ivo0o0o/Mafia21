const OrgRelations = require("./relations.model");
const { v4: uuidv4 } = require("uuid");

async function getRelations(orgId) {
  let rel = await OrgRelations.findOne({ orgId });
  if (!rel) rel = await OrgRelations.create({ orgId });
  return rel;
}

// 1. Промяна на отношения
async function changeRelation(orgId, targetOrgId, amount) {
  const rel = await getRelations(orgId);

  let r = rel.relations.find(x => x.targetOrgId === targetOrgId);
  if (!r) {
    r = {
      targetOrgId,
      value: 0,
      status: "neutral"
    };
    rel.relations.push(r);
  }

  r.value = Math.max(-100, Math.min(100, r.value + amount));

  if (r.value >= 60) r.status = "ally";
  else if (r.value >= 20) r.status = "friendly";
  else if (r.value <= -60) r.status = "hostile";
  else if (r.value <= -20) r.status = "enemy";
  else r.status = "neutral";

  r.lastChange = new Date();
  rel.lastUpdate = new Date();

  await rel.save();
  return r;
}

// 2. Създаване на дипломатическо действие
async function createDiplomacy(orgId, payload) {
  const rel = await getRelations(orgId);

  const dip = {
    dipId: uuidv4(),
    type: payload.type,
    targetOrgId: payload.targetOrgId,
    duration: payload.duration || 72,
    status: "active"
  };

  rel.diplomacy.push(dip);
  rel.lastUpdate = new Date();

  await rel.save();
  return dip;
}

// 3. Тик на дипломация — изтичане на срокове
async function diplomacyTick(orgId) {
  const rel = await getRelations(orgId);

  const now = Date.now();

  for (const dip of rel.diplomacy) {
    if (dip.status !== "active") continue;

    const elapsed = (now - dip.timestamp.getTime()) / 3600000;
    if (elapsed >= dip.duration) {
      dip.status = "expired";
    }
  }

  rel.lastUpdate = new Date();
  await rel.save();
  return rel;
}

module.exports = {
  getRelations,
  changeRelation,
  createDiplomacy,
  diplomacyTick
};