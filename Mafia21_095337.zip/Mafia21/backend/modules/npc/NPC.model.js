const mongoose = require("mongoose");

const npcSchema = new mongoose.Schema({

  // BASIC INFO
  name: { type: String, required: true },
  title: { type: String, default: "" },
  description: { type: String, default: "" },

  // DISTRICT
  district: { type: String, default: "center" },

  // ROLE
  role: {
    type: String,
    enum: [
      "quest_giver",
      "shop",
      "trainer",
      "criminal",
      "police",
      "fixer",
      "story"
    ],
    default: "quest_giver"
  },

  // DIALOGUES
  dialogues: {
    greeting: { type: String, default: "" },
    missionOffer: { type: String, default: "" },
    missionComplete: { type: String, default: "" },
    shopWelcome: { type: String, default: "" }
  },

  // SHOP ITEMS (if role = shop)
  shopItems: [{
    itemId: { type: mongoose.Schema.Types.ObjectId, ref: "Item" },
    price: { type: Number, default: 100 }
  }],

  // TRAINER SKILLS (if role = trainer)
  trainerSkills: [{
    skill: { type: String },
    price: { type: Number, default: 50 },
    xpGain: { type: Number, default: 10 }
  }],

  // ACTIVE
  active: { type: Boolean, default: true }

}, { timestamps: true });

module.exports = mongoose.model("NPC", npcSchema);