const NpcMissionEngine = require("./npc.mission.engine");

module.exports = {

  async getMission(req, res) {
    try {
      const npc = req.npc; // идва от middleware или от база
      if (!npc) return res.status(404).json({ error: "NPC not found" });

      const mission = await NpcMissionEngine.getNpcMission(npc);

      if (!mission)
        return res.status(200).json({ success: true, mission: null });

      res.status(200).json({ success: true, mission });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};