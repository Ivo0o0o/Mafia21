const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const engine = require("./economy.engine");

// GOD: виж икономиката
router.get("/:npcId", godAccess, async (req, res) => {
  const eco = await engine.getEconomy(req.params.npcId);
  res.json(eco);
});

// GOD: добави доход
router.post("/income", godAccess, async (req, res) => {
  const { npcId, amount, source } = req.body;
  const eco = await engine.addIncome(npcId, amount, source);
  res.json(eco);
});

// GOD: добави разход
router.post("/expense", godAccess, async (req, res) => {
  const { npcId, amount, type } = req.body;
  const eco = await engine.addExpense(npcId, amount, type);
  res.json(eco);
});

// GOD: инвестиция
router.post("/invest", godAccess, async (req, res) => {
  const { npcId, businessName, amount } = req.body;
  const eco = await engine.invest(npcId, businessName, amount);
  res.json(eco);
});

// GOD: икономически тик
router.post("/tick", godAccess, async (req, res) => {
  const { npcId } = req.body;
  const eco = await engine.economicTick(npcId);
  res.json(eco);
});

module.exports = router;