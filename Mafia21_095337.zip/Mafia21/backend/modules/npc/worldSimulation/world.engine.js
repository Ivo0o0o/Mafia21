const WorldSimulation = require("./world.model");
const { v4: uuidv4 } = require("uuid");

async function getWorld() {
  let world = await WorldSimulation.findOne();
  if (!world) world = await WorldSimulation.create({});
  return world;
}

// 1. Създаване на война
async function createWar(attackerOrgId, defenderOrgId, intensity = 50) {
  const world = await getWorld();

  const war = {
    warId: uuidv4(),
    attackerOrgId,
    defenderOrgId,
    intensity,
    progress: 0,
    status: "active"
  };

  world.wars.push(war);
  world.lastUpdate = new Date();
  await world.save();
  return war;
}

// 2. Глобален икономически тик
function economyTick(world) {
  world.economy.globalIndex += Math.floor((Math.random() - 0.5) * 20);
  world.economy.inflation = Math.max(0, world.economy.inflation + (Math.random() - 0.5));
  world.economy.blackMarket += Math.floor((Math.random() - 0.5) * 15);
  world.economy.resourceValue += Math.floor((Math.random() - 0.5) * 10);
}

// 3. Глобален криминален тик
function crimeTick(world) {
  world.crime.globalCrimeRate = Math.max(0, world.crime.globalCrimeRate + (Math.random() - 0.5) * 5);
  world.crime.syndicateActivity = Math.max(0, world.crime.syndicateActivity + (Math.random() - 0.5) * 7);
  world.crime.corruption = Math.max(0, world.crime.corruption + (Math.random() - 0.5) * 4);
}

// 4. Пазарен тик
function marketTick(world) {
  world.markets.weaponsPrice = Math.max(10, world.markets.weaponsPrice + Math.floor((Math.random() - 0.5) * 10));
  world.markets.drugsPrice = Math.max(20, world.markets.drugsPrice + Math.floor((Math.random() - 0.5) * 15));
  world.markets.moneyLaunderingRate = Math.max(0.5, Math.min(0.95, world.markets.moneyLaunderingRate + (Math.random() - 0.5) * 0.02));
  world.markets.resourceDemand = Math.max(0, world.markets.resourceDemand + Math.floor((Math.random() - 0.5) * 10));
}

// 5. Тик на войни
function warsTick(world) {
  for (const war of world.wars) {
    if (war.status !== "active") continue;

    const gain = Math.floor(war.intensity * 0.4 + Math.random() * 20);
    war.progress = Math.min(100, war.progress + gain);

    if (war.progress >= 100) {
      war.status = "ended";
    }
  }
}

// 6. Глобален тик
async function worldTick() {
  const world = await getWorld();

  economyTick(world);
  crimeTick(world);
  marketTick(world);
  warsTick(world);

  world.lastUpdate = new Date();
  await world.save();
  return world;
}

module.exports = {
  getWorld,
  createWar,
  worldTick
};