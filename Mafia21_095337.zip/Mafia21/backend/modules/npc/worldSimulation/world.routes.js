const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./world.engine");

// GOD: виж света
router.get("/", godAccess, async (req, res) => {
  res.json(await engine.getWorld());
});

// GOD: създай война
router.post("/war", godAccess, async (req, res) => {
  const { attackerOrgId, defenderOrgId, intensity } = req.body;
  res.json(await engine.createWar(attackerOrgId, defenderOrgId, intensity));
});

// GOD: глобален тик
router.post("/tick", godAccess, async (req, res) => {
  res.json(await engine.worldTick());
});

module.exports = router;