const mongoose = require("mongoose");

const worldSchema = new mongoose.Schema({
  economy: {
    globalIndex: { type: Number, default: 1000 },
    inflation: { type: Number, default: 2 },
    blackMarket: { type: Number, default: 300 },
    resourceValue: { type: Number, default: 100 }
  },

  crime: {
    globalCrimeRate: { type: Number, default: 40 },
    syndicateActivity: { type: Number, default: 50 },
    corruption: { type: Number, default: 30 }
  },

  wars: [
    {
      warId: String,
      attackerOrgId: String,
      defenderOrgId: String,
      intensity: Number,
      progress: { type: Number, default: 0 },
      status: {
        type: String,
        enum: ["active", "ended"],
        default: "active"
      },
      timestamp: { type: Date, default: Date.now }
    }
  ],

  markets: {
    weaponsPrice: { type: Number, default: 100 },
    drugsPrice: { type: Number, default: 200 },
    moneyLaunderingRate: { type: Number, default: 0.85 },
    resourceDemand: { type: Number, default: 50 }
  },

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("WorldSimulation", worldSchema);