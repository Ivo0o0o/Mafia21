const mongoose = require("mongoose");

const territorySchema = new mongoose.Schema({
  orgId: { type: String, required: true },

  territories: [
    {
      district: String,
      control: { type: Number, default: 0 }, // 0–100
      stability: { type: Number, default: 50 }, // 0–100
      income: { type: Number, default: 0 },
      resistance: { type: Number, default: 20 }, // 0–100
      lastChange: { type: Date, default: Date.now }
    }
  ],

  conflicts: [
    {
      conflictId: String,
      district: String,
      attackerOrgId: String,
      defenderOrgId: String,
      intensity: Number,
      progress: { type: Number, default: 0 }, // 0–100
      status: {
        type: String,
        enum: ["active", "resolved"],
        default: "active"
      },
      timestamp: { type: Date, default: Date.now }
    }
  ],

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("OrgTerritory", territorySchema);