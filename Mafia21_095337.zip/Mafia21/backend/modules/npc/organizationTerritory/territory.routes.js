const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./territory.engine");

// GOD: виж територии
router.get("/:orgId", godAccess, async (req, res) => {
  res.json(await engine.getTerritory(req.params.orgId));
});

// GOD: добави територия
router.post("/add", godAccess, async (req, res) => {
  const { orgId, district } = req.body;
  res.json(await engine.addTerritory(orgId, district));
});

// GOD: промени контрол
router.post("/control", godAccess, async (req, res) => {
  const { orgId, district, amount } = req.body;
  res.json(await engine.changeControl(orgId, district, amount));
});

// GOD: създай конфликт
router.post("/conflict", godAccess, async (req, res) => {
  const { orgId, payload } = req.body;
  res.json(await engine.createConflict(orgId, payload));
});

// GOD: тик на територии
router.post("/tick", godAccess, async (req, res) => {
  const { orgId } = req.body;
  res.json(await engine.territoryTick(orgId));
});

module.exports = router;