const OrgTerritory = require("./territory.model");
const { v4: uuidv4 } = require("uuid");

async function getTerritory(orgId) {
  let terr = await OrgTerritory.findOne({ orgId });
  if (!terr) terr = await OrgTerritory.create({ orgId });
  return terr;
}

// 1. Добавяне на територия
async function addTerritory(orgId, district) {
  const terr = await getTerritory(orgId);

  terr.territories.push({
    district,
    control: 0,
    stability: 50,
    income: 0,
    resistance: 20
  });

  terr.lastUpdate = new Date();
  await terr.save();
  return terr;
}

// 2. Промяна на контрол
async function changeControl(orgId, district, amount) {
  const terr = await getTerritory(orgId);

  const t = terr.territories.find(x => x.district === district);
  if (!t) throw new Error("Territory not found");

  t.control = Math.max(0, Math.min(100, t.control + amount));
  t.stability = Math.max(0, Math.min(100, t.stability + amount * 0.3));
  t.income = Math.floor(t.control * 10);
  t.lastChange = new Date();

  terr.lastUpdate = new Date();
  await terr.save();
  return t;
}

// 3. Създаване на конфликт
async function createConflict(orgId, payload) {
  const terr = await getTerritory(orgId);

  const conflict = {
    conflictId: uuidv4(),
    district: payload.district,
    attackerOrgId: orgId,
    defenderOrgId: payload.defenderOrgId,
    intensity: payload.intensity || 50,
    progress: 0,
    status: "active"
  };

  terr.conflicts.push(conflict);
  terr.lastUpdate = new Date();

  await terr.save();
  return conflict;
}

// 4. Тик на територии — развитие на конфликти
async function territoryTick(orgId) {
  const terr = await getTerritory(orgId);

  for (const conflict of terr.conflicts) {
    if (conflict.status !== "active") continue;

    const baseGain = conflict.intensity * 0.4;
    const randomFactor = Math.random() * 20;
    const progressGain = Math.floor(baseGain + randomFactor);

    conflict.progress = Math.min(100, conflict.progress + progressGain);

    if (conflict.progress >= 100) {
      conflict.status = "resolved";

      const t = terr.territories.find(x => x.district === conflict.district);
      if (t) {
        t.control = 100;
        t.stability = Math.max(30, t.stability - conflict.intensity * 0.2);
        t.income = Math.floor(t.control * 10);
        t.lastChange = new Date();
      }
    }
  }

  terr.lastUpdate = new Date();
  await terr.save();
  return terr;
}

module.exports = {
  getTerritory,
  addTerritory,
  changeControl,
  createConflict,
  territoryTick
};