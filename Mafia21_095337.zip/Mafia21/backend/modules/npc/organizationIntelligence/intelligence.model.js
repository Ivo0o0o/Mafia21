const mongoose = require("mongoose");

const intelligenceSchema = new mongoose.Schema({
  orgId: { type: String, required: true },

  spies: { type: [String], default: [] },      // NPC IDs
  surveillanceTargets: { type: [String], default: [] }, // NPC IDs
  trackedDistricts: { type: [String], default: [] },

  intelReports: [
    {
      targetId: String,
      type: {
        type: String,
        enum: ["npc_activity", "organization", "district", "economy", "secret"],
        required: true
      },
      data: Object,
      timestamp: { type: Date, default: Date.now }
    }
  ],

  intelLevel: { type: Number, default: 10 },   // 0–100
  secrecyLevel: { type: Number, default: 10 }, // 0–100

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("OrgIntelligence", intelligenceSchema);