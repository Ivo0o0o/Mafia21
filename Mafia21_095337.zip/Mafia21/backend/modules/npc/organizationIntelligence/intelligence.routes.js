const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./intelligence.engine");

// GOD: виж разузнаването
router.get("/:orgId", godAccess, async (req, res) => {
  res.json(await engine.getIntel(req.params.orgId));
});

// GOD: добави шпионин
router.post("/addSpy", godAccess, async (req, res) => {
  const { orgId, npcId } = req.body;
  res.json(await engine.addSpy(orgId, npcId));
});

// GOD: следи NPC
router.post("/trackNpc", godAccess, async (req, res) => {
  const { orgId, targetId } = req.body;
  res.json(await engine.trackNpc(orgId, targetId));
});

// GOD: следи район
router.post("/trackDistrict", godAccess, async (req, res) => {
  const { orgId, district } = req.body;
  res.json(await engine.trackDistrict(orgId, district));
});

// GOD: NPC доклад
router.post("/npcReport", godAccess, async (req, res) => {
  const { orgId, targetId } = req.body;
  res.json(await engine.generateNpcReport(orgId, targetId));
});

// GOD: районен доклад
router.post("/districtReport", godAccess, async (req, res) => {
  const { orgId, district } = req.body;
  res.json(await engine.generateDistrictReport(orgId, district));
});

// GOD: intelligence tick
router.post("/tick", godAccess, async (req, res) => {
  const { orgId } = req.body;
  res.json(await engine.intelligenceTick(orgId));
});

module.exports = router;