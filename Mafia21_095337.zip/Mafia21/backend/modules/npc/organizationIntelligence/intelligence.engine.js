const OrgIntelligence = require("./intelligence.model");
const NPCPersonality = require("../personality.model");
const NPCLife = require("../life.model");
const NPCSocial = require("../social.model");
const NPCEconomy = require("../economy.model");
const OrgControl = require("../organizationControl/orgControl.model");

async function getIntel(orgId) {
  let intel = await OrgIntelligence.findOne({ orgId });
  if (!intel) intel = await OrgIntelligence.create({ orgId });
  return intel;
}

// 1. Добавяне на шпиони
async function addSpy(orgId, npcId) {
  const intel = await getIntel(orgId);
  if (!intel.spies.includes(npcId)) intel.spies.push(npcId);
  intel.intelLevel += 5;
  await intel.save();
  return intel;
}

// 2. Следене на NPC
async function trackNpc(orgId, targetId) {
  const intel = await getIntel(orgId);
  if (!intel.surveillanceTargets.includes(targetId)) {
    intel.surveillanceTargets.push(targetId);
  }
  intel.intelLevel += 3;
  await intel.save();
  return intel;
}

// 3. Следене на район
async function trackDistrict(orgId, district) {
  const intel = await getIntel(orgId);
  if (!intel.trackedDistricts.includes(district)) {
    intel.trackedDistricts.push(district);
  }
  intel.intelLevel += 2;
  await intel.save();
  return intel;
}

// 4. Генериране на доклад за NPC
async function generateNpcReport(orgId, targetId) {
  const intel = await getIntel(orgId);

  const personality = await NPCPersonality.findOne({ npcId: targetId });
  const life = await NPCLife.findOne({ npcId: targetId });
  const social = await NPCSocial.findOne({ npcId: targetId });
  const economy = await NPCEconomy.findOne({ npcId: targetId });

  const report = {
    targetId,
    type: "npc_activity",
    data: {
      personality,
      life,
      social,
      economy
    }
  };

  intel.intelReports.push(report);
  intel.intelLevel += 5;
  intel.lastUpdate = new Date();

  await intel.save();
  return report;
}

// 5. Доклад за район
async function generateDistrictReport(orgId, district) {
  const intel = await getIntel(orgId);

  const control = await OrgControl.findOne({ district });

  const report = {
    targetId: district,
    type: "district",
    data: {
      control
    }
  };

  intel.intelReports.push(report);
  intel.intelLevel += 4;
  intel.lastUpdate = new Date();

  await intel.save();
  return report;
}

// 6. Пълен Intelligence Tick
async function intelligenceTick(orgId) {
  const intel = await getIntel(orgId);

  intel.intelLevel += intel.spies.length * 0.5;
  intel.secrecyLevel += intel.surveillanceTargets.length * 0.3;

  intel.intelLevel = Math.min(100, intel.intelLevel);
  intel.secrecyLevel = Math.min(100, intel.secrecyLevel);

  intel.lastUpdate = new Date();
  await intel.save();

  return intel;
}

module.exports = {
  getIntel,
  addSpy,
  trackNpc,
  trackDistrict,
  generateNpcReport,
  generateDistrictReport,
  intelligenceTick
};