const Mission = require("../missions/mission.model");

module.exports = {

  // NPC decides which mission to give
  async getNpcMission(npc) {

    // 1) Filter missions by district
    let missions = await Mission.find({ active: true });

    if (npc.district) {
      missions = missions.filter(m => m.district === npc.district);
    }

    // 2) Filter by NPC personality
    if (npc.personality) {
      missions = missions.filter(m => {
        if (npc.personality === "aggressive") return ["kill", "sabotage"].includes(m.type);
        if (npc.personality === "friendly") return ["delivery", "collect"].includes(m.type);
        if (npc.personality === "criminal") return ["steal", "craft", "kill"].includes(m.type);
        if (npc.personality === "dealer") return ["delivery", "craft"].includes(m.type);
        return true;
      });
    }

    // 3) Filter by NPC organization
    if (npc.organizationId) {
      missions = missions.filter(m => m.type !== "sabotage"); // org NPCs don't sabotage their own org
    }

    // 4) Filter by difficulty (NPC level)
    missions = missions.filter(m => m.difficulty <= npc.level + 1);

    // 5) Random mission
    if (missions.length === 0) return null;

    const random = missions[Math.floor(Math.random() * missions.length)];
    return random;
  }
};