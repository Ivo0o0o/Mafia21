const NpcAI = require("./npcAI.model");
const User = require("../users/user.model");

async function updateMood(npcId, userId) {
  const npc = await NpcAI.findOne({ npcId });
  const user = await User.findById(userId);

  if (!npc || !user) throw new Error("NPC or user not found");

  // Примерна логика:
  if (user.skills.intimidation > 50) {
    npc.mood = "scared";
    npc.fearLevel += 20;
  }

  if (user.skills.shooting > 70) {
    npc.mood = "aggressive";
    npc.aggressionLevel += 30;
  }

  if (user.skills.negotiation > 60) {
    npc.mood = "calm";
    npc.fearLevel -= 10;
    npc.aggressionLevel -= 10;
  }

  npc.lastInteraction = new Date();
  await npc.save();

  return npc;
}

async function patrol(npcId) {
  const npc = await NpcAI.findOne({ npcId });
  if (!npc) throw new Error("NPC not found");

  if (!npc.patrolRoute.length) return npc;

  // NPC се движи към следващата точка
  const nextPoint = npc.patrolRoute[0];

  npc.location = nextPoint;

  // Завъртаме патрулната точка
  npc.patrolRoute.push(npc.patrolRoute.shift());

  await npc.save();
  return npc;
}

module.exports = {
  updateMood,
  patrol
};