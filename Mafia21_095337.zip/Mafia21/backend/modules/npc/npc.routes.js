const router = require("express").Router();
const NPCController = require("./npc.controller");

// GET all NPCs
router.get("/", NPCController.getAll);

// GET single NPC
router.get("/:id", NPCController.get);

// BUY item from NPC shop
router.post("/:id/buy", NPCController.buy);

// TRAIN skill at NPC trainer
router.post("/:id/train", NPCController.train);

module.exports = router;