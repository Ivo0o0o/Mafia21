const mongoose = require("mongoose");

const influenceSchema = new mongoose.Schema({

  // Район
  district: { type: String, required: true },

  // Влияние на организацията в района
  clanInfluence: { type: Number, default: 0 },

  // Престъпност в района
  crimeLevel: { type: Number, default: 0 },

  // Икономически бонуси
  economyLevel: { type: Number, default: 0 },

  // Последна промяна
  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("Influence", influenceSchema);