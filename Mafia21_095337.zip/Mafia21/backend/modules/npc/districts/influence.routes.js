const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./influence.engine");

// ---------------------------------------------
// GOD: Update influence for district
// ---------------------------------------------
router.post("/update", godAccess, async (req, res) => {
  try {
    const { district, clanInfluence, crimeLevel, economyLevel } = req.body;

    if (!district) {
      return res.status(400).json({ error: "Missing district" });
    }

    const result = await engine.updateInfluence(district, {
      clanInfluence,
      crimeLevel,
      economyLevel
    });

    res.json(result);

  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ---------------------------------------------
// GOD: Get influence for district
// ---------------------------------------------
router.get("/:district", godAccess, async (req, res) => {
  const result = await engine.getInfluence(req.params.district);
  res.json(result);
});

// ---------------------------------------------
// GOD: List all districts influence (Map View)
// ---------------------------------------------
router.get("/", godAccess, async (req, res) => {
  const result = await engine.listAll();
  res.json(result);
});

module.exports = router;