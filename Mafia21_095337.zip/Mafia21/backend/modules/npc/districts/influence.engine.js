const Influence = require("./influence.model");

class InfluenceEngine {

  // -----------------------------------------
  // UPDATE INFLUENCE (used by District Control)
  // -----------------------------------------
  async updateInfluence(district, { clanInfluence, crimeLevel, economyLevel }) {
    let inf = await Influence.findOne({ district });

    if (!inf) {
      inf = await Influence.create({
        district,
        clanInfluence: clanInfluence || 0,
        crimeLevel: crimeLevel || 0,
        economyLevel: economyLevel || 0
      });
      return inf;
    }

    if (clanInfluence !== undefined) inf.clanInfluence = clanInfluence;
    if (crimeLevel !== undefined) inf.crimeLevel = crimeLevel;
    if (economyLevel !== undefined) inf.economyLevel = economyLevel;

    inf.lastUpdate = Date.now();
    await inf.save();

    return inf;
  }

  // -----------------------------------------
  // GET INFLUENCE FOR DISTRICT
  // -----------------------------------------
  async getInfluence(district) {
    return await Influence.findOne({ district });
  }

  // -----------------------------------------
  // LIST ALL DISTRICTS (for map)
  // -----------------------------------------
  async listAll() {
    return await Influence.find().sort({ clanInfluence: -1 });
  }

  // -----------------------------------------
  // DECAY SYSTEM (WorldTick PRO)
  // -----------------------------------------
  async decayInfluence(district, amount = 2) {
    const inf = await Influence.findOne({ district });
    if (!inf) return null;

    inf.clanInfluence -= amount;
    if (inf.clanInfluence < 0) inf.clanInfluence = 0;

    inf.crimeLevel -= Math.floor(amount * 0.5);
    if (inf.crimeLevel < 0) inf.crimeLevel = 0;

    inf.economyLevel -= Math.floor(amount * 0.3);
    if (inf.economyLevel < 0) inf.economyLevel = 0;

    inf.lastUpdate = Date.now();
    await inf.save();

    return inf;
  }
}

module.exports = new InfluenceEngine();