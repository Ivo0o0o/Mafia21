const Overseer = require("./overseer.model");
const WorldEvent = require("../worldEvents/worldEvents.model");
const CitySim = require("../citySimulation/citySim.model");
const OrgOperations = require("../organizationOperations/operations.model");
const PlayerInteraction = require("../playerInteraction/playerInteraction.model");

async function getOverseer() {
  let o = await Overseer.findOne({ worldId: "default" });
  if (!o) o = await Overseer.create({});
  return o;
}

// Rule #1 – никакви задачи без контекст:
// мисия/събитие трябва да засяга поне 2:
// NPC, клан, събитие, репутация, баланс на сила, икономика, отношения.

function hasMeaning(context) {
  let score = 0;
  if (context.npcId) score++;
  if (context.orgId) score++;
  if (context.eventType) score++;
  if (context.affectsReputation) score++;
  if (context.affectsPowerBalance) score++;
  if (context.affectsEconomy) score++;
  if (context.affectsRelations) score++;
  return score >= 2;
}

// 1. Обновяване на метрики от света
async function updateMetrics() {
  const o = await getOverseer();

  const events = await WorldEvent.find().sort({ timestamp: -1 }).limit(10);
  const cities = await CitySim.find();
  const players = await PlayerInteraction.find();

  // crimePressure
  o.metrics.crimePressure = Math.min(
    100,
    Math.max(
      0,
      cities.reduce((sum, c) => sum + c.crimeLevel, 0) / (cities.length || 1)
    )
  );

  // economicStability
  o.metrics.economicStability = Math.min(
    100,
    Math.max(
      0,
      cities.reduce((sum, c) => sum + c.economyLevel, 0) / (cities.length || 1)
    )
  );

  // npcActivity
  o.metrics.npcActivity = Math.min(
    100,
    Math.max(
      0,
      cities.reduce((sum, c) => sum + c.npcActivity, 0) / (cities.length || 1)
    )
  );

  // playerInfluence
  o.metrics.playerInfluence = Math.min(
    100,
    Math.max(
      0,
      players.reduce((sum, p) => sum + p.reputation + p.respect, 0) /
        ((players.length || 1) * 2)
    )
  );

  // worldTension – базирано на събития
  o.metrics.worldTension = Math.min(
    100,
    Math.max(
      0,
      events.reduce((sum, e) => sum + (e.impact.diplomacy || 0), 0) +
        events.length * 2
    )
  );

  // chaosIndex – комбинация от crime + random + събития
  o.metrics.chaosIndex = Math.min(
    100,
    Math.max(
      0,
      o.metrics.crimePressure * 0.3 +
        (events.length || 0) * 3 +
        Math.floor(Math.random() * 10)
    )
  );

  o.lastUpdate = new Date();
  await o.save();
  return o;
}

// 2. Dynamic Frames – регулиране на света
async function applyDynamicFrames() {
  const o = await getOverseer();

  // ако хаосът е висок → намаляваме събитията
  if (o.metrics.chaosIndex > 70) {
    o.lastDecision = "reduce_events";
  }
  // ако скуката е висока (ниско напрежение, ниска престъпност) → увеличаваме събитията
  else if (o.metrics.worldTension < 20 && o.metrics.crimePressure < 20) {
    o.lastDecision = "increase_events";
  }
  // ако играчът доминира → светът му се противопоставя
  else if (o.metrics.playerInfluence > 70) {
    o.lastDecision = "challenge_player";
  } else {
    o.lastDecision = "idle";
  }

  await o.save();
  return o;
}

// 3. Mission / Event Suggestions (логика със смисъл)
async function generateMeaningfulAction() {
  const o = await getOverseer();

  const contextBase = {
    npcId: null,
    orgId: null,
    eventType: null,
    affectsReputation: false,
    affectsPowerBalance: false,
    affectsEconomy: false,
    affectsRelations: false
  };

  let suggestion = null;

  switch (o.lastDecision) {
    case "challenge_player":
      suggestion = {
        type: "mission",
        title: "Намери доносника в твоя клан",
        context: {
          ...contextBase,
          orgId: "someOrg",
          affectsReputation: true,
          affectsPowerBalance: true,
          affectsRelations: true
        }
      };
      break;

    case "increase_events":
      suggestion = {
        type: "event",
        title: "Нов черен пазар набира сила",
        context: {
          ...contextBase,
          eventType: "black_market_boom",
          affectsEconomy: true,
          affectsPowerBalance: true
        }
      };
      break;

    case "reduce_events":
      suggestion = {
        type: "state",
        title: "Светът се опитва да се успокои",
        context: {
          ...contextBase,
          affectsEconomy: true,
          affectsRelations: true
        }
      };
      break;

    default:
      suggestion = {
        type: "none",
        title: "Няма нужда от ескалация",
        context: contextBase
      };
      break;
  }

  if (!hasMeaning(suggestion.context)) {
    return {
      ...suggestion,
      rejectedByRule1: true
    };
  }

  return suggestion;
}

// 4. Overseer Tick – централна стъпка
async function overseerTick() {
  const o1 = await updateMetrics();
  const o2 = await applyDynamicFrames();
  const action = await generateMeaningfulAction();

  return {
    overseer: o2,
    action
  };
}

module.exports = {
  getOverseer,
  updateMetrics,
  applyDynamicFrames,
  generateMeaningfulAction,
  overseerTick
};