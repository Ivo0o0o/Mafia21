const mongoose = require("mongoose");

const overseerSchema = new mongoose.Schema({
  worldId: { type: String, default: "default" },

  metrics: {
    crimePressure: { type: Number, default: 30 },      // престъпност
    economicStability: { type: Number, default: 50 },  // икономика
    clanPowerBalance: { type: Number, default: 50 },   // баланс на кланове
    npcActivity: { type: Number, default: 50 },        // активност
    playerInfluence: { type: Number, default: 20 },    // влияние на играча
    worldTension: { type: Number, default: 30 },       // напрежение
    chaosIndex: { type: Number, default: 10 }          // хаос
  },

  lastDecision: {
    type: String,
    default: "idle"
  },

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("Overseer", overseerSchema);