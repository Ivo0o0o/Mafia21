const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const engine = require("./overseer.engine");

// GOD: виж Overseer
router.get("/", godAccess, async (req, res) => {
  const o = await engine.getOverseer();
  res.json(o);
});

// GOD: ръчен metrics update
router.post("/updateMetrics", godAccess, async (req, res) => {
  const o = await engine.updateMetrics();
  res.json(o);
});

// GOD: overseer tick (пълна логика)
router.post("/tick", godAccess, async (req, res) => {
  const result = await engine.overseerTick();
  res.json(result);
});

// GOD: само suggestion
router.get("/suggestion", godAccess, async (req, res) => {
  const action = await engine.generateMeaningfulAction();
  res.json(action);
});

module.exports = router;