const mongoose = require("mongoose");

const strategySchema = new mongoose.Schema({
  orgId: { type: String, required: true },

  // текуща стратегическа линия
  currentStrategy: {
    type: String, // war / peace / expand / retreat / defend / opportunistic
    default: "peace"
  },

  // мотиви
  motives: {
    aggression: { type: Number, default: 50 },   // 0–100
    greed: { type: Number, default: 50 },        // 0–100
    fear: { type: Number, default: 50 },         // 0–100
    ambition: { type: Number, default: 50 },     // 0–100
    stability: { type: Number, default: 50 }     // 0–100
  },

  // последно решение
  lastDecision: { type: String, default: "" },
  lastTarget: { type: String, default: "" },
  timestamp: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("Strategy", strategySchema);