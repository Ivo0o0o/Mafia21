const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./strategy.engine");

// GOD: виж стратегия
router.get("/:orgId", godAccess, async (req, res) => {
  res.json(await engine.getStrategy(req.params.orgId));
});

// GOD: ръчно задаване
router.post("/set", godAccess, async (req, res) => {
  const { orgId, strategy } = req.body;
  res.json(await engine.setStrategy(orgId, strategy));
});

// GOD: изчисляване
router.post("/compute", godAccess, async (req, res) => {
  const { orgId } = req.body;
  res.json(await engine.computeStrategy(orgId));
});

// GOD: тик
router.post("/tick", godAccess, async (req, res) => {
  res.json(await engine.strategyTick());
});

module.exports = router;