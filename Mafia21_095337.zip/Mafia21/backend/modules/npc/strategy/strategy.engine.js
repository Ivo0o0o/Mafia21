const Strategy = require("./strategy.model");
const Diplomacy = require("../diplomacy/diplomacy.model");
const Territory = require("../territory/territory.model");

async function getStrategy(orgId) {
  let strat = await Strategy.findOne({ orgId });
  if (!strat) strat = await Strategy.create({ orgId });
  return strat;
}

// вътрешна функция: оценка на заплахи
function evaluateThreat(dip) {
  let threat = 0;
  for (const [targetId, host] of dip.hostility.entries()) {
    threat += host;
  }
  return Math.min(100, threat);
}

// вътрешна функция: оценка на възможности
function evaluateOpportunity(terr) {
  let opp = 0;
  for (const zone of terr.zones) {
    if (zone.control < 40 && zone.influence > 60) opp += 20;
    if (zone.dominance > 70) opp += 10;
  }
  return Math.min(100, opp);
}

// основна стратегическа логика
async function computeStrategy(orgId) {
  const strat = await getStrategy(orgId);
  const dip = await Diplomacy.findOne({ orgId });
  const terr = await Territory.findOne({ orgId });

  const threat = dip ? evaluateThreat(dip) : 0;
  const opportunity = terr ? evaluateOpportunity(terr) : 0;

  const { aggression, greed, fear, ambition, stability } = strat.motives;

  let decision = "peace";

  // логика за война
  if (aggression + threat > 120 && fear < 40) {
    decision = "war";
  }

  // логика за експанзия
  else if (ambition + opportunity > 120 && stability > 40) {
    decision = "expand";
  }

  // логика за отстъпление
  else if (fear + threat > 130) {
    decision = "retreat";
  }

  // логика за защита
  else if (stability + threat > 110) {
    decision = "defend";
  }

  // опортюнистично поведение
  else if (greed + opportunity > 100) {
    decision = "opportunistic";
  }

  strat.currentStrategy = decision;
  strat.lastDecision = decision;
  strat.timestamp = new Date();

  await strat.save();
  return strat;
}

// ръчно задаване на стратегия
async function setStrategy(orgId, strategy) {
  const strat = await getStrategy(orgId);
  strat.currentStrategy = strategy;
  strat.lastDecision = strategy;
  strat.timestamp = new Date();
  await strat.save();
  return strat;
}

// стратегически тик
async function strategyTick() {
  const all = await Strategy.find();
  const results = [];

  for (const strat of all) {
    const updated = await computeStrategy(strat.orgId);
    results.push(updated);
  }

  return results;
}

module.exports = {
  getStrategy,
  computeStrategy,
  setStrategy,
  strategyTick
};