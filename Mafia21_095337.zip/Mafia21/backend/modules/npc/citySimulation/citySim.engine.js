const CitySim = require("./citySim.model");
const OrgControl = require("../organizationControl/orgControl.model");
const WorldEvent = require("../worldEvents/worldEvents.model");
const NPCLife = require("../life.model");

async function getDistrict(district) {
  let sim = await CitySim.findOne({ district });
  if (!sim) sim = await CitySim.create({ district });
  return sim;
}

// 1. Обновяване на престъпност
async function updateCrime(sim, control) {
  if (control) {
    sim.crimeLevel += control.crimeBoost * 0.5;
    sim.clanInfluence = control.controlLevel;
  }

  // NPC активност влияе
  sim.crimeLevel += (sim.npcActivity - 50) * 0.1;

  sim.crimeLevel = Math.max(0, Math.min(100, sim.crimeLevel));
}

// 2. Обновяване на икономика
async function updateEconomy(sim, control) {
  if (control) {
    sim.economyLevel += control.incomeBoost * 0.3;
  }

  // престъпност влияе негативно
  sim.economyLevel -= sim.crimeLevel * 0.1;

  sim.economyLevel = Math.max(0, Math.min(100, sim.economyLevel));
}

// 3. Обновяване на NPC активност
async function updateNpcActivity(sim) {
  const hour = new Date().getHours();

  if (hour >= 6 && hour < 12) sim.npcActivity = 60;     // сутрин
  else if (hour >= 12 && hour < 18) sim.npcActivity = 80; // ден
  else if (hour >= 18 && hour < 24) sim.npcActivity = 70; // вечер
  else sim.npcActivity = 30;                             // нощ
}

// 4. Обновяване на настроение на населението
async function updatePopulationMood(sim) {
  if (sim.crimeLevel > 70) sim.populationMood = "scared";
  else if (sim.crimeLevel > 50) sim.populationMood = "worried";
  else if (sim.economyLevel < 20) sim.populationMood = "angry";
  else sim.populationMood = "calm";
}

// 5. Влияние от глобални събития
async function applyWorldEvents(sim) {
  const events = await WorldEvent.find().sort({ timestamp: -1 }).limit(5);

  for (const e of events) {
    sim.crimeLevel += e.impact.crime || 0;
    sim.economyLevel += e.impact.economy || 0;
  }
}

// 6. Пълен City Simulation Tick
async function cityTick(district) {
  const sim = await getDistrict(district);
  const control = await OrgControl.findOne({ district });

  await updateNpcActivity(sim);
  await updateCrime(sim, control);
  await updateEconomy(sim, control);
  await updatePopulationMood(sim);
  await applyWorldEvents(sim);

  sim.lastUpdate = new Date();
  await sim.save();

  return sim;
}

module.exports = {
  getDistrict,
  cityTick
};