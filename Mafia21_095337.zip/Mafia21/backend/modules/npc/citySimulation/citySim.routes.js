const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./citySim.engine");

// GOD: виж район
router.get("/:district", godAccess, async (req, res) => {
  res.json(await engine.getDistrict(req.params.district));
});

// GOD: city tick
router.post("/tick", godAccess, async (req, res) => {
  const { district } = req.body;
  res.json(await engine.cityTick(district));
});

module.exports = router;