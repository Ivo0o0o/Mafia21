const mongoose = require("mongoose");

const citySimSchema = new mongoose.Schema({
  district: { type: String, required: true },

  crimeLevel: { type: Number, default: 10 },        // 0–100
  economyLevel: { type: Number, default: 50 },      // 0–100
  npcActivity: { type: Number, default: 50 },       // 0–100
  clanInfluence: { type: Number, default: 0 },      // 0–100

  populationMood: {
    type: String,
    enum: ["calm", "worried", "scared", "angry", "rebellious"],
    default: "calm"
  },

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("CitySim", citySimSchema);