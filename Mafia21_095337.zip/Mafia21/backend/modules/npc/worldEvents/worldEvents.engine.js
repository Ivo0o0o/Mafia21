const WorldEvent = require("./worldEvents.model");
const { v4: uuidv4 } = require("uuid");
const OrgEconomy = require("../organizationEconomy/orgEconomy.model");
const OrgDiplomacy = require("../organizationDiplomacy/diplomacy.model");
const OrgLogistics = require("../organizationLogistics/logistics.model");
const OrgControl = require("../organizationControl/orgControl.model");
const NPCLife = require("../life.model");

async function createEvent(type, impact, affectedDistricts = [], affectedOrgs = []) {
  const event = await WorldEvent.create({
    eventId: uuidv4(),
    type,
    impact,
    affectedDistricts,
    affectedOrgs
  });

  await applyEventImpact(event);
  return event;
}

async function applyEventImpact(event) {
  const { impact, affectedOrgs, affectedDistricts } = event;

  // 1. Икономика
  for (const orgId of affectedOrgs) {
    const eco = await OrgEconomy.findOne({ orgId });
    if (!eco) continue;

    eco.wallet.money += impact.economy || 0;
    eco.wallet.income += Math.max(0, impact.economy || 0);
    eco.wallet.expenses += Math.max(0, -(impact.economy || 0));

    await eco.save();
  }

  // 2. Дипломация
  if (impact.diplomacy) {
    for (const orgId of affectedOrgs) {
      await OrgDiplomacy.updateMany(
        { $or: [{ orgA: orgId }, { orgB: orgId }] },
        { $inc: { tensionLevel: impact.diplomacy } }
      );
    }
  }

  // 3. Логистика
  if (impact.logistics) {
    for (const orgId of affectedOrgs) {
      const log = await OrgLogistics.findOne({ orgId });
      if (!log) continue;

      for (const wh of log.warehouses) {
        wh.stored.resources += impact.logistics;
      }

      await log.save();
    }
  }

  // 4. Контрол над райони
  if (impact.crime) {
    for (const district of affectedDistricts) {
      await OrgControl.updateMany(
        { district },
        { $inc: { crimeBoost: impact.crime } }
      );
    }
  }

  // 5. NPC настроение
  if (impact.npcMood) {
    await NPCLife.updateMany(
      {},
      { $set: { emotionalState: impact.npcMood > 0 ? "motivated" : "scared" } }
    );
  }
}

async function listEvents() {
  return await WorldEvent.find().sort({ timestamp: -1 });
}

async function worldTick() {
  // автоматично генериране на събитие
  const types = [
    "economic_crisis",
    "police_raid",
    "gang_war",
    "black_market_boom",
    "district_uprising",
    "npc_strike",
    "intel_leak",
    "resource_shortage",
    "weather_disaster"
  ];

  const type = types[Math.floor(Math.random() * types.length)];

  const impact = {
    economy: Math.floor(Math.random() * 2000) - 1000,
    crime: Math.floor(Math.random() * 20) - 10,
    npcMood: Math.floor(Math.random() * 2) === 0 ? -1 : 1,
    clanPower: Math.floor(Math.random() * 10) - 5,
    logistics: Math.floor(Math.random() * 50) - 25,
    diplomacy: Math.floor(Math.random() * 20) - 10
  };

  const event = await createEvent(type, impact, [], []);
  return event;
}

module.exports = {
  createEvent,
  applyEventImpact,
  listEvents,
  worldTick
};