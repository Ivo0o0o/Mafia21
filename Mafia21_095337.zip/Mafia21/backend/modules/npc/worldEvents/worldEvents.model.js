const mongoose = require("mongoose");

const worldEventSchema = new mongoose.Schema({
  eventId: { type: String, required: true },
  type: {
    type: String,
    enum: [
      "economic_crisis",
      "police_raid",
      "gang_war",
      "black_market_boom",
      "district_uprising",
      "npc_strike",
      "intel_leak",
      "resource_shortage",
      "weather_disaster"
    ],
    required: true
  },

  impact: {
    economy: Number,
    crime: Number,
    npcMood: Number,
    clanPower: Number,
    logistics: Number,
    diplomacy: Number
  },

  affectedDistricts: [String],
  affectedOrgs: [String],
  timestamp: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("WorldEvent", worldEventSchema);