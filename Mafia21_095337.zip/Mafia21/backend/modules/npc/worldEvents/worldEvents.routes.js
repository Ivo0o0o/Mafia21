const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./worldEvents.engine");

// GOD: създай събитие
router.post("/create", godAccess, async (req, res) => {
  const { type, impact, affectedDistricts, affectedOrgs } = req.body;
  res.json(await engine.createEvent(type, impact, affectedDistricts, affectedOrgs));
});

// GOD: всички събития
router.get("/", godAccess, async (req, res) => {
  res.json(await engine.listEvents());
});

// GOD: world tick
router.post("/tick", godAccess, async (req, res) => {
  res.json(await engine.worldTick());
});

module.exports = router;