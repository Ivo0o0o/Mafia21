const mongoose = require("mongoose");

const npcEconomySchema = new mongoose.Schema({
  npcId: { type: String, required: true },

  wallet: {
    money: { type: Number, default: 100 },
    income: { type: Number, default: 0 },
    expenses: { type: Number, default: 0 }
  },

  assets: {
    businesses: { type: Array, default: [] },
    vehicles: { type: Array, default: [] },
    weapons: { type: Array, default: [] },
    equipment: { type: Array, default: [] }
  },

  incomeSources: {
    extortion: { type: Number, default: 0 },
    hacking: { type: Number, default: 0 },
    theft: { type: Number, default: 0 },
    deals: { type: Number, default: 0 },
    missions: { type: Number, default: 0 },
    clanOperations: { type: Number, default: 0 } // ако искаш кланови операции
  },

  expensesList: {
    bribes: { type: Number, default: 0 },
    weapons: { type: Number, default: 0 },
    transport: { type: Number, default: 0 },
    services: { type: Number, default: 0 },
    investments: { type: Number, default: 0 },
    clanFunding: { type: Number, default: 0 } // финансиране на клан/организация
  },

  financialBehavior: {
    type: String,
    enum: ["saving", "risky", "aggressive", "greedy", "strategic"],
    default: "strategic"
  },

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("NPCEconomy", npcEconomySchema);