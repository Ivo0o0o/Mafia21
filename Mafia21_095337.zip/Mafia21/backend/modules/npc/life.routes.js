const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const { getLife, updateLife } = require("./life.engine");

// GOD: виж NPC живот
router.get("/:npcId", godAccess, async (req, res) => {
  const life = await getLife(req.params.npcId);
  res.json(life);
});

// GOD: обнови NPC живот
router.post("/update", godAccess, async (req, res) => {
  const { npcId } = req.body;
  const life = await updateLife(npcId);
  res.json(life);
});

module.exports = router;