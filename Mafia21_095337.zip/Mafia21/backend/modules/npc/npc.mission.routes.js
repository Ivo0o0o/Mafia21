const router = require("express").Router();
const NpcMissionController = require("./npc.mission.controller");

// GET /npc/:id/mission
router.get("/:id/mission", async (req, res, next) => {
  // Тук зареждаме NPC от базата
  const NPC = require("./npc.model");

  try {
    const npc = await NPC.findById(req.params.id);
    if (!npc) return res.status(404).json({ error: "NPC not found" });

    req.npc = npc;
    next();

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}, NpcMissionController.getMission);

module.exports = router;