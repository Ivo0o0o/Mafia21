// =========================
// NPC CONTROLLER (FINAL)
// =========================
//
// Работи с NPC.service.js и NPC.interaction.js
// =========================

const NPC = require('./NPC.model');
const NPCService = require('./NPC.service');
const NPCInteraction = require('./NPC.interaction');
const User = require('../users/User.model');

module.exports = {

  // =========================
  // ВЗИМАНЕ НА ВСИЧКИ NPC
  // =========================
  getAll: async (req, res) => {
    try {
      const npcs = await NPC.find();
      res.json(npcs);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // =========================
  // ВЗИМАНЕ НА NPC ПО РАЙОН
  // =========================
  getByDistrict: async (req, res) => {
    try {
      const { district } = req.params;
      const npcs = await NPCService.getNPCsByDistrict(district);
      res.json(npcs);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // =========================
  // СЪЗДАВАНЕ НА NPC (ADMIN)
  // =========================
  create: async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Само админ може да създава NPC' });
      }

      const npc = await NPC.create(req.body);
      res.json({ message: 'NPC създаден', npc });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // =========================
  // NPC РЕАГИРА НА ПРЕСТЪПЛЕНИЕ
  // =========================
  reactToCrime: async (req, res) => {
    try {
      const { district } = req.params;
      const { severity } = req.body;

      await NPCService.npcReactToCrime(district, severity);

      res.json({ message: `NPC в ${district} реагираха на престъпление.` });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // =========================
  // NPC АТАКУВА БИЗНЕС
  // =========================
  attackBusiness: async (req, res) => {
    try {
      const { district } = req.params;

      const result = await NPCService.npcAttackBusiness(district);

      if (!result) {
        return res.json({ message: 'Няма NPC или бизнеси в този район.' });
      }

      res.json({
        message: `${result.npc} атакува ${result.business}`,
        damage: result.damage
      });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // =========================
  // NPC ВЛИЯЕ НА DISTRICT
  // =========================
  applyDistrictEffects: async (req, res) => {
    try {
      const { district } = req.params;

      await NPCService.applyDistrictEffects(district);

      res.json({ message: `NPC ефектите са приложени върху ${district}.` });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // =========================
  // NPC ВЛИЯЕ НА ИГРАЧА
  // =========================
  affectPlayer: async (req, res) => {
    try {
      const { district } = req.params;
      const userId = req.user.id;

      await NPCService.affectPlayerInfluence(userId, district);

      res.json({ message: 'NPC повлияха на влиянието ти в района.' });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // =========================
  // NPC INTERACT (старото ти действие)
  // =========================
  interact: async (req, res) => {
    try {
      const { npcId } = req.params;
      const npc = await NPC.findById(npcId);
      if (!npc) return res.status(404).json({ error: 'NPC не е намерен' });

      const player = await User.findById(req.user.id);

      // NPC влияние върху района
      await NPCInteraction.applyDistrictEffects(npc.district);

      // NPC може да атакува играча
      const attackResult = await NPCInteraction.attackBusiness(npc.district);

      res.json({
        npc,
        attackResult,
        message: attackResult?.damage
          ? `${npc.name} нанесе щета на бизнес в района.`
          : `${npc.name} не атакува този път.`
      });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};