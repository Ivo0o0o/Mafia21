const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./operations.engine");

// GOD: виж операции
router.get("/:orgId", godAccess, async (req, res) => {
  res.json(await engine.getOperations(req.params.orgId));
});

// GOD: създай операция
router.post("/create", godAccess, async (req, res) => {
  const { orgId, payload } = req.body;
  res.json(await engine.createOperation(orgId, payload));
});

// GOD: стартирай операция
router.post("/start", godAccess, async (req, res) => {
  const { orgId, opId } = req.body;
  res.json(await engine.startOperation(orgId, opId));
});

// GOD: тик на операции
router.post("/tick", godAccess, async (req, res) => {
  const { orgId } = req.body;
  res.json(await engine.operationsTick(orgId));
});

module.exports = router;