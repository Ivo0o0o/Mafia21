const mongoose = require("mongoose");

const operationSchema = new mongoose.Schema({
  orgId: { type: String, required: true },

  operations: [
    {
      opId: String,
      type: {
        type: String,
        enum: ["raid", "sabotage", "kidnap", "hack", "extort"],
        required: true
      },
      targetDistrict: String,
      targetOrgId: String,
      intensity: { type: Number, default: 50 }, // 0–100
      riskLevel: { type: Number, default: 50 }, // 0–100
      status: {
        type: String,
        enum: ["planned", "ongoing", "failed", "success"],
        default: "planned"
      },
      impact: {
        economy: { type: Number, default: 0 },
        territory: { type: Number, default: 0 },
        relations: { type: Number, default: 0 }
      },
      timestamp: { type: Date, default: Date.now }
    }
  ],

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("OrgOperations", operationSchema);