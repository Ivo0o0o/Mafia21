const OrgOperations = require("./operations.model");
const { v4: uuidv4 } = require("uuid");

async function getOperations(orgId) {
  let ops = await OrgOperations.findOne({ orgId });
  if (!ops) ops = await OrgOperations.create({ orgId });
  return ops;
}

// 1. Създаване на операция
async function createOperation(orgId, payload) {
  const ops = await getOperations(orgId);

  const operation = {
    opId: uuidv4(),
    type: payload.type,
    targetDistrict: payload.targetDistrict || null,
    targetOrgId: payload.targetOrgId || null,
    intensity: payload.intensity ?? 50,
    riskLevel: payload.riskLevel ?? 50,
    status: "planned",
    impact: {
      economy: 0,
      territory: 0,
      relations: 0
    }
  };

  ops.operations.push(operation);
  ops.lastUpdate = new Date();
  await ops.save();
  return operation;
}

// 2. Стартиране на операция
async function startOperation(orgId, opId) {
  const ops = await getOperations(orgId);

  const op = ops.operations.find(o => o.opId === opId);
  if (!op) throw new Error("Operation not found");

  if (op.status !== "planned") return op;

  op.status = "ongoing";
  ops.lastUpdate = new Date();
  await ops.save();
  return op;
}

// 3. Тик на операции — изход, риск, последствия
async function operationsTick(orgId) {
  const ops = await getOperations(orgId);

  for (const op of ops.operations) {
    if (op.status !== "ongoing") continue;

    const baseSuccessChance = op.intensity / 100;
    const riskModifier = op.riskLevel / 100;
    const successChance = Math.max(0.05, baseSuccessChance - riskModifier * 0.3);
    const failChance = Math.max(0.05, riskModifier - baseSuccessChance * 0.2);

    if (Math.random() < failChance) {
      op.status = "failed";
      op.impact.economy = -Math.floor(op.intensity * 0.3);
      op.impact.territory = -Math.floor(op.intensity * 0.2);
      op.impact.relations = -Math.floor(op.intensity * 0.4);
      continue;
    }

    if (Math.random() < successChance) {
      op.status = "success";

      switch (op.type) {
        case "raid":
          op.impact.economy = Math.floor(op.intensity * 0.5);
          op.impact.territory = Math.floor(op.intensity * 0.4);
          op.impact.relations = -Math.floor(op.intensity * 0.3);
          break;
        case "sabotage":
          op.impact.economy = -Math.floor(op.intensity * 0.6);
          op.impact.territory = Math.floor(op.intensity * 0.2);
          op.impact.relations = -Math.floor(op.intensity * 0.4);
          break;
        case "kidnap":
          op.impact.economy = Math.floor(op.intensity * 0.3);
          op.impact.territory = 0;
          op.impact.relations = -Math.floor(op.intensity * 0.6);
          break;
        case "hack":
          op.impact.economy = Math.floor(op.intensity * 0.7);
          op.impact.territory = 0;
          op.impact.relations = -Math.floor(op.intensity * 0.2);
          break;
        case "extort":
          op.impact.economy = Math.floor(op.intensity * 0.4);
          op.impact.territory = 0;
          op.impact.relations = -Math.floor(op.intensity * 0.5);
          break;
        default:
          break;
      }
    }
  }

  ops.lastUpdate = new Date();
  await ops.save();
  return ops;
}

module.exports = {
  getOperations,
  createOperation,
  startOperation,
  operationsTick
};