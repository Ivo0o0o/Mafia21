const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const engine = require("./npcCombat.engine");

// GOD: NPC Combat Simulation
router.post("/fight", godAccess, async (req, res) => {
  try {
    const { npcId, userId } = req.body;
    const result = await engine.npcCombat(npcId, userId);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;