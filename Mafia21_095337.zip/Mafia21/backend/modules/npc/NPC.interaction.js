// =========================
// NPC INTERACTION LAYER (FINAL)
// =========================
//
// Свързва NPC AI с Crime, Districts и Influence.
// =========================

const District = require('../Districts/District.model');
const InfluenceService = require('../Districts/Influence.service');
const Business = require('../Business/Business.model');
const NPC = require('./NPC.model');

module.exports = {
  // NPC реагира на престъпление
  onCrime: async (districtName, severity) => {
    const npcs = await NPC.find({ district: districtName });

    for (const npc of npcs) {
      npc.aggression = Math.min(100, npc.aggression + severity * 2);
      npc.fear = Math.max(0, npc.fear - severity);
      await npc.save();
    }
  },

  // NPC влияе на District crimeRate
  applyDistrictEffects: async (districtName) => {
    const npcs = await NPC.find({ district: districtName });
    const district = await District.findOne({ name: districtName });

    if (!district) return;

    let totalAggression = 0;
    let totalFear = 0;

    for (const npc of npcs) {
      totalAggression += npc.aggression;
      totalFear += npc.fear;
    }

    const avgAggression = totalAggression / npcs.length || 0;
    const avgFear = totalFear / npcs.length || 0;

    district.crimeRate = Math.min(1, district.crimeRate + avgAggression * 0.001);
    district.npcControl = Math.min(100, district.npcControl + avgAggression * 0.1);

    await district.save();
  },

  // NPC атакува бизнес
  attackBusiness: async (districtName) => {
    const npcs = await NPC.find({ district: districtName });
    const businesses = await Business.find({ district: districtName });

    if (npcs.length === 0 || businesses.length === 0) return;

    const npc = npcs[Math.floor(Math.random() * npcs.length)];
    const business = businesses[Math.floor(Math.random() * businesses.length)];

    // NPC прави щета
    business.income = Math.max(0, business.income - npc.power * 2);
    await business.save();

    npc.lastAttack = Date.now();
    npc.aggression = Math.min(100, npc.aggression + 5);
    await npc.save();

    return {
      npc: npc.name,
      business: business.name,
      damage: npc.power * 2
    };
  },

  // NPC влияе на Influence на играча
  affectPlayerInfluence: async (userId, districtName) => {
    const npcs = await NPC.find({ district: districtName });

    let totalFear = 0;
    for (const npc of npcs) totalFear += npc.fear;

    const fearFactor = totalFear / npcs.length || 0;

    await InfluenceService.removeInfluence(
      userId,
      districtName,
      fearFactor * 0.1,
      "NPC intimidation"
    );
  }
};