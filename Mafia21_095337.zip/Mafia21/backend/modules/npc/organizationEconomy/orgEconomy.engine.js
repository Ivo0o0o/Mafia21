const OrgEconomy = require("./orgEconomy.model");
const OrgControl = require("../organizationControl/orgControl.model");
const NPCEconomy = require("../economy.model");

async function getOrgEconomy(orgId) {
  let eco = await OrgEconomy.findOne({ orgId });
  if (!eco) eco = await OrgEconomy.create({ orgId });
  return eco;
}

// 1. Доходи от контролирани райони
async function collectDistrictIncome(orgId) {
  const eco = await getOrgEconomy(orgId);
  const districts = await OrgControl.find({ orgId });

  let total = 0;

  for (const d of districts) {
    total += d.controlLevel * 2; // всяко ниво дава 2$
  }

  eco.wallet.money += total;
  eco.districtIncome += total;
  eco.wallet.income += total;

  await eco.save();
  return eco;
}

// 2. Доходи от NPC бизнеси
async function collectBusinessIncome(orgId, npcIds) {
  const eco = await getOrgEconomy(orgId);

  let total = 0;

  for (const npcId of npcIds) {
    const npcEco = await NPCEconomy.findOne({ npcId });
    if (!npcEco) continue;

    for (const b of npcEco.assets.businesses) {
      total += b.value * 0.05; // 5% данък към клана
    }
  }

  eco.wallet.money += total;
  eco.businessIncome += total;
  eco.wallet.income += total;

  await eco.save();
  return eco;
}

// 3. Данък върху NPC доходи
async function collectNpcTax(orgId, npcIds) {
  const eco = await getOrgEconomy(orgId);

  let total = 0;

  for (const npcId of npcIds) {
    const npcEco = await NPCEconomy.findOne({ npcId });
    if (!npcEco) continue;

    const tax = npcEco.wallet.income * 0.10; // 10% данък
    total += tax;

    npcEco.wallet.money -= tax;
    npcEco.wallet.expenses += tax;
    await npcEco.save();
  }

  eco.wallet.money += total;
  eco.npcTaxIncome += total;
  eco.wallet.income += total;

  await eco.save();
  return eco;
}

// 4. Общ икономически тик
async function orgEconomicTick(orgId, npcIds) {
  await collectDistrictIncome(orgId);
  await collectBusinessIncome(orgId, npcIds);
  await collectNpcTax(orgId, npcIds);

  const eco = await getOrgEconomy(orgId);
  eco.lastUpdate = new Date();
  await eco.save();

  return eco;
}

module.exports = {
  getOrgEconomy,
  collectDistrictIncome,
  collectBusinessIncome,
  collectNpcTax,
  orgEconomicTick
};