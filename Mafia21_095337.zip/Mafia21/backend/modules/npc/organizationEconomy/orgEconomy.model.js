const mongoose = require("mongoose");

const orgEconomySchema = new mongoose.Schema({
  orgId: { type: String, required: true },

  wallet: {
    money: { type: Number, default: 500 },
    income: { type: Number, default: 0 },
    expenses: { type: Number, default: 0 }
  },

  districtIncome: { type: Number, default: 0 },   // доходи от контролирани райони
  businessIncome: { type: Number, default: 0 },   // доходи от NPC бизнеси
  npcTaxIncome: { type: Number, default: 0 },     // процент от NPC доходи

  lastUpdate: { type: Date, default: Date.now }
}, { timestamps: true });

module.exports = mongoose.model("OrgEconomy", orgEconomySchema);