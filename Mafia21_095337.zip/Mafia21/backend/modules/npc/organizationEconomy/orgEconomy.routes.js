const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./orgEconomy.engine");

// GOD: виж икономиката на организация
router.get("/:orgId", godAccess, async (req, res) => {
  const eco = await engine.getOrgEconomy(req.params.orgId);
  res.json(eco);
});

// GOD: доходи от райони
router.post("/districtIncome", godAccess, async (req, res) => {
  const { orgId } = req.body;
  const eco = await engine.collectDistrictIncome(orgId);
  res.json(eco);
});

// GOD: доходи от NPC бизнеси
router.post("/businessIncome", godAccess, async (req, res) => {
  const { orgId, npcIds } = req.body;
  const eco = await engine.collectBusinessIncome(orgId, npcIds);
  res.json(eco);
});

// GOD: NPC данък
router.post("/npcTax", godAccess, async (req, res) => {
  const { orgId, npcIds } = req.body;
  const eco = await engine.collectNpcTax(orgId, npcIds);
  res.json(eco);
});

// GOD: пълен икономически тик
router.post("/tick", godAccess, async (req, res) => {
  const { orgId, npcIds } = req.body;
  const eco = await engine.orgEconomicTick(orgId, npcIds);
  res.json(eco);
});

module.exports = router;