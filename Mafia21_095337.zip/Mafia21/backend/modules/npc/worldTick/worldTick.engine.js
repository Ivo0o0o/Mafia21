const NPC = require("../npc.model");
const Organization = require("../../organizations/organization.model");
const WarfareEngine = require("../organizationWarfare/warfare.engine");
const CombatEngine = require("../combat/combat.engine");

module.exports = {

  async runTick() {
    const npcs = await NPC.find();

    for (const npc of npcs) {
      // NPC регенерация
      npc.hp = Math.min(npc.maxHp, npc.hp + 1);

      // NPC пасивно влияние
      npc.influence = Math.min(100, npc.influence + 0.2);

      await npc.save();
    }

    // Организационни войни
    await WarfareEngine.tickWarfare();

    return { success: true, npcs: npcs.length };
  }
};