const WorldTickEngine = require("./worldTick.engine");

module.exports = {

  async tick(req, res) {
    try {
      const result = await WorldTickEngine.runTick();
      res.json({
        success: true,
        message: "WorldTick executed",
        result
      });
    } catch (err) {
      res.status(500).json({
        success: false,
        error: err.message
      });
    }
  }
};