const NPC = require('./NPC.model');
const District = require('../districts/District.model');
const WalletService = require('../economy/wallet.service');

module.exports = {
  /**
   * NPC влияе на района (престъпност, влияние)
   */
  applyInfluence: async (npc) => {
    const district = await District.findOne({ name: npc.district });
    if (!district) return;

    // NPC увеличава или намалява престъпността
    if (npc.role === 'boss' || npc.role === 'dealer') {
      district.crimeRate = Math.min(1, district.crimeRate + npc.aggression * 0.2);
    } else {
      district.crimeRate = Math.max(0, district.crimeRate - npc.influence * 0.02);
    }

    // NPC влияе на икономиката
    district.influence += npc.influence * 0.1;

    await district.save();
  },

  /**
   * NPC атакува играча (ако е агресивен)
   */
  tryAttackPlayer: async (npc, player) => {
    const chance = npc.aggression;
    const roll = Math.random();

    if (roll <= chance) {
      const penalty = Math.round(50 * npc.strength);
      const wallet = await WalletService.removeMoney(player._id, penalty, `NPC attack: ${npc.name}`);

      return {
        attacked: true,
        penalty,
        balanceAfter: wallet.balance,
        message: `${npc.name} те атакува в ${npc.district}!`
      };
    }

    return { attacked: false };
  }
};