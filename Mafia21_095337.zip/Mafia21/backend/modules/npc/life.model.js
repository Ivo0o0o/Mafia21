const mongoose = require("mongoose");

const npcLifeSchema = new mongoose.Schema({
  npcId: { type: String, required: true },

  dailyRoutine: {
    morning: { type: String, default: "patrol" },
    day: { type: String, default: "idle" },
    evening: { type: String, default: "extort" },
    night: { type: String, default: "hide" }
  },

  emotionalState: {
    type: String,
    enum: ["calm", "angry", "nervous", "scared", "motivated", "desperate"],
    default: "calm"
  },

  activityState: {
    type: String,
    enum: ["active", "passive", "hidden", "aggressive", "observing"],
    default: "passive"
  },

  development: {
    respectGrowth: { type: Number, default: 0 },
    fearGrowth: { type: Number, default: 0 },
    loyaltyGrowth: { type: Number, default: 0 }
  },

  lastLifeEvent: { type: String, default: "" },
  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("NPCLife", npcLifeSchema);