const NpcAI = require("./npcAI.model");
const User = require("../users/user.model");
const { npcThreatCheck } = require("./npcThreat.engine");

// Combat formulas
function chanceToHit(npc, user) {
  const base = npc.weaponAccuracy || 40;
  const userDodge = user.skills.dodge || 0;

  return Math.max(5, base - userDodge * 0.5);
}

function damageOutput(npc) {
  const base = npc.weaponDamage || 10;
  const aggressionBonus = npc.aggressionLevel * 0.2;

  return Math.round(base + aggressionBonus);
}

function userDefense(user) {
  return user.skills.defense || 0;
}

async function npcCombat(npcId, userId) {
  const npc = await NpcAI.findOne({ npcId });
  const user = await User.findById(userId);

  if (!npc || !user) throw new Error("NPC or user not found");

  // 1) Проверяваме NPC Threat
  const threat = await npcThreatCheck(npcId, userId);

  // 2) Ако NPC не е в режим "attack" → няма бой
  if (!["attack", "persistent_aggression"].includes(threat.action)) {
    return {
      combat: false,
      reason: "NPC is not attacking",
      threat
    };
  }

  // 3) Изчисляваме шанс за удар
  const hitChance = chanceToHit(npc, user);
  const roll = Math.random() * 100;
  const hit = roll < hitChance;

  // 4) Ако NPC уцели
  if (hit) {
    const dmg = damageOutput(npc);
    const defense = userDefense(user);
    const finalDamage = Math.max(0, dmg - defense);

    user.health -= finalDamage;
    await user.save();

    return {
      combat: true,
      hit: true,
      damage: finalDamage,
      npcAction: threat.action,
      npcMood: npc.mood,
      userHealth: user.health
    };
  }

  // 5) Ако NPC пропусне
  return {
    combat: true,
    hit: false,
    damage: 0,
    npcAction: threat.action,
    npcMood: npc.mood,
    userHealth: user.health
  };
}

module.exports = { npcCombat };