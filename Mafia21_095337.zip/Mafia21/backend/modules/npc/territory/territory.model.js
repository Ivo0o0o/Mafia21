const mongoose = require("mongoose");

const territorySchema = new mongoose.Schema({
  orgId: { type: String, required: true },

  // зони под влияние
  zones: {
    type: [
      {
        zoneId: String,      // уникален ID на зона
        control: Number,     // 0–100 ниво на контрол
        influence: Number,   // 0–100 ниво на влияние
        dominance: Number,   // 0–100 доминация
        lastChange: { type: Date, default: Date.now }
      }
    ],
    default: []
  },

  // история на действията
  lastAction: { type: String, default: "" },
  lastZone: { type: String, default: "" },
  timestamp: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("Territory", territorySchema);