const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./territory.engine");

// GOD: виж териториален профил
router.get("/:orgId", godAccess, async (req, res) => {
  res.json(await engine.getTerritory(req.params.orgId));
});

// GOD: промяна на влияние
router.post("/influence", godAccess, async (req, res) => {
  const { orgId, zoneId, amount } = req.body;
  res.json(await engine.adjustInfluence(orgId, zoneId, Number(amount)));
});

// GOD: промяна на контрол
router.post("/control", godAccess, async (req, res) => {
  const { orgId, zoneId, amount } = req.body;
  res.json(await engine.adjustControl(orgId, zoneId, Number(amount)));
});

// GOD: завземане
router.post("/capture", godAccess, async (req, res) => {
  const { orgId, zoneId } = req.body;
  res.json(await engine.captureZone(orgId, zoneId));
});

// GOD: загуба
router.post("/lose", godAccess, async (req, res) => {
  const { orgId, zoneId } = req.body;
  res.json(await engine.loseZone(orgId, zoneId));
});

// GOD: доминация
router.post("/dominate", godAccess, async (req, res) => {
  const { orgId, zoneId } = req.body;
  res.json(await engine.dominateZone(orgId, zoneId));
});

// GOD: тик
router.post("/tick", godAccess, async (req, res) => {
  res.json(await engine.territoryTick());
});

module.exports = router;