const Territory = require("./territory.model");

async function getTerritory(orgId) {
  let terr = await Territory.findOne({ orgId });
  if (!terr) terr = await Territory.create({ orgId });
  return terr;
}

function findZone(terr, zoneId) {
  let zone = terr.zones.find(z => z.zoneId === zoneId);
  if (!zone) {
    zone = {
      zoneId,
      control: 0,
      influence: 0,
      dominance: 0,
      lastChange: new Date()
    };
    terr.zones.push(zone);
  }
  return zone;
}

// промяна на влияние
async function adjustInfluence(orgId, zoneId, amount) {
  const terr = await getTerritory(orgId);
  const zone = findZone(terr, zoneId);

  zone.influence = Math.max(0, Math.min(100, zone.influence + amount));
  zone.lastChange = new Date();

  terr.lastAction = "Influence adjusted";
  terr.lastZone = zoneId;
  terr.timestamp = new Date();

  await terr.save();
  return terr;
}

// промяна на контрол
async function adjustControl(orgId, zoneId, amount) {
  const terr = await getTerritory(orgId);
  const zone = findZone(terr, zoneId);

  zone.control = Math.max(0, Math.min(100, zone.control + amount));
  zone.lastChange = new Date();

  terr.lastAction = "Control adjusted";
  terr.lastZone = zoneId;
  terr.timestamp = new Date();

  await terr.save();
  return terr;
}

// завземане на зона
async function captureZone(orgId, zoneId) {
  const terr = await getTerritory(orgId);
  const zone = findZone(terr, zoneId);

  zone.control = 100;
  zone.influence = Math.max(zone.influence, 70);
  zone.dominance = Math.max(zone.dominance, 80);
  zone.lastChange = new Date();

  terr.lastAction = "Zone captured";
  terr.lastZone = zoneId;
  terr.timestamp = new Date();

  await terr.save();
  return terr;
}

// загуба на зона
async function loseZone(orgId, zoneId) {
  const terr = await getTerritory(orgId);
  const zone = findZone(terr, zoneId);

  zone.control = 0;
  zone.dominance = Math.max(0, zone.dominance - 50);
  zone.influence = Math.max(0, zone.influence - 30);
  zone.lastChange = new Date();

  terr.lastAction = "Zone lost";
  terr.lastZone = zoneId;
  terr.timestamp = new Date();

  await terr.save();
  return terr;
}

// доминация в зона
async function dominateZone(orgId, zoneId) {
  const terr = await getTerritory(orgId);
  const zone = findZone(terr, zoneId);

  zone.dominance = 100;
  zone.control = Math.max(zone.control, 80);
  zone.influence = Math.max(zone.influence, 90);
  zone.lastChange = new Date();

  terr.lastAction = "Zone dominated";
  terr.lastZone = zoneId;
  terr.timestamp = new Date();

  await terr.save();
  return terr;
}

// TERRITORY TICK — естествена динамика
async function territoryTick() {
  const all = await Territory.find();

  for (const terr of all) {
    for (const zone of terr.zones) {
      // естествено разпадане на контрол без активност
      zone.control = Math.max(0, zone.control - 1);
      // влияние се стабилизира
      if (zone.influence > 50) zone.influence -= 1;
      else if (zone.influence < 50) zone.influence += 1;

      // доминация пада, ако контролът е нисък
      if (zone.control < 30) {
        zone.dominance = Math.max(0, zone.dominance - 2);
      }

      zone.lastChange = new Date();
    }

    terr.lastAction = "Territory tick";
    terr.timestamp = new Date();

    await terr.save();
  }

  return all;
}

module.exports = {
  getTerritory,
  adjustInfluence,
  adjustControl,
  captureZone,
  loseZone,
  dominateZone,
  territoryTick
};