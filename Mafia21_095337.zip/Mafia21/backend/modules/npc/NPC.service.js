const NPC = require("./npc.model");
const InventoryService = require("../inventory/inventory.service");
const User = require("../user/user.model");

module.exports = {

  // ======================================================
  // GET ALL NPCs
  // ======================================================
  async getAll() {
    return NPC.find({ active: true })
      .populate("shopItems.itemId");
  },

  // ======================================================
  // GET NPC BY ID
  // ======================================================
  async getById(id) {
    return NPC.findById(id)
      .populate("shopItems.itemId");
  },

  // ======================================================
  // BUY ITEM FROM NPC SHOP
  // ======================================================
  async buyItem(userId, npcId, itemId) {
    const npc = await NPC.findById(npcId).populate("shopItems.itemId");
    if (!npc) throw { type: "NOT_FOUND", message: "NPC not found" };

    if (npc.role !== "shop") {
      throw { type: "CONFLICT", message: "NPC is not a shop" };
    }

    const shopItem = npc.shopItems.find(i => i.itemId._id.toString() === itemId);
    if (!shopItem) throw { type: "NOT_FOUND", message: "Item not sold here" };

    const user = await User.findById(userId);
    if (!user) throw { type: "NOT_FOUND", message: "User not found" };

    if (user.money < shopItem.price) {
      throw { type: "CONFLICT", message: "Not enough money" };
    }

    // PAY
    user.money -= shopItem.price;
    await user.save();

    // ADD ITEM
    await InventoryService.addItems(userId, [{
      itemId: shopItem.itemId._id,
      quantity: 1
    }]);

    return {
      success: true,
      item: shopItem.itemId,
      price: shopItem.price
    };