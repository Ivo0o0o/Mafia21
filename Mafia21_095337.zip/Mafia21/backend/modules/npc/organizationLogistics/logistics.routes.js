const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./logistics.engine");

// GOD: виж логистиката
router.get("/:orgId", godAccess, async (req, res) => {
  res.json(await engine.getLogistics(req.params.orgId));
});

// GOD: добави склад
router.post("/addWarehouse", godAccess, async (req, res) => {
  const { orgId, district, capacity } = req.body;
  res.json(await engine.addWarehouse(orgId, district, capacity));
});

// GOD: складирай ресурси
router.post("/storeCargo", godAccess, async (req, res) => {
  const { orgId, district, cargo } = req.body;
  res.json(await engine.storeCargo(orgId, district, cargo));
});

// GOD: създай конвой
router.post("/createConvoy", godAccess, async (req, res) => {
  const { orgId, fromDistrict, toDistrict, cargo } = req.body;
  res.json(await engine.createConvoy(orgId, fromDistrict, toDistrict, cargo));
});

// GOD: логистичен тик
router.post("/tick", godAccess, async (req, res) => {
  const { orgId } = req.body;
  res.json(await engine.logisticsTick(orgId));
});

module.exports = router;