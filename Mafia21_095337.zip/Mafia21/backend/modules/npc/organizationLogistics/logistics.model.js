const mongoose = require("mongoose");

const logisticsSchema = new mongoose.Schema({
  orgId: { type: String, required: true },

  warehouses: [
    {
      district: String,
      capacity: Number,
      stored: {
        weapons: Number,
        drugs: Number,
        money: Number,
        resources: Number
      }
    }
  ],

  convoys: [
    {
      convoyId: String,
      fromDistrict: String,
      toDistrict: String,
      cargo: {
        weapons: Number,
        drugs: Number,
        money: Number,
        resources: Number
      },
      riskLevel: Number,
      status: {
        type: String,
        enum: ["en_route", "arrived", "lost", "attacked"],
        default: "en_route"
      },
      timestamp: { type: Date, default: Date.now }
    }
  ],

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("OrgLogistics", logisticsSchema);