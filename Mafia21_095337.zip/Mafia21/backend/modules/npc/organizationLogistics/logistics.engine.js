const OrgLogistics = require("./logistics.model");
const { v4: uuidv4 } = require("uuid");

async function getLogistics(orgId) {
  let log = await OrgLogistics.findOne({ orgId });
  if (!log) log = await OrgLogistics.create({ orgId });
  return log;
}

// 1. Създаване на склад
async function addWarehouse(orgId, district, capacity = 1000) {
  const log = await getLogistics(orgId);

  log.warehouses.push({
    district,
    capacity,
    stored: { weapons: 0, drugs: 0, money: 0, resources: 0 }
  });

  log.lastUpdate = new Date();
  await log.save();
  return log;
}

// 2. Добавяне на ресурси в склад
async function storeCargo(orgId, district, cargo) {
  const log = await getLogistics(orgId);

  const wh = log.warehouses.find(w => w.district === district);
  if (!wh) throw new Error("Warehouse not found");

  wh.stored.weapons += cargo.weapons || 0;
  wh.stored.drugs += cargo.drugs || 0;
  wh.stored.money += cargo.money || 0;
  wh.stored.resources += cargo.resources || 0;

  log.lastUpdate = new Date();
  await log.save();
  return wh;
}

// 3. Създаване на конвой
async function createConvoy(orgId, fromDistrict, toDistrict, cargo) {
  const log = await getLogistics(orgId);

  const convoy = {
    convoyId: uuidv4(),
    fromDistrict,
    toDistrict,
    cargo,
    riskLevel: Math.floor(Math.random() * 50),
    status: "en_route"
  };

  log.convoys.push(convoy);
  log.lastUpdate = new Date();

  await log.save();
  return convoy;
}

// 4. Логистичен тик — движение на конвои
async function logisticsTick(orgId) {
  const log = await getLogistics(orgId);

  for (const convoy of log.convoys) {
    if (convoy.status !== "en_route") continue;

    // шанс за атака
    const attackChance = convoy.riskLevel > 30 ? 0.3 : 0.1;
    if (Math.random() < attackChance) {
      convoy.status = "attacked";
      continue;
    }

    // шанс за загуба
    const lossChance = convoy.riskLevel > 40 ? 0.2 : 0.05;
    if (Math.random() < lossChance) {
      convoy.status = "lost";
      continue;
    }

    // пристига успешно
    convoy.status = "arrived";

    // добавяме товара в склада на дестинацията
    const wh = log.warehouses.find(w => w.district === convoy.toDistrict);
    if (wh) {
      wh.stored.weapons += convoy.cargo.weapons || 0;
      wh.stored.drugs += convoy.cargo.drugs || 0;
      wh.stored.money += convoy.cargo.money || 0;
      wh.stored.resources += convoy.cargo.resources || 0;
    }
  }

  log.lastUpdate = new Date();
  await log.save();
  return log;
}

module.exports = {
  getLogistics,
  addWarehouse,
  storeCargo,
  createConvoy,
  logisticsTick
};