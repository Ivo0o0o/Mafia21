const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const { getNPCProfile, updateNPCProfile } = require("./personality.engine");

// GOD: виж NPC профил
router.get("/:npcId", godAccess, async (req, res) => {
  const profile = await getNPCProfile(req.params.npcId);
  res.json(profile);
});

// GOD: промени NPC профил
router.post("/update", godAccess, async (req, res) => {
  const { npcId, data } = req.body;
  const profile = await updateNPCProfile(npcId, data);
  res.json(profile);
});

module.exports = router;