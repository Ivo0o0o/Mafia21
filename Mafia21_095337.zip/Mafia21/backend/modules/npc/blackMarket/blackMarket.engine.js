const BlackMarketDeal = require("./blackMarket.model");

async function createDeal(data) {
  return await BlackMarketDeal.create(data);
}

async function completeDeal(id) {
  const deal = await BlackMarketDeal.findById(id);
  if (!deal) return null;

  deal.status = "completed";
  deal.riskLevel -= 10;
  deal.secrecyLevel += 10;

  await deal.save();
  return deal;
}

async function failDeal(id) {
  const deal = await BlackMarketDeal.findById(id);
  if (!deal) return null;

  deal.status = "failed";
  deal.riskLevel += 20;
  deal.secrecyLevel -= 20;

  await deal.save();
  return deal;
}

async function cancelDeal(id) {
  const deal = await BlackMarketDeal.findById(id);
  if (!deal) return null;

  deal.status = "cancelled";
  deal.riskLevel -= 5;

  await deal.save();
  return deal;
}

async function listDeals(orgId) {
  return await BlackMarketDeal.find({
    $or: [{ sellerOrg: orgId }, { buyerOrg: orgId }]
  });
}

async function blackMarketTick() {
  const deals = await BlackMarketDeal.find({ status: "pending" });

  for (const deal of deals) {
    deal.riskLevel += Math.floor(Math.random() * 5);
    deal.secrecyLevel -= Math.floor(Math.random() * 3);

    deal.riskLevel = Math.max(0, Math.min(100, deal.riskLevel));
    deal.secrecyLevel = Math.max(0, Math.min(100, deal.secrecyLevel));

    deal.timestamp = new Date();
    await deal.save();
  }

  return deals;
}

module.exports = {
  createDeal,
  completeDeal,
  failDeal,
  cancelDeal,
  listDeals,
  blackMarketTick
};