const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./blackMarket.engine");

// GOD: създаване на сделка
router.post("/create", godAccess, async (req, res) => {
  res.json(await engine.createDeal(req.body));
});

// GOD: завършване
router.post("/complete", godAccess, async (req, res) => {
  res.json(await engine.completeDeal(req.body.id));
});

// GOD: провал
router.post("/fail", godAccess, async (req, res) => {
  res.json(await engine.failDeal(req.body.id));
});

// GOD: отказ
router.post("/cancel", godAccess, async (req, res) => {
  res.json(await engine.cancelDeal(req.body.id));
});

// GOD: списък сделки
router.get("/list/:orgId", godAccess, async (req, res) => {
  res.json(await engine.listDeals(req.params.orgId));
});

// GOD: тик
router.post("/tick", godAccess, async (req, res) => {
  res.json(await engine.blackMarketTick());
});

module.exports = router;