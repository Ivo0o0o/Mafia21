const mongoose = require("mongoose");

const blackMarketSchema = new mongoose.Schema({
  sellerOrg: { type: String, required: true },
  buyerOrg: { type: String, required: true },

  itemType: {
    type: String,
    enum: ["weapons", "drugs", "resources", "info", "services", "package"],
    required: true
  },

  itemName: { type: String, required: true },
  quantity: { type: Number, default: 1 },
  price: { type: Number, required: true },

  riskLevel: { type: Number, default: 50 },   // 0–100
  secrecyLevel: { type: Number, default: 50 }, // 0–100

  status: {
    type: String,
    enum: ["pending", "completed", "failed", "cancelled"],
    default: "pending"
  },

  timestamp: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("BlackMarketDeal", blackMarketSchema);