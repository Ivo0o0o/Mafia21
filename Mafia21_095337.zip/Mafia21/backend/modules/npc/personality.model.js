const mongoose = require("mongoose");

const npcPersonalitySchema = new mongoose.Schema({
  npcId: { type: String, required: true },

  identity: {
    name: { type: String, default: "Unknown" },
    nickname: { type: String, default: "" },
    role: {
      type: String,
      enum: ["gangster", "boss", "informant", "hacker", "thug", "driver", "enforcer"],
      default: "gangster"
    },
    age: { type: Number, default: 30 },
    origin: { type: String, default: "Unknown" }
  },

  biography: {
    story: { type: String, default: "" },
    crimes: { type: Array, default: [] },
    alliances: { type: Array, default: [] },
    betrayals: { type: Array, default: [] },
    victories: { type: Array, default: [] },
    losses: { type: Array, default: [] }
  },

  reputation: {
    fear: { type: Number, default: 0 },
    respect: { type: Number, default: 0 },
    notoriety: { type: Number, default: 0 },
    rank: { type: Number, default: 1 }
  },

  relationships: {
    friends: { type: Array, default: [] },
    enemies: { type: Array, default: [] },
    clan: { type: String, default: null }
  },

  preferences: {
    attack: { type: Number, default: 10 },
    flee: { type: Number, default: 10 },
    extort: { type: Number, default: 10 },
    negotiate: { type: Number, default: 10 },
    sabotage: { type: Number, default: 10 },
    hack: { type: Number, default: 10 }
  },

  weaknesses: {
    money: { type: Number, default: 0 },
    authority: { type: Number, default: 0 },
    fearPlayers: { type: Array, default: [] },
    fearNPCs: { type: Array, default: [] },
    fearDistricts: { type: Array, default: [] }
  },

  goals: {
    personal: { type: String, default: "" },
    clan: { type: String, default: "" },
    territory: { type: String, default: "" },
    criminal: { type: String, default: "" }
  }

}, { timestamps: true });

module.exports = mongoose.model("NPCPersonality", npcPersonalitySchema);