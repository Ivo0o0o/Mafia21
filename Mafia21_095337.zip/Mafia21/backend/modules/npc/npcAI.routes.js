const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const engine = require("./npcAI.engine");

// GOD: промяна на настроение
router.post("/mood", godAccess, async (req, res) => {
  try {
    const { npcId, userId } = req.body;
    const result = await engine.updateMood(npcId, userId);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// GOD: патрул
router.post("/patrol", godAccess, async (req, res) => {
  try {
    const { npcId } = req.body;
    const result = await engine.patrol(npcId);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;