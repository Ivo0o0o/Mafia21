const NpcAI = require("./npcAI.model");
const User = require("../users/user.model");

async function npcThreatCheck(npcId, userId) {
  const npc = await NpcAI.findOne({ npcId });
  const user = await User.findById(userId);

  if (!npc || !user) throw new Error("NPC or user not found");

  let action = "neutral";

  // Ако NPC е агресивен
  if (npc.aggressionLevel > 60) {
    if (user.skills.shooting < 40) {
      action = "attack";
    } else {
      action = "call_backup";
    }
  }

  // Ако NPC е изплашен
  if (npc.fearLevel > 50) {
    if (user.skills.intimidation > 60) {
      action = "run";
    } else {
      action = "hide";
    }
  }

  return {
    npcId,
    action,
    mood: npc.mood,
    aggressionLevel: npc.aggressionLevel,
    fearLevel: npc.fearLevel
  };
}

module.exports = { npcThreatCheck };