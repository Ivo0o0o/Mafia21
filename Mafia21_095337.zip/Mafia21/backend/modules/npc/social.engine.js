const NPCSocial = require("./social.model");

async function getSocial(npcId) {
  let social = await NPCSocial.findOne({ npcId });
  if (!social) social = await NPCSocial.create({ npcId });
  return social;
}

async function addFriend(npcId, targetId) {
  const social = await getSocial(npcId);
  if (!social.friends.includes(targetId)) social.friends.push(targetId);
  social.enemies = social.enemies.filter(e => e !== targetId);
  await social.save();
  return social;
}

async function addEnemy(npcId, targetId) {
  const social = await getSocial(npcId);
  if (!social.enemies.includes(targetId)) social.enemies.push(targetId);
  social.friends = social.friends.filter(f => f !== targetId);
  await social.save();
  return social;
}

async function addAlly(npcId, targetId) {
  const social = await getSocial(npcId);
  if (!social.allies.includes(targetId)) social.allies.push(targetId);
  await social.save();
  return social;
}

async function addRival(npcId, targetId) {
  const social = await getSocial(npcId);
  if (!social.rivals.includes(targetId)) social.rivals.push(targetId);
  await social.save();
  return social;
}

async function recordSocialEvent(npcId, type, targetId) {
  const social = await getSocial(npcId);

  if (type === "help") social.socialMemory.helpedBy.push(targetId);
  if (type === "attack") social.socialMemory.attackedBy.push(targetId);
  if (type === "betray") social.socialMemory.betrayedBy.push(targetId);
  if (type === "support") social.socialMemory.supportedBy.push(targetId);

  await social.save();
  return social;
}

module.exports = {
  getSocial,
  addFriend,
  addEnemy,
  addAlly,
  addRival,
  recordSocialEvent
};