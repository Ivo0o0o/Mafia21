const Warfare = require("./warfare.model");

async function createBattle(data) {
  return await Warfare.create(data);
}

async function resolveBattle(id) {
  const battle = await Warfare.findById(id);
  if (!battle) return null;

  const atk = battle.attackerPower;
  const def = battle.defenderPower;

  if (atk === def) {
    battle.outcome = "stalemate";
  } else if (atk > def) {
    battle.outcome = "attacker_win";
  } else {
    battle.outcome = "defender_win";
  }

  battle.casualtiesAttacker = Math.floor(Math.random() * 20);
  battle.casualtiesDefender = Math.floor(Math.random() * 20);

  battle.lastAction = "Battle resolved";

  await battle.save();
  return battle;
}

async function boostAttack(id, amount) {
  const battle = await Warfare.findById(id);
  if (!battle) return null;

  battle.attackerPower += amount;
  battle.lastAction = "Attack boosted";

  await battle.save();
  return battle;
}

async function boostDefense(id, amount) {
  const battle = await Warfare.findById(id);
  if (!battle) return null;

  battle.defenderPower += amount;
  battle.lastAction = "Defense boosted";

  await battle.save();
  return battle;
}

async function warfareTick() {
  const battles = await Warfare.find({ outcome: "pending" });

  for (const b of battles) {
    b.attackerPower += Math.floor(Math.random() * 5);
    b.defenderPower += Math.floor(Math.random() * 5);

    b.lastAction = "Warfare tick";
    b.timestamp = new Date();

    await b.save();
  }

  return battles;
}

module.exports = {
  createBattle,
  resolveBattle,
  boostAttack,
  boostDefense,
  warfareTick
};