const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./warfare.engine");

// GOD: създаване на битка
router.post("/create", godAccess, async (req, res) => {
  res.json(await engine.createBattle(req.body));
});

// GOD: решаване
router.post("/resolve", godAccess, async (req, res) => {
  res.json(await engine.resolveBattle(req.body.id));
});

// GOD: бууст атака
router.post("/boostAttack", godAccess, async (req, res) => {
  const { id, amount } = req.body;
  res.json(await engine.boostAttack(id, amount));
});

// GOD: бууст защита
router.post("/boostDefense", godAccess, async (req, res) => {
  const { id, amount } = req.body;
  res.json(await engine.boostDefense(id, amount));
});

// GOD: тик
router.post("/tick", godAccess, async (req, res) => {
  res.json(await engine.warfareTick());
});

module.exports = router;