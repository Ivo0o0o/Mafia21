const mongoose = require("mongoose");

const warfareSchema = new mongoose.Schema({
  attackerOrg: { type: String, required: true },
  defenderOrg: { type: String, required: true },

  battleType: {
    type: String,
    enum: ["raid", "ambush", "assault", "defense", "operation"],
    required: true
  },

  attackerPower: { type: Number, default: 0 },
  defenderPower: { type: Number, default: 0 },

  outcome: {
    type: String,
    enum: ["pending", "attacker_win", "defender_win", "stalemate"],
    default: "pending"
  },

  casualtiesAttacker: { type: Number, default: 0 },
  casualtiesDefender: { type: Number, default: 0 },

  territoryId: { type: String, default: null },

  timestamp: { type: Date, default: Date.now },
  lastAction: { type: String, default: "" }

}, { timestamps: true });

module.exports = mongoose.model("Warfare", warfareSchema);