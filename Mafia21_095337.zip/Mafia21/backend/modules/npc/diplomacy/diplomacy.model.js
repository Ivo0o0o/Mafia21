const mongoose = require("mongoose");

const diplomacySchema = new mongoose.Schema({
  orgId: { type: String, required: true },

  relations: {
    type: Map,
    of: Number, // -100 до +100
    default: {}
  },

  alliances: {
    type: [String], // orgId списък
    default: []
  },

  treaties: {
    type: [
      {
        targetId: String,
        type: String, // peace / trade / nonAggression
        expires: Date
      }
    ],
    default: []
  },

  hostility: {
    type: Map,
    of: Number, // 0–100
    default: {}
  },

  lastAction: { type: String, default: "" },
  lastTarget: { type: String, default: "" },
  timestamp: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("Diplomacy", diplomacySchema);