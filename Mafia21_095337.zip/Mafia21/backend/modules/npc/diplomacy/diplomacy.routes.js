const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./diplomacy.engine");

// GOD: виж дипломатически профил
router.get("/:orgId", godAccess, async (req, res) => {
  res.json(await engine.getDiplomacy(req.params.orgId));
});

// GOD: промяна на отношения
router.post("/relation", godAccess, async (req, res) => {
  const { orgId, targetId, amount } = req.body;
  res.json(await engine.adjustRelation(orgId, targetId, Number(amount)));
});

// GOD: съюз
router.post("/alliance", godAccess, async (req, res) => {
  const { orgId, targetId } = req.body;
  res.json(await engine.declareAlliance(orgId, targetId));
});

// GOD: разрив
router.post("/break", godAccess, async (req, res) => {
  const { orgId, targetId } = req.body;
  res.json(await engine.breakAlliance(orgId, targetId));
});

// GOD: договор
router.post("/treaty", godAccess, async (req, res) => {
  const { orgId, targetId, type, duration } = req.body;
  res.json(await engine.signTreaty(orgId, targetId, type, Number(duration)));
});

// GOD: ескалация
router.post("/escalate", godAccess, async (req, res) => {
  const { orgId, targetId, amount } = req.body;
  res.json(await engine.escalate(orgId, targetId, Number(amount)));
});

// GOD: тик
router.post("/tick", godAccess, async (req, res) => {
  res.json(await engine.diplomacyTick());
});

module.exports = router;