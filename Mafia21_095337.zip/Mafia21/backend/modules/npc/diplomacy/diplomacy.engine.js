const Diplomacy = require("./diplomacy.model");

async function getDiplomacy(orgId) {
  let dip = await Diplomacy.findOne({ orgId });
  if (!dip) dip = await Diplomacy.create({ orgId });
  return dip;
}

async function adjustRelation(orgId, targetId, amount) {
  const dip = await getDiplomacy(orgId);

  const current = dip.relations.get(targetId) || 0;
  dip.relations.set(targetId, Math.max(-100, Math.min(100, current + amount)));

  dip.lastAction = "Relation adjusted";
  dip.lastTarget = targetId;
  dip.timestamp = new Date();

  await dip.save();
  return dip;
}

async function declareAlliance(orgId, targetId) {
  const dip = await getDiplomacy(orgId);

  if (!dip.alliances.includes(targetId)) {
    dip.alliances.push(targetId);
  }

  dip.relations.set(targetId, 100);
  dip.hostility.set(targetId, 0);

  dip.lastAction = "Alliance declared";
  dip.lastTarget = targetId;
  dip.timestamp = new Date();

  await dip.save();
  return dip;
}

async function breakAlliance(orgId, targetId) {
  const dip = await getDiplomacy(orgId);

  dip.alliances = dip.alliances.filter(id => id !== targetId);
  dip.relations.set(targetId, -50);
  dip.hostility.set(targetId, 50);

  dip.lastAction = "Alliance broken";
  dip.lastTarget = targetId;
  dip.timestamp = new Date();

  await dip.save();
  return dip;
}

async function signTreaty(orgId, targetId, type, durationDays) {
  const dip = await getDiplomacy(orgId);

  dip.treaties.push({
    targetId,
    type,
    expires: new Date(Date.now() + durationDays * 86400000)
  });

  dip.lastAction = "Treaty signed";
  dip.lastTarget = targetId;
  dip.timestamp = new Date();

  await dip.save();
  return dip;
}

async function escalate(orgId, targetId, amount = 10) {
  const dip = await getDiplomacy(orgId);

  const current = dip.hostility.get(targetId) || 0;
  dip.hostility.set(targetId, Math.min(100, current + amount));

  dip.relations.set(targetId, Math.max(-100, (dip.relations.get(targetId) || 0) - amount));

  dip.lastAction = "Hostility escalated";
  dip.lastTarget = targetId;
  dip.timestamp = new Date();

  await dip.save();
  return dip;
}

async function diplomacyTick() {
  const all = await Diplomacy.find();

  for (const dip of all) {
    // изтичане на договори
    dip.treaties = dip.treaties.filter(t => t.expires > new Date());

    // естествено затопляне/охлаждане
    for (const [targetId, rel] of dip.relations.entries()) {
      const newRel = rel + (rel < 0 ? 1 : -1);
      dip.relations.set(targetId, Math.max(-100, Math.min(100, newRel)));
    }

    for (const [targetId, host] of dip.hostility.entries()) {
      const newHost = host - 1;
      dip.hostility.set(targetId, Math.max(0, newHost));
    }

    dip.lastAction = "Diplomacy tick";
    dip.timestamp = new Date();

    await dip.save();
  }

  return all;
}

module.exports = {
  getDiplomacy,
  adjustRelation,
  declareAlliance,
  breakAlliance,
  signTreaty,
  escalate,
  diplomacyTick
};