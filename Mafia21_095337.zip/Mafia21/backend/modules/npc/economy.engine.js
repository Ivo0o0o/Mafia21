const NPCEconomy = require("./economy.model");

async function getEconomy(npcId) {
  let eco = await NPCEconomy.findOne({ npcId });
  if (!eco) eco = await NPCEconomy.create({ npcId });
  return eco;
}

async function addIncome(npcId, amount, source) {
  const eco = await getEconomy(npcId);

  eco.wallet.money += amount;
  eco.wallet.income += amount;

  if (eco.incomeSources[source] !== undefined) {
    eco.incomeSources[source] += amount;
  }

  await eco.save();
  return eco;
}

async function addExpense(npcId, amount, type) {
  const eco = await getEconomy(npcId);

  eco.wallet.money -= amount;
  eco.wallet.expenses += amount;

  if (eco.expensesList[type] !== undefined) {
    eco.expensesList[type] += amount;
  }

  await eco.save();
  return eco;
}

async function invest(npcId, businessName, amount) {
  const eco = await getEconomy(npcId);

  if (eco.wallet.money < amount) throw new Error("Not enough money");

  eco.wallet.money -= amount;
  eco.assets.businesses.push({ name: businessName, value: amount });

  eco.expensesList.investments += amount;

  await eco.save();
  return eco;
}

async function economicTick(npcId) {
  const eco = await getEconomy(npcId);

  // Финансово поведение
  switch (eco.financialBehavior) {
    case "saving":
      eco.wallet.money += 5;
      break;

    case "risky":
      eco.wallet.money += Math.floor(Math.random() * 20) - 10;
      break;

    case "aggressive":
      eco.wallet.money += 15;
      eco.expensesList.weapons += 5;
      break;

    case "greedy":
      eco.wallet.money += 10;
      eco.expensesList.bribes += 3;
      break;

    case "strategic":
      eco.wallet.money += 8;
      eco.expensesList.investments += 4;
      break;
  }

  eco.lastUpdate = new Date();
  await eco.save();
  return eco;
}

module.exports = {
  getEconomy,
  addIncome,
  addExpense,
  invest,
  economicTick
};