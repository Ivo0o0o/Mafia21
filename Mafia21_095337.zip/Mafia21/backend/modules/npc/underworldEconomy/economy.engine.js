const UnderworldEconomy = require("./economy.model");

async function getEconomy(orgId) {
  let eco = await UnderworldEconomy.findOne({ orgId });
  if (!eco) eco = await UnderworldEconomy.create({ orgId });
  return eco;
}

async function addIncome(orgId, amount) {
  const eco = await getEconomy(orgId);

  eco.balance += amount;
  eco.income += amount;
  eco.lastAction = "Income added";

  await eco.save();
  return eco;
}

async function addExpense(orgId, amount) {
  const eco = await getEconomy(orgId);

  eco.balance -= amount;
  eco.expenses += amount;
  eco.lastAction = "Expense added";

  await eco.save();
  return eco;
}

async function launderMoney(orgId, amount) {
  const eco = await getEconomy(orgId);

  const cleaned = Math.floor(amount * (eco.launderingLevel / 100));
  eco.balance += cleaned;
  eco.launderingLevel += 5;
  eco.lastAction = "Money laundered";

  eco.launderingLevel = Math.min(100, eco.launderingLevel);

  await eco.save();
  return eco;
}

async function racketeer(orgId) {
  const eco = await getEconomy(orgId);

  const extorted = Math.floor(Math.random() * 500);
  eco.balance += extorted;
  eco.racketeeringLevel += 10;
  eco.lastAction = "Racketeering";

  eco.racketeeringLevel = Math.min(100, eco.racketeeringLevel);

  await eco.save();
  return eco;
}

async function increaseInfluence(orgId) {
  const eco = await getEconomy(orgId);

  eco.influenceLevel += 15;
  eco.lastAction = "Influence increased";

  eco.influenceLevel = Math.min(100, eco.influenceLevel);

  await eco.save();
  return eco;
}

async function economyTick() {
  const all = await UnderworldEconomy.find();

  for (const eco of all) {
    eco.balance += eco.income;
    eco.balance -= eco.expenses;

    eco.influenceLevel += Math.floor(eco.balance / 10000);
    eco.launderingLevel += Math.floor(Math.random() * 2);
    eco.racketeeringLevel += Math.floor(Math.random() * 3);

    eco.influenceLevel = Math.min(100, eco.influenceLevel);
    eco.launderingLevel = Math.min(100, eco.launderingLevel);
    eco.racketeeringLevel = Math.min(100, eco.racketeeringLevel);

    eco.lastAction = "Economy tick";
    eco.timestamp = new Date();

    await eco.save();
  }

  return all;
}

module.exports = {
  getEconomy,
  addIncome,
  addExpense,
  launderMoney,
  racketeer,
  increaseInfluence,
  economyTick
};