const mongoose = require("mongoose");

const economySchema = new mongoose.Schema({
  orgId: { type: String, required: true },

  balance: { type: Number, default: 0 },          // текущи пари
  income: { type: Number, default: 0 },           // дневен приход
  expenses: { type: Number, default: 0 },         // дневни разходи

  launderingLevel: { type: Number, default: 0 },  // 0–100
  racketeeringLevel: { type: Number, default: 0 },// 0–100
  influenceLevel: { type: Number, default: 0 },   // 0–100

  lastAction: { type: String, default: "" },
  timestamp: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("UnderworldEconomy", economySchema);