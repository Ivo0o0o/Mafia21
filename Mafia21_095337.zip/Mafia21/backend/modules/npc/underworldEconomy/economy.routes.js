const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./economy.engine");

// GOD: виж икономика
router.get("/:orgId", godAccess, async (req, res) => {
  res.json(await engine.getEconomy(req.params.orgId));
});

// GOD: приход
router.post("/income", godAccess, async (req, res) => {
  const { orgId, amount } = req.body;
  res.json(await engine.addIncome(orgId, amount));
});

// GOD: разход
router.post("/expense", godAccess, async (req, res) => {
  const { orgId, amount } = req.body;
  res.json(await engine.addExpense(orgId, amount));
});

// GOD: перачница
router.post("/launder", godAccess, async (req, res) => {
  const { orgId, amount } = req.body;
  res.json(await engine.launderMoney(orgId, amount));
});

// GOD: рекет
router.post("/racketeer", godAccess, async (req, res) => {
  const { orgId } = req.body;
  res.json(await engine.racketeer(orgId));
});

// GOD: влияние
router.post("/influence", godAccess, async (req, res) => {
  const { orgId } = req.body;
  res.json(await engine.increaseInfluence(orgId));
});

// GOD: тик
router.post("/tick", godAccess, async (req, res) => {
  res.json(await engine.economyTick());
});

module.exports = router;