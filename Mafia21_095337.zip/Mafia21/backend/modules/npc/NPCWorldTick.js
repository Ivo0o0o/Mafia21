const mongoose = require('mongoose');

const districtSchema = new mongoose.Schema({
  // Основна информация
  name: { type: String, required: true, unique: true },
  description: { type: String, default: '' },

  // Контрол от играч
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },

  // Контрол от NPC (0–100)
  npcControl: { type: Number, default: 0 },

  // Коя NPC организация държи района
  npcOwner: { type: String, default: null }, // organizationId

  // Икономика
  baseIncome: { type: Number, default: 100 },

  // Влияние върху бизнеси (0–20)
  influence: { type: Number, default: 1 },

  // Престъпност (0–1 → 0.3 = 30%)
  crimeRate: { type: Number, default: 0 },

  // География (ако решиш да правиш карта)
  coordinates: {
    x: { type: Number, default: 0 },
    y: { type: Number, default: 0 }
  },

  // Автоматичен тик
  lastTick: { type: Date, default: null }
}, { timestamps: true });

module.exports = mongoose.model('District', districtSchema);// =========================
// NPC WORLD TICK PRO
// =========================
//
// Това е глобалният AI цикъл, който обновява NPC състоянието,
// влиянието, агресията, страха, престъпността и районите.
// Работи заедно с npc.action.engine.js
// =========================

const NpcDistrictEngine = require("./NPC.district.engine");
const NPC = require("./npc.model");
const District = require("../Districts/District.model");

module.exports = async function npcWorldTick() {
  try {
    const npcs = await NPC.find();
    const districts = await District.find();

    for (const npc of npcs) {

      // 1) NPC реагира на престъпност в района
      const district = districts.find(d => d.name === npc.district);
      if (district) {
        if (district.crimeRate > 0.5) {
          npc.aggression = Math.min(1, npc.aggression + 0.01);
        } else {
          npc.aggression = Math.max(0, npc.aggression - 0.005);
        }
      }

      // 2) NPC влияние расте или пада
      npc.influence += (npc.role === "boss" ? 0.5 : 0.2);
      npc.influence = Math.min(100, npc.influence);

      // 3) NPC страх намалява агресия
      if (npc.fear > 0) {
        npc.aggression = Math.max(0, npc.aggression - npc.fear * 0.0005);
      }

      // 4) NPC level-up (автоматично развитие)
      if (npc.influence > npc.level * 10) {
        npc.level += 1;
      }

      // 5) NPC организация влияе на поведението
      if (npc.organizationId) {
        npc.rewardBonus += 0.01;   // NPC от организация дават по-добри мисии
        npc.penaltyBonus += 0.005; // NPC от организация наказват по-силно
      }

      // 6) NPC cooldown за атаки
      if (npc.lastAttack) {
        const diff = Date.now() - npc.lastAttack.getTime();
        if (diff > 1000 * 60 * 10) { // 10 минути
          npc.attackChance = Math.min(0.2, npc.attackChance + 0.01);
        }
      }

      // 7) NPC агресия расте с времето
      npc.aggression = Math.min(1, npc.aggression + 0.002);

      // 8) NPC страх пада с времето
      npc.fear = Math.max(0, npc.fear - 0.1);

      await npc.save();
    }

await NpcDistrictEngine.updateDistrictControl();

    return { status: "NPC World Tick PRO executed" };

  } catch (err) {
    console.error("NPCWorldTick PRO ERROR:", err);
    return { error: err.message };
  }
};