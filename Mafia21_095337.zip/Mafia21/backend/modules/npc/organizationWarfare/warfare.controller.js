// modules/npc/organizationWarfare/warfare.controller.js

const {
  startWar,
  getWarHistory,
  calculateBattlePower
} = require("./warfare.engine");

class WarfareController {

  // Start a war (GOD only)
  async start(req, res) {
    try {
      const { attackerOrgId, defenderOrgId, district } = req.body;

      if (!attackerOrgId || !defenderOrgId || !district) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const war = await startWar(attackerOrgId, defenderOrgId, district);
      res.json(war);

    } catch (err) {
      console.error("WARFARE START ERROR:", err);
      res.status(400).json({ error: err.message });
    }
  }

  // Get war history
  async history(req, res) {
    try {
      const { orgId } = req.params;
      const wars = await getWarHistory(orgId);
      res.json(wars);

    } catch (err) {
      console.error("WARFARE HISTORY ERROR:", err);
      res.status(500).json({ error: "Failed to fetch war history" });
    }
  }

  // Get battle power
  async power(req, res) {
    try {
      const { orgId } = req.params;
      const power = await calculateBattlePower(orgId);

      res.json({
        orgId,
        battlePower: power
      });

    } catch (err) {
      console.error("BATTLE POWER ERROR:", err);
      res.status(500).json({ error: "Failed to calculate battle power" });
    }
  }
}

module.exports = new WarfareController();