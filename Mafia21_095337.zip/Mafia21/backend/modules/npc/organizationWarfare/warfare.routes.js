const express = require("express");
const router = express.Router();

const { godAccess } = require("../../../src/middleware/godAccess");
const {
  startWar,
  getWarHistory,
  calculateBattlePower
} = require("./warfare.engine");

// ---------------------------------------------
// GOD: Start a war between organizations (PRO)
// ---------------------------------------------
router.post("/start", godAccess, async (req, res) => {
  try {
    const { attackerOrgId, defenderOrgId, district } = req.body;

    if (!attackerOrgId || !defenderOrgId || !district) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    const war = await startWar(attackerOrgId, defenderOrgId, district);
    res.json(war);

  } catch (err) {
    console.error("WARFARE ERROR:", err);
    res.status(400).json({ error: err.message });
  }
});

// ---------------------------------------------
// GOD: Get war history for an organization (PRO)
// ---------------------------------------------
router.get("/history/:orgId", godAccess, async (req, res) => {
  try {
    const wars = await getWarHistory(req.params.orgId);
    res.json(wars);

  } catch (err) {
    console.error("WARFARE HISTORY ERROR:", err);
    res.status(500).json({ error: "Failed to fetch war history" });
  }
});

// ---------------------------------------------
// GOD: Get organization battle power (PRO)
// ---------------------------------------------
router.get("/power/:orgId", godAccess, async (req, res) => {
  try {
    const power = await calculateBattlePower(req.params.orgId);
    res.json({ orgId: req.params.orgId, battlePower: power });

  } catch (err) {
    console.error("BATTLE POWER ERROR:", err);
    res.status(500).json({ error: "Failed to calculate battle power" });
  }
});

module.exports = router;