const OrgWarfare = require("./warfare.model");
const NPCOrganization = require("../organization/organization.model");
const OrgControl = require("../organizationControl/orgControl.model");
const NPC = require("../../npc/npc.model");

// -------------------------------
// BATTLE POWER CALCULATION PRO
// -------------------------------
async function calculateBattlePower(orgId) {
  const org = await NPCOrganization.findById(orgId);
  if (!org) throw new Error("Organization not found");

  let power = 0;

  // Role-based combat strength (PRO balanced values)
  const rolePower = {
    boss: 25,
    enforcer: 18,
    soldier: 12,
    driver: 6,
    hacker: 4
  };

  for (const role in rolePower) {
    power += (org.roles[role]?.length || 0) * rolePower[role];
  }

  // District influence adds strategic advantage
  const districts = await OrgControl.find({ orgId });
  for (const d of districts) {
    power += d.controlLevel * 0.7; // PRO multiplier
  }

  // Organization influence system
  power += org.influence * 0.5;

  // Random combat variance (PRO realism)
  power *= (0.9 + Math.random() * 0.2);

  return Math.floor(power);
}

// -------------------------------
// WAR STARTER PRO
// -------------------------------
async function startWar(attackerOrgId, defenderOrgId, district) {
  const attackerPower = await calculateBattlePower(attackerOrgId);
  const defenderPower = await calculateBattlePower(defenderOrgId);

  let result = "stalemate";
  let territoryChange = false;

  // PRO battle resolution
  if (attackerPower > defenderPower * 1.1) {
    result = "attackerwin";
    territoryChange = true;
  } else if (defenderPower > attackerPower * 1.1) {
    result = "defenderwin";
  }

  // PRO casualties system
  const casualties = {
    attacker: Math.floor((defenderPower / attackerPower) * 8),
    defender: Math.floor((attackerPower / defenderPower) * 8)
  };

  // Influence shift (PRO)
  const influenceShift =
    result === "attackerwin"
      ? Math.floor((attackerPower - defenderPower) * 0.1)
      : result === "defenderwin"
      ? Math.floor((defenderPower - attackerPower) * 0.1)
      : 0;

  // -------------------------------
  // NPC PARTICIPANTS (Combat PRO)
  // -------------------------------
  const attackerNPC = await NPC.findOne({ organization: attackerOrgId }).sort({ combatSkill: -1 });
  const defenderNPC = await NPC.findOne({ organization: defenderOrgId }).sort({ combatSkill: -1 });

  // -------------------------------
  // TERRITORY CAPTURE SYSTEM PRO
  // -------------------------------
  if (territoryChange) {
    let control = await OrgControl.findOne({ district });

    if (!control) {
      // District was neutral
      await OrgControl.create({
        orgId: attackerOrgId,
        district,
        controlLevel: 25
      });
    } else {
      // District was owned by defender
      control.orgId = attackerOrgId;
      control.controlLevel = Math.floor(control.controlLevel * 0.5);
      await control.save();
    }
  }

  // -------------------------------
  // WAR LOG CREATION PRO
  // -------------------------------
  const warLog = await OrgWarfare.create({
    attackerOrgId,
    defenderOrgId,
    district,
    battlePower: { attacker: attackerPower, defender: defenderPower },
    result,
    casualties,
    territoryChange,
    influenceShift,
    participants: {
      attackerNPC: attackerNPC?._id || null,
      defenderNPC: defenderNPC?._id || null
    }
  });

  return warLog;
}

// -------------------------------
// WAR HISTORY
// -------------------------------
async function getWarHistory(orgId) {
  return await OrgWarfare.find({
    $or: [{ attackerOrgId: orgId }, { defenderOrgId: orgId }]
  }).sort({ timestamp: -1 });
}

module.exports = {
  startWar,
  getWarHistory,
  calculateBattlePower
};