// modules/npc/organizationWarfare/warfare.service.js

const {
  startWar,
  getWarHistory,
  calculateBattlePower
} = require("./warfare.engine");

class WarfareService {

  async startWar(attackerOrgId, defenderOrgId, district) {
    return await startWar(attackerOrgId, defenderOrgId, district);
  }

  async getHistory(orgId) {
    return await getWarHistory(orgId);
  }

  async getPower(orgId) {
    return await calculateBattlePower(orgId);
  }
}

module.exports = new WarfareService();