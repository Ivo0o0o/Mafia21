const mongoose = require("mongoose");

const warfareSchema = new mongoose.Schema({

  // Коя организация атакува
  attackerOrgId: { type: mongoose.Schema.Types.ObjectId, ref: "Organization", required: true },

  // Коя организация защитава
  defenderOrgId: { type: mongoose.Schema.Types.ObjectId, ref: "Organization", required: true },

  // Районът, за който се води битката
  district: { type: String, required: true },

  // Сила на битката (battle power)
  battlePower: {
    attacker: { type: Number, default: 0 },
    defender: { type: Number, default: 0 }
  },

  // Резултат от битката
  result: {
    type: String,
    enum: ["attacker_win", "defender_win", "stalemate"],
    default: "stalemate"
  },

  // Жертви
  casualties: {
    attacker: { type: Number, default: 0 },
    defender: { type: Number, default: 0 }
  },

  // Дали районът е превзет
  territoryChange: { type: Boolean, default: false },

  // Колко influence е загубено/спечелено
  influenceShift: { type: Number, default: 0 },

  // NPC, участвали в битката
  participants: {
    attackerNPC: { type: mongoose.Schema.Types.ObjectId, ref: "NPC", default: null },
    defenderNPC: { type: mongoose.Schema.Types.ObjectId, ref: "NPC", default: null }
  },

  // Време на битката
  timestamp: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("OrgWarfare", warfareSchema);