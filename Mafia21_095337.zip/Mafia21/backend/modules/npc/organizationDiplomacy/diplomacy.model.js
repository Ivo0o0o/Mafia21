const mongoose = require("mongoose");

const diplomacySchema = new mongoose.Schema({
  orgA: { type: String, required: true },     // организация А
  orgB: { type: String, required: true },     // организация Б

  status: {
    type: String,
    enum: ["neutral", "alliance", "war", "truce", "hostile"],
    default: "neutral"
  },

  trustLevel: { type: Number, default: 50 },   // 0–100
  tensionLevel: { type: Number, default: 0 },  // 0–100

  lastAction: { type: String, default: "" },   // последно дипломатическо действие
  timestamp: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("OrgDiplomacy", diplomacySchema);