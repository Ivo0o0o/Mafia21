const OrgDiplomacy = require("./diplomacy.model");

async function getRelation(orgA, orgB) {
  let rel = await OrgDiplomacy.findOne({ orgA, orgB });
  if (!rel) rel = await OrgDiplomacy.create({ orgA, orgB });
  return rel;
}

async function setAlliance(orgA, orgB) {
  const rel = await getRelation(orgA, orgB);

  rel.status = "alliance";
  rel.trustLevel += 20;
  rel.tensionLevel = 0;
  rel.lastAction = "Alliance formed";

  await rel.save();
  return rel;
}

async function setWar(orgA, orgB) {
  const rel = await getRelation(orgA, orgB);

  rel.status = "war";
  rel.trustLevel = 0;
  rel.tensionLevel += 40;
  rel.lastAction = "War declared";

  await rel.save();
  return rel;
}

async function setTruce(orgA, orgB) {
  const rel = await getRelation(orgA, orgB);

  rel.status = "truce";
  rel.trustLevel += 10;
  rel.tensionLevel -= 20;
  rel.lastAction = "Truce signed";

  await rel.save();
  return rel;
}

async function setHostile(orgA, orgB) {
  const rel = await getRelation(orgA, orgB);

  rel.status = "hostile";
  rel.trustLevel -= 20;
  rel.tensionLevel += 20;
  rel.lastAction = "Hostile stance";

  await rel.save();
  return rel;
}

async function betray(orgA, orgB) {
  const rel = await getRelation(orgA, orgB);

  rel.status = "hostile";
  rel.trustLevel = 0;
  rel.tensionLevel = 100;
  rel.lastAction = "Betrayal";

  await rel.save();
  return rel;
}

async function negotiate(orgA, orgB) {
  const rel = await getRelation(orgA, orgB);

  rel.trustLevel += 5;
  rel.tensionLevel -= 5;
  rel.lastAction = "Negotiation";

  await rel.save();
  return rel;
}

async function diplomacyTick(orgA, orgB) {
  const rel = await getRelation(orgA, orgB);

  // естествено развитие
  if (rel.status === "alliance") {
    rel.trustLevel += 2;
    rel.tensionLevel -= 1;
  }

  if (rel.status === "hostile") {
    rel.trustLevel -= 2;
    rel.tensionLevel += 2;
  }

  if (rel.status === "truce") {
    rel.trustLevel += 1;
    rel.tensionLevel -= 1;
  }

  rel.trustLevel = Math.max(0, Math.min(100, rel.trustLevel));
  rel.tensionLevel = Math.max(0, Math.min(100, rel.tensionLevel));

  rel.lastAction = "Diplomacy tick";
  rel.timestamp = new Date();

  await rel.save();
  return rel;
}

module.exports = {
  getRelation,
  setAlliance,
  setWar,
  setTruce,
  setHostile,
  betray,
  negotiate,
  diplomacyTick
};