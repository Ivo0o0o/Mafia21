const mongoose = require("mongoose");

const npcSocialSchema = new mongoose.Schema({
  npcId: { type: String, required: true },

  friends: { type: Array, default: [] },
  enemies: { type: Array, default: [] },
  allies: { type: Array, default: [] },
  rivals: { type: Array, default: [] },

  influence: { type: Number, default: 10 },   // социално влияние
  respect: { type: Number, default: 10 },     // уважение
  fear: { type: Number, default: 10 },        // страх

  socialMemory: {
    helpedBy: { type: Array, default: [] },
    attackedBy: { type: Array, default: [] },
    betrayedBy: { type: Array, default: [] },
    supportedBy: { type: Array, default: [] }
  }

}, { timestamps: true });

module.exports = mongoose.model("NPCSocial", npcSocialSchema);