const NPCLife = require("./life.model");
const NPCPersonality = require("./personality.model");
const NpcAI = require("./npcAI.model");

function getTimeOfDay() {
  const hour = new Date().getHours();
  if (hour >= 6 && hour < 12) return "morning";
  if (hour >= 12 && hour < 18) return "day";
  if (hour >= 18 && hour < 24) return "evening";
  return "night";
}

async function getLife(npcId) {
  let life = await NPCLife.findOne({ npcId });
  if (!life) life = await NPCLife.create({ npcId });
  return life;
}

async function updateLife(npcId) {
  const life = await getLife(npcId);
  const personality = await NPCPersonality.findOne({ npcId });
  const npc = await NpcAI.findOne({ npcId });

  const time = getTimeOfDay();
  const routineAction = life.dailyRoutine[time];

  // Емоции според събития
  if (npc.fearLevel > 60) life.emotionalState = "scared";
  else if (npc.aggressionLevel > 60) life.emotionalState = "angry";
  else life.emotionalState = "calm";

  // Активност според характер
  if (personality.behaviorStyle === "violent") life.activityState = "aggressive";
  else if (personality.behaviorStyle === "stealthy") life.activityState = "hidden";
  else if (personality.behaviorStyle === "diplomatic") life.activityState = "observing";
  else life.activityState = "active";

  // Развитие
  life.development.respectGrowth += npc.aggressionLevel / 10;
  life.development.fearGrowth += npc.fearLevel / 10;

  life.lastLifeEvent = `NPC performed ${routineAction} during ${time}`;
  life.lastUpdate = new Date();

  await life.save();
  return life;
}

module.exports = {
  getLife,
  updateLife
};