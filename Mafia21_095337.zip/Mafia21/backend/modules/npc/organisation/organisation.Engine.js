const Organization = require("./organization.model");

async function createOrganization(name, type, leaderNpcId) {
  const org = await Organization.create({
    name,
    type,
    leader: leaderNpcId,
    members: [{ npcId: leaderNpcId, role: "leader" }]
  });

  return org;
}

async function addMember(orgId, npcId, role = "recruit") {
  const org = await Organization.findById(orgId);
  if (!org) throw new Error("Organization not found");

  org.members.push({ npcId, role });
  await org.save();
  return org;
}

async function removeMember(orgId, npcId) {
  const org = await Organization.findById(orgId);
  if (!org) throw new Error("Organization not found");

  org.members = org.members.filter(m => m.npcId !== npcId);
  await org.save();
  return org;
}

async function changeRole(orgId, npcId, newRole) {
  const org = await Organization.findById(orgId);
  if (!org) throw new Error("Organization not found");

  const member = org.members.find(m => m.npcId === npcId);
  if (!member) throw new Error("Member not found");

  member.role = newRole;
  await org.save();
  return org;
}

async function changeLeader(orgId, npcId) {
  const org = await Organization.findById(orgId);
  if (!org) throw new Error("Organization not found");

  org.leader = npcId;

  const member = org.members.find(m => m.npcId === npcId);
  if (member) member.role = "leader";
  else org.members.push({ npcId, role: "leader" });

  await org.save();
  return org;
}

async function setTerritory(orgId, territoryName, influence, incomeBonus, dangerLevel) {
  const org = await Organization.findById(orgId);
  if (!org) throw new Error("Organization not found");

  org.territory = {
    name: territoryName,
    influence,
    incomeBonus,
    dangerLevel
  };

  await org.save();
  return org;
}

async function addRelation(orgId, targetOrgId, type) {
  const org = await Organization.findById(orgId);
  if (!org) throw new Error("Organization not found");

  if (type === "ally") org.relations.allies.push(targetOrgId);
  if (type === "enemy") org.relations.enemies.push(targetOrgId);

  await org.save();
  return org;
}

async function addResources(orgId, resources) {
  const org = await Organization.findById(orgId);
  if (!org) throw new Error("Organization not found");

  for (const key in resources) {
    org.resources[key] += resources[key];
  }

  await org.save();
  return org;
}

module.exports = {
  createOrganization,
  addMember,
  removeMember,
  changeRole,
  changeLeader,
  setTerritory,
  addRelation,
  addResources
};