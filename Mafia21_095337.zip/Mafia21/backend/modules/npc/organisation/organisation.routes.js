const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const engine = require("./organization.engine");

// GOD: създай организация
router.post("/create", godAccess, async (req, res) => {
  const { name, type, leaderNpcId } = req.body;
  const org = await engine.createOrganization(name, type, leaderNpcId);
  res.json(org);
});

// GOD: добави член
router.post("/addMember", godAccess, async (req, res) => {
  const { orgId, npcId, role } = req.body;
  const org = await engine.addMember(orgId, npcId, role);
  res.json(org);
});

// GOD: премахни член
router.post("/removeMember", godAccess, async (req, res) => {
  const { orgId, npcId } = req.body;
  const org = await engine.removeMember(orgId, npcId);
  res.json(org);
});

// GOD: промени роля
router.post("/changeRole", godAccess, async (req, res) => {
  const { orgId, npcId, role } = req.body;
  const org = await engine.changeRole(orgId, npcId, role);
  res.json(org);
});

// GOD: нов лидер
router.post("/changeLeader", godAccess, async (req, res) => {
  const { orgId, npcId } = req.body;
  const org = await engine.changeLeader(orgId, npcId);
  res.json(org);
});

// GOD: територия
router.post("/territory", godAccess, async (req, res) => {
  const { orgId, name, influence, incomeBonus, dangerLevel } = req.body;
  const org = await engine.setTerritory(orgId, name, influence, incomeBonus, dangerLevel);
  res.json(org);
});

// GOD: отношения
router.post("/relation", godAccess, async (req, res) => {
  const { orgId, targetOrgId, type } = req.body;
  const org = await engine.addRelation(orgId, targetOrgId, type);
  res.json(org);
});

// GOD: ресурси
router.post("/resources", godAccess, async (req, res) => {
  const { orgId, resources } = req.body;
  const org = await engine.addResources(orgId, resources);
  res.json(org);
});

module.exports = router;