const mongoose = require("mongoose");

const organizationSchema = new mongoose.Schema({
  name: { type: String, required: true },
  type: {
    type: String,
    enum: ["gang", "clan", "cartel", "family", "syndicate", "corporation"],
    required: true
  },

  leader: { type: String, default: null }, // npcId

  members: [
    {
      npcId: String,
      role: {
        type: String,
        enum: [
          "leader",
          "underboss",
          "captain",
          "soldier",
          "recruit",
          "advisor",
          "financier",
          "hacker",
          "enforcer"
        ],
        default: "recruit"
      }
    }
  ],

  resources: {
    money: { type: Number, default: 0 },
    weapons: { type: Number, default: 0 },
    vehicles: { type: Number, default: 0 },
    businesses: { type: Array, default: [] }
  },

  territory: {
    name: { type: String, default: null },
    influence: { type: Number, default: 0 }, // колко контрол имат
    incomeBonus: { type: Number, default: 0 }, // бонус към NPC Economy
    dangerLevel: { type: Number, default: 0 } // колко е опасно
  },

  relations: {
    allies: { type: Array, default: [] }, // organizationId
    enemies: { type: Array, default: [] }
  },

  operations: {
    extortion: { type: Number, default: 0 },
    drugs: { type: Number, default: 0 },
    hacking: { type: Number, default: 0 },
    smuggling: { type: Number, default: 0 },
    businessControl: { type: Number, default: 0 }
  }

}, { timestamps: true });

module.exports = mongoose.model("Organization", organizationSchema);