const NPC = require("../npc.model");
const Player = require("../../player/player.model");
const District = require("../../world/districts/District.model");
const Organization = require("../../organizations/organization.model");

module.exports = {

  async fight(npcId, playerId) {
    const npc = await NPC.findById(npcId);
    const player = await Player.findById(playerId);

    if (!npc || !player) {
      return { error: "NPC или Player не е намерен" };
    }

    // ============================
    // DISTRICT BONUS
    // ============================
    const district = await District.findOne({ name: npc.district });
    const districtBonus = district ? district.influence * 0.1 : 0;

    // ============================
    // ORGANIZATION BONUS
    // ============================
    let orgBonusA = 0;
    if (npc.organizationId) {
      const org = await Organization.findById(npc.organizationId);
      if (org) orgBonusA = org.attackBonus || 0;
    }

    // ============================
    // NPC → PLAYER ATTACK
    // ============================
    const npcBaseDamage =
      npc.strength +
      npc.level +
      districtBonus +
      orgBonusA +
      Math.random() * 3;

    const npcCritChance = npc.aggression;
    const npcCrit = Math.random() < npcCritChance;

    const npcFinalDamage = npcCrit ? npcBaseDamage * 1.5 : npcBaseDamage;

    const playerDefense =
      player.level +
      player.armor +
      player.experience * 0.05;

    const damageToPlayer = Math.max(1, npcFinalDamage - playerDefense);

    player.hp = Math.max(0, player.hp - damageToPlayer);

    // ============================
    // PLAYER → NPC COUNTER ATTACK
    // ============================
    const playerBaseDamage =
      player.strength +
      player.level +
      Math.random() * 2;

    const playerCritChance = player.aggression || 0.05; // малък шанс
    const playerCrit = Math.random() < playerCritChance;

    const playerFinalDamage = playerCrit ? playerBaseDamage * 1.5 : playerBaseDamage;

    const npcDefense =
      npc.level +
      npc.fear * 0.1;

    const damageToNpc = Math.max(1, playerFinalDamage - npcDefense);

    npc.hp = Math.max(0, npc.hp - damageToNpc);

    // Save both
    await player.save();
    await npc.save();

    // ============================
    // FINAL RESULT OBJECT
    // ============================
    return {
      attacker: npc.name,
      defender: player.username,

      npcDamage: Math.round(damageToPlayer),
      playerDamage: Math.round(damageToNpc),

      npcHP: npc.hp,
      playerHP: player.hp,

      npcCritical: npcCrit,
      playerCritical: playerCrit,

      districtBonus,
      orgBonusA
    };
  }
};