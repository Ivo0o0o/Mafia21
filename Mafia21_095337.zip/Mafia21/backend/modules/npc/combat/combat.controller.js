const CombatEngine = require("./combat.engine");

module.exports = {

  async npcVsNpc(req, res) {
    try {
      const { attackerId, defenderId } = req.body;

      // Проверка за липсващи параметри
      if (!attackerId || !defenderId) {
        return res.status(400).json({
          success: false,
          error: "Missing attackerId or defenderId"
        });
      }

      const result = await CombatEngine.fight(attackerId, defenderId);

      if (result.error) {
        return res.status(404).json({
          success: false,
          error: result.error
        });
      }

      return res.json({
        success: true,
        combat: result,
        message: "NPC combat executed successfully"
      });

    } catch (err) {
      console.error("NPC Combat Error:", err);
      return res.status(500).json({
        success: false,
        error: "Internal server error",
        details: err.message
      });
    }
  }
};