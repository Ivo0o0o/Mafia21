const PlayerCombatEngine = require("./playerCombat.engine");

module.exports = {

  async npcVsPlayer(req, res) {
    try {
      const { npcId, playerId } = req.body;

      // Проверка за липсващи параметри
      if (!npcId || !playerId) {
        return res.status(400).json({
          success: false,
          error: "Missing npcId or playerId"
        });
      }

      const result = await PlayerCombatEngine.fight(npcId, playerId);

      if (result.error) {
        return res.status(404).json({
          success: false,
          error: result.error
        });
      }

      return res.json({
        success: true,
        combat: result,
        message: "NPC vs Player combat executed successfully"
      });

    } catch (err) {
      console.error("NPC vs Player Combat Error:", err);
      return res.status(500).json({
        success: false,
        error: "Internal server error",
        details: err.message
      });
    }
  }
};