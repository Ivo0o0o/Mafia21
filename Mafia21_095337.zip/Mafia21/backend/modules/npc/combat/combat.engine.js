const NPC = require("../npc.model");
const District = require("../../world/districts/District.model");
const Organization = require("../../organizations/organization.model");

module.exports = {

  async fight(attackerId, defenderId) {
    const attacker = await NPC.findById(attackerId);
    const defender = await NPC.findById(defenderId);

    if (!attacker || !defender) {
      return { error: "NPC not found" };
    }

    // District bonus
    const district = await District.findOne({ name: attacker.district });
    const districtBonus = district ? district.influence * 0.1 : 0;

    // Organization bonus
    let orgBonusA = 0;
    let orgBonusD = 0;

    if (attacker.organizationId) {
      const org = await Organization.findById(attacker.organizationId);
      if (org) orgBonusA = org.attackBonus || 0;
    }

    if (defender.organizationId) {
      const org = await Organization.findById(defender.organizationId);
      if (org) orgBonusD = org.defenseBonus || 0;
    }

    // ============================
    // ATTACKER DAMAGE CALCULATION
    // ============================
    const baseDamageA =
      attacker.strength +
      attacker.level +
      districtBonus +
      orgBonusA +
      Math.random() * 3;

    const critChanceA = attacker.aggression;
    const isCritA = Math.random() < critChanceA;

    const finalDamageA = isCritA ? baseDamageA * 1.5 : baseDamageA;

    const defenseD =
      defender.level +
      orgBonusD +
      defender.fear * 0.1;

    const damageToDefender = Math.max(1, finalDamageA - defenseD);

    defender.hp = Math.max(0, defender.hp - damageToDefender);

    // ============================
    // DEFENDER COUNTER-ATTACK
    // ============================
    const baseDamageD =
      defender.strength +
      defender.level +
      Math.random() * 2;

    const critChanceD = defender.aggression * 0.5; // по-малък шанс за контра
    const isCritD = Math.random() < critChanceD;

    const finalDamageD = isCritD ? baseDamageD * 1.5 : baseDamageD;

    const defenseA =
      attacker.level +
      attacker.fear * 0.1;

    const damageToAttacker = Math.max(1, finalDamageD - defenseA);

    attacker.hp = Math.max(0, attacker.hp - damageToAttacker);

    // Save both NPCs
    await attacker.save();
    await defender.save();

    return {
      attacker: attacker.name,
      defender: defender.name,

      attackerDamage: Math.round(damageToAttacker),
      defenderDamage: Math.round(damageToDefender),

      attackerHP: attacker.hp,
      defenderHP: defender.hp,

      attackerCritical: isCritA,
      defenderCritical: isCritD,

      districtBonus,
      orgBonusA,
      orgBonusD
    };
  }
};