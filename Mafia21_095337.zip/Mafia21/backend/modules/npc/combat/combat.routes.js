const router = require("express").Router();
const CombatController = require("./combat.controller");

// NPC vs NPC Combat (PRO)
router.post("/npc-vs-npc", CombatController.npcVsNpc);

// Health check / debug endpoint (полезно за админ панела)
router.get("/status", (req, res) => {
  res.json({
    success: true,
    message: "NPC Combat module is active"
  });
});

module.exports = router;