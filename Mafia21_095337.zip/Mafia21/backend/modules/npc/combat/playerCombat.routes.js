const router = require("express").Router();
const PlayerCombatController = require("./playerCombat.controller");

// NPC → Player Combat (PRO)
router.post("/npc-vs-player", PlayerCombatController.npcVsPlayer);

// Health check / debug endpoint
router.get("/status", (req, res) => {
  res.json({
    success: true,
    message: "Player Combat module is active"
  });
});

module.exports = router;