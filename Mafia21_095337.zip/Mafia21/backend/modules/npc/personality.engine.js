const NPCPersonality = require("./personality.model");

async function getNPCProfile(npcId) {
  let profile = await NPCPersonality.findOne({ npcId });
  if (!profile) profile = await NPCPersonality.create({ npcId });
  return profile;
}

async function updateNPCProfile(npcId, data) {
  let profile = await getNPCProfile(npcId);

  for (const key in data) {
    if (profile[key] !== undefined) {
      profile[key] = data[key];
    }
  }

  await profile.save();
  return profile;
}

module.exports = {
  getNPCProfile,
  updateNPCProfile
};