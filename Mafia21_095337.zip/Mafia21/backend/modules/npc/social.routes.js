const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const engine = require("./social.engine");

// GOD: виж социалния профил
router.get("/:npcId", godAccess, async (req, res) => {
  const social = await engine.getSocial(req.params.npcId);
  res.json(social);
});

// GOD: добави приятел
router.post("/friend", godAccess, async (req, res) => {
  const { npcId, targetId } = req.body;
  const social = await engine.addFriend(npcId, targetId);
  res.json(social);
});

// GOD: добави враг
router.post("/enemy", godAccess, async (req, res) => {
  const { npcId, targetId } = req.body;
  const social = await engine.addEnemy(npcId, targetId);
  res.json(social);
});

// GOD: добави съюзник
router.post("/ally", godAccess, async (req, res) => {
  const { npcId, targetId } = req.body;
  const social = await engine.addAlly(npcId, targetId);
  res.json(social);
});

// GOD: добави конкурент
router.post("/rival", godAccess, async (req, res) => {
  const { npcId, targetId } = req.body;
  const social = await engine.addRival(npcId, targetId);
  res.json(social);
});

// GOD: запиши социално събитие
router.post("/event", godAccess, async (req, res) => {
  const { npcId, type, targetId } = req.body;
  const social = await engine.recordSocialEvent(npcId, type, targetId);
  res.json(social);
});

module.exports = router;