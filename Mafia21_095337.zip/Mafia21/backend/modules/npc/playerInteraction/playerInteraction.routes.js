const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./playerInteraction.engine");

// GOD: виж играча
router.get("/:playerId", godAccess, async (req, res) => {
  res.json(await engine.getPlayer(req.params.playerId));
});

// GOD: играчът помага NPC
router.post("/helpNpc", godAccess, async (req, res) => {
  const { playerId, npcId } = req.body;
  res.json(await engine.playerHelpNpc(playerId, npcId));
});

// GOD: играчът напада NPC
router.post("/attackNpc", godAccess, async (req, res) => {
  const { playerId, npcId } = req.body;
  res.json(await engine.playerAttackNpc(playerId, npcId));
});

// GOD: играчът напада клан
router.post("/attackClan", godAccess, async (req, res) => {
  const { playerId, orgId } = req.body;
  res.json(await engine.playerAttackClan(playerId, orgId));
});

// GOD: играчът прави сделка с клан
router.post("/dealClan", godAccess, async (req, res) => {
  const { playerId, orgId } = req.body;
  res.json(await engine.playerDealClan(playerId, orgId));
});

// GOD: player tick
router.post("/tick", godAccess, async (req, res) => {
  const { playerId } = req.body;
  res.json(await engine.playerTick(playerId));
});

module.exports = router;