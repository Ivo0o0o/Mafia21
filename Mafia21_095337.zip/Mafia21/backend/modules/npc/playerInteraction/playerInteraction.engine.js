const PlayerInteraction = require("./playerInteraction.model");
const NPCSocial = require("../social.model");
const OrgDiplomacy = require("../organizationDiplomacy/diplomacy.model");
const OrgOperations = require("../organizationOperations/operations.model");

async function getPlayer(playerId) {
  let pi = await PlayerInteraction.findOne({ playerId });
  if (!pi) pi = await PlayerInteraction.create({ playerId });
  return pi;
}

// 1. Играчът помага на NPC
async function playerHelpNpc(playerId, npcId) {
  const pi = await getPlayer(playerId);

  pi.reputation += 5;
  pi.respect += 3;

  pi.npcReactions.push({
    npcId,
    reaction: "friendly"
  });

  await pi.save();

  // NPC социална памет
  const social = await NPCSocial.findOne({ npcId });
  if (social) {
    social.socialMemory.helpedBy.push(playerId);
    await social.save();
  }

  return pi;
}

// 2. Играчът напада NPC
async function playerAttackNpc(playerId, npcId) {
  const pi = await getPlayer(playerId);

  pi.reputation -= 10;
  pi.fear += 10;

  pi.npcReactions.push({
    npcId,
    reaction: "afraid"
  });

  await pi.save();

  const social = await NPCSocial.findOne({ npcId });
  if (social) {
    social.socialMemory.attackedBy.push(playerId);
    await social.save();
  }

  return pi;
}

// 3. Играчът атакува клан
async function playerAttackClan(playerId, orgId) {
  const pi = await getPlayer(playerId);

  let rel = pi.clanRelations.find(r => r.orgId === orgId);
  if (!rel) {
    rel = { orgId, relation: "hostile", trust: 0, tension: 50 };
    pi.clanRelations.push(rel);
  }

  rel.relation = "hostile";
  rel.trust -= 10;
  rel.tension += 20;

  pi.reputation -= 15;
  pi.fear += 5;

  await pi.save();

  // Кланът реагира чрез операции
  const ops = await OrgOperations.findOne({ orgId });
  if (ops) {
    ops.operations.push({
      opId: "retaliation_" + Date.now(),
      type: "attack",
      targetId: playerId,
      district: "unknown",
      successChance: 60,
      riskLevel: 20,
      reward: 0
    });
    await ops.save();
  }

  return pi;
}

// 4. Играчът прави сделка с клан
async function playerDealClan(playerId, orgId) {
  const pi = await getPlayer(playerId);

  let rel = pi.clanRelations.find(r => r.orgId === orgId);
  if (!rel) {
    rel = { orgId, relation: "friendly", trust: 20, tension: 0 };
    pi.clanRelations.push(rel);
  }

  rel.relation = "friendly";
  rel.trust += 15;
  rel.tension -= 10;

  pi.reputation += 10;
  pi.respect += 5;

  await pi.save();

  // Дипломатически ефект
  await OrgDiplomacy.updateMany(
    { $or: [{ orgA: orgId }, { orgB: orgId }] },
    { $inc: { trustLevel: 5 } }
  );

  return pi;
}

// 5. Пълен Player Interaction Tick
async function playerTick(playerId) {
  const pi = await getPlayer(playerId);

  // естествено развитие
  pi.reputation -= 0.5;
  pi.fear -= 0.2;
  pi.respect -= 0.3;

  pi.reputation = Math.max(0, Math.min(100, pi.reputation));
  pi.fear = Math.max(0, Math.min(100, pi.fear));
  pi.respect = Math.max(0, Math.min(100, pi.respect));

  pi.lastUpdate = new Date();
  await pi.save();

  return pi;
}

module.exports = {
  getPlayer,
  playerHelpNpc,
  playerAttackNpc,
  playerAttackClan,
  playerDealClan,
  playerTick
};