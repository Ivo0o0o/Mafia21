const mongoose = require("mongoose");

const playerInteractionSchema = new mongoose.Schema({
  playerId: { type: String, required: true },

  reputation: { type: Number, default: 50 },     // 0–100
  fear: { type: Number, default: 10 },           // 0–100
  respect: { type: Number, default: 10 },        // 0–100

  clanRelations: [
    {
      orgId: String,
      relation: {
        type: String,
        enum: ["friendly", "neutral", "hostile"],
        default: "neutral"
      },
      trust: Number,
      tension: Number
    }
  ],

  npcReactions: [
    {
      npcId: String,
      reaction: {
        type: String,
        enum: ["friendly", "neutral", "afraid", "aggressive"],
        default: "neutral"
      },
      lastInteraction: { type: Date, default: Date.now }
    }
  ],

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("PlayerInteraction", playerInteractionSchema);