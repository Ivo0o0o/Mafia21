const NPCBehavior = require("./behavior.model");
const NPCDialogue = require("../dialogueEngine/dialogue.model");
const PlayerInteraction = require("../playerInteraction/playerInteraction.model");
const Overseer = require("../overseer/overseer.model");
const Mission = require("../missionEngine/mission.model");

async function getBehavior(npcId) {
  let b = await NPCBehavior.findOne({ npcId });
  if (!b) b = await NPCBehavior.create({ npcId });
  return b;
}

async function decideBehavior(npcId, playerId) {
  const b = await getBehavior(npcId);
  const d = await NPCDialogue.findOne({ npcId });
  const pi = await PlayerInteraction.findOne({ playerId });
  const overseer = await Overseer.findOne({ worldId: "default" });
  const activeMission = await Mission.findOne({ status: "active" });

  let decision = "idle";

  // 1. Страх → бягство
  if (b.fear > 60 || d.relationshipToPlayer === "afraid") {
    decision = "flee";
  }

  // 2. Агресия → атака
  if (b.aggression > 70 || d.personalityType === "aggressive") {
    if (d.relationshipToPlayer === "hostile") {
      decision = "attack";
    }
  }

  // 3. Лоялност → помощ
  if (b.loyalty > 60 || d.personalityType === "loyal") {
    decision = "assist";
  }

  // 4. Overseer напрежение → NPC става нервен
  if (overseer.metrics.worldTension > 70) {
    if (b.aggression > 40) decision = "attack";
    else decision = "observe";
  }

  // 5. Мисия → NPC следи играча
  if (activeMission) {
    decision = "follow";
  }

  // 6. Ако играчът е легенда → NPC се държи различно
  if (pi && pi.fear > 60) {
    if (decision === "attack") decision = "observe";
    if (decision === "flee") decision = "idle";
  }

  b.state = decision;
  b.lastDecision = decision;
  b.lastUpdate = new Date();
  await b.save();

  return decision;
}

async function updateBehaviorStats(npcId, stats) {
  const b = await getBehavior(npcId);

  if (stats.aggression !== undefined) b.aggression = stats.aggression;
  if (stats.fear !== undefined) b.fear = stats.fear;
  if (stats.loyalty !== undefined) b.loyalty = stats.loyalty;

  await b.save();
  return b;
}

module.exports = {
  getBehavior,
  decideBehavior,
  updateBehaviorStats
};