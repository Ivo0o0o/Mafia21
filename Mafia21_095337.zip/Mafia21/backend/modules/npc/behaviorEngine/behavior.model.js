const mongoose = require("mongoose");

const behaviorSchema = new mongoose.Schema({
  npcId: { type: String, required: true },

  // Основно поведение
  state: {
    type: String,
    enum: ["idle", "flee", "attack", "follow", "assist", "observe"],
    default: "idle"
  },

  aggression: { type: Number, default: 20 },   // 0–100
  fear: { type: Number, default: 20 },         // 0–100
  loyalty: { type: Number, default: 20 },      // 0–100

  lastDecision: { type: String, default: "" },
  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("NPCBehavior", behaviorSchema);