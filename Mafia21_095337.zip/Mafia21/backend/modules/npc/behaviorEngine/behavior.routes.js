const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const engine = require("./behavior.engine");

// GOD: вземи решение
router.post("/decide", godAccess, async (req, res) => {
  const { npcId, playerId } = req.body;
  res.json(await engine.decideBehavior(npcId, playerId));
});

// GOD: промени статистики
router.post("/stats", godAccess, async (req, res) => {
  const { npcId, stats } = req.body;
  res.json(await engine.updateBehaviorStats(npcId, stats));
});

// GOD: виж профил
router.get("/:npcId", godAccess, async (req, res) => {
  res.json(await engine.getBehavior(req.params.npcId));
});

module.exports = router;