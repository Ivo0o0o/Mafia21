const mongoose = require("mongoose");

const npcAISchema = new mongoose.Schema({
  npcId: { type: String, required: true },

  mood: {
    type: String,
    enum: ["calm", "neutral", "suspicious", "scared", "aggressive"],
    default: "neutral"
  },

  location: {
    district: { type: String, default: "unknown" },
    x: { type: Number, default: 0 },
    y: { type: Number, default: 0 }
  },

  patrolRoute: [
    {
      district: String,
      x: Number,
      y: Number
    }
  ],

  lastInteraction: {
    type: Date,
    default: null
  },

  aggressionLevel: { type: Number, default: 0 }, // 0–100
  fearLevel: { type: Number, default: 0 },       // 0–100

}, { timestamps: true });

module.exports = mongoose.model("NpcAI", npcAISchema);

const mongoose = require("mongoose");

const npcAISchema = new mongoose.Schema({
  npcId: { type: String, required: true },

  mood: {
    type: String,
    enum: ["calm", "neutral", "suspicious", "scared", "aggressive"],
    default: "neutral"
  },

  location: {
    district: { type: String, default: "unknown" },
    x: { type: Number, default: 0 },
    y: { type: Number, default: 0 }
  },

  patrolRoute: [
    {
      district: String,
      x: Number,
      y: Number
    }
  ],

  lastInteraction: {
    type: Date,
    default: null
  },

  aggressionLevel: { type: Number, default: 0 }, // 0–100
  fearLevel: { type: Number, default: 0 }        // 0–100

}, { timestamps: true });

module.exports = mongoose.model("NpcAI", npcAISchema);