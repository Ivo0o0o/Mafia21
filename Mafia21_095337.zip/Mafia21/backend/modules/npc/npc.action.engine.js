const NPC = require("./npc.model");
const NpcMissionEngine = require("./npc.mission.engine");

module.exports = {

  async tick() {
    const npcs = await NPC.find();

    for (const npc of npcs) {

      // 1) Cooldown check
      if (npc.lastAction && Date.now() - npc.lastAction.getTime() < 30000) {
        continue; // 30 сек
      }

      // 2) Personality-based decision
      const action = this.chooseAction(npc);

      // 3) Execute action
      await this.executeAction(npc, action);

      // 4) Update cooldown
      npc.lastAction = new Date();
      await npc.save();
    }
  },

  chooseAction(npc) {
    // Personality → Action
    if (npc.personality === "aggressive") return "attack";
    if (npc.personality === "criminal") return "steal";
    if (npc.personality === "dealer") return "deal";
    if (npc.personality === "friendly") return "giveMission";

    return "idle";
  },

  async executeAction(npc, action) {
    switch (action) {

      case "giveMission":
        const mission = await NpcMissionEngine.getNpcMission(npc);
        console.log(`NPC ${npc.name} предлага мисия:`, mission?.name);
        break;

      case "attack":
        console.log(`NPC ${npc.name} атакува бизнес в район ${npc.district}`);
        break;

      case "steal":
        console.log(`NPC ${npc.name} краде в район ${npc.district}`);
        break;

      case "deal":
        console.log(`NPC ${npc.name} продава стока в район ${npc.district}`);
        break;

      default:
        console.log(`NPC ${npc.name} стои спокойно.`);
        break;
    }
  }
};