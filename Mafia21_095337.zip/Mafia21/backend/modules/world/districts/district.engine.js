const District = require("./district.model");
const { v4: uuidv4 } = require("uuid");

// 1. Създай район
async function createDistrict(name, x, y) {
  const d = await District.create({
    districtId: uuidv4(),
    name,
    position: { x, y }
  });
  return d;
}

// 2. Вземи всички райони
async function listDistricts() {
  return await District.find().sort({ name: 1 });
}

// 3. Обнови престъпност
async function updateCrime(districtId, amount) {
  const d = await District.findOne({ districtId });
  if (!d) return null;

  d.crimeLevel = Math.max(0, Math.min(100, d.crimeLevel + amount));
  await d.save();
  return d;
}

// 4. Обнови икономика
async function updateEconomy(districtId, amount) {
  const d = await District.findOne({ districtId });
  if (!d) return null;

  d.economyLevel = Math.max(0, Math.min(100, d.economyLevel + amount));
  await d.save();
  return d;
}

// 5. Обнови NPC активност
async function updateNPCDensity(districtId, amount) {
  const d = await District.findOne({ districtId });
  if (!d) return null;

  d.npcDensity = Math.max(0, Math.min(100, d.npcDensity + amount));
  await d.save();
  return d;
}

// 6. Обнови полиция
async function updatePolicePresence(districtId, amount) {
  const d = await District.findOne({ districtId });
  if (!d) return null;

  d.policePresence = Math.max(0, Math.min(100, d.policePresence + amount));
  await d.save();
  return d;
}

// 7. Играч контрол
async function updatePlayerControl(districtId, amount) {
  const d = await District.findOne({ districtId });
  if (!d) return null;

  d.playerControl = Math.max(0, Math.min(100, d.playerControl + amount));
  await d.save();
  return d;
}

module.exports = {
  createDistrict,
  listDistricts,
  updateCrime,
  updateEconomy,
  updateNPCDensity,
  updatePolicePresence,
  updatePlayerControl
};