const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./district.engine");

// GOD: create district
router.post("/create", godAccess, async (req, res) => {
  const { name, x, y } = req.body;
  res.json(await engine.createDistrict(name, x, y));
});

// GOD: list districts
router.get("/", godAccess, async (req, res) => {
  res.json(await engine.listDistricts());
});

// GOD: update crime
router.post("/crime", godAccess, async (req, res) => {
  const { districtId, amount } = req.body;
  res.json(await engine.updateCrime(districtId, amount));
});

// GOD: update economy
router.post("/economy", godAccess, async (req, res) => {
  const { districtId, amount } = req.body;
  res.json(await engine.updateEconomy(districtId, amount));
});

// GOD: update npc density
router.post("/npc", godAccess, async (req, res) => {
  const { districtId, amount } = req.body;
  res.json(await engine.updateNPCDensity(districtId, amount));
});

// GOD: update police
router.post("/police", godAccess, async (req, res) => {
  const { districtId, amount } = req.body;
  res.json(await engine.updatePolicePresence(districtId, amount));
});

// GOD: update player control
router.post("/control", godAccess, async (req, res) => {
  const { districtId, amount } = req.body;
  res.json(await engine.updatePlayerControl(districtId, amount));
});

module.exports = router;

const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const District = require("./district.model");

// GET district by ID
router.get("/:districtId", godAccess, async (req, res) => {
  const d = await District.findOne({ districtId: req.params.districtId });
  if (!d) return res.json({ error: "District not found" });
  res.json(d);
});

module.exports = router;