const mongoose = require("mongoose");

const districtSchema = new mongoose.Schema({
  districtId: { type: String, required: true },
  name: { type: String, required: true },

  // географски координати (за карта)
  position: {
    x: { type: Number, default: 0 },
    y: { type: Number, default: 0 }
  },

  // динамика
  crimeLevel: { type: Number, default: 20 },      // престъпност
  economyLevel: { type: Number, default: 30 },    // икономика
  npcDensity: { type: Number, default: 10 },      // NPC активност
  policePresence: { type: Number, default: 15 },  // полиция

  // контрол от играча
  playerControl: { type: Number, default: 0 },    // 0–100

  // контрол от организации
  orgControl: [
    {
      orgId: String,
      control: Number
    }
  ],

  lastUpdate: { type: Date, default: Date.now }

}, { timestamps: true });

module.exports = mongoose.model("District", districtSchema);