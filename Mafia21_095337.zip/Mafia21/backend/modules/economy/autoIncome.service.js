const WalletService = require('./wallet.service');
const Transaction = require('./Transaction.model');
const District = require('../districts/District.model'); // смени името, ако е различно

// Примерна формула – адаптирай според твоя модел:
// income = baseIncome * influenceMultiplier * (1 - crimePenalty)

function calculateDistrictIncome(district) {
  const baseIncome = district.baseIncome || 100; // ако нямаш поле, можеш да го добавиш
  const influence = district.influence || 1;     // 1 = нормално, >1 = бонус
  const crimeRate = district.crimeRate || 0;     // 0–1 (напр. 0.3 = 30%)

  const influenceMultiplier = 1 + (influence * 0.1);   // всяка точка влияние дава +10%
  const crimePenalty = Math.min(crimeRate, 0.9);       // максимум 90% наказание

  const income = baseIncome * influenceMultiplier * (1 - crimePenalty);

  return Math.max(0, Math.round(income));
}

module.exports = {
  runIncomeTick: async () => {
    // Взимаме всички райони
    const districts = await District.find({});

    const results = [];

    for (const district of districts) {
      // ако районът няма owner – пропускаме
      if (!district.owner) continue;

      const income = calculateDistrictIncome(district);
      if (income <= 0) continue;

      // Добавяме пари в портфейла на собственика
      const wallet = await WalletService.addMoney(district.owner, income, `Auto income from district ${district.name}`);

      // Логваме транзакцията (вече се логва в addMoney, но ако искаш отделен лог – можеш да добавиш тук)
      results.push({
        district: district._id,
        districtName: district.name,
        owner: district.owner,
        income,
        balanceAfter: wallet.balance
      });
    }

    return results;
  }
};