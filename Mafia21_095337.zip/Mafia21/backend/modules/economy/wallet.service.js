const Wallet = require('./Wallet.model');
const Transaction = require('./Transaction.model');

module.exports = {
  getWallet: async (userId) => {
    let wallet = await Wallet.findOne({ user: userId });
    if (!wallet) wallet = await Wallet.create({ user: userId });
    return wallet;
  },

  addMoney: async (userId, amount, reason = '') => {
    const wallet = await module.exports.getWallet(userId);
    wallet.balance += amount;
    await wallet.save();

    await Transaction.create({
      type: 'income',
      amount,
      toUser: userId,
      reason
    });

    return wallet;
  },

  removeMoney: async (userId, amount, reason = '') => {
    const wallet = await module.exports.getWallet(userId);
    if (wallet.balance < amount) throw new Error('Недостатъчен баланс');

    wallet.balance -= amount;
    await wallet.save();

    await Transaction.create({
      type: 'expense',
      amount,
      fromUser: userId,
      reason
    });

    return wallet;
  },

  transfer: async (fromUser, toUser, amount, reason = '') => {
    const fromWallet = await module.exports.getWallet(fromUser);
    const toWallet = await module.exports.getWallet(toUser);

    if (fromWallet.balance < amount) throw new Error('Недостатъчен баланс');

    fromWallet.balance -= amount;
    toWallet.balance += amount;

    await fromWallet.save();
    await toWallet.save();

    await Transaction.create({
      type: 'transfer',
      amount,
      fromUser,
      toUser,
      reason
    });

    return { fromWallet, toWallet };
  }
};