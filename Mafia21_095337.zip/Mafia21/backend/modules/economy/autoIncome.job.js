const autoIncomeService = require('./autoIncome.service');

// Интервал в милисекунди – напр. на всеки 5 минути
const INTERVAL_MS = 5 * 60 * 1000;

// Ако искаш веднъж на час:
// const INTERVAL_MS = 60 * 60 * 1000;

let isRunning = false;

async function runJob() {
  if (isRunning) {
    console.log('[AutoIncome] Skip tick – already running');
    return;
  }

  isRunning = true;
  console.log('[AutoIncome] Tick started');

  try {
    const results = await autoIncomeService.runIncomeTick();
    console.log('[AutoIncome] Tick finished. Districts processed:', results.length);
  } catch (err) {
    console.error('[AutoIncome] Error:', err.message);
  } finally {
    isRunning = false;
  }
}

module.exports = {
  startAutoIncomeJob: () => {
    console.log('[AutoIncome] Scheduler started. Interval:', INTERVAL_MS, 'ms');
    // Пускаме веднага един път
    runJob();
    // После периодично
    setInterval(runJob, INTERVAL_MS);
  }
};