const express = require('express');
const router = express.Router();
const controller = require('./economy.controller');
const auth = require('../../core/auth');

router.get('/wallet', auth, controller.getWallet);
router.get('/transactions', auth, controller.getTransactions);
router.post('/transfer', auth, controller.transfer);

module.exports = router;