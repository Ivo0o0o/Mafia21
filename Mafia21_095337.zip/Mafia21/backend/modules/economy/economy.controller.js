const walletService = require('./wallet.service');
const Transaction = require('./Transaction.model');

module.exports = {
  getWallet: async (req, res) => {
    try {
      const wallet = await walletService.getWallet(req.user._id);
      res.json(wallet);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  getTransactions: async (req, res) => {
    try {
      const tx = await Transaction.find({
        $or: [
          { fromUser: req.user._id },
          { toUser: req.user._id }
        ]
      }).sort({ createdAt: -1 });

      res.json(tx);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  transfer: async (req, res) => {
    try {
      const { toUser, amount, reason } = req.body;
      const result = await walletService.transfer(req.user._id, toUser, amount, reason);
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  }
};