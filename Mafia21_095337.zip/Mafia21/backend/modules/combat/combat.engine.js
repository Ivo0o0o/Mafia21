const CombatLog = require("./combat.model");
const User = require("../users/user.model");
const NpcAI = require("../npc/npcAI.model");

async function combat(userId, npcId) {
  const user = await User.findById(userId);
  const npc = await NpcAI.findOne({ npcId });

  if (!user || !npc) throw new Error("User or NPC not found");

  let userChance = 50;

  // Умения на играча
  userChance += user.skills.shooting * 0.5;
  userChance += user.skills.intimidation * 0.2;

  // NPC настроение
  if (npc.mood === "aggressive") userChance -= 20;
  if (npc.mood === "scared") userChance += 20;

  // NPC агресия/страх
  userChance -= npc.aggressionLevel * 0.3;
  userChance += npc.fearLevel * 0.3;

  // Ограничаваме шанс
  if (userChance < 5) userChance = 5;
  if (userChance > 95) userChance = 95;

  const roll = Math.random() * 100;
  const success = roll <= userChance;

  let result = success ? "win" : "lose";
  let damage = success ? Math.floor(Math.random() * 20) : Math.floor(Math.random() * 40);

  // NPC реакция след бой
  if (!success) {
    npc.aggressionLevel += 10;
    npc.fearLevel -= 10;
  } else {
    npc.fearLevel += 20;
    npc.aggressionLevel -= 10;
  }

  await npc.save();

  const log = await CombatLog.create({
    attackerId: userId,
    defenderId: npcId,
    attackerType: "player",
    defenderType: "npc",
    result,
    damage
  });

  return { success, userChance, roll, result, damage, npc };
}

module.exports = { combat };