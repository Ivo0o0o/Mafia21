const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const engine = require("./combat.engine");

// Играч атакува NPC
router.post("/fight", async (req, res) => {
  try {
    const { userId, npcId } = req.body;
    const result = await engine.combat(userId, npcId);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// GOD: виж всички боеве
router.get("/logs", godAccess, async (req, res) => {
  const CombatLog = require("./combat.model");
  const logs = await CombatLog.find().sort({ timestamp: -1 });
  res.json(logs);
});

module.exports = router;