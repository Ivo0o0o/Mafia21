const mongoose = require("mongoose");

const combatSchema = new mongoose.Schema({
  attackerId: String,
  defenderId: String,
  attackerType: { type: String, enum: ["player", "npc"], default: "player" },
  defenderType: { type: String, enum: ["player", "npc"], default: "npc" },

  result: String, // win / lose / escape
  damage: Number,
  timestamp: { type: Date, default: Date.now }
});

module.exports = mongoose.model("CombatLog", combatSchema);