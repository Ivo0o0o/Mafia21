const express = require('express');
const router = express.Router();
const controller = require('./god.controller');
const auth = require('../../core/auth');

router.post('/setRole', auth, controller.setRole);
router.post('/setMoney', auth, controller.setMoney);
router.post('/setDistrictCrime', auth, controller.setDistrictCrime);
router.post('/setDistrictInfluence', auth, controller.setDistrictInfluence);

module.exports = router;