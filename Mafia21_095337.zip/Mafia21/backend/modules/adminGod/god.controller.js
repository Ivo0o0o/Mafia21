const godEngine = require('./godEngine');

module.exports = {
  setRole: async (req, res) => {
    try {
      if (req.user.role !== 'god') {
        return res.status(403).json({ error: 'Само Бог може да променя роли.' });
      }

      const user = await godEngine.setRole(req.body.userId, req.body.role);
      res.json({ message: 'Ролята е променена.', user });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  setMoney: async (req, res) => {
    try {
      if (req.user.role !== 'god') {
        return res.status(403).json({ error: 'Само Бог може да променя пари.' });
      }

      const user = await godEngine.setMoney(req.body.userId, req.body.amount);
      res.json({ message: 'Парите са променени.', user });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  setDistrictCrime: async (req, res) => {
    try {
      if (req.user.role !== 'god') {
        return res.status(403).json({ error: 'Само Бог може да променя престъпност.' });
      }

      const district = await godEngine.setDistrictCrime(req.body.districtName, req.body.value);
      res.json({ message: 'Престъпността е променена.', district });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  setDistrictInfluence: async (req, res) => {
    try {
      if (req.user.role !== 'god') {
        return res.status(403).json({ error: 'Само Бог може да променя влияние.' });
      }

      const district = await godEngine.setDistrictInfluence(req.body.districtName, req.body.value);
      res.json({ message: 'Влиянието е променено.', district });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};