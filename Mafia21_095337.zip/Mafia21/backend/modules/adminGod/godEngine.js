const User = require('../users/User.model');
const District = require('../districts/District.model');
const NPC = require('../npc/NPC.model');
const Clan = require('../clans/Clan.model');
const Event = require('../events/Event.model');
const Business = require('../businesses/Business.model');
const CyberOp = require('../cyber/CyberOp.model');

module.exports = {
  // Пълен контрол над ролите
  setRole: async (userId, role) => {
    const user = await User.findById(userId);
    if (!user) throw new Error('Потребителят не е намерен');

    user.role = role;
    await user.save();
    return user;
  },

  // Пълен контрол над икономиката
  setMoney: async (userId, amount) => {
    const user = await User.findById(userId);
    if (!user) throw new Error('Потребителят не е намерен');

    user.money = amount;
    await user.save();
    return user;
  },

  // Пълен контрол над районите
  setDistrictCrime: async (districtName, value) => {
    const district = await District.findOne({ name: districtName });
    if (!district) throw new Error('Районът не е намерен');

    district.crimeRate = value;
    await district.save();
    return district;
  },

  setDistrictInfluence: async (districtName, value) => {
    const district = await District.findOne({ name: districtName });
    if (!district) throw new Error('Районът не е намерен');

    district.influence = value;
    await district.save();
    return district;
  },

  // Пълен контрол над NPC
  setNPCStrength: async (npcId, value) => {
    const npc = await NPC.findById(npcId);
    if (!npc) throw new Error('NPC не е намерен');

    npc.strength = value;
    await npc.save();
    return npc;
  },

  // Пълен контрол над кланове
  setClanInfluence: async (clanId, value) => {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error('Кланът не е намерен');

    clan.influence = value;
    await clan.save();
    return clan;
  },

  // Пълен контрол над събития
  triggerEvent: async (eventId) => {
    const event = await Event.findById(eventId);
    if (!event) throw new Error('Събитието не е намерено');

    event.active = true;
    await event.save();
    return event;
  },

  stopEvent: async (eventId) => {
    const event = await Event.findById(eventId);
    if (!event) throw new Error('Събитието не е намерено');

    event.active = false;
    await event.save();
    return event;
  },

  // Пълен контрол над бизнеси
  setBusinessIncome: async (businessId, value) => {
    const biz = await Business.findById(businessId);
    if (!biz) throw new Error('Бизнесът не е намерен');

    biz.baseIncome = value;
    await biz.save();
    return biz;
  },

  // Пълен контрол над кибер операции
  setCyberReward: async (opId, value) => {
    const op = await CyberOp.findById(opId);
    if (!op) throw new Error('Кибер операцията не е намерена');

    op.baseReward = value;
    await op.save();
    return op;
  }
};