const User = require('../users/User.model');
const Admin = require('./Admin.model');

module.exports = {
  makeGod: async (userId) => {
    const user = await User.findById(userId);
    if (!user) throw new Error('Потребителят не е намерен');

    user.role = 'god';
    user.permissions = ['ALL'];
    await user.save();

    await Admin.findOneAndUpdate(
      { userId },
      { level: 3, permissions: ['ALL'] },
      { upsert: true }
    );

    return user;
  },

  makeAdmin: async (userId) => {
    const user = await User.findById(userId);
    if (!user) throw new Error('Потребителят не е намерен');

    user.role = 'admin';
    user.permissions = ['MANAGE_NPC', 'MANAGE_EVENTS', 'MANAGE_CLANS'];
    await user.save();

    await Admin.findOneAndUpdate(
      { userId },
      { level: 2, permissions: user.permissions },
      { upsert: true }
    );

    return user;
  },

  makeModerator: async (userId) => {
    const user = await User.findById(userId);
    if (!user) throw new Error('Потребителят не е намерен');

    user.role = 'moderator';
    user.permissions = ['BAN', 'MUTE', 'VIEW_LOGS'];
    await user.save();

    await Admin.findOneAndUpdate(
      { userId },
      { level: 1, permissions: user.permissions },
      { upsert: true }
    );

    return user;
  },

  removeAdminRights: async (userId) => {
    const user = await User.findById(userId);
    if (!user) throw new Error('Потребителят не е намерен');

    user.role = 'player';
    user.permissions = [];
    await user.save();

    await Admin.deleteOne({ userId });

    return user;
  }
};