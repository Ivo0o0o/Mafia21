const adminEngine = require('./adminEngine');
const User = require('../users/User.model');

module.exports = {
  makeGod: async (req, res) => {
    try {
      if (req.user.role !== 'god') {
        return res.status(403).json({ error: 'Само Бог може да създава Бог.' });
      }

      const user = await adminEngine.makeGod(req.body.userId);
      res.json({ message: 'Потребителят е повишен до GOD.', user });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  makeAdmin: async (req, res) => {
    try {
      if (req.user.role !== 'god') {
        return res.status(403).json({ error: 'Само Бог може да създава админи.' });
      }

      const user = await adminEngine.makeAdmin(req.body.userId);
      res.json({ message: 'Потребителят е повишен до ADMIN.', user });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  makeModerator: async (req, res) => {
    try {
      if (!['god', 'admin'].includes(req.user.role)) {
        return res.status(403).json({ error: 'Нямаш права да създаваш модератори.' });
      }

      const user = await adminEngine.makeModerator(req.body.userId);
      res.json({ message: 'Потребителят е повишен до MODERATOR.', user });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  removeRights: async (req, res) => {
    try {
      if (req.user.role !== 'god') {
        return res.status(403).json({ error: 'Само Бог може да премахва права.' });
      }

      const user = await adminEngine.removeAdminRights(req.body.userId);
      res.json({ message: 'Потребителят е върнат до PLAYER.', user });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};