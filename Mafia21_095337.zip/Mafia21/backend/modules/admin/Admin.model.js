const mongoose = require('mongoose');

const adminSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  level: { type: Number, default: 1 }, // 1 = модератор, 2 = админ, 3 = бог
  permissions: [{ type: String }]
}, { timestamps: true });

module.exports = mongoose.model('Admin', adminSchema);