const express = require('express');
const router = express.Router();
const controller = require('./admin.controller');
const auth = require('../../core/auth');

router.post('/makeGod', auth, controller.makeGod);
router.post('/makeAdmin', auth, controller.makeAdmin);
router.post('/makeModerator', auth, controller.makeModerator);
router.post('/removeRights', auth, controller.removeRights);

module.exports = router;