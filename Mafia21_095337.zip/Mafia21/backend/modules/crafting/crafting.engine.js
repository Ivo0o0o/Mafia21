const CraftingRecipe = require("./crafting.model");
const CraftingService = require("./crafting.service");
const InventoryService = require("../inventory/inventory.service");
const Item = require("../items/item.model");

module.exports = {

  // ======================================================
  // CALCULATE SUCCESS CHANCE (dynamic)
  // ======================================================
  calculateSuccessChance(recipe, player) {
    let chance = recipe.successChance;

    // Player crafting skill bonus
    if (player.craftingSkill) {
      chance += player.craftingSkill * 2; // +2% per skill level
    }

    // Cap at 100%
    if (chance > 100) chance = 100;

    return chance;
  },

  // ======================================================
  // CALCULATE TIME REQUIRED (dynamic)
  // ======================================================
  calculateTime(recipe, player) {
    let time = recipe.timeRequired;

    // Faster crafting with higher skill
    if (player.craftingSkill) {
      time -= player.craftingSkill * 0.2; // -0.2 sec per skill level
    }

    if (time < 1) time = 1; // Minimum 1 second

    return time;
  },

  // ======================================================
  // CALCULATE HEAT (police attention)
  // ======================================================
  calculateHeat(recipe, player) {
    let heat = recipe.heat;

    // Illegal crafting increases heat
    if (recipe.illegal) {
      heat += 10;
    }

    // Player perks reduce heat
    if (player.perks?.stealthCrafter) {
      heat -= 5;
    }

    if (heat < 0) heat = 0;

    return heat;
  },

  // ======================================================
  // CALCULATE XP REWARD
  // ======================================================
  calculateXP(recipe, player) {
    let xp = recipe.xpReward;

    // Bonus XP for low-level players
    if (player.level < 10) {
      xp += 5;
    }

    return xp;
  },

  // ======================================================
  // SIMULATE CRAFTING (preview)
  // ======================================================
  async simulate(ownerId, recipeId, player) {
    const recipe = await CraftingService.getRecipe(recipeId);
    if (!recipe) return { success: false, error: "Recipe not found" };

    const hasMaterials = await CraftingService.hasMaterials(ownerId, recipe);
    const hasTools = await CraftingService.hasTools(ownerId, recipe);

    return {
      recipe: recipe.name,
      canCraft: hasMaterials && hasTools,
      missingMaterials: !hasMaterials,
      missingTools: !hasTools,
      successChance: this.calculateSuccessChance(recipe, player),
      timeRequired: this.calculateTime(recipe, player),
      heat: this.calculateHeat(recipe, player),
      xpReward: this.calculateXP(recipe, player)
    };
  },

  // ======================================================
  // FULL CRAFTING PROCESS
  // ======================================================
  async craft(ownerId, recipeId, player) {
    const recipe = await CraftingService.getRecipe(recipeId);
    if (!recipe) return { success: false, error: "Recipe not found" };

    // Check materials
    const hasMaterials = await CraftingService.hasMaterials(ownerId, recipe);
    if (!hasMaterials) return { success: false, error: "Missing materials" };

    // Check tools
    const hasTools = await CraftingService.hasTools(ownerId, recipe);
    if (!hasTools) return { success: false, error: "Missing tools" };

    // Dynamic success chance
    const chance = this.calculateSuccessChance(recipe, player);
    const roll = Math.random() * 100;
    const success = roll <= chance;

    // Consume materials ALWAYS
    await CraftingService.consumeMaterials(ownerId, recipe);

    // Apply tool durability
    await CraftingService.applyToolDurability(ownerId, recipe);

    if (!success) {
      return {
        success: false,
        error: "Crafting failed",
        roll,
        chance
      };
    }

    // Add crafted item
    await InventoryService.addItem(ownerId, recipe.resultItem._id, recipe.resultQuantity);

    return {
      success: true,
      item: recipe.resultItem,
      quantity: recipe.resultQuantity,
      xp: this.calculateXP(recipe, player),
      heat: this.calculateHeat(recipe, player),
      timeRequired: this.calculateTime(recipe, player)
    };
  }
};