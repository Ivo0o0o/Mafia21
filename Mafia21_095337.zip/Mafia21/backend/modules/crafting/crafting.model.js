const mongoose = require("mongoose");

// ======================================================
// MATERIAL REQUIREMENT
// ======================================================
const materialSchema = new mongoose.Schema({
  item: { type: mongoose.Schema.Types.ObjectId, ref: "Item", required: true },
  quantity: { type: Number, required: true }
}, { _id: false });

// ======================================================
// TOOL REQUIREMENT
// ======================================================
const toolSchema = new mongoose.Schema({
  item: { type: mongoose.Schema.Types.ObjectId, ref: "Item", required: true },
  durabilityCost: { type: Number, default: 0 }
}, { _id: false });

// ======================================================
// CRAFTING RECIPE MODEL
// ======================================================
const craftingSchema = new mongoose.Schema({

  // Name of the recipe
  name: { type: String, required: true },

  // Result item
  resultItem: { type: mongoose.Schema.Types.ObjectId, ref: "Item", required: true },

  // Result quantity
  resultQuantity: { type: Number, default: 1 },

  // Required materials
  materials: {
    type: [materialSchema],
    default: []
  },

  // Required tools
  tools: {
    type: [toolSchema],
    default: []
  },

  // Crafting difficulty
  craftingLevel: { type: Number, default: 1 },

  // Time required (in seconds)
  timeRequired: { type: Number, default: 3 },

  // Success chance (0–100)
  successChance: { type: Number, default: 100 },

  // Heat generated (police attention)
  heat: { type: Number, default: 0 },

  // Illegal crafting flag
  illegal: { type: Boolean, default: false },

  // Experience reward
  xpReward: { type: Number, default: 10 }

}, { timestamps: true });

module.exports = mongoose.model("CraftingRecipe", craftingSchema);