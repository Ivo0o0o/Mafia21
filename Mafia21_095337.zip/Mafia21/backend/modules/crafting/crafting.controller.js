const CraftingService = require("./crafting.service");
const CraftingEngine = require("./crafting.engine");

module.exports = {

  // ======================================================
  // LIST ALL RECIPES
  // ======================================================
  async list(req, res) {
    try {
      const recipes = await CraftingService.listRecipes();
      res.json({ success: true, recipes });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // GET SINGLE RECIPE
  // ======================================================
  async get(req, res) {
    try {
      const { recipeId } = req.params;

      const recipe = await CraftingService.getRecipe(recipeId);
      if (!recipe) return res.status(404).json({ error: "Recipe not found" });

      res.json({ success: true, recipe });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // SIMULATE CRAFTING (preview)
  // ======================================================
  async simulate(req, res) {
    try {
      const ownerId = req.user.id;
      const { recipeId } = req.params;

      const player = req.user; // craftingSkill, perks, level

      const result = await CraftingEngine.simulate(ownerId, recipeId, player);
      res.json({ success: true, simulation: result });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // CRAFT ITEM
  // ======================================================
  async craft(req, res) {
    try {
      const ownerId = req.user.id;
      const { recipeId } = req.params;

      const player = req.user;

      const result = await CraftingEngine.craft(ownerId, recipeId, player);

      if (!result.success) {
        return res.json({
          success: false,
          error: result.error,
          roll: result.roll,
          chance: result.chance
        });
      }

      res.json({
        success: true,
        item: result.item,
        quantity: result.quantity,
        xp: result.xp,
        heat: result.heat,
        timeRequired: result.timeRequired
      });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};