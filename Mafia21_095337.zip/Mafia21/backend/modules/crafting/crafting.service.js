const CraftingRecipe = require("./crafting.model");
const InventoryService = require("../inventory/inventory.service");
const Item = require("../items/item.model");

module.exports = {

  // ======================================================
  // GET ALL RECIPES
  // ======================================================
  async listRecipes() {
    return await CraftingRecipe.find()
      .populate("materials.item")
      .populate("tools.item")
      .populate("resultItem");
  },

  // ======================================================
  // GET SINGLE RECIPE
  // ======================================================
  async getRecipe(recipeId) {
    return await CraftingRecipe.findById(recipeId)
      .populate("materials.item")
      .populate("tools.item")
      .populate("resultItem");
  },

  // ======================================================
  // CHECK MATERIALS
  // ======================================================
  async hasMaterials(ownerId, recipe) {
    const inv = await InventoryService.getInventory(ownerId);
    if (!inv) return false;

    for (const req of recipe.materials) {
      const slot = inv.items.find(i => i.item._id.toString() === req.item._id.toString());
      if (!slot || slot.quantity < req.quantity) return false;
    }

    return true;
  },

  // ======================================================
  // CHECK TOOLS
  // ======================================================
  async hasTools(ownerId, recipe) {
    const inv = await InventoryService.getInventory(ownerId);
    if (!inv) return false;

    for (const tool of recipe.tools) {
      const slot = inv.items.find(i => i.item._id.toString() === tool.item._id.toString());
      if (!slot) return false;
    }

    return true;
  },

  // ======================================================
  // REMOVE MATERIALS
  // ======================================================
  async consumeMaterials(ownerId, recipe) {
    for (const req of recipe.materials) {
      await InventoryService.removeItem(ownerId, req.item._id, req.quantity);
    }
  },

  // ======================================================
  // APPLY TOOL DURABILITY COST
  // ======================================================
  async applyToolDurability(ownerId, recipe) {
    const inv = await InventoryService.getInventory(ownerId);

    for (const tool of recipe.tools) {
      const slot = inv.items.find(i => i.item._id.toString() === tool.item._id.toString());
      if (!slot) continue;

      // Намаляване на durability
      slot.item.durability -= tool.durabilityCost;
      if (slot.item.durability < 0) slot.item.durability = 0;

      await slot.item.save();
    }
  },

  // ======================================================
  // CRAFT ITEM
  // ======================================================
  async craft(ownerId, recipeId) {
    const recipe = await this.getRecipe(recipeId);
    if (!recipe) return { success: false, error: "Recipe not found" };

    // Check materials
    const hasMaterials = await this.hasMaterials(ownerId, recipe);
    if (!hasMaterials) return { success: false, error: "Missing materials" };

    // Check tools
    const hasTools = await this.hasTools(ownerId, recipe);
    if (!hasTools) return { success: false, error: "Missing required tools" };

    // Success chance
    const roll = Math.random() * 100;
    const success = roll <= recipe.successChance;

    // Consume materials ALWAYS
    await this.consumeMaterials(ownerId, recipe);

    // Apply tool durability
    await this.applyToolDurability(ownerId, recipe);

    if (!success) {
      return {
        success: false,
        error: "Crafting failed",
        roll,
        chance: recipe.successChance
      };
    }

    // Add crafted item
    await InventoryService.addItem(ownerId, recipe.resultItem._id, recipe.resultQuantity);

    return {
      success: true,
      item: recipe.resultItem,
      quantity: recipe.resultQuantity,
      xp: recipe.xpReward
    };
  }
};