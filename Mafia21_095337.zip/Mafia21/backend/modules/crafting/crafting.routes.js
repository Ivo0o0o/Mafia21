const router = require("express").Router();
const CraftingController = require("./crafting.controller");

// ======================================================
// RECIPES
// ======================================================
router.get("/recipes", CraftingController.list);
router.get("/recipe/:recipeId", CraftingController.get);

// ======================================================
// SIMULATION (preview)
// ======================================================
router.get("/simulate/:recipeId", CraftingController.simulate);

// ======================================================
// CRAFT ITEM
// ======================================================
router.post("/craft/:recipeId", CraftingController.craft);

module.exports = router;