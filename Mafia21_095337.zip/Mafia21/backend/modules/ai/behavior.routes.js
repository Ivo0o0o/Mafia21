const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const engine = require("./behavior.engine");

// GOD: изпълни решение
router.post("/execute/:decisionId", godAccess, async (req, res) => {
  const result = await engine.executeDecision(req.params.decisionId);
  res.json(result);
});

module.exports = router;