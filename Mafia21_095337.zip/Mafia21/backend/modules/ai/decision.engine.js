const AIDecision = require("./decision.model");
const NpcAI = require("../npc/npcAI.model");
const Influence = require("../districts/influence.model");

async function decide(npcId) {
  const npc = await NpcAI.findOne({ npcId });
  if (!npc) throw new Error("NPC not found");

  const districtState = await Influence.findOne({ district: npc.location.district });

  let decision = "idle";
  let reason = "default";

  // 1. Ако NPC е много агресивен
  if (npc.aggressionLevel > 70) {
    decision = "attack";
    reason = "high aggression";
  }

  // 2. Ако NPC е много изплашен
  else if (npc.fearLevel > 60) {
    decision = "flee";
    reason = "high fear";
  }

  // 3. Ако районът е опасен
  else if (districtState && districtState.crimeLevel > 60) {
    decision = "patrol";
    reason = "high crime in district";
  }

  // 4. Ако районът е под влияние на клан
  else if (districtState && districtState.clanInfluence > 50) {
    decision = "extort";
    reason = "clan influence";
  }

  // 5. Ако NPC е спокоен
  else if (npc.mood === "calm") {
    decision = "idle";
    reason = "calm mood";
  }

  // 6. Ако NPC е подозрителен
  else if (npc.mood === "suspicious") {
    decision = "patrol";
    reason = "suspicious mood";
  }

  // 7. Ако NPC е неутрален
  else {
    decision = "idle";
    reason = "neutral mood";
  }

  const log = await AIDecision.create({
    npcId,
    decision,
    reason,
    district: npc.location.district
  });

  return log;
}

module.exports = { decide };

const { applyPersonalityToDecision } = require("./personality.engine");

decision = await applyPersonalityToDecision(npcId, decision);