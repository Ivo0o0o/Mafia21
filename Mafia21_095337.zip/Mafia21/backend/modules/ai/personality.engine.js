const Personality = require("./personality.model");
const NpcAI = require("../npc/npcAI.model");

async function getPersonality(npcId) {
  let p = await Personality.findOne({ npcId });
  if (!p) p = await Personality.create({ npcId });
  return p;
}

async function applyPersonalityToDecision(npcId, decision) {
  const personality = await getPersonality(npcId);

  // Променяме решението според характера
  const bias = personality.reactionBias;

  const weighted = {
    attack: bias.attack,
    flee: bias.flee,
    extort: bias.extort,
    hide: bias.hide,
    patrol: bias.patrol
  };

  // Добавяме влияние от temperament
  if (personality.temperament === "impulsive") weighted.attack += 10;
  if (personality.temperament === "calculated") weighted.hide += 10;
  if (personality.temperament === "fast") weighted.patrol += 5;
  if (personality.temperament === "slow") weighted.flee += 5;

  // Добавяме влияние от behaviorStyle
  if (personality.behaviorStyle === "violent") weighted.attack += 15;
  if (personality.behaviorStyle === "stealthy") weighted.hide += 15;
  if (personality.behaviorStyle === "diplomatic") weighted.extort += 10;
  if (personality.behaviorStyle === "chaotic") weighted.patrol += 10;
  if (personality.behaviorStyle === "opportunistic") weighted.extort += 5;

  // Избираме най-високото
  let finalDecision = decision;
  let max = 0;

  for (const key in weighted) {
    if (weighted[key] > max) {
      max = weighted[key];
      finalDecision = key;
    }
  }

  return finalDecision;
}

module.exports = {
  getPersonality,
  applyPersonalityToDecision
};