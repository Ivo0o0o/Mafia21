const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const Personality = require("./personality.model");

// GOD: промени личността на NPC
router.post("/set", godAccess, async (req, res) => {
  const { npcId, personalityType, temperament, behaviorStyle, reactionBias } = req.body;

  let p = await Personality.findOne({ npcId });
  if (!p) p = await Personality.create({ npcId });

  if (personalityType) p.personalityType = personalityType;
  if (temperament) p.temperament = temperament;
  if (behaviorStyle) p.behaviorStyle = behaviorStyle;
  if (reactionBias) p.reactionBias = reactionBias;

  await p.save();
  res.json(p);
});

// GOD: виж личността
router.get("/:npcId", godAccess, async (req, res) => {
  const p = await Personality.findOne({ npcId: req.params.npcId });
  res.json(p);
});

module.exports = router;