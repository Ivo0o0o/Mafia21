const Behavior = require("./behavior.model");
const Decision = require("./decision.model");

async function executeDecision(decisionId) {
  const decision = await Decision.findById(decisionId);
  if (!decision) return null;

  const action = mapDecisionToBehavior(decision.decision);

  const behavior = await Behavior.create({
    npcId: decision.npcId,
    action: action.type,
    params: action.params,
    decisionId
  });

  return behavior;
}

function mapDecisionToBehavior(decision) {
  switch (decision) {
    case "patrol":
      return { type: "move", params: { pattern: "patrol" } };

    case "flee":
      return { type: "move", params: { pattern: "escape" } };

    case "attack":
      return { type: "attack", params: { target: "nearestEnemy" } };

    case "hide":
      return { type: "move", params: { pattern: "hide" } };

    case "investigate":
      return { type: "interact", params: { target: "eventLocation" } };

    default:
      return { type: "idle", params: {} };
  }
}

module.exports = {
  executeDecision
};