const { runAILoop } = require("./loop.engine");

function startAILoop() {
  console.log("AI Loop Engine started.");

  setInterval(async () => {
    try {
      await runAILoop();
    } catch (err) {
      console.error("AI Loop error:", err.message);
    }
  }, 5000); // AI взима решения на всеки 5 секунди
}

module.exports = { startAILoop };