const express = require("express");
const router = express.Router();
const { godAccess } = require("../../src/middleware/godAccess");
const engine = require("./decision.engine");

// GOD: форсирай NPC да вземе решение
router.post("/run", godAccess, async (req, res) => {
  try {
    const { npcId } = req.body;
    const result = await engine.decide(npcId);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// GOD: виж логове
router.get("/logs", godAccess, async (req, res) => {
  const AIDecision = require("./decision.model");
  const logs = await AIDecision.find().sort({ timestamp: -1 });
  res.json(logs);
});

module.exports = router;