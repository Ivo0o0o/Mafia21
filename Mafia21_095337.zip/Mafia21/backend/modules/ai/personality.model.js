const mongoose = require("mongoose");

const personalitySchema = new mongoose.Schema({
  npcId: { type: String, required: true },

  personalityType: {
    type: String,
    enum: [
      "aggressive",
      "calm",
      "nervous",
      "manipulative",
      "loyal",
      "dominant",
      "coward",
      "unpredictable"
    ],
    default: "neutral"
  },

  temperament: {
    type: String,
    enum: ["fast", "slow", "calculated", "impulsive"],
    default: "calculated"
  },

  behaviorStyle: {
    type: String,
    enum: ["violent", "stealthy", "diplomatic", "chaotic", "opportunistic"],
    default: "opportunistic"
  },

  reactionBias: {
    attack: { type: Number, default: 10 },
    flee: { type: Number, default: 10 },
    extort: { type: Number, default: 10 },
    hide: { type: Number, default: 10 },
    patrol: { type: Number, default: 10 }
  }

}, { timestamps: true });

module.exports = mongoose.model("AIPersonality", personalitySchema);