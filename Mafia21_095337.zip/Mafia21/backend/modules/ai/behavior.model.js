const mongoose = require("mongoose");

const behaviorSchema = new mongoose.Schema({
  npcId: { type: String, required: true },
  action: { type: String, required: true }, // move, attack, flee, hide, interact
  params: { type: Object, default: {} },
  decisionId: { type: String },
  timestamp: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Behavior", behaviorSchema);