const mongoose = require("mongoose");

const decisionSchema = new mongoose.Schema({
  npcId: { type: String, required: true },
  decision: { type: String, required: true }, // attack, flee, patrol, hide, extort, help, idle
  reason: { type: String, default: "" },
  district: { type: String, default: "" },
  timestamp: { type: Date, default: Date.now }
});

module.exports = mongoose.model("AIDecision", decisionSchema);