const NpcAI = require("../npc/npcAI.model");
const { decide } = require("./decision.engine");
const { triggerEvent } = require("../worldEvents/event.engine");

async function runAILoop() {
  const npcs = await NpcAI.find();

  for (const npc of npcs) {
    // 1. NPC взима решение
    const decisionLog = await decide(npc.npcId);

    // 2. Изпълняваме действие според решението
    await executeDecision(npc, decisionLog.decision);
  }
}

async function executeDecision(npc, decision) {
  switch (decision) {
    case "attack":
      await triggerEvent({
        type: "crime",
        district: npc.location.district,
        description: `NPC ${npc.npcId} атакува в района.`,
        impact: { crime: 5, npcAggression: 10 }
      });
      break;

    case "flee":
      await triggerEvent({
        type: "random",
        district: npc.location.district,
        description: `NPC ${npc.npcId} избяга.`,
        impact: { npcFear: 10 }
      });
      break;

    case "extort":
      await triggerEvent({
        type: "clan",
        district: npc.location.district,
        description: `NPC ${npc.npcId} изнудва бизнес.`,
        impact: { clanInfluence: 5, crime: 3 }
      });
      break;

    case "patrol":
      npc.location.x += Math.floor(Math.random() * 3);
      npc.location.y += Math.floor(Math.random() * 3);
      await npc.save();
      break;

    case "hide":
      await triggerEvent({
        type: "random",
        district: npc.location.district,
        description: `NPC ${npc.npcId} се скри.`,
        impact: { npcFear: 5 }
      });
      break;

    default:
      // idle — NPC не прави нищо
      break;
  }
}

module.exports = { runAILoop };