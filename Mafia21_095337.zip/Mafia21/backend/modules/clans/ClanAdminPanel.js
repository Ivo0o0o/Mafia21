// =========================
// CLAN ADMIN PANEL (PRO)
// =========================
//
// Този модул:
// - управлява UI логиката за клан админ панела
// - извиква API към ClanAdmin.routes.js
// - използва се от admin.js (фронтенд)
// =========================

const ClanAdminPanel = {
  // =========================
  // LOAD PANEL DATA
  // =========================
  async load(clanId) {
    const res = await fetch(`/api/clan/admin/${clanId}`, {
      method: "GET",
      headers: { "Authorization": localStorage.getItem("token") }
    });

    const data = await res.json();
    if (!data.success) throw new Error(data.error);

    return data.clan;
  },

  // =========================
  // PROMOTE MEMBER
  // =========================
  async promote(clanId, memberId) {
    const res = await fetch(`/api/clan/admin/${clanId}/promote/${memberId}`, {
      method: "POST",
      headers: { "Authorization": localStorage.getItem("token") }
    });

    return await res.json();
  },

  // =========================
  // DEMOTE MEMBER
  // =========================
  async demote(clanId, memberId) {
    const res = await fetch(`/api/clan/admin/${clanId}/demote/${memberId}`, {
      method: "POST",
      headers: { "Authorization": localStorage.getItem("token") }
    });

    return await res.json();
  },

  // =========================
  // KICK MEMBER
  // =========================
  async kick(clanId, memberId) {
    const res = await fetch(`/api/clan/admin/${clanId}/kick/${memberId}`, {
      method: "POST",
      headers: { "Authorization": localStorage.getItem("token") }
    });

    return await res.json();
  },

  // =========================
  // INVITE MEMBER
  // =========================
  async invite(clanId, userId) {
    const res = await fetch(`/api/clan/admin/${clanId}/invite`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ userId })
    });

    return await res.json();
  },

  // =========================
  // ACCEPT INVITE
  // =========================
  async acceptInvite(clanId) {
    const res = await fetch(`/api/clan/admin/${clanId}/accept`, {
      method: "POST",
      headers: { "Authorization": localStorage.getItem("token") }
    });

    return await res.json();
  },

  // =========================
  // ADD TREASURY MONEY
  // =========================
  async addTreasury(clanId, amount) {
    const res = await fetch(`/api/clan/admin/${clanId}/treasury/add`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ amount })
    });

    return await res.json();
  },

  // =========================
  // SPEND TREASURY MONEY
  // =========================
  async spendTreasury(clanId, amount, reason) {
    const res = await fetch(`/api/clan/admin/${clanId}/treasury/spend`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ amount, reason })
    });

    return await res.json();
  },

  // =========================
  // LEVEL UP CLAN
  // =========================
  async levelUp(clanId) {
    const res = await fetch(`/api/clan/admin/${clanId}/levelup`, {
      method: "POST",
      headers: { "Authorization": localStorage.getItem("token") }
    });

    return await res.json();
  }
};

module.exports = ClanAdminPanel;