// =========================
// CLAN HEIST PANEL (PRO)
// =========================
//
// Този модул:
// - управлява UI логиката за клановите обири
// - извиква API към ClanHeist.js през backend routes
// - използва се от admin.js (фронтенд)
// =========================

const ClanHeistPanel = {
  // =========================
  // GET ACTIVE HEIST
  // =========================
  async getActiveHeist(clanId) {
    const res = await fetch(`/api/clan/heist/${clanId}`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // START HEIST
  // =========================
  async startHeist(clanId, heistType) {
    const res = await fetch(`/api/clan/heist/start`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanId, heistType })
    });

    return await res.json();
  },

  // =========================
  // ASSIGN ROLE
  // =========================
  async assignRole(clanId, playerId, role) {
    const res = await fetch(`/api/clan/heist/assignRole`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanId, playerId, role })
    });

    return await res.json();
  },

  // =========================
  // PROGRESS HEIST
  // =========================
  async progress(clanId, amount) {
    const res = await fetch(`/api/clan/heist/progress`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanId, amount })
    });

    return await res.json();
  },

  // =========================
  // FINISH HEIST
  // =========================
  async finishHeist(clanId) {
    const res = await fetch(`/api/clan/heist/finish`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanId })
    });

    return await res.json();
  }
};

module.exports = ClanHeistPanel;