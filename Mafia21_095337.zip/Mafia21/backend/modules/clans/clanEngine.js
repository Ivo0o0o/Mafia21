const Clan = require("./Clan.model");
const District = require("../world/districts/District.model");

module.exports = {
  // =========================
  // ADD TERRITORY TO CLAN
  // =========================
  addTerritory: async (clanId, districtName) => {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    const district = await District.findOne({ name: districtName });
    if (!district) throw new Error("Районът не е намерен");

    // Ако районът е контролиран от друг клан → отказ
    if (district.control && String(district.control) !== String(clan._id)) {
      throw new Error("Районът вече е контролиран от друг клан");
    }

    // Добавяне на територия
    if (!clan.territories.includes(districtName)) {
      clan.territories.push(districtName);

      // Кланово влияние
      clan.influence += 5;
      clan.clanPower += 2;

      // Влияние по райони
      clan.districtInfluence.set(districtName, (clan.districtInfluence.get(districtName) || 0) + 10);

      // Лог
      clan.logs.push({
        text: `Кланът завзе район: ${districtName}`,
        date: new Date()
      });

      await clan.save();
    }

    // Обновяване на района
    district.control = clan._id;
    district.influence += 2;

    await district.save();

    return { clan, district };
  },

  // =========================
  // REMOVE TERRITORY FROM CLAN
  // =========================
  removeTerritory: async (clanId, districtName) => {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    const district = await District.findOne({ name: districtName });
    if (!district) throw new Error("Районът не е намерен");

    // Премахване от списъка
    clan.territories = clan.territories.filter(t => t !== districtName);

    // Намаляване на влияние
    clan.influence = Math.max(0, clan.influence - 5);
    clan.clanPower = Math.max(0, clan.clanPower - 2);

    // Премахване на influence по район
    clan.districtInfluence.delete(districtName);

    // Лог
    clan.logs.push({
      text: `Кланът загуби район: ${districtName}`,
      date: new Date()
    });

    await clan.save();

    // Обновяване на района
    district.control = null;
    district.influence = Math.max(0, district.influence - 2);

    await district.save();

    return { clan, district };
  }
};