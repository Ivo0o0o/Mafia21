// =========================
// CLAN TASKS PANEL (PRO)
// =========================
//
// Този модул:
// - управлява UI логиката за клановите задачи
// - извиква API към ClanTasks.js през backend routes
// - използва се от admin.js (фронтенд)
// =========================

const ClanTasksPanel = {
  // =========================
  // GET ALL TASKS FOR CLAN
  // =========================
  async getTasks(clanId) {
    const res = await fetch(`/api/clan/tasks/${clanId}`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // CREATE NEW TASK
  // =========================
  async createTask(clanId, taskType, description) {
    const res = await fetch(`/api/clan/tasks/create`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanId, taskType, description })
    });

    return await res.json();
  },

  // =========================
  // UPDATE TASK PROGRESS
  // =========================
  async updateProgress(clanId, taskIndex, amount) {
    const res = await fetch(`/api/clan/tasks/update`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanId, taskIndex, amount })
    });

    return await res.json();
  },

  // =========================
  // RESET TASKS
  // =========================
  async resetTasks(clanId) {
    const res = await fetch(`/api/clan/tasks/reset`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanId })
    });

    return await res.json();
  },

  // =========================
  // PLAYER CONTRIBUTION
  // =========================
  async contribute(playerId, clanId, taskIndex, amount) {
    const res = await fetch(`/api/clan/tasks/contribute`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ playerId, clanId, taskIndex, amount })
    });

    return await res.json();
  }
};

module.exports = ClanTasksPanel;