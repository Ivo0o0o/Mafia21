const Clan = require("./Clan.model");
const User = require("../player/player.model");

const HEIST_TYPES = {
  bank: {
    name: "Обир на банка",
    difficulty: 3,
    reward: 100000,
    risk: 25,
    roles: ["Хакер", "Шофьор", "Стрелец", "Техник"]
  },
  convoy: {
    name: "Обир на конвой",
    difficulty: 2,
    reward: 50000,
    risk: 15,
    roles: ["Шофьор", "Стрелец", "Саботьор"]
  },
  warehouse: {
    name: "Обир на склад",
    difficulty: 1,
    reward: 25000,
    risk: 10,
    roles: ["Техник", "Стрелец"]
  }
};

module.exports = {
  // =========================
  // START HEIST
  // =========================
  async startHeist(clanId, heistType) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    const type = HEIST_TYPES[heistType];
    if (!type) throw new Error("Невалиден тип обир");

    clan.activeHeist = {
      type: heistType,
      name: type.name,
      reward: type.reward,
      risk: type.risk,
      difficulty: type.difficulty,
      roles: type.roles,
      assigned: {},
      progress: 0,
      completed: false,
      startTime: new Date()
    };

    clan.logs.push({
      text: `Кланът започна обир: ${type.name}`,
      date: new Date()
    });

    await clan.save();
    return clan.activeHeist;
  },

  // =========================
  // ASSIGN ROLE
  // =========================
  async assignRole(clanId, playerId, role) {
    const clan = await Clan.findById(clanId);
    const player = await User.findById(playerId);

    if (!clan || !player) throw new Error("Кланът или играчът не е намерен");
    if (!clan.activeHeist) throw new Error("Няма активен обир");

    if (!clan.activeHeist.roles.includes(role)) {
      throw new Error("Невалидна роля");
    }

    clan.activeHeist.assigned[role] = {
      playerId,
      username: player.username
    };

    clan.logs.push({
      text: `${player.username} беше назначен като ${role} в обира`,
      date: new Date()
    });

    await clan.save();
    return clan.activeHeist;
  },

  // =========================
  // PROGRESS HEIST
  // =========================
  async progress(clanId, amount) {
    const clan = await Clan.findById(clanId);
    if (!clan.activeHeist) throw new Error("Няма активен обир");

    clan.activeHeist.progress += amount;

    if (clan.activeHeist.progress >= 100) {
      return await this.finishHeist(clanId);
    }

    await clan.save();
    return clan.activeHeist;
  },

  // =========================
  // FINISH HEIST
  // =========================
  async finishHeist(clanId) {
    const clan = await Clan.findById(clanId);
    const heist = clan.activeHeist;

    if (!heist) throw new Error("Няма активен обир");

    // Риск от провал
    const roll = Math.random() * 100;
    let failed = roll < heist.risk;

    if (failed) {
      clan.logs.push({
        text: `❌ Обирът се провали! Полицията засече операцията.`,
        date: new Date()
      });

      clan.influence -= 10;
      clan.activeHeist = null;
      await clan.save();

      return { success: false, heist };
    }

    // Успешен обир
    clan.treasury += heist.reward;
    clan.influence += 20;
    clan.clanPower += 15;

    clan.logs.push({
      text: `✔ Успешен обир: ${heist.name} (+${heist.reward}$)`,
      date: new Date()
    });

    // XP за играчите
    for (const role of Object.keys(heist.assigned)) {
      const playerId = heist.assigned[role].playerId;
      const player = await User.findById(playerId);
      if (!player) continue;

      player.xp = (player.xp || 0) + 200;
      await player.save();
    }

    clan.activeHeist = null;
    await clan.save();

    return { success: true, heist };
  },

  // =========================
  // GET ACTIVE HEIST
  // =========================
  async getActiveHeist(clanId) {
    const clan = await Clan.findById(clanId);
    return clan.activeHeist || null;
  }
};