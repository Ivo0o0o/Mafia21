// =========================
// CLAN RANKING PANEL (PRO)
// =========================
//
// Този модул:
// - управлява UI логиката за клановите класации
// - извиква API към ClanRanking.js през backend routes
// - използва се от admin.js (фронтенд)
// =========================

const ClanRankingPanel = {
  // =========================
  // GET GLOBAL RANKING
  // =========================
  async getGlobalRanking() {
    const res = await fetch(`/api/clan/ranking/global`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // GET CATEGORY RANKING
  // =========================
  async getRankingBy(category) {
    const res = await fetch(`/api/clan/ranking/category/${category}`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // GET SEASON RANKING
  // =========================
  async getSeasonRanking(seasonId) {
    const res = await fetch(`/api/clan/ranking/season/${seasonId}`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // ADD SEASON SCORE
  // =========================
  async addSeasonScore(clanId, seasonId, score) {
    const res = await fetch(`/api/clan/ranking/season/add`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanId, seasonId, score })
    });

    return await res.json();
  }
};

module.exports = ClanRankingPanel;