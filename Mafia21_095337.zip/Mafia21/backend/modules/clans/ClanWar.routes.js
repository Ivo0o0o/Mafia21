const express = require("express");
const router = express.Router();

const controller = require("./ClanWar.controller");
const auth = require("../core/auth");

// Започване на война
router.post("/start", auth, controller.startWar);

// Битка между кланове
router.post("/battle", auth, controller.battle);

// Завземане на територия
router.post("/territory/:districtName", auth, controller.takeTerritory);

// Приключване на война
router.post("/end", auth, controller.endWar);

module.exports = router;