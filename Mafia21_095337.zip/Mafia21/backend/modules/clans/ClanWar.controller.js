const Clan = require("./Clan.model");
const ClanWar = require("./ClanWar.engine");
const authError = "Нямаш права за кланови войни";

function isClanAdmin(clan, userId) {
  const isLeader = String(clan.leader) === String(userId);
  const isOfficer = clan.officers.includes(userId);
  return isLeader || isOfficer;
}

module.exports = {
  // =========================
  // START WAR
  // =========================
  startWar: async (req, res) => {
    try {
      const { attackerId, defenderId } = req.body;

      const attacker = await Clan.findById(attackerId);
      const defender = await Clan.findById(defenderId);

      if (!attacker || !defender) {
        return res.status(404).json({ success: false, error: "Кланът не е намерен" });
      }

      if (!isClanAdmin(attacker, req.user.id)) {
        return res.status(403).json({ success: false, error: authError });
      }

      const result = await ClanWar.startWar(attackerId, defenderId);

      res.json({
        success: true,
        message: `Войната между ${attacker.name} и ${defender.name} започна`,
        ...result
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // BATTLE
  // =========================
  battle: async (req, res) => {
    try {
      const { attackerId, defenderId } = req.body;

      const attacker = await Clan.findById(attackerId);
      if (!attacker) return res.status(404).json({ success: false, error: "Кланът не е намерен" });

      if (!isClanAdmin(attacker, req.user.id)) {
        return res.status(403).json({ success: false, error: authError });
      }

      const result = await ClanWar.battle(attackerId, defenderId);

      res.json({
        success: true,
        message: `Битката между клановете приключи`,
        ...result
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // TAKE TERRITORY
  // =========================
  takeTerritory: async (req, res) => {
    try {
      const { winnerId, loserId } = req.body;
      const { districtName } = req.params;

      const winner = await Clan.findById(winnerId);
      if (!winner) return res.status(404).json({ success: false, error: "Кланът не е намерен" });

      if (!isClanAdmin(winner, req.user.id)) {
        return res.status(403).json({ success: false, error: authError });
      }

      const result = await ClanWar.takeTerritory(winnerId, loserId, districtName);

      res.json({
        success: true,
        message: `Районът ${districtName} е завзет`,
        ...result
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // END WAR
  // =========================
  endWar: async (req, res) => {
    try {
      const { attackerId, defenderId } = req.body;

      const attacker = await Clan.findById(attackerId);
      if (!attacker) return res.status(404).json({ success: false, error: "Кланът не е намерен" });

      if (!isClanAdmin(attacker, req.user.id)) {
        return res.status(403).json({ success: false, error: authError });
      }

      const result = await ClanWar.endWar(attackerId, defenderId);

      res.json({
        success: true,
        message: "Войната приключи",
        ...result
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
};