const Clan = require("./Clan.model");
const User = require("../player/player.model");

const RAID_TYPES = {
  small: {
    name: "Малък рейд",
    hp: 5000,
    reward: 15000,
    clanPoints: 30,
    durationHours: 12
  },
  medium: {
    name: "Среден рейд",
    hp: 20000,
    reward: 50000,
    clanPoints: 100,
    durationHours: 24
  },
  large: {
    name: "Голям рейд",
    hp: 50000,
    reward: 150000,
    clanPoints: 300,
    durationHours: 48
  },
  legendary: {
    name: "Легендарен рейд",
    hp: 150000,
    reward: 500000,
    clanPoints: 1000,
    durationHours: 72
  }
};

module.exports = {
  // =========================
  // START RAID
  // =========================
  async startRaid(clanId, raidType) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    const type = RAID_TYPES[raidType];
    if (!type) throw new Error("Невалиден тип рейд");

    clan.activeRaid = {
      type: raidType,
      name: type.name,
      maxHp: type.hp,
      hp: type.hp,
      reward: type.reward,
      clanPoints: type.clanPoints,
      startTime: new Date(),
      endTime: new Date(Date.now() + type.durationHours * 3600000),
      contributions: []
    };

    clan.logs.push({
      text: `Кланът започна ${type.name} (HP: ${type.hp})`,
      date: new Date()
    });

    await clan.save();
    return clan.activeRaid;
  },

  // =========================
  // PLAYER ATTACK (CONTRIBUTION)
  // =========================
  async attack(playerId, clanId, damage) {
    const player = await User.findById(playerId);
    if (!player) throw new Error("Играчът не е намерен");

    if (player.clan?.toString() !== clanId.toString()) {
      throw new Error("Играчът не е член на този клан");
    }

    const clan = await Clan.findById(clanId);
    if (!clan.activeRaid) throw new Error("Няма активен рейд");

    // Нанасяме щета
    clan.activeRaid.hp -= damage;
    if (clan.activeRaid.hp < 0) clan.activeRaid.hp = 0;

    // Записваме приноса
    clan.activeRaid.contributions.push({
      playerId,
      username: player.username,
      damage,
      date: new Date()
    });

    clan.logs.push({
      text: `${player.username} нанесе ${damage} щета в рейда`,
      date: new Date()
    });

    await clan.save();

    // Ако рейдът е победен
    if (clan.activeRaid.hp === 0) {
      return await this.finishRaid(clanId);
    }

    return clan.activeRaid;
  },

  // =========================
  // FINISH RAID
  // =========================
  async finishRaid(clanId) {
    const clan = await Clan.findById(clanId);
    if (!clan.activeRaid) throw new Error("Няма активен рейд");

    const raid = clan.activeRaid;

    // Награди за клана
    clan.treasury += raid.reward;
    clan.seasonPoints = (clan.seasonPoints || 0) + raid.clanPoints;

    clan.logs.push({
      text: `Кланът победи рейда "${raid.name}" и получи ${raid.reward}$ и ${raid.clanPoints} точки`,
      date: new Date()
    });

    // Награди за играчите
    const playerRewards = {};
    for (const c of raid.contributions) {
      playerRewards[c.playerId] = (playerRewards[c.playerId] || 0) + c.damage;
    }

    // Превръщаме щетата в XP
    for (const playerId of Object.keys(playerRewards)) {
      const player = await User.findById(playerId);
      if (!player) continue;

      const xpGain = Math.floor(playerRewards[playerId] / 10);
      player.xp = (player.xp || 0) + xpGain;

      await player.save();
    }

    // Изчистваме рейда
    clan.activeRaid = null;
    await clan.save();

    return {
      clan,
      raid,
      playerRewards
    };
  },

  // =========================
  // GET ACTIVE RAID
  // =========================
  async getActiveRaid(clanId) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    return clan.activeRaid || null;
  }
};