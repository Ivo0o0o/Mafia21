const express = require("express");
const router = express.Router();

const controller = require("./Clan.controller");
const auth = require("../core/auth");

// Взимане на всички кланове
router.get("/", auth, controller.getAll);

// Създаване на клан
router.post("/", auth, controller.create);

// Присъединяване към клан
router.post("/join/:clanId", auth, controller.join);

// Добавяне на територия към клан
router.post("/territory/:clanId", auth, controller.addTerritory);

module.exports = router;