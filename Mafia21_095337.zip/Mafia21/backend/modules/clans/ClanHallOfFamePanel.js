// =========================
// CLAN HALL OF FAME PANEL (PRO)
// =========================
//
// Този модул:
// - управлява UI логиката за Hall of Fame
// - извиква API към ClanHallOfFame.js през backend routes
// - използва се от admin.js (фронтенд)
// =========================

const ClanHallOfFamePanel = {
  // =========================
  // GET CLAN HALL OF FAME
  // =========================
  async getClanHall(clanId) {
    const res = await fetch(`/api/clan/hof/${clanId}`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // GET GLOBAL HALL OF FAME
  // =========================
  async getGlobalHall() {
    const res = await fetch(`/api/clan/hof/global`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // GET TOP 10 CLANS OF ALL TIME
  // =========================
  async getTop10() {
    const res = await fetch(`/api/clan/hof/top10`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // ADD SEASON CHAMPION
  // =========================
  async addSeasonChampion(seasonId, clanId) {
    const res = await fetch(`/api/clan/hof/season`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ seasonId, clanId })
    });

    return await res.json();
  },

  // =========================
  // ADD YEAR CHAMPION
  // =========================
  async addYearChampion(year, clanId) {
    const res = await fetch(`/api/clan/hof/year`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ year, clanId })
    });

    return await res.json();
  },

  // =========================
  // ADD SPECIAL AWARD
  // =========================
  async addSpecialAward(clanId, awardName) {
    const res = await fetch(`/api/clan/hof/special`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanId, awardName })
    });

    return await res.json();
  }
};

module.exports = ClanHallOfFamePanel;