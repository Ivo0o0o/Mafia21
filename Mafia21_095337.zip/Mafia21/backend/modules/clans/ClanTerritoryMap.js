const Clan = require("./Clan.model");

module.exports = {
  // =========================
  // GET FULL TERRITORY MAP
  // =========================
  async getMap() {
    const clans = await Clan.find();

    const map = {};

    for (const clan of clans) {
      for (const district of clan.territories) {
        map[district] = {
          clanId: clan._id,
          clanName: clan.name,
          color: clan.color || "#FF0000",
          influence: clan.influence,
          power: clan.clanPower
        };
      }
    }

    return map;
  },

  // =========================
  // GET DISTRICT INFO
  // =========================
  async getDistrict(districtName) {
    const clans = await Clan.find();

    for (const clan of clans) {
      if (clan.territories.includes(districtName)) {
        return {
          district: districtName,
          clanId: clan._id,
          clanName: clan.name,
          color: clan.color || "#FF0000",
          influence: clan.influence,
          power: clan.clanPower
        };
      }
    }

    return {
      district: districtName,
      clanId: null,
      clanName: "Никой",
      color: "#444444",
      influence: 0,
      power: 0
    };
  },

  // =========================
  // SET TERRITORY OWNER
  // =========================
  async setOwner(districtName, clanId) {
    const clans = await Clan.find();

    // Премахваме територията от всички кланове
    for (const clan of clans) {
      if (clan.territories.includes(districtName)) {
        clan.territories = clan.territories.filter(d => d !== districtName);
        await clan.save();
      }
    }

    // Добавяме територията към новия клан
    const newOwner = await Clan.findById(clanId);
    if (!newOwner) throw new Error("Кланът не е намерен");

    newOwner.territories.push(districtName);

    newOwner.logs.push({
      text: `Кланът завзе територия: ${districtName}`,
      date: new Date()
    });

    await newOwner.save();

    return {
      district: districtName,
      clanId: newOwner._id,
      clanName: newOwner.name,
      color: newOwner.color || "#FF0000"
    };
  },

  // =========================
  // GET COLOR LEGEND
  // =========================
  async getLegend() {
    const clans = await Clan.find();

    return clans.map(clan => ({
      clanId: clan._id,
      clanName: clan.name,
      color: clan.color || "#FF0000"
    }));
  }
};