const Clan = require("./Clan.model");
const User = require("../player/player.model");

// =========================
// CREATE CLAN (used by controller)
// =========================
async function createClan(leaderId, data) {
  const leader = await User.findById(leaderId);
  if (!leader) throw new Error("Лидерът не е намерен");

  const existingClan = await Clan.findOne({ members: leaderId });
  if (existingClan) throw new Error("Вече си член на клан");

  const clan = await Clan.create({
    name: data.name,
    tag: data.tag,
    description: data.description || "",
    leader: leaderId,
    officers: [],
    members: [leaderId],
    color: data.color || "#ff0000",
    treasury: 0,
    clanLevel: 1,
    clanPower: 5,
    influence: 0,
    reputation: 0,
    territories: []
  });

  clan.logs.push({
    text: `Кланът е създаден от ${leader.username}`,
    date: new Date()
  });

  await clan.save();
  return clan;
}

// =========================
// JOIN CLAN
// =========================
async function joinClan(clanId, userId) {
  const clan = await Clan.findById(clanId);
  if (!clan) throw new Error("Кланът не е намерен");

  if (clan.members.includes(userId)) {
    return clan; // вече е член
  }

  clan.members.push(userId);
  clan.reputation += 1;
  clan.clanPower += 1;

  clan.logs.push({
    text: `Играчът ${userId} се присъедини към клана`,
    date: new Date()
  });

  await clan.save();
  return clan;
}

// =========================
// LEAVE CLAN
// =========================
async function leaveClan(clanId, userId) {
  const clan = await Clan.findById(clanId);
  if (!clan) throw new Error("Кланът не е намерен");

  // Лидерът не може да напусне — трябва да прехвърли лидерството
  if (String(clan.leader) === String(userId)) {
    throw new Error("Лидерът не може да напусне клана");
  }

  clan.members = clan.members.filter(m => String(m) !== String(userId));
  clan.officers = clan.officers.filter(o => String(o) !== String(userId));

  clan.reputation = Math.max(0, clan.reputation - 1);
  clan.clanPower = Math.max(0, clan.clanPower - 1);

  clan.logs.push({
    text: `Играчът ${userId} напусна клана`,
    date: new Date()
  });

  await clan.save();
  return clan;
}

// =========================
// PROMOTE MEMBER → OFFICER
// =========================
async function promoteMember(clanId, leaderId, memberId) {
  const clan = await Clan.findById(clanId);
  if (!clan) throw new Error("Кланът не е намерен");

  if (String(clan.leader) !== String(leaderId)) {
    throw new Error("Само лидерът може да повишава членове");
  }

  if (!clan.members.includes(memberId)) {
    throw new Error("Играчът не е член на клана");
  }

  if (!clan.officers.includes(memberId)) {
    clan.officers.push(memberId);
  }

  clan.logs.push({
    text: `Играчът ${memberId} беше повишен в офицер`,
    date: new Date()
  });

  await clan.save();
  return clan;
}

// =========================
// DEMOTE MEMBER → REMOVE OFFICER
// =========================
async function demoteMember(clanId, leaderId, memberId) {
  const clan = await Clan.findById(clanId);
  if (!clan) throw new Error("Кланът не е намерен");

  if (String(clan.leader) !== String(leaderId)) {
    throw new Error("Само лидерът може да понижава членове");
  }

  clan.officers = clan.officers.filter(o => String(o) !== String(memberId));

  clan.logs.push({
    text: `Играчът ${memberId} беше понижен`,
    date: new Date()
  });

  await clan.save();
  return clan;
}

// =========================
// ADD TREASURY MONEY
// =========================
async function addTreasury(clanId, amount, reason = "Входящи средства") {
  const clan = await Clan.findById(clanId);
  if (!clan) throw new Error("Кланът не е намерен");

  clan.treasury += amount;

  clan.logs.push({
    text: `${amount}$ добавени в клановата каса (${reason})`,
    date: new Date()
  });

  await clan.save();
  return clan.treasury;
}

// =========================
// SPEND TREASURY MONEY
// =========================
async function spendTreasury(clanId, amount, reason = "Разход") {
  const clan = await Clan.findById(clanId);
  if (!clan) throw new Error("Кланът не е намерен");

  if (clan.treasury < amount) {
    throw new Error("Недостатъчно средства в клановата каса");
  }

  clan.treasury -= amount;

  clan.logs.push({
    text: `${amount}$ изхарчени от клановата каса (${reason})`,
    date: new Date()
  });

  await clan.save();
  return clan.treasury;
}

// =========================
// LEVEL UP CLAN
// =========================
async function levelUpClan(clanId) {
  const clan = await Clan.findById(clanId);
  if (!clan) throw new Error("Кланът не е намерен");

  if (clan.clanLevel >= 10) {
    throw new Error("Кланът е на максимално ниво");
  }

  clan.clanLevel += 1;
  clan.clanPower += 3;
  clan.influence += 2;

  clan.logs.push({
    text: `Кланът достигна ниво ${clan.clanLevel}`,
    date: new Date()
  });

  await clan.save();
  return clan;
}

module.exports = {
  createClan,
  joinClan,
  leaveClan,
  promoteMember,
  demoteMember,
  addTreasury,
  spendTreasury,
  levelUpClan
};