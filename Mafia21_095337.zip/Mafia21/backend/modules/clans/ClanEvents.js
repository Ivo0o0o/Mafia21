const Clan = require("./Clan.model");

const EVENT_TYPES = {
  tournament: {
    name: "Кланов турнир",
    durationHours: 24,
    reward: 20000,
    description: "Клановете се състезават по сила, влияние и победи."
  },
  seasonWar: {
    name: "Сезонна война",
    durationHours: 72,
    reward: 50000,
    description: "Глобална война между всички кланове."
  },
  clanMission: {
    name: "Кланова мисия",
    durationHours: 12,
    reward: 10000,
    description: "Кланът изпълнява мисия за влияние и ресурси."
  },
  globalEvent: {
    name: "Глобално събитие",
    durationHours: 48,
    reward: 30000,
    description: "Всички кланове участват в общо предизвикателство."
  }
};

module.exports = {
  // =========================
  // START EVENT
  // =========================
  async startEvent(eventType) {
    const event = EVENT_TYPES[eventType];
    if (!event) throw new Error("Събитието не съществува");

    const startTime = new Date();
    const endTime = new Date(startTime.getTime() + event.durationHours * 3600000);

    const eventData = {
      type: eventType,
      name: event.name,
      description: event.description,
      reward: event.reward,
      startTime,
      endTime,
      participants: [],
      results: []
    };

    global.activeClanEvent = eventData;

    return eventData;
  },

  // =========================
  // JOIN EVENT
  // =========================
  async joinEvent(clanId) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    if (!global.activeClanEvent) {
      throw new Error("Няма активно събитие");
    }

    if (!global.activeClanEvent.participants.includes(clanId)) {
      global.activeClanEvent.participants.push(clanId);
    }

    clan.logs.push({
      text: `Кланът се включи в събитие: ${global.activeClanEvent.name}`,
      date: new Date()
    });

    await clan.save();

    return global.activeClanEvent;
  },

  // =========================
  // SUBMIT EVENT SCORE
  // =========================
  async submitScore(clanId, score) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    if (!global.activeClanEvent) {
      throw new Error("Няма активно събитие");
    }

    global.activeClanEvent.results.push({
      clanId,
      clanName: clan.name,
      score
    });

    return global.activeClanEvent;
  },

  // =========================
  // END EVENT
  // =========================
  async endEvent() {
    if (!global.activeClanEvent) {
      throw new Error("Няма активно събитие");
    }

    const event = global.activeClanEvent;

    // Сортираме резултатите
    event.results.sort((a, b) => b.score - a.score);

    const winner = event.results[0];
    if (!winner) {
      global.activeClanEvent = null;
      return { winner: null, event };
    }

    const clan = await Clan.findById(winner.clanId);
    if (!clan) throw new Error("Кланът победител не е намерен");

    clan.treasury += event.reward;
    clan.influence += 20;
    clan.clanPower += 10;

    clan.logs.push({
      text: `Кланът спечели събитие: ${event.name} и получи ${event.reward}$`,
      date: new Date()
    });

    await clan.save();

    const result = { winner: clan, event };

    global.activeClanEvent = null;

    return result;
  },

  // =========================
  // GET ACTIVE EVENT
  // =========================
  getActiveEvent() {
    return global.activeClanEvent || null;
  }
};