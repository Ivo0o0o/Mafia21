// =========================
// CLAN WAR PANEL (PRO)
// =========================
//
// Този модул:
// - управлява UI логиката за кланови войни
// - извиква API към ClanWar.routes.js
// - използва се от admin.js (фронтенд)
// =========================

const ClanWarPanel = {
  // =========================
  // START WAR
  // =========================
  async startWar(attackerId, defenderId) {
    const res = await fetch(`/api/clan/war/start`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ attackerId, defenderId })
    });

    return await res.json();
  },

  // =========================
  // BATTLE
  // =========================
  async battle(attackerId, defenderId) {
    const res = await fetch(`/api/clan/war/battle`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ attackerId, defenderId })
    });

    return await res.json();
  },

  // =========================
  // TAKE TERRITORY
  // =========================
  async takeTerritory(winnerId, loserId, districtName) {
    const res = await fetch(`/api/clan/war/territory/${districtName}`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ winnerId, loserId })
    });

    return await res.json();
  },

  // =========================
  // END WAR
  // =========================
  async endWar(attackerId, defenderId) {
    const res = await fetch(`/api/clan/war/end`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ attackerId, defenderId })
    });

    return await res.json();
  }
};

module.exports = ClanWarPanel;