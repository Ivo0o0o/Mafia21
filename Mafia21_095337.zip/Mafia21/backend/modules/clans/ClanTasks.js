const Clan = require("./Clan.model");
const User = require("../player/player.model");

const TASK_TYPES = {
  daily: {
    name: "Ежедневна задача",
    reward: 1000,
    clanPoints: 5,
    resetHours: 24
  },
  weekly: {
    name: "Седмична задача",
    reward: 5000,
    clanPoints: 20,
    resetHours: 168 // 7 дни
  },
  seasonal: {
    name: "Сезонна задача",
    reward: 20000,
    clanPoints: 100,
    resetHours: 720 // 30 дни
  }
};

module.exports = {
  // =========================
  // CREATE TASK FOR CLAN
  // =========================
  async createTask(clanId, taskType, description) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    const type = TASK_TYPES[taskType];
    if (!type) throw new Error("Невалиден тип задача");

    if (!clan.tasks) clan.tasks = [];

    clan.tasks.push({
      type: taskType,
      description,
      reward: type.reward,
      clanPoints: type.clanPoints,
      progress: 0,
      goal: 100,
      createdAt: new Date(),
      completed: false
    });

    clan.logs.push({
      text: `Създадена е ${type.name}: ${description}`,
      date: new Date()
    });

    await clan.save();
    return clan.tasks;
  },

  // =========================
  // UPDATE TASK PROGRESS
  // =========================
  async updateProgress(clanId, taskIndex, amount) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    const task = clan.tasks?.[taskIndex];
    if (!task) throw new Error("Задачата не е намерена");

    if (task.completed) return task;

    task.progress += amount;

    if (task.progress >= task.goal) {
      task.completed = true;

      clan.treasury += task.reward;
      clan.seasonPoints = (clan.seasonPoints || 0) + task.clanPoints;

      clan.logs.push({
        text: `Кланът изпълни задача: ${task.description} (+${task.reward}$, +${task.clanPoints} точки)`,
        date: new Date()
      });
    }

    await clan.save();
    return task;
  },

  // =========================
  // RESET TASKS (DAILY/WEEKLY/SEASONAL)
  // =========================
  async resetTasks(clanId) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    const now = new Date();

    for (const task of clan.tasks || []) {
      const type = TASK_TYPES[task.type];
      if (!type) continue;

      const hoursPassed = (now - new Date(task.createdAt)) / 3600000;

      if (hoursPassed >= type.resetHours) {
        task.progress = 0;
        task.completed = false;
        task.createdAt = now;

        clan.logs.push({
          text: `Задачата "${task.description}" беше рестартирана (${type.name})`,
          date: now
        });
      }
    }

    await clan.save();
    return clan.tasks;
  },

  // =========================
  // GET ALL TASKS FOR CLAN
  // =========================
  async getTasks(clanId) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    return clan.tasks || [];
  },

  // =========================
  // PLAYER CONTRIBUTION
  // =========================
  async contribute(playerId, clanId, taskIndex, amount) {
    const player = await User.findById(playerId);
    if (!player) throw new Error("Играчът не е намерен");

    if (player.clan?.toString() !== clanId.toString()) {
      throw new Error("Играчът не е член на този клан");
    }

    const result = await this.updateProgress(clanId, taskIndex, amount);

    return {
      player: player.username,
      task: result
    };
  }
};