const Clan = require("./Clan.model");

module.exports = {
  // =========================
  // GET DIPLOMACY STATUS BETWEEN TWO CLANS
  // =========================
  async getStatus(clanAId, clanBId) {
    const clanA = await Clan.findById(clanAId);
    const clanB = await Clan.findById(clanBId);

    if (!clanA || !clanB) throw new Error("Кланът не е намерен");

    const statusA = clanA.diplomacy?.[clanBId] || "neutral";
    const statusB = clanB.diplomacy?.[clanAId] || "neutral";

    return {
      clanA: clanA.name,
      clanB: clanB.name,
      statusA,
      statusB
    };
  },

  // =========================
  // SET DIPLOMACY STATUS
  // =========================
  async setStatus(clanAId, clanBId, status) {
    const clanA = await Clan.findById(clanAId);
    const clanB = await Clan.findById(clanBId);

    if (!clanA || !clanB) throw new Error("Кланът не е намерен");

    if (!clanA.diplomacy) clanA.diplomacy = {};
    if (!clanB.diplomacy) clanB.diplomacy = {};

    clanA.diplomacy[clanBId] = status;
    clanB.diplomacy[clanAId] = status;

    clanA.logs.push({
      text: `Дипломатически статус с ${clanB.name}: ${status}`,
      date: new Date()
    });

    clanB.logs.push({
      text: `Дипломатически статус с ${clanA.name}: ${status}`,
      date: new Date()
    });

    await clanA.save();
    await clanB.save();

    return { clanA, clanB, status };
  },

  // =========================
  // FORM ALLIANCE
  // =========================
  async formAlliance(clanAId, clanBId) {
    return await this.setStatus(clanAId, clanBId, "alliance");
  },

  // =========================
  // FORM TRADE PACT
  // =========================
  async tradePact(clanAId, clanBId) {
    const result = await this.setStatus(clanAId, clanBId, "trade");

    // Бонуси от търговски пакт
    result.clanA.businessBoost += 5;
    result.clanB.businessBoost += 5;

    result.clanA.logs.push({
      text: `Търговски пакт с ${result.clanB.name}: +5% бизнес доходи`,
      date: new Date()
    });

    result.clanB.logs.push({
      text: `Търговски пакт с ${result.clanA.name}: +5% бизнес доходи`,
      date: new Date()
    });

    await result.clanA.save();
    await result.clanB.save();

    return result;
  },

  // =========================
  // FORM PEACE TREATY
  // =========================
  async peaceTreaty(clanAId, clanBId) {
    const result = await this.setStatus(clanAId, clanBId, "peace");

    // Бонуси от мирен договор
    result.clanA.influence += 10;
    result.clanB.influence += 10;

    result.clanA.logs.push({
      text: `Мирен договор с ${result.clanB.name}: +10 влияние`,
      date: new Date()
    });

    result.clanB.logs.push({
      text: `Мирен договор с ${result.clanA.name}: +10 влияние`,
      date: new Date()
    });

    await result.clanA.save();
    await result.clanB.save();

    return result;
  },

  // =========================
  // BREAK RELATIONS
  // =========================
  async breakRelations(clanAId, clanBId) {
    const clanA = await Clan.findById(clanAId);
    const clanB = await Clan.findById(clanBId);

    if (!clanA || !clanB) throw new Error("Кланът не е намерен");

    if (clanA.diplomacy) delete clanA.diplomacy[clanBId];
    if (clanB.diplomacy) delete clanB.diplomacy[clanAId];

    clanA.logs.push({
      text: `Дипломатическите отношения с ${clanB.name} са прекъснати`,
      date: new Date()
    });

    clanB.logs.push({
      text: `Дипломатическите отношения с ${clanA.name} са прекъснати`,
      date: new Date()
    });

    await clanA.save();
    await clanB.save();

    return { clanA, clanB };
  },

  // =========================
  // GET DIPLOMACY OVERVIEW FOR CLAN
  // =========================
  async getOverview(clanId) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    return clan.diplomacy || {};
  }
};