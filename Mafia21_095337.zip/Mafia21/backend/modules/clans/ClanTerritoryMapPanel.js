// =========================
// CLAN TERRITORY MAP PANEL (PRO)
// =========================
//
// Този модул:
// - управлява UI логиката за визуалната карта на териториите
// - извиква API към ClanTerritoryMap.js през backend routes
// - използва се от admin.js (фронтенд)
// =========================

const ClanTerritoryMapPanel = {
  // =========================
  // GET FULL MAP
  // =========================
  async getMap() {
    const res = await fetch(`/api/clan/map`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // GET DISTRICT INFO
  // =========================
  async getDistrict(districtName) {
    const res = await fetch(`/api/clan/map/district/${districtName}`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // SET OWNER OF DISTRICT
  // =========================
  async setOwner(districtName, clanId) {
    const res = await fetch(`/api/clan/map/setOwner`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ districtName, clanId })
    });

    return await res.json();
  },

  // =========================
  // GET LEGEND (COLORS)
  // =========================
  async getLegend() {
    const res = await fetch(`/api/clan/map/legend`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  }
};

module.exports = ClanTerritoryMapPanel;