const Clan = require("./Clan.model");
const District = require("../world/districts/District.model");

module.exports = {
  // =========================
  // START WAR BETWEEN CLANS
  // =========================
  async startWar(attackerId, defenderId) {
    const attacker = await Clan.findById(attackerId);
    const defender = await Clan.findById(defenderId);

    if (!attacker || !defender) {
      throw new Error("Един от клановете не е намерен");
    }

    if (attackerId === defenderId) {
      throw new Error("Клан не може да започне война със себе си");
    }

    attacker.logs.push({
      text: `Кланът започна война срещу ${defender.name}`,
      date: new Date()
    });

    defender.logs.push({
      text: `Кланът беше нападнат от ${attacker.name}`,
      date: new Date()
    });

    await attacker.save();
    await defender.save();

    return { attacker, defender };
  },

  // =========================
  // RESOLVE WAR BATTLE
  // =========================
  async battle(attackerId, defenderId) {
    const attacker = await Clan.findById(attackerId);
    const defender = await Clan.findById(defenderId);

    if (!attacker || !defender) {
      throw new Error("Един от клановете не е намерен");
    }

    // Формула за сила
    const attackerPower = attacker.clanPower + attacker.members.length * 2;
    const defenderPower = defender.clanPower + defender.members.length * 2;

    const randomFactor = Math.floor(Math.random() * 10);

    const attackerScore = attackerPower + randomFactor;
    const defenderScore = defenderPower + (10 - randomFactor);

    let winner, loser;

    if (attackerScore > defenderScore) {
      winner = attacker;
      loser = defender;
    } else {
      winner = defender;
      loser = attacker;
    }

    // Логове
    winner.logs.push({
      text: `Кланът победи ${loser.name} в битка`,
      date: new Date()
    });

    loser.logs.push({
      text: `Кланът беше победен от ${winner.name}`,
      date: new Date()
    });

    // Репутация
    winner.reputation += 3;
    loser.reputation = Math.max(0, loser.reputation - 2);

    // Сила
    winner.clanPower += 2;
    loser.clanPower = Math.max(0, loser.clanPower - 1);

    await winner.save();
    await loser.save();

    return { winner, loser };
  },

  // =========================
  // TAKE TERRITORY AFTER WIN
  // =========================
  async takeTerritory(winnerId, loserId, districtName) {
    const winner = await Clan.findById(winnerId);
    const loser = await Clan.findById(loserId);
    const district = await District.findOne({ name: districtName });

    if (!winner || !loser) throw new Error("Кланът не е намерен");
    if (!district) throw new Error("Районът не е намерен");

    // Ако районът не е на губещия → няма смисъл
    if (String(district.control) !== String(loser._id)) {
      throw new Error("Губещият клан не контролира този район");
    }

    // Премахване от губещия
    loser.territories = loser.territories.filter(t => t !== districtName);
    loser.districtInfluence.delete(districtName);
    loser.influence = Math.max(0, loser.influence - 5);

    loser.logs.push({
      text: `Кланът загуби район ${districtName}`,
      date: new Date()
    });

    // Добавяне към победителя
    if (!winner.territories.includes(districtName)) {
      winner.territories.push(districtName);
    }

    winner.districtInfluence.set(districtName, 10);
    winner.influence += 5;
    winner.clanPower += 3;

    winner.logs.push({
      text: `Кланът завзе район ${districtName} от ${loser.name}`,
      date: new Date()
    });

    // Обновяване на района
    district.control = winner._id;
    district.influence += 3;

    await loser.save();
    await winner.save();
    await district.save();

    return { winner, loser, district };
  },

  // =========================
  // END WAR
  // =========================
  async endWar(attackerId, defenderId) {
    const attacker = await Clan.findById(attackerId);
    const defender = await Clan.findById(defenderId);

    if (!attacker || !defender) {
      throw new Error("Кланът не е намерен");
    }

    attacker.logs.push({
      text: `Войната с ${defender.name} приключи`,
      date: new Date()
    });

    defender.logs.push({
      text: `Войната с ${attacker.name} приключи`,
      date: new Date()
    });

    await attacker.save();
    await defender.save();

    return { attacker, defender };
  }
};