const Clan = require("./Clan.model");

const UPGRADE_TREE = {
  // =========================
  // LEVEL 1 → 2
  // =========================
  level2: {
    cost: 5000,
    requirements: { clanLevel: 1 },
    effects: {
      clanLevel: 2,
      clanPower: 5,
      influence: 10,
      businessBoost: 5
    }
  },

  // =========================
  // LEVEL 2 → 3
  // =========================
  level3: {
    cost: 15000,
    requirements: { clanLevel: 2 },
    effects: {
      clanLevel: 3,
      clanPower: 10,
      influence: 20,
      businessBoost: 10,
      npcBoost: 5
    }
  },

  // =========================
  // LEVEL 3 → 4
  // =========================
  level4: {
    cost: 30000,
    requirements: { clanLevel: 3 },
    effects: {
      clanLevel: 4,
      clanPower: 15,
      influence: 30,
      businessBoost: 15,
      npcBoost: 10,
      battleBoost: 5
    }
  },

  // =========================
  // LEVEL 4 → 5
  // =========================
  level5: {
    cost: 60000,
    requirements: { clanLevel: 4 },
    effects: {
      clanLevel: 5,
      clanPower: 25,
      influence: 50,
      businessBoost: 20,
      npcBoost: 15,
      battleBoost: 10
    }
  }
};

module.exports = {
  // =========================
  // GET AVAILABLE UPGRADES
  // =========================
  async getAvailableUpgrades(clanId) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    const available = [];

    for (const key in UPGRADE_TREE) {
      const upgrade = UPGRADE_TREE[key];

      if (upgrade.requirements.clanLevel === clan.clanLevel) {
        available.push({
          id: key,
          cost: upgrade.cost,
          effects: upgrade.effects
        });
      }
    }

    return available;
  },

  // =========================
  // APPLY UPGRADE
  // =========================
  async applyUpgrade(clanId, upgradeId) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    const upgrade = UPGRADE_TREE[upgradeId];
    if (!upgrade) throw new Error("Ъпгрейдът не съществува");

    // Проверка за ниво
    if (upgrade.requirements.clanLevel !== clan.clanLevel) {
      throw new Error("Кланът не отговаря на изискванията за този ъпгрейд");
    }

    // Проверка за пари
    if (clan.treasury < upgrade.cost) {
      throw new Error("Недостатъчно средства в клановата каса");
    }

    // Плащане
    clan.treasury -= upgrade.cost;

    // Прилагане на ефекти
    for (const key in upgrade.effects) {
      clan[key] = upgrade.effects[key];
    }

    clan.logs.push({
      text: `Кланът получи ъпгрейд: ${upgradeId}`,
      date: new Date()
    });

    await clan.save();

    return clan;
  }
};