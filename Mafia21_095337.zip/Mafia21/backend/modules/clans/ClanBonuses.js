const Clan = require("./Clan.model");
const User = require("../player/player.model");

module.exports = {
  // =========================
  // APPLY BONUSES TO PLAYER
  // =========================
  async applyPlayerBonuses(playerId) {
    const player = await User.findById(playerId);
    if (!player) throw new Error("Играчът не е намерен");

    if (!player.clan) return player; // няма клан → няма бонуси

    const clan = await Clan.findById(player.clan);
    if (!clan) return player;

    const bonuses = {
      incomeBonus: clan.businessBoost || 0,
      battleBonus: clan.battleBoost || 0,
      npcBonus: clan.npcBoost || 0,
      influenceBonus: clan.influence || 0,
      powerBonus: clan.clanPower || 0
    };

    // Прилагаме бонусите към играча
    player.bonuses = bonuses;

    await player.save();
    return player;
  },

  // =========================
  // CALCULATE PLAYER INCOME WITH CLAN BONUS
  // =========================
  calculateIncome(baseIncome, player) {
    if (!player.bonuses || !player.bonuses.incomeBonus) {
      return baseIncome;
    }

    const bonusPercent = player.bonuses.incomeBonus;
    const bonusAmount = Math.floor(baseIncome * (bonusPercent / 100));

    return baseIncome + bonusAmount;
  },

  // =========================
  // CALCULATE BATTLE POWER WITH CLAN BONUS
  // =========================
  calculateBattlePower(basePower, player) {
    if (!player.bonuses || !player.bonuses.battleBonus) {
      return basePower;
    }

    const bonus = player.bonuses.battleBonus;
    return basePower + bonus;
  },

  // =========================
  // CALCULATE NPC SUPPORT BONUS
  // =========================
  calculateNPCBonus(player) {
    if (!player.bonuses || !player.bonuses.npcBonus) {
      return 0;
    }

    return player.bonuses.npcBonus * 5; // NPC дават 5$ на точка
  },

  // =========================
  // APPLY BONUSES TO ALL CLAN MEMBERS
  // =========================
  async applyBonusesToClan(clanId) {
    const clan = await Clan.findById(clanId).populate("members");
    if (!clan) throw new Error("Кланът не е намерен");

    const results = [];

    for (const member of clan.members) {
      const updated = await this.applyPlayerBonuses(member._id);
      results.push(updated);
    }

    return results;
  }
};