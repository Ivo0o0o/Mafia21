const Clan = require("./Clan.model");

const BLACK_MARKET_ITEMS = [
  {
    id: "weapon_pack",
    name: "Пакет нелегални оръжия",
    price: 15000,
    clanBonus: { power: 10 },
    risk: 15 // шанс за наказание
  },
  {
    id: "rare_materials",
    name: "Редки материали",
    price: 25000,
    clanBonus: { influence: 20 },
    risk: 10
  },
  {
    id: "forbidden_tech",
    name: "Забранена технология",
    price: 50000,
    clanBonus: { clanPower: 25 },
    risk: 25
  },
  {
    id: "smuggled_goods",
    name: "Контрабандни стоки",
    price: 10000,
    clanBonus: { treasury: 5000 },
    risk: 5
  }
];

module.exports = {
  // =========================
  // GET DAILY BLACK MARKET OFFER
  // =========================
  async getDailyOffer() {
    const index = Math.floor((Date.now() / 86400000) % BLACK_MARKET_ITEMS.length);
    return BLACK_MARKET_ITEMS[index];
  },

  // =========================
  // BUY FROM BLACK MARKET
  // =========================
  async buy(clanId, itemId) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    const item = BLACK_MARKET_ITEMS.find(i => i.id === itemId);
    if (!item) throw new Error("Предметът не съществува");

    if (clan.treasury < item.price) {
      throw new Error("Кланът няма достатъчно пари");
    }

    // Плащане
    clan.treasury -= item.price;

    // Бонуси
    if (item.clanBonus.power) clan.power += item.clanBonus.power;
    if (item.clanBonus.influence) clan.influence += item.clanBonus.influence;
    if (item.clanBonus.clanPower) clan.clanPower += item.clanBonus.clanPower;
    if (item.clanBonus.treasury) clan.treasury += item.clanBonus.treasury;

    // Риск от наказание
    const roll = Math.random() * 100;
    let penalty = null;

    if (roll < item.risk) {
      penalty = {
        type: "police",
        message: "Полицията е разбрала за сделката!",
        fine: Math.floor(item.price * 0.5)
      };

      clan.treasury -= penalty.fine;
      clan.influence -= 5;

      clan.logs.push({
        text: `⚠ Черен пазар: Полицията наложи глоба ${penalty.fine}$`,
        date: new Date()
      });
    }

    clan.logs.push({
      text: `Кланът купи от черния пазар: ${item.name} (${item.price}$)`,
      date: new Date()
    });

    await clan.save();

    return {
      item,
      penalty,
      clan
    };
  },

  // =========================
  // GET FULL ITEM LIST
  // =========================
  async getItems() {
    return BLACK_MARKET_ITEMS;
  }
};