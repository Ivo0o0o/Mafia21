const Clan = require("./Clan.model");
const ClanService = require("./Clan.service");
const clanEngine = require("./Clan.engine");

// Проверка дали потребителят е лидер или офицер
function isClanAdmin(clan, userId) {
  const isLeader = String(clan.leader) === String(userId);
  const isOfficer = clan.officers.includes(userId);
  return isLeader || isOfficer;
}

module.exports = {
  // =========================
  // GET CLAN ADMIN PANEL DATA
  // =========================
  getAdminPanel: async (req, res) => {
    try {
      const clan = await Clan.findById(req.params.clanId)
        .populate("leader")
        .populate("officers")
        .populate("members");

      if (!clan) {
        return res.status(404).json({ success: false, error: "Кланът не е намерен" });
      }

      if (!isClanAdmin(clan, req.user.id)) {
        return res.status(403).json({ success: false, error: "Нямаш права за админ панела" });
      }

      res.json({
        success: true,
        clan
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // PROMOTE MEMBER → OFFICER
  // =========================
  promote: async (req, res) => {
    try {
      const { clanId, memberId } = req.params;

      const clan = await Clan.findById(clanId);
      if (!clan) return res.status(404).json({ success: false, error: "Кланът не е намерен" });

      if (String(clan.leader) !== String(req.user.id)) {
        return res.status(403).json({ success: false, error: "Само лидерът може да повишава" });
      }

      const updatedClan = await ClanService.promoteMember(clanId, req.user.id, memberId);

      res.json({
        success: true,
        message: "Играчът е повишен в офицер",
        clan: updatedClan
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // DEMOTE MEMBER → REMOVE OFFICER
  // =========================
  demote: async (req, res) => {
    try {
      const { clanId, memberId } = req.params;

      const clan = await Clan.findById(clanId);
      if (!clan) return res.status(404).json({ success: false, error: "Кланът не е намерен" });

      if (String(clan.leader) !== String(req.user.id)) {
        return res.status(403).json({ success: false, error: "Само лидерът може да понижава" });
      }

      const updatedClan = await ClanService.demoteMember(clanId, req.user.id, memberId);

      res.json({
        success: true,
        message: "Играчът е понижен",
        clan: updatedClan
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // KICK MEMBER
  // =========================
  kick: async (req, res) => {
    try {
      const { clanId, memberId } = req.params;

      const clan = await Clan.findById(clanId);
      if (!clan) return res.status(404).json({ success: false, error: "Кланът не е намерен" });

      if (!isClanAdmin(clan, req.user.id)) {
        return res.status(403).json({ success: false, error: "Нямаш права да изхвърляш членове" });
      }

      const updatedClan = await ClanService.leaveClan(clanId, memberId);

      res.json({
        success: true,
        message: "Играчът е изхвърлен от клана",
        clan: updatedClan
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // INVITE MEMBER
  // =========================
  invite: async (req, res) => {
    try {
      const { clanId } = req.params;
      const { userId } = req.body;

      const clan = await Clan.findById(clanId);
      if (!clan) return res.status(404).json({ success: false, error: "Кланът не е намерен" });

      if (!isClanAdmin(clan, req.user.id)) {
        return res.status(403).json({ success: false, error: "Нямаш права да каниш" });
      }

      clan.invites.push({ user: userId, date: new Date() });
      clan.logs.push({ text: `Покана изпратена към ${userId}`, date: new Date() });

      await clan.save();

      res.json({
        success: true,
        message: "Поканата е изпратена",
        clan
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // ACCEPT INVITE
  // =========================
  acceptInvite: async (req, res) => {
    try {
      const { clanId } = req.params;

      const clan = await Clan.findById(clanId);
      if (!clan) return res.status(404).json({ success: false, error: "Кланът не е намерен" });

      const invite = clan.invites.find(i => String(i.user) === String(req.user.id));
      if (!invite) {
        return res.status(400).json({ success: false, error: "Няма покана" });
      }

      const updatedClan = await ClanService.joinClan(clanId, req.user.id);

      clan.invites = clan.invites.filter(i => String(i.user) !== String(req.user.id));
      await clan.save();

      res.json({
        success: true,
        message: "Присъедини се към клана",
        clan: updatedClan
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // TREASURY: ADD MONEY
  // =========================
  addTreasury: async (req, res) => {
    try {
      const { clanId } = req.params;
      const { amount } = req.body;

      const clan = await Clan.findById(clanId);
      if (!clan) return res.status(404).json({ success: false, error: "Кланът не е намерен" });

      if (!isClanAdmin(clan, req.user.id)) {
        return res.status(403).json({ success: false, error: "Нямаш права за касата" });
      }

      const treasury = await ClanService.addTreasury(clanId, amount);

      res.json({
        success: true,
        message: "Средствата са добавени",
        treasury
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // TREASURY: SPEND MONEY
  // =========================
  spendTreasury: async (req, res) => {
    try {
      const { clanId } = req.params;
      const { amount, reason } = req.body;

      const clan = await Clan.findById(clanId);
      if (!clan) return res.status(404).json({ success: false, error: "Кланът не е намерен" });

      if (!isClanAdmin(clan, req.user.id)) {
        return res.status(403).json({ success: false, error: "Нямаш права за касата" });
      }

      const treasury = await ClanService.spendTreasury(clanId, amount, reason);

      res.json({
        success: true,
        message: "Средствата са изхарчени",
        treasury
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // LEVEL UP CLAN
  // =========================
  levelUp: async (req, res) => {
    try {
      const { clanId } = req.params;

      const clan = await Clan.findById(clanId);
      if (!clan) return res.status(404).json({ success: false, error: "Кланът не е намерен" });

      if (String(clan.leader) !== String(req.user.id)) {
        return res.status(403).json({ success: false, error: "Само лидерът може да вдига нивото" });
      }

      const updatedClan = await ClanService.levelUpClan(clanId);

      res.json({
        success: true,
        message: "Кланът е повишен",
        clan: updatedClan
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
};