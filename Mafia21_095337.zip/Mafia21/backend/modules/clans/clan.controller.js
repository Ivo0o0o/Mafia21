const Clan = require("./Clan.model");
const clanEngine = require("./Clan.engine");
const User = require("../player/player.model");

module.exports = {
  // =========================
  // GET ALL CLANS
  // =========================
  getAll: async (req, res) => {
    try {
      const clans = await Clan.find()
        .populate("leader")
        .populate("officers")
        .populate("members");

      res.json({
        success: true,
        clans
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // CREATE CLAN
  // =========================
  create: async (req, res) => {
    try {
      const leader = await User.findById(req.user.id);
      if (!leader) {
        return res.status(404).json({ success: false, error: "Лидерът не е намерен" });
      }

      // Проверка дали играчът вече е в клан
      const existingClan = await Clan.findOne({ members: req.user.id });
      if (existingClan) {
        return res.status(400).json({
          success: false,
          error: "Вече си член на клан"
        });
      }

      const clan = await Clan.create({
        name: req.body.name,
        tag: req.body.tag,
        description: req.body.description || "",
        leader: leader._id,
        officers: [],
        members: [leader._id],
        color: req.body.color || "#ff0000",
        treasury: 0,
        clanLevel: 1,
        clanPower: 5,
        influence: 0,
        reputation: 0,
        territories: []
      });

      clan.logs.push({
        text: `Кланът е създаден от ${leader.username}`,
        date: new Date()
      });

      await clan.save();

      res.json({
        success: true,
        message: "Кланът е създаден успешно.",
        clan
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // JOIN CLAN
  // =========================
  join: async (req, res) => {
    try {
      const { clanId } = req.params;

      const clan = await Clan.findById(clanId);
      if (!clan) {
        return res.status(404).json({ success: false, error: "Кланът не е намерен" });
      }

      // Проверка дали играчът вече е член
      if (clan.members.includes(req.user.id)) {
        return res.json({
          success: true,
          message: "Вече си член на този клан",
          clan
        });
      }

      clan.members.push(req.user.id);
      clan.reputation += 1;
      clan.clanPower += 1;

      clan.logs.push({
        text: `${req.user.username} се присъедини към клана`,
        date: new Date()
      });

      await clan.save();

      res.json({
        success: true,
        message: "Присъедини се към клана успешно.",
        clan
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  },

  // =========================
  // ADD TERRITORY
  // =========================
  addTerritory: async (req, res) => {
    try {
      const { clanId } = req.params;
      const { districtName } = req.body;

      // Само лидер или офицер може да добавя територии
      const clan = await Clan.findById(clanId);
      if (!clan) {
        return res.status(404).json({ success: false, error: "Кланът не е намерен" });
      }

      const isLeader = String(clan.leader) === String(req.user.id);
      const isOfficer = clan.officers.includes(req.user.id);

      if (!isLeader && !isOfficer) {
        return res.status(403).json({
          success: false,
          error: "Само лидер или офицер може да управлява територии"
        });
      }

      const result = await clanEngine.addTerritory(clanId, districtName);

      res.json({
        success: true,
        message: "Територията е добавена към клана.",
        clan: result.clan,
        district: result.district
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
};