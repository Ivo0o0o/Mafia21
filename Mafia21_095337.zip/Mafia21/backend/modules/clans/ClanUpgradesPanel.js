// =========================
// CLAN UPGRADES PANEL (PRO)
// =========================
//
// Този модул:
// - управлява UI логиката за кланови ъпгрейди
// - извиква API към ClanUpgrades.js през backend routes
// - използва се от admin.js (фронтенд)
// =========================

const ClanUpgradesPanel = {
  // =========================
  // GET AVAILABLE UPGRADES
  // =========================
  async getAvailable(clanId) {
    const res = await fetch(`/api/clan/upgrades/${clanId}`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // APPLY UPGRADE
  // =========================
  async apply(clanId, upgradeId) {
    const res = await fetch(`/api/clan/upgrades/${clanId}/apply`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ upgradeId })
    });

    return await res.json();
  }
};

module.exports = ClanUpgradesPanel;