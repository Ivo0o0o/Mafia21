const Clan = require("./Clan.model");
const Business = require("../business/Business.model");

module.exports = {
  // =========================
  // CALCULATE CLAN INCOME FROM BUSINESSES
  // =========================
  async calculateIncome(clanId) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    // Взимаме всички бизнеси, които са в териториите на клана
    const businesses = await Business.find({
      district: { $in: clan.territories }
    });

    let totalIncome = 0;

    for (const b of businesses) {
      const baseIncome = b.income || 0;
      const clanBoost = clan.businessBoost || 0;

      totalIncome += baseIncome + Math.floor(baseIncome * (clanBoost / 100));
    }

    // Добавяме в касата
    clan.treasury += totalIncome;

    clan.logs.push({
      text: `Кланът получи ${totalIncome}$ от бизнеси`,
      date: new Date()
    });

    await clan.save();

    return { clan, totalIncome };
  },

  // =========================
  // APPLY DAILY CLAN ECONOMY TICK
  // =========================
  async dailyTick() {
    const clans = await Clan.find();

    const results = [];

    for (const clan of clans) {
      // Бонус от влияние
      const influenceBonus = Math.floor(clan.influence / 10);
      const powerBonus = Math.floor(clan.clanPower / 5);

      const totalBonus = influenceBonus + powerBonus;

      clan.treasury += totalBonus;

      clan.logs.push({
        text: `Дневен бонус: ${totalBonus}$ (влияние + сила)`,
        date: new Date()
      });

      await clan.save();

      results.push({
        clanId: clan._id,
        bonus: totalBonus
      });
    }

    return results;
  },

  // =========================
  // APPLY NPC SUPPORT BONUS
  // =========================
  async npcSupportTick() {
    const clans = await Clan.find();

    for (const clan of clans) {
      const npcBoost = clan.npcBoost || 0;
      if (npcBoost <= 0) continue;

      const bonus = npcBoost * 10;

      clan.treasury += bonus;

      clan.logs.push({
        text: `NPC подкрепа: ${bonus}$ добавени в касата`,
        date: new Date()
      });

      await clan.save();
    }
  }
};