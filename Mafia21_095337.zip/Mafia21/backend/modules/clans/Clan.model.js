const mongoose = require('mongoose');

const clanSchema = new mongoose.Schema({
  // Основна информация
  name: { type: String, required: true, unique: true },
  tag: { type: String, required: true, unique: true }, // кратък таг, напр. BOSS
  description: { type: String, default: "" },

  // Лидер и членове
  leader: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  officers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  members: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],

  // Кланова икономика
  treasury: { type: Number, default: 0 }, // пари в клана
  clanLevel: { type: Number, default: 1 }, // 1–10
  clanPower: { type: Number, default: 0 }, // обща сила

  // Влияние и репутация
  influence: { type: Number, default: 0 },   // влияние в града
  reputation: { type: Number, default: 0 },  // кланова репутация

  // Територии
  territories: [{ type: String }],           // имена на райони
  districtInfluence: {
    type: Map,
    of: Number,
    default: {}
  },

  // Бонуси
  businessBoost: { type: Number, default: 0 }, // бонус към бизнес доходи
  battleBoost: { type: Number, default: 0 },   // бонус към битки
  npcBoost: { type: Number, default: 0 },       // NPC работят за клана

  // Войни
  wars: [{
    enemyClan: { type: mongoose.Schema.Types.ObjectId, ref: 'Clan' },
    wins: { type: Number, default: 0 },
    losses: { type: Number, default: 0 }
  }],

  // Покани
  invites: [{
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    date: { type: Date, default: Date.now }
  }],

  // Логове
  logs: [{
    text: { type: String },
    date: { type: Date, default: Date.now }
  }],

  // Визуално
  color: { type: String, default: '#ff0000' }

}, { timestamps: true });

module.exports = mongoose.model('Clan', clanSchema);