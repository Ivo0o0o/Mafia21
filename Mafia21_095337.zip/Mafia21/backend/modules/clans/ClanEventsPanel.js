// =========================
// CLAN EVENTS PANEL (PRO)
// =========================
//
// Този модул:
// - управлява UI логиката за кланови събития
// - извиква API към ClanEvents.js през backend routes
// - използва се от admin.js (фронтенд)
// =========================

const ClanEventsPanel = {
  // =========================
  // GET ACTIVE EVENT
  // =========================
  async getActiveEvent() {
    const res = await fetch(`/api/clan/events/active`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // START EVENT
  // =========================
  async startEvent(eventType) {
    const res = await fetch(`/api/clan/events/start`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ eventType })
    });

    return await res.json();
  },

  // =========================
  // JOIN EVENT
  // =========================
  async joinEvent(clanId) {
    const res = await fetch(`/api/clan/events/join`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanId })
    });

    return await res.json();
  },

  // =========================
  // SUBMIT SCORE
  // =========================
  async submitScore(clanId, score) {
    const res = await fetch(`/api/clan/events/score`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanId, score })
    });

    return await res.json();
  },

  // =========================
  // END EVENT
  // =========================
  async endEvent() {
    const res = await fetch(`/api/clan/events/end`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  }
};

module.exports = ClanEventsPanel;