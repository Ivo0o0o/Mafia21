// =========================
// CLAN DIPLOMACY PANEL (PRO)
// =========================
//
// Този модул:
// - управлява UI логиката за дипломатически отношения между кланове
// - извиква API към ClanDiplomacy.js през backend routes
// - използва се от admin.js (фронтенд)
// =========================

const ClanDiplomacyPanel = {
  // =========================
  // GET DIPLOMACY OVERVIEW
  // =========================
  async getOverview(clanId) {
    const res = await fetch(`/api/clan/diplomacy/${clanId}`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // GET STATUS BETWEEN TWO CLANS
  // =========================
  async getStatus(clanAId, clanBId) {
    const res = await fetch(`/api/clan/diplomacy/status`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanAId, clanBId })
    });

    return await res.json();
  },

  // =========================
  // SET DIPLOMACY STATUS
  // =========================
  async setStatus(clanAId, clanBId, status) {
    const res = await fetch(`/api/clan/diplomacy/set`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanAId, clanBId, status })
    });

    return await res.json();
  },

  // =========================
  // FORM ALLIANCE
  // =========================
  async formAlliance(clanAId, clanBId) {
    const res = await fetch(`/api/clan/diplomacy/alliance`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanAId, clanBId })
    });

    return await res.json();
  },

  // =========================
  // FORM TRADE PACT
  // =========================
  async tradePact(clanAId, clanBId) {
    const res = await fetch(`/api/clan/diplomacy/trade`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanAId, clanBId })
    });

    return await res.json();
  },

  // =========================
  // FORM PEACE TREATY
  // =========================
  async peaceTreaty(clanAId, clanBId) {
    const res = await fetch(`/api/clan/diplomacy/peace`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanAId, clanBId })
    });

    return await res.json();
  },

  // =========================
  // BREAK RELATIONS
  // =========================
  async breakRelations(clanAId, clanBId) {
    const res = await fetch(`/api/clan/diplomacy/break`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanAId, clanBId })
    });

    return await res.json();
  }
};

module.exports = ClanDiplomacyPanel;