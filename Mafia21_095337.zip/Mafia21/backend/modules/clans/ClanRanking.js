const Clan = require("./Clan.model");

module.exports = {
  // =========================
  // GLOBAL RANKING
  // =========================
  async getGlobalRanking() {
    const clans = await Clan.find();

    const ranking = clans
      .map(clan => ({
        id: clan._id,
        name: clan.name,
        power: clan.clanPower,
        influence: clan.influence,
        territories: clan.territories.length,
        treasury: clan.treasury,
        wins: clan.wins || 0
      }))
      .sort((a, b) => {
        // Основна формула за ранк
        const scoreA =
          a.power * 3 +
          a.influence * 2 +
          a.territories * 5 +
          a.treasury / 1000 +
          a.wins * 10;

        const scoreB =
          b.power * 3 +
          b.influence * 2 +
          b.territories * 5 +
          b.treasury / 1000 +
          b.wins * 10;

        return scoreB - scoreA;
      });

    return ranking;
  },

  // =========================
  // RANKING BY CATEGORY
  // =========================
  async getRankingBy(category) {
    const clans = await Clan.find();

    const validCategories = [
      "power",
      "influence",
      "territories",
      "treasury",
      "wins"
    ];

    if (!validCategories.includes(category)) {
      throw new Error("Невалидна категория за класация");
    }

    return clans
      .map(clan => ({
        id: clan._id,
        name: clan.name,
        value:
          category === "territories"
            ? clan.territories.length
            : clan[category] || 0
      }))
      .sort((a, b) => b.value - a.value);
  },

  // =========================
  // SEASONAL RANKING
  // =========================
  async getSeasonRanking(seasonId) {
    const clans = await Clan.find();

    const ranking = clans
      .map(clan => ({
        id: clan._id,
        name: clan.name,
        seasonScore: clan.seasons?.[seasonId] || 0
      }))
      .sort((a, b) => b.seasonScore - a.seasonScore);

    return ranking;
  },

  // =========================
  // UPDATE SEASON SCORE
  // =========================
  async addSeasonScore(clanId, seasonId, score) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    if (!clan.seasons) clan.seasons = {};
    clan.seasons[seasonId] = (clan.seasons[seasonId] || 0) + score;

    clan.logs.push({
      text: `Кланът получи ${score} сезонни точки`,
      date: new Date()
    });

    await clan.save();
    return clan;
  }
};