// =========================
// CLAN NPC PANEL (PRO)
// =========================
//
// Този модул:
// - управлява UI логиката за NPC помощниците на клана
// - извиква API към ClanNPCSupport.js през backend routes
// - използва се от admin.js (фронтенд)
// =========================

const ClanNPCPanel = {
  // =========================
  // GET NPC LIST
  // =========================
  async getNPCs(clanId) {
    const res = await fetch(`/api/clan/npc/${clanId}`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // BUY NPC
  // =========================
  async buyNPC(clanId, npcType) {
    const res = await fetch(`/api/clan/npc/${clanId}/buy`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ npcType })
    });

    return await res.json();
  },

  // =========================
  // REMOVE NPC
  // =========================
  async removeNPC(clanId, npcIndex) {
    const res = await fetch(`/api/clan/npc/${clanId}/remove`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ npcIndex })
    });

    return await res.json();
  },

  // =========================
  // DAILY NPC BONUS
  // =========================
  async dailyBonus(clanId) {
    const res = await fetch(`/api/clan/npc/${clanId}/daily`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  }
};

module.exports = ClanNPCPanel;