const Clan = require("./Clan.model");

module.exports = {
  // =========================
  // GET REPUTATION
  // =========================
  async getReputation(clanId) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    if (!clan.reputation) {
      clan.reputation = {
        police: 0,
        mafia: 0,
        citizens: 0,
        business: 0
      };
      await clan.save();
    }

    return clan.reputation;
  },

  // =========================
  // CHANGE REPUTATION
  // =========================
  async change(clanId, faction, amount) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    const valid = ["police", "mafia", "citizens", "business"];
    if (!valid.includes(faction)) {
      throw new Error("Невалидна фракция");
    }

    if (!clan.reputation) {
      clan.reputation = { police: 0, mafia: 0, citizens: 0, business: 0 };
    }

    clan.reputation[faction] += amount;

    clan.logs.push({
      text: `Репутацията с ${faction} се промени с ${amount}`,
      date: new Date()
    });

    await clan.save();
    return clan.reputation;
  },

  // =========================
  // APPLY ACTION EFFECTS
  // =========================
  async applyAction(clanId, actionType) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    if (!clan.reputation) {
      clan.reputation = { police: 0, mafia: 0, citizens: 0, business: 0 };
    }

    const rep = clan.reputation;

    switch (actionType) {
      case "heist_success":
        rep.police -= 20;
        rep.mafia += 10;
        rep.citizens -= 5;
        rep.business -= 10;
        break;

      case "heist_fail":
        rep.police += 15;
        rep.mafia -= 10;
        rep.citizens -= 10;
        rep.business -= 5;
        break;

      case "raid_success":
        rep.citizens += 10;
        rep.business += 5;
        break;

      case "blackmarket_buy":
        rep.police -= 10;
        rep.mafia += 15;
        rep.business -= 5;
        break;

      case "help_citizens":
        rep.citizens += 20;
        rep.police += 5;
        break;

      case "protect_business":
        rep.business += 25;
        rep.police += 10;
        break;

      default:
        throw new Error("Невалидно действие");
    }

    clan.logs.push({
      text: `Репутацията беше променена от действие: ${actionType}`,
      date: new Date()
    });

    await clan.save();
    return rep;
  },

  // =========================
  // GET REPUTATION EFFECTS
  // =========================
  async getEffects(clanId) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    const rep = clan.reputation || {
      police: 0,
      mafia: 0,
      citizens: 0,
      business: 0
    };

    return {
      policeRisk: Math.max(0, rep.police * -1), // колкото по-ниска репутация → повече риск
      mafiaSupport: Math.max(0, rep.mafia),     // бонуси от мафията
      citizenTrust: Math.max(0, rep.citizens),  // по-нисък риск от доноси
      businessDiscount: Math.max(0, rep.business / 10) // отстъпки
    };
  }
};