const Clan = require("./Clan.model");

const NPC_TYPES = {
  guard: {
    name: "Охрана",
    cost: 5000,
    dailyBonus: 20,
    battleBoost: 5,
    description: "Охраната увеличава защитата на териториите и дава бонус в битки."
  },
  spy: {
    name: "Шпионин",
    cost: 8000,
    dailyBonus: 10,
    intelBoost: 15,
    description: "Шпионинът дава информация за други кланове и увеличава влияние."
  },
  dealer: {
    name: "Дилър",
    cost: 6000,
    dailyBonus: 30,
    incomeBoost: 10,
    description: "Дилърът увеличава приходите от бизнеси."
  },
  enforcer: {
    name: "Рекетьор",
    cost: 10000,
    dailyBonus: 50,
    influenceBoost: 20,
    description: "Рекетьорът увеличава контрол върху територии."
  },
  fighter: {
    name: "Боец",
    cost: 7000,
    dailyBonus: 0,
    battleBoost: 10,
    description: "Боецът дава голям бонус към битки."
  }
};

module.exports = {
  // =========================
  // BUY NPC FOR CLAN
  // =========================
  async buyNPC(clanId, npcType) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    const npc = NPC_TYPES[npcType];
    if (!npc) throw new Error("NPC типът не съществува");

    if (clan.treasury < npc.cost) {
      throw new Error("Недостатъчно средства в касата");
    }

    clan.treasury -= npc.cost;

    if (!clan.npcs) clan.npcs = [];

    clan.npcs.push({
      type: npcType,
      name: npc.name,
      acquiredAt: new Date()
    });

    clan.logs.push({
      text: `Кланът нае NPC: ${npc.name}`,
      date: new Date()
    });

    await clan.save();
    return clan;
  },

  // =========================
  // DAILY NPC BONUS TICK
  // =========================
  async dailyNPCBonus(clanId) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    if (!clan.npcs || clan.npcs.length === 0) return { bonus: 0 };

    let totalBonus = 0;

    for (const npcData of clan.npcs) {
      const npc = NPC_TYPES[npcData.type];
      if (!npc) continue;

      totalBonus += npc.dailyBonus;

      // Прилагаме ефекти
      if (npc.battleBoost) clan.battleBoost += npc.battleBoost;
      if (npc.incomeBoost) clan.businessBoost += npc.incomeBoost;
      if (npc.influenceBoost) clan.influence += npc.influenceBoost;
      if (npc.intelBoost) clan.intel = (clan.intel || 0) + npc.intelBoost;
    }

    clan.treasury += totalBonus;

    clan.logs.push({
      text: `NPC бонус: +${totalBonus}$`,
      date: new Date()
    });

    await clan.save();

    return { clan, bonus: totalBonus };
  },

  // =========================
  // REMOVE NPC
  // =========================
  async removeNPC(clanId, npcIndex) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    if (!clan.npcs || !clan.npcs[npcIndex]) {
      throw new Error("NPC не е намерен");
    }

    const removed = clan.npcs[npcIndex];

    clan.npcs.splice(npcIndex, 1);

    clan.logs.push({
      text: `NPC ${removed.name} беше премахнат`,
      date: new Date()
    });

    await clan.save();
    return clan;
  },

  // =========================
  // GET NPC LIST
  // =========================
  async getNPCs(clanId) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    return clan.npcs || [];
  }
};