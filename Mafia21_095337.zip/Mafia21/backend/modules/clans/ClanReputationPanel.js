// =========================
// CLAN REPUTATION PANEL (PRO)
// =========================
//
// Този модул:
// - управлява UI логиката за репутацията на клана
// - извиква API към ClanReputation.js през backend routes
// - използва се от admin.js (фронтенд)
// =========================

const ClanReputationPanel = {
  // =========================
  // GET REPUTATION
  // =========================
  async getReputation(clanId) {
    const res = await fetch(`/api/clan/reputation/${clanId}`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // CHANGE REPUTATION
  // =========================
  async change(clanId, faction, amount) {
    const res = await fetch(`/api/clan/reputation/change`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanId, faction, amount })
    });

    return await res.json();
  },

  // =========================
  // APPLY ACTION EFFECTS
  // =========================
  async applyAction(clanId, actionType) {
    const res = await fetch(`/api/clan/reputation/applyAction`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanId, actionType })
    });

    return await res.json();
  },

  // =========================
  // GET EFFECTS
  // =========================
  async getEffects(clanId) {
    const res = await fetch(`/api/clan/reputation/effects/${clanId}`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  }
};

module.exports = ClanReputationPanel;