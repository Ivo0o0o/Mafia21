const Clan = require("./Clan.model");

module.exports = {
  // =========================
  // ADD SEASON CHAMPION
  // =========================
  async addSeasonChampion(seasonId, clanId) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    if (!clan.hallOfFame) clan.hallOfFame = [];

    clan.hallOfFame.push({
      type: "season",
      seasonId,
      name: clan.name,
      date: new Date()
    });

    clan.logs.push({
      text: `Кланът беше добавен в Hall of Fame като шампион на сезон ${seasonId}`,
      date: new Date()
    });

    await clan.save();
    return clan;
  },

  // =========================
  // ADD YEARLY CHAMPION
  // =========================
  async addYearChampion(year, clanId) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    if (!clan.hallOfFame) clan.hallOfFame = [];

    clan.hallOfFame.push({
      type: "year",
      year,
      name: clan.name,
      date: new Date()
    });

    clan.logs.push({
      text: `Кланът беше добавен в Hall of Fame като шампион за ${year}`,
      date: new Date()
    });

    await clan.save();
    return clan;
  },

  // =========================
  // ADD SPECIAL AWARD
  // =========================
  async addSpecialAward(clanId, awardName) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    if (!clan.hallOfFame) clan.hallOfFame = [];

    clan.hallOfFame.push({
      type: "special",
      award: awardName,
      name: clan.name,
      date: new Date()
    });

    clan.logs.push({
      text: `Кланът получи специална награда: ${awardName}`,
      date: new Date()
    });

    await clan.save();
    return clan;
  },

  // =========================
  // GET HALL OF FAME FOR CLAN
  // =========================
  async getClanHall(clanId) {
    const clan = await Clan.findById(clanId);
    if (!clan) throw new Error("Кланът не е намерен");

    return clan.hallOfFame || [];
  },

  // =========================
  // GET GLOBAL HALL OF FAME
  // =========================
  async getGlobalHall() {
    const clans = await Clan.find();

    const hall = [];

    for (const clan of clans) {
      if (clan.hallOfFame && clan.hallOfFame.length > 0) {
        hall.push({
          clanId: clan._id,
          clanName: clan.name,
          entries: clan.hallOfFame
        });
      }
    }

    // Сортираме по дата (най-новите първи)
    hall.sort((a, b) => {
      const lastA = a.entries[a.entries.length - 1]?.date || 0;
      const lastB = b.entries[b.entries.length - 1]?.date || 0;
      return lastB - lastA;
    });

    return hall;
  },

  // =========================
  // GET TOP 10 CLANS OF ALL TIME
  // =========================
  async getTop10() {
    const clans = await Clan.find();

    const ranking = clans
      .map(clan => ({
        id: clan._id,
        name: clan.name,
        fame: (clan.hallOfFame?.length || 0) * 10 +
              (clan.wins || 0) * 5 +
              clan.clanPower +
              clan.influence
      }))
      .sort((a, b) => b.fame - a.fame)
      .slice(0, 10);

    return ranking;
  }
};