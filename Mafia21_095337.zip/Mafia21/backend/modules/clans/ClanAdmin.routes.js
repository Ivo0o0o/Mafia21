const express = require("express");
const router = express.Router();

const controller = require("./ClanAdmin.controller");
const auth = require("../core/auth");

// =========================
// CLAN ADMIN PANEL ROUTES
// =========================

// Взимане на админ панела
router.get("/:clanId", auth, controller.getAdminPanel);

// Управление на членове
router.post("/:clanId/promote/:memberId", auth, controller.promote);
router.post("/:clanId/demote/:memberId", auth, controller.demote);
router.post("/:clanId/kick/:memberId", auth, controller.kick);

// Покани
router.post("/:clanId/invite", auth, controller.invite);
router.post("/:clanId/accept", auth, controller.acceptInvite);

// Кланова каса
router.post("/:clanId/treasury/add", auth, controller.addTreasury);
router.post("/:clanId/treasury/spend", auth, controller.spendTreasury);

// Ниво на клана
router.post("/:clanId/levelup", auth, controller.levelUp);

module.exports = router;