// =========================
// CLAN BLACK MARKET PANEL (PRO)
// =========================
//
// Този модул:
// - управлява UI логиката за черния пазар
// - извиква API към ClanBlackMarket.js през backend routes
// - използва се от admin.js (фронтенд)
// =========================

const ClanBlackMarketPanel = {
  // =========================
  // GET DAILY OFFER
  // =========================
  async getDailyOffer() {
    const res = await fetch(`/api/clan/blackmarket/daily`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // GET ALL ITEMS
  // =========================
  async getItems() {
    const res = await fetch(`/api/clan/blackmarket/items`, {
      method: "GET",
      headers: {
        "Authorization": localStorage.getItem("token")
      }
    });

    return await res.json();
  },

  // =========================
  // BUY ITEM
  // =========================
  async buy(clanId, itemId) {
    const res = await fetch(`/api/clan/blackmarket/buy`, {
      method: "POST",
      headers: {
        "Authorization": localStorage.getItem("token"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ clanId, itemId })
    });

    return await res.json();
  }
};

module.exports = ClanBlackMarketPanel;