const mongoose = require("mongoose");

// REQUIRED ITEMS
const requiredItemSchema = new mongoose.Schema({
  itemId: { type: mongoose.Schema.Types.ObjectId, ref: "Item", required: true },
  quantity: { type: Number, required: true }
}, { _id: false });

// REWARD ITEMS
const rewardItemSchema = new mongoose.Schema({
  itemId: { type: mongoose.Schema.Types.ObjectId, ref: "Item", required: true },
  quantity: { type: Number, required: true }
}, { _id: false });

// REQUIRED SKILLS
const requiredSkillsSchema = new mongoose.Schema({
  shooting: { type: Number, default: 0 },
  hacking: { type: Number, default: 0 },
  negotiation: { type: Number, default: 0 },
  intimidation: { type: Number, default: 0 },
  deception: { type: Number, default: 0 },
  driving: { type: Number, default: 0 }
}, { _id: false });

const missionSchema = new mongoose.Schema({

  // BASIC INFO
  name: { type: String, required: true },
  description: { type: String, default: "" },

  // TYPE
  type: {
    type: String,
    enum: [
      "delivery",
      "kill",
      "steal",
      "craft",
      "collect",
      "escort",
      "sabotage",
      "npc",
      "crime"
    ],
    default: "delivery"
  },

  // DISTRICT
  district: { type: String, default: "center" },

  // NPC giver
  npcGiver: { type: mongoose.Schema.Types.ObjectId, ref: "NPC", default: null },

  // DIFFICULTY (1–10)
  difficulty: { type: Number, default: 1 },

  // REQUIRED LEVEL
  requiredLevel: { type: Number, default: 1 },

  // REQUIRED SKILLS
  requiredSkills: {
    type: requiredSkillsSchema,
    default: {}
  },

  // REQUIRED ITEMS
  requiredItems: {
    type: [requiredItemSchema],
    default: []
  },

  // REWARD ITEMS
  rewardItems: {
    type: [rewardItemSchema],
    default: []
  },

  // MONEY REWARD
  rewardMoney: { type: Number, default: 100 },

  // XP REWARD
  rewardXP: { type: Number, default: 20 },

  // DURATION (seconds)
  duration: { type: Number, default: 10 },

  // RISK (0–100)
  risk: { type: Number, default: 0 },

  // ILLEGAL FLAG
  illegal: { type: Boolean, default: false },

  // HEAT (police attention)
  heat: { type: Number, default: 0 },

  // ACTIVE / DISABLED
  active: { type: Boolean, default: true }

}, { timestamps: true });

module.exports = mongoose.model("Mission", missionSchema);