const Mission = require("./mission.model");
const User = require("../user/user.model");
const InventoryService = require("../inventory/inventory.service");
const missionRewards = require("./missionRewards");

const {
  addCrimeReward,
  addLootReward,
  getVipEffects
} = require("../playerState/playerState.engine");

module.exports = {

  // ======================================================
  // GET ALL MISSIONS
  // ======================================================
  async getAll() {
    return Mission.find({ active: true })
      .sort({ difficulty: 1 })
      .populate("requiredItems.itemId rewardItems.itemId npcGiver");
  },

  // ======================================================
  // GET BY ID
  // ======================================================
  async getById(id) {
    return Mission.findById(id)
      .populate("requiredItems.itemId rewardItems.itemId npcGiver");
  },

  // ======================================================
  // START MISSION
  // ======================================================
  async startMission(userId, missionId) {
    const mission = await Mission.findById(missionId)
      .populate("requiredItems.itemId npcGiver");

    if (!mission) throw { type: "NOT_FOUND", message: "Mission not found" };
    if (!mission.active) throw { type: "CONFLICT", message: "Mission disabled" };

    const user = await User.findById(userId);
    if (!user) throw { type: "NOT_FOUND", message: "User not found" };

    const vip = await getVipEffects(userId);

    // LEVEL CHECK
    if (user.level < mission.requiredLevel) {
      throw { type: "CONFLICT", message: "Level too low" };
    }

    // SKILL CHECK
    const requiredSkills = mission.requiredSkills || {};
    const userSkills = user.skills || {};

    for (const skill of Object.keys(requiredSkills)) {
      if ((userSkills[skill] || 0) < requiredSkills[skill]) {
        throw { type: "CONFLICT", message: `Skill too low: ${skill}` };
      }
    }

    // REQUIRED ITEMS CHECK
    const hasItems = await InventoryService.hasItems(userId, mission.requiredItems);
    if (!hasItems) {
      throw { type: "CONFLICT", message: "Missing required items" };
    }

    // DURATION + VIP BOOST
    let durationMs = mission.duration * 1000;
    if (vip?.cooldownBoost) {
      durationMs = Math.floor(durationMs * vip.cooldownBoost);
    }

    const now = Date.now();

    return {
      success: true,
      missionId,
      userId,
      startedAt: now,
      endsAt: now + durationMs,
      duration: Math.floor(durationMs / 1000)
    };
  },

  // ======================================================
  // FINISH MISSION (FULL REWARD PIPELINE)
  // ======================================================
  async finishMission(userId, missionId) {
    const mission = await Mission.findById(missionId)
      .populate("requiredItems.itemId rewardItems.itemId npcGiver");

    if (!mission) throw { type: "NOT_FOUND", message: "Mission not found" };

    const user = await User.findById(userId);
    if (!user) throw { type: "NOT_FOUND", message: "User not found" };

    // RISK CHECK
    const roll = Math.random() * 100;
    if (roll < mission.risk) {
      return {
        success: false,
        message: "Mission failed due to risk",
        roll,
        risk: mission.risk
      };
    }

    // REMOVE REQUIRED ITEMS
    await InventoryService.removeItems(userId, mission.requiredItems);

    // ADD REWARD ITEMS
    await InventoryService.addItems(userId, mission.rewardItems);

    // ======================================================
    // APPLY MISSION REWARD MULTIPLIERS
    // ======================================================
    const multiplier = missionRewards.calculateFinalReward(mission, user);

    const baseMoney = mission.rewardMoney;
    const baseXP = mission.rewardXP;

    const finalMoney = Math.floor(baseMoney * multiplier);
    const finalXP = Math.floor(baseXP * multiplier);

    // VIP BOOST
    const boosted = await addCrimeReward(userId, finalMoney, finalXP);

    // LOOT BOOST
    const finalLoot = await addLootReward(userId, mission.rewardItems || []);

    // HEAT (illegal missions)
    let heat = mission.heat;
    if (mission.illegal) heat += 10;

    return {
      success: true,
      missionId,
      reward: {
        money: boosted.money,
        xp: boosted.xp,
        loot: finalLoot,
        multiplier,
        heat
      }
    };
  }
};