/**
 * Mission Rewards Multipliers (PRO Version 2026)
 * Работи с mission.service.js и mission.engine.js
 */

module.exports = {

  // ======================================================
  // Множител според типа мисия
  // ======================================================
  typeMultiplier: {
    delivery: 1.0,
    kill: 1.5,
    steal: 1.3,
    craft: 1.2,
    collect: 1.1,
    escort: 1.4,
    sabotage: 1.6,
    npc: 1.2,
    crime: 1.3
  },

  // ======================================================
  // Множител според трудността (1–10)
  // ======================================================
  difficultyMultiplier: (difficulty) => {
    const base = 1.0 + (difficulty * 0.15); // +15% на ниво трудност
    return Number(base.toFixed(2));
  },

  // ======================================================
  // Множител според риска (0–100)
  // ======================================================
  riskMultiplier: (risk) => {
    return 1 + (risk / 100); // рискът увеличава наградата пропорционално
  },

  // ======================================================
  // Множител според heat (illegal missions)
  // ======================================================
  heatMultiplier: (heat) => {
    return 1 + (heat * 0.02); // +2% на точка heat
  },

  // ======================================================
  // Множител според нивото на играча
  // ======================================================
  levelMultiplier: (level) => {
    return 1 + (level * 0.01); // +1% на ниво
  },

  // ======================================================
  // Финално изчисление на наградата
  // ======================================================
  calculateFinalReward(mission, user) {
    const typeMult = this.typeMultiplier[mission.type] || 1.0;
    const diffMult = this.difficultyMultiplier(mission.difficulty);
    const riskMult = this.riskMultiplier(mission.risk);
    const heatMult = this.heatMultiplier(mission.heat || 0);
    const levelMult = this.levelMultiplier(user.level || 1);

    const totalMultiplier = typeMult * diffMult * riskMult * heatMult * levelMult;

    return Number(totalMultiplier.toFixed(2));
  }
};