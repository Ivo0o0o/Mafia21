const router = require("express").Router();
const MissionController = require("./mission.controller");

// ======================================================
// GET ALL MISSIONS
// ======================================================
router.get("/", MissionController.getAll);

// ======================================================
// GET SINGLE MISSION
// ======================================================
router.get("/:id", MissionController.get);

// ======================================================
// SIMULATE MISSION (preview)
// ======================================================
router.get("/simulate/:id", MissionController.simulate);

// ======================================================
// START MISSION
// ======================================================
router.post("/start/:id", MissionController.start);

// ======================================================
// FINISH MISSION
// ======================================================
router.post("/finish/:id", MissionController.finish);

module.exports = router;