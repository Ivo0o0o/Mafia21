const Mission = require("./mission.model");
const InventoryService = require("../inventory/inventory.service");
const User = require("../user/user.model");
const missionRewards = require("./missionRewards");
const { getVipEffects } = require("../playerState/playerState.engine");

module.exports = {

  // ======================================================
  // CHECK IF PLAYER CAN START MISSION
  // ======================================================
  async canStartMission(userId, missionId) {
    const mission = await Mission.findById(missionId)
      .populate("requiredItems.itemId npcGiver");

    if (!mission) return { ok: false, error: "Mission not found" };
    if (!mission.active) return { ok: false, error: "Mission disabled" };

    const user = await User.findById(userId);
    if (!user) return { ok: false, error: "User not found" };

    // LEVEL CHECK
    if (user.level < mission.requiredLevel) {
      return { ok: false, error: "Level too low" };
    }

    // SKILL CHECK
    const requiredSkills = mission.requiredSkills || {};
    const userSkills = user.skills || {};

    for (const skill of Object.keys(requiredSkills)) {
      if ((userSkills[skill] || 0) < requiredSkills[skill]) {
        return { ok: false, error: `Skill too low: ${skill}` };
      }
    }

    // REQUIRED ITEMS CHECK
    const hasItems = await InventoryService.hasItems(userId, mission.requiredItems);
    if (!hasItems) {
      return { ok: false, error: "Missing required items" };
    }

    return { ok: true, mission, user };
  },

  // ======================================================
  // CALCULATE MISSION DURATION (VIP BOOST)
  // ======================================================
  async calculateDuration(userId, mission) {
    const vip = await getVipEffects(userId);

    let durationMs = mission.duration * 1000;

    if (vip?.cooldownBoost) {
      durationMs = Math.floor(durationMs * vip.cooldownBoost);
    }

    return {
      durationMs,
      durationSec: Math.floor(durationMs / 1000)
    };
  },

  // ======================================================
  // CALCULATE RISK RESULT
  // ======================================================
  calculateRisk(mission) {
    const roll = Math.random() * 100;
    const failChance = mission.risk || 0;

    if (roll < failChance) {
      return {
        failed: true,
        roll,
        failChance
      };
    }

    return {
      failed: false,
      roll,
      failChance
    };
  },

  // ======================================================
  // CALCULATE HEAT (illegal missions)
  // ======================================================
  calculateHeat(mission) {
    let heat = mission.heat || 0;

    if (mission.illegal) {
      heat += 10;
    }

    return heat;
  },

  // ======================================================
  // PREVIEW MISSION (simulate)
  // ======================================================
  async simulate(userId, missionId) {
    const check = await this.canStartMission(userId, missionId);
    if (!check.ok) return { success: false, error: check.error };

    const { mission, user } = check;

    const duration = await this.calculateDuration(userId, mission);
    const risk = this.calculateRisk(mission);
    const heat = this.calculateHeat(mission);

    // MULTIPLIER PREVIEW
    const multiplier = missionRewards.calculateFinalReward(mission, user);

    const previewMoney = Math.floor(mission.rewardMoney * multiplier);
    const previewXP = Math.floor(mission.rewardXP * multiplier);

    return {
      success: true,
      missionId,
      name: mission.name,
      type: mission.type,
      district: mission.district,
      npcGiver: mission.npcGiver,
      requiredLevel: mission.requiredLevel,
      requiredSkills: mission.requiredSkills,
      requiredItems: mission.requiredItems,
      rewardItems: mission.rewardItems,
      preview: {
        money: previewMoney,
        xp: previewXP,
        multiplier,
        heat,
        risk: mission.risk
      },
      duration: duration.durationSec,
      canStart: true
    };
  }
};