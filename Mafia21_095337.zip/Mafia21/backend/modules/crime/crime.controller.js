const CrimeService = require('./crime.service');

module.exports = {
  // Връща всички престъпления
  list: async (req, res) => {
    try {
      const crimes = await CrimeService.getAll();
      res.json({ ok: true, crimes });
    } catch (err) {
      console.error("Crime list error:", err);
      res.status(500).json({ ok: false, error: err.message });
    }
  },

  // Изпълнение на престъпление
  do: async (req, res) => {
    try {
      const userId = req.user.id;
      const crimeId = req.params.id;

      const result = await CrimeService.doCrime(userId, crimeId);

      // Връщаме резултата директно от CrimeEngine
      // Той вече съдържа:
      // - success/fail/jail
      // - money/xp/loot
      // - cooldown
      // - influence промяна
      // - district реакция
      // - NPC реакция
      // - lastAction логове
      return res.json({
        ok: true,
        ...result
      });

    } catch (err) {
      console.error("Crime do error:", err);
      res.status(500).json({ ok: false, error: err.message });
    }
  }
};