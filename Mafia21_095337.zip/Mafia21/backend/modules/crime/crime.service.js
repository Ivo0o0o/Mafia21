const Crime = require('./crime.model');
const User = require('../user/user.model');
const InfluenceService = require('../influence/influence.service');
const DistrictEngine = require('../district/district.engine');
const NPC = require('../npc/npc.engine');

// VIP reward functions
const {
  addCrimeReward,
  addLootReward,
  getVipEffects
} = require('../playerState/playerState.engine');

module.exports = {
  // Взима всички престъпления
  getAll: async () => {
    return await Crime.find({});
  },

  // Основна Crime логика
  doCrime: async (userId, crimeId) => {
    const crime = await Crime.findById(crimeId);
    if (!crime) throw new Error('Crime not found');

    const user = await User.findById(userId);
    if (!user) throw new Error('User not found');

    const vip = await getVipEffects(userId);

    // LEVEL CHECK
    if (user.level < crime.minLevel) {
      return { success: false, message: 'Level too low' };
    }

    // COOLDOWN CHECK
    let cooldownMs = crime.cooldown * 1000;
    if (vip?.cooldownBoost) cooldownMs = Math.floor(cooldownMs * vip.cooldownBoost);

    if (user.crimeCooldown && user.crimeCooldown > Date.now()) {
      const remaining = Math.floor((user.crimeCooldown - Date.now()) / 1000);
      return { success: false, message: `Cooldown: ${remaining}s remaining` };
    }

    // SUCCESS / FAIL / JAIL ROLLS
    const successRoll = Math.random() * 100;
    const jailRoll = Math.random() * 100;

    // JAIL LOGIC
    const jailChance = crime.jailChance + crime.risk * 0.2; // риск увеличава шанс за арест

    if (jailRoll <= jailChance) {
      user.jailUntil = Date.now() + 60000; // 60 sec jail
      user.crimeCooldown = Date.now() + cooldownMs;
      await user.save();

      // NPC реакция
      await NPC.onCrimeJail(userId, crime.districtName, crime);

      // District реакция
      await DistrictEngine.onCrimeJail(crime.districtName);

      return { success: false, jail: true, message: 'You got caught!' };
    }

    // SUCCESS LOGIC
    const successChance = crime.successChance - crime.risk * 0.3; // риск намалява шанс за успех

    if (successRoll <= successChance) {
      // MONEY REWARD
      const baseMoney = Math.floor(
        Math.random() * (crime.rewardMax - crime.rewardMin) + crime.rewardMin
      );

      // XP REWARD
      const baseXP = Math.floor(
        Math.random() * (crime.xpMax - crime.xpMin) + crime.xpMin
      );

      // LOOT
      const baseLoot = crime.loot || [];

      // VIP BOOST
      const boosted = await addCrimeReward(userId, baseMoney, baseXP);
      const finalLoot = await addLootReward(userId, baseLoot);

      // APPLY COOLDOWN
      user.crimeCooldown = Date.now() + cooldownMs;
      await user.save();

      // Influence промяна
      await InfluenceService.changeInfluence({
        userId,
        districtName: crime.districtName,
        delta: Math.floor(crime.risk / 10), // риск → влияние
        lastAction: `crime:${crime.name}`
      });

      // District реакция
      await DistrictEngine.onCrimeSuccess(crime.districtName, crime.risk);

      // NPC реакция
      await NPC.onCrimeSuccess(userId, crime.districtName, crime);

      return {
        success: true,
        reward: {
          money: boosted.money,
          xp: boosted.xp,
          loot: finalLoot
        },
        cooldown: Math.floor(cooldownMs / 1000)
      };
    }

    // FAIL LOGIC
    user.crimeCooldown = Date.now() + cooldownMs;
    await user.save();

    // Influence намалява при провал
    await InfluenceService.changeInfluence({
        userId,
        districtName: crime.districtName,
        delta: -Math.floor(crime.risk / 20),
        lastAction: `crime_fail:${crime.name}`
    });

    // District реакция
    await DistrictEngine.onCrimeFail(crime.districtName);

    // NPC реакция
    await NPC.onCrimeFail(userId, crime.districtName, crime);

    return {
      success: false,
      message: 'Crime failed',
      cooldown: Math.floor(cooldownMs / 1000)
    };
  }
};