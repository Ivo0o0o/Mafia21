const router = require('express').Router();
const CrimeController = require('./crime.controller');
const auth = require('../../core/auth');

// =========================
// PUBLIC ROUTES
// =========================

// Списък с всички престъпления
router.get('/list', CrimeController.list);

// Извършване на престъпление
router.post('/do/:id', auth, CrimeController.do);

// Взимане на конкретно престъпление
router.get('/:id', CrimeController.getOne);

// =========================
// ADMIN ROUTES
// =========================

// Създаване на престъпление
router.post('/create', auth, (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Само админ може да създава престъпления' });
  }
  next();
}, CrimeController.create);

// Редакция на престъпление
router.put('/edit/:id', auth, (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Само админ може да редактира престъпления' });
  }
  next();
}, CrimeController.edit);

// Изтриване на престъпление
router.delete('/delete/:id', auth, (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Само админ може да изтрива престъпления' });
  }
  next();
}, CrimeController.delete);

// =========================
// EXTRA ROUTES
// =========================

// Проверка на cooldown
router.get('/cooldown/:id', auth, CrimeController.cooldown);

// Статистика за престъпления
router.get('/stats/all', auth, CrimeController.stats);

module.exports = router;