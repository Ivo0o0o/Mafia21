const mongoose = require('mongoose');

const CrimeSchema = new mongoose.Schema({
  // Име на престъплението
  name: { type: String, required: true },

  // Описание за UI / GOD панел
  description: { type: String, required: true },

  // Минимално ниво на играча
  minLevel: { type: Number, default: 1 },

  // Награда в пари
  rewardMin: { type: Number, default: 10 },
  rewardMax: { type: Number, default: 100 },

  // Награда XP
  xpMin: { type: Number, default: 5 },
  xpMax: { type: Number, default: 50 },

  // Базов шанс за успех (%)
  successChance: { type: Number, default: 70 },

  // Базов шанс за арест (%)
  jailChance: { type: Number, default: 10 },

  // Риск (0–100) — влияе на NPC и Influence
  risk: { type: Number, default: 20 },

  // Кулдаун в секунди
  cooldown: { type: Number, default: 30 },

  // Район — за DistrictEngine и Influence
  districtName: { type: String, required: true },

  // Последна промяна (GOD логове)
  lastAction: { type: String, default: "" }
}, { timestamps: true });

module.exports = mongoose.model('Crime', CrimeSchema);