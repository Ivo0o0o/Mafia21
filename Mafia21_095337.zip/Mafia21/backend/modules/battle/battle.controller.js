const BattleEngine = require("./battle.engine");

module.exports = {
  async start(req, res) {
    try {
      const { userId, enemyId } = req.body;

      if (!userId || !enemyId) {
        return res.status(400).json({
          success: false,
          error: "Missing parameters"
        });
      }

      const result = await BattleEngine.startBattle(userId, enemyId);

      res.json(result);

    } catch (err) {
      res.status(500).json({
        success: false,
        error: err.message
      });
    }
  }
};