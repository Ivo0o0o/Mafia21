const router = require("express").Router();
const BattleController = require("./battle.controller");
const auth = require("../core/auth"); // FIXED PATH

// Start battle
router.post("/start", auth, BattleController.start);

// Debug / Health check
router.get("/status", (req, res) => {
  res.json({
    success: true,
    message: "Battle module is active"
  });
});

module.exports = router;