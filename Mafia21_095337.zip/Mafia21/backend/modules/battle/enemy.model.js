const mongoose = require('mongoose');

const EnemySchema = new mongoose.Schema({
  name: { type: String, required: true },

  // Combat stats
  damage: { type: Number, required: true },
  defense: { type: Number, required: true },

  // Rewards
  rewardMoney: { type: Number, default: 0 },
  rewardXP: { type: Number, default: 10 },
  loot: { type: Array, default: [] },

  // Cooldown after battle
  cooldown: { type: Number, default: 10 }, // seconds

  // Difficulty (optional)
  difficulty: { type: Number, default: 1 }
});

module.exports = mongoose.model('Enemy', EnemySchema);