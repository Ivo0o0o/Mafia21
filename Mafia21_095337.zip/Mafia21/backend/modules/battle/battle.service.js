const User = require("../player/player.model");
const Enemy = require("./enemy.model");

const {
  addCrimeReward,
  addLootReward,
  getVipEffects
} = require("../player/playerState.engine");

module.exports = {
  async startBattle(userId, enemyId) {
    try {
      const user = await User.findById(userId);
      if (!user) {
        return { success: false, error: "Player not found" };
      }

      const enemy = await Enemy.findById(enemyId);
      if (!enemy) {
        return { success: false, error: "Enemy not found" };
      }

      // VIP effects
      const vip = await getVipEffects(userId);

      // Base stats
      let userDamage = user.damage || 0;
      let userDefense = user.defense || 0;

      // VIP boosts
      if (vip?.battleDamageBoost) {
        userDamage = Math.floor(userDamage * vip.battleDamageBoost);
      }

      if (vip?.battleDefenseBoost) {
        userDefense = Math.floor(userDefense * vip.battleDefenseBoost);
      }

      // Cooldown
      let cooldownMs = (enemy.cooldown || 5) * 1000;

      if (vip?.cooldownBoost) {
        cooldownMs = Math.floor(cooldownMs * vip.cooldownBoost);
      }

      // Check cooldown
      if (user.battleCooldown && user.battleCooldown > Date.now()) {
        const remaining = Math.floor((user.battleCooldown - Date.now()) / 1000);
        return {
          success: false,
          message: `Cooldown: ${remaining}s remaining`
        };
      }

      // Battle roll
      const userPower = userDamage + userDefense;
      const enemyPower = (enemy.damage || 0) + (enemy.defense || 0);

      const success = userPower >= enemyPower;

      // Apply cooldown
      user.battleCooldown = Date.now() + cooldownMs;

      // If win
      if (success) {
        const baseMoney = enemy.rewardMoney || 0;
        const baseXP = enemy.rewardXP || 10;
        const baseLoot = enemy.loot || [];

        // VIP Money + XP boost
        const boosted = await addCrimeReward(userId, baseMoney, baseXP);

        // VIP Loot boost
        const finalLoot = await addLootReward(userId, baseLoot);

        await user.save();

        return {
          success: true,
          reward: {
            money: boosted.money,
            xp: boosted.xp,
            loot: finalLoot
          },
          cooldown: Math.floor(cooldownMs / 1000)
        };
      }

      // If lose
      await user.save();

      return {
        success: false,
        message: "You lost the battle",
        cooldown: Math.floor(cooldownMs / 1000)
      };

    } catch (err) {
      return {
        success: false,
        error: err.message
      };
    }
  }
};