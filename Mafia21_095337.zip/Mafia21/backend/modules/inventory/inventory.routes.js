const router = require("express").Router();
const InventoryController = require("./inventory.controller");

// ======================================================
// MAIN INVENTORY
// ======================================================
router.get("/get/:ownerId", InventoryController.getInventory);
router.post("/add", InventoryController.addItem);
router.post("/remove", InventoryController.removeItem);

// ======================================================
// EQUIPMENT
// ======================================================
router.post("/equip", InventoryController.equipItem);
router.post("/unequip", InventoryController.unequipItem);

// ======================================================
// WEIGHT SYSTEM
// ======================================================
router.get("/weight/:ownerId", InventoryController.getWeight);
router.post("/weight/update/:ownerId", InventoryController.updateWeight);

// ======================================================
// STASH
// ======================================================
router.post("/stash/add", InventoryController.addToStash);
router.post("/stash/remove", InventoryController.removeFromStash);

// ======================================================
// ORGANIZATION STASH
// ======================================================
router.post("/orgstash/add", InventoryController.addToOrgStash);
router.post("/orgstash/remove", InventoryController.removeFromOrgStash);

// ======================================================
// CLEAR INVENTORY
// ======================================================
router.post("/clear/:ownerId", InventoryController.clearInventory);

module.exports = router;