const InventoryService = require('./inventory.service');
const Item = require('../items/item.model');

module.exports = {

  // ======================================================
  // CALCULATE MAX WEIGHT BASED ON PLAYER LEVEL
  // ======================================================
  getMaxWeight(player) {
    // Примерна формула: базово 50 + 5 на ниво
    return 50 + (player.level * 5);
  },

  // ======================================================
  // CAN PLAYER CARRY ITEM?
  // ======================================================
  async canCarry(player, itemId, quantity = 1) {
    const item = await Item.findById(itemId);
    if (!item) return false;

    const currentWeight = await InventoryService.getTotalWeight(player._id);
    const maxWeight = this.getMaxWeight(player);

    const itemWeight = item.weight * quantity;

    return (currentWeight + itemWeight) <= maxWeight;
  },

  // ======================================================
  // AUTO-UPDATE CURRENT WEIGHT
  // ======================================================
  async updateWeight(ownerId) {
    const inv = await InventoryService.getInventory(ownerId);
    if (!inv) return null;

    let total = 0;

    for (const slot of inv.items) {
      total += slot.item.weight * slot.quantity;
    }

    inv.currentWeight = total;
    await inv.save();

    return total;
  },

  // ======================================================
  // EQUIPMENT SYSTEM (slots)
  // ======================================================
  async equip(ownerId, itemId, slot) {
    const inv = await InventoryService.getInventory(ownerId);
    if (!inv) return null;

    const itemSlot = inv.items.find(i => i.item._id.toString() === itemId);
    if (!itemSlot) return false;

    // Unequip all items in this slot
    inv.items.forEach(i => {
      if (i.slot === slot) {
        i.equipped = false;
        i.slot = null;
      }
    });

    // Equip new item
    itemSlot.equipped = true;
    itemSlot.slot = slot;

    await inv.save();
    return inv;
  },

  async unequip(ownerId, itemId) {
    const inv = await InventoryService.getInventory(ownerId);
    if (!inv) return null;

    const itemSlot = inv.items.find(i => i.item._id.toString() === itemId);
    if (!itemSlot) return false;

    itemSlot.equipped = false;
    itemSlot.slot = null;

    await inv.save();
    return inv;
  },

  // ======================================================
  // STASH SYSTEM (player home storage)
  // ======================================================
  async stashAdd(ownerId, itemId, quantity = 1) {
    return await InventoryService.addToStash(ownerId, itemId, quantity);
  },

  async stashRemove(ownerId, itemId, quantity = 1) {
    return await InventoryService.removeFromStash(ownerId, itemId, quantity);
  },

  // ======================================================
  // ORGANIZATION STASH SYSTEM
  // ======================================================
  async orgStashAdd(ownerId, itemId, quantity = 1) {
    return await InventoryService.addToOrgStash(ownerId, itemId, quantity);
  },

  async orgStashRemove(ownerId, itemId, quantity = 1) {
    return await InventoryService.removeFromOrgStash(ownerId, itemId, quantity);
  },

  // ======================================================
  // CHECK IF ITEM CAN BE EQUIPPED (weapon/armor/tools)
  // ======================================================
  canEquip(item) {
    const allowedTypes = ['weapon', 'armor', 'tool'];
    return allowedTypes.includes(item.type);
  },

  // ======================================================
  // CHECK IF ITEM IS OVER STACK LIMIT
  // ======================================================
  isOverStack(item, quantity) {
    if (!item.stackable) return quantity > 1;
    return quantity > item.maxStack;
  }
};