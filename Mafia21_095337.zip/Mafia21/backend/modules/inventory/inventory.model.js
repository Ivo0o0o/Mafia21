const mongoose = require("mongoose");

// ======================================================
// SINGLE INVENTORY ITEM
// ======================================================
const inventoryItemSchema = new mongoose.Schema({
  item: { type: mongoose.Schema.Types.ObjectId, ref: "Item", required: true },
  quantity: { type: Number, default: 1 },

  // Combat / equipment
  equipped: { type: Boolean, default: false },
  slot: { type: Number, default: null } // weapon slot, armor slot, etc.
}, { _id: false });

// ======================================================
// MAIN INVENTORY MODEL
// ======================================================
const inventorySchema = new mongoose.Schema({

  // Owner: User, NPC, Organization
  ownerId: { type: mongoose.Schema.Types.ObjectId, required: true },

  // Main inventory
  items: {
    type: [inventoryItemSchema],
    default: []
  },

  // Player stash (home storage)
  stash: {
    type: [inventoryItemSchema],
    default: []
  },

  // Organization stash (shared storage)
  orgStash: {
    type: [inventoryItemSchema],
    default: []
  },

  // Weight system
  maxWeight: { type: Number, default: 50 },
  currentWeight: { type: Number, default: 0 }

}, { timestamps: true });

module.exports = mongoose.model("Inventory", inventorySchema);