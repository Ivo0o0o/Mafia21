const InventoryService = require("./inventory.service");
const InventoryEngine = require("./inventory.engine");

module.exports = {

  // ======================================================
  // GET FULL INVENTORY
  // ======================================================
  async getInventory(req, res) {
    try {
      const ownerId = req.params.ownerId || req.user.id;

      const inv = await InventoryService.getInventory(ownerId);
      if (!inv) return res.status(404).json({ error: "Inventory not found" });

      res.json({ success: true, inventory: inv });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // ADD ITEM
  // ======================================================
  async addItem(req, res) {
    try {
      const ownerId = req.user.id;
      const { itemId, quantity } = req.body;

      const inv = await InventoryService.addItem(ownerId, itemId, quantity);
      if (!inv) return res.status(400).json({ error: "Cannot add item" });

      await InventoryEngine.updateWeight(ownerId);

      res.json({ success: true, inventory: inv });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // REMOVE ITEM
  // ======================================================
  async removeItem(req, res) {
    try {
      const ownerId = req.user.id;
      const { itemId, quantity } = req.body;

      const inv = await InventoryService.removeItem(ownerId, itemId, quantity);
      if (!inv) return res.status(400).json({ error: "Cannot remove item" });

      await InventoryEngine.updateWeight(ownerId);

      res.json({ success: true, inventory: inv });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // EQUIP ITEM
  // ======================================================
  async equipItem(req, res) {
    try {
      const ownerId = req.user.id;
      const { itemId, slot } = req.body;

      const inv = await InventoryEngine.equip(ownerId, itemId, slot);
      if (!inv) return res.status(400).json({ error: "Cannot equip item" });

      res.json({ success: true, inventory: inv });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // UNEQUIP ITEM
  // ======================================================
  async unequipItem(req, res) {
    try {
      const ownerId = req.user.id;
      const { itemId } = req.body;

      const inv = await InventoryEngine.unequip(ownerId, itemId);
      if (!inv) return res.status(400).json({ error: "Cannot unequip item" });

      res.json({ success: true, inventory: inv });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // GET WEIGHT
  // ======================================================
  async getWeight(req, res) {
    try {
      const ownerId = req.params.ownerId || req.user.id;

      const weight = await InventoryService.getTotalWeight(ownerId);
      res.json({ success: true, weight });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // UPDATE WEIGHT
  // ======================================================
  async updateWeight(req, res) {
    try {
      const ownerId = req.params.ownerId || req.user.id;

      const weight = await InventoryEngine.updateWeight(ownerId);
      res.json({ success: true, weight });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // STASH
  // ======================================================
  async addToStash(req, res) {
    try {
      const ownerId = req.user.id;
      const { itemId, quantity } = req.body;

      const inv = await InventoryService.addToStash(ownerId, itemId, quantity);
      res.json({ success: true, inventory: inv });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  async removeFromStash(req, res) {
    try {
      const ownerId = req.user.id;
      const { itemId, quantity } = req.body;

      const inv = await InventoryService.removeFromStash(ownerId, itemId, quantity);
      res.json({ success: true, inventory: inv });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // ORGANIZATION STASH
  // ======================================================
  async addToOrgStash(req, res) {
    try {
      const ownerId = req.user.id;
      const { itemId, quantity } = req.body;

      const inv = await InventoryService.addToOrgStash(ownerId, itemId, quantity);
      res.json({ success: true, inventory: inv });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  async removeFromOrgStash(req, res) {
    try {
      const ownerId = req.user.id;
      const { itemId, quantity } = req.body;

      const inv = await InventoryService.removeFromOrgStash(ownerId, itemId, quantity);
      res.json({ success: true, inventory: inv });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // ======================================================
  // CLEAR INVENTORY
  // ======================================================
  async clearInventory(req, res) {
    try {
      const ownerId = req.params.ownerId || req.user.id;

      const result = await InventoryService.clearInventory(ownerId);
      res.json({ success: true, cleared: result });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};