const Inventory = require('./inventory.model');
const Item = require('../items/item.model');

module.exports = {

  // ======================================================
  // GET INVENTORY BY OWNER
  // ======================================================
  async getInventory(ownerId) {
    return await Inventory.findOne({ ownerId })
      .populate('items.item')
      .populate('stash.item')
      .populate('orgStash.item');
  },

  // ======================================================
  // CREATE INVENTORY (при нов User/NPC/Org)
  // ======================================================
  async createInventory(ownerId) {
    return await Inventory.create({ ownerId });
  },

  // ======================================================
  // ADD ITEM TO INVENTORY
  // ======================================================
  async addItem(ownerId, itemId, quantity = 1) {
    let inv = await Inventory.findOne({ ownerId });
    if (!inv) inv = await this.createInventory(ownerId);

    const item = await Item.findById(itemId);
    if (!item) return null;

    // Проверка за stackable
    let existing = inv.items.find(i => i.item.toString() === itemId);

    if (existing) {
      if (!item.stackable) return false;

      existing.quantity += quantity;

      if (existing.quantity > item.maxStack) {
        existing.quantity = item.maxStack;
      }
    } else {
      inv.items.push({
        item: itemId,
        quantity: item.stackable ? quantity : 1
      });
    }

    await inv.save();
    return inv;
  },

  // ======================================================
  // REMOVE ITEM FROM INVENTORY
  // ======================================================
  async removeItem(ownerId, itemId, quantity = 1) {
    const inv = await Inventory.findOne({ ownerId });
    if (!inv) return null;

    const existing = inv.items.find(i => i.item.toString() === itemId);
    if (!existing) return false;

    existing.quantity -= quantity;

    if (existing.quantity <= 0) {
      inv.items = inv.items.filter(i => i.item.toString() !== itemId);
    }

    await inv.save();
    return inv;
  },

  // ======================================================
  // EQUIP ITEM
  // ======================================================
  async equipItem(ownerId, itemId, slot) {
    const inv = await Inventory.findOne({ ownerId });
    if (!inv) return null;

    const existing = inv.items.find(i => i.item.toString() === itemId);
    if (!existing) return false;

    existing.equipped = true;
    existing.slot = slot;

    await inv.save();
    return inv;
  },

  // ======================================================
  // UNEQUIP ITEM
  // ======================================================
  async unequipItem(ownerId, itemId) {
    const inv = await Inventory.findOne({ ownerId });
    if (!inv) return null;

    const existing = inv.items.find(i => i.item.toString() === itemId);
    if (!existing) return false;

    existing.equipped = false;
    existing.slot = null;

    await inv.save();
    return inv;
  },

  // ======================================================
  // GET TOTAL WEIGHT
  // ======================================================
  async getTotalWeight(ownerId) {
    const inv = await Inventory.findOne({ ownerId }).populate('items.item');
    if (!inv) return 0;

    let total = 0;

    for (const slot of inv.items) {
      total += slot.item.weight * slot.quantity;
    }

    return total;
  },

  // ======================================================
  // CLEAR INVENTORY
  // ======================================================
  async clearInventory(ownerId) {
    const inv = await Inventory.findOne({ ownerId });
    if (!inv) return null;

    inv.items = [];
    await inv.save();

    return true;
  },

  // ======================================================
  // STASH MANAGEMENT
  // ======================================================
  async addToStash(ownerId, itemId, quantity = 1) {
    const inv = await Inventory.findOne({ ownerId });
    if (!inv) return null;

    let existing = inv.stash.find(i => i.item.toString() === itemId);

    if (existing) {
      existing.quantity += quantity;
    } else {
      inv.stash.push({ item: itemId, quantity });
    }

    await inv.save();
    return inv;
  },

  async removeFromStash(ownerId, itemId, quantity = 1) {
    const inv = await Inventory.findOne({ ownerId });
    if (!inv) return null;

    let existing = inv.stash.find(i => i.item.toString() === itemId);
    if (!existing) return false;

    existing.quantity -= quantity;

    if (existing.quantity <= 0) {
      inv.stash = inv.stash.filter(i => i.item.toString() !== itemId);
    }

    await inv.save();
    return inv;
  },

  // ======================================================
  // ORG STASH MANAGEMENT
  // ======================================================
  async addToOrgStash(ownerId, itemId, quantity = 1) {
    const inv = await Inventory.findOne({ ownerId });
    if (!inv) return null;

    let existing = inv.orgStash.find(i => i.item.toString() === itemId);

    if (existing) {
      existing.quantity += quantity;
    } else {
      inv.orgStash.push({ item: itemId, quantity });
    }

    await inv.save();
    return inv;
  },

  async removeFromOrgStash(ownerId, itemId, quantity = 1) {
    const inv = await Inventory.findOne({ ownerId });
    if (!inv) return null;

    let existing = inv.orgStash.find(i => i.item.toString() === itemId);
    if (!existing) return false;

    existing.quantity -= quantity;

    if (existing.quantity <= 0) {
      inv.orgStash = inv.orgStash.filter(i => i.item.toString() !== itemId);
    }

    await inv.save();
    return inv;
  }
};