// backend/modules/player.model.js
const mongoose = require("mongoose");

const PlayerSchema = new mongoose.Schema({
  name: { type: String, default: "Unnamed" },

  // CORE STATS
  hp: { type: Number, default: 100 },
  maxHp: { type: Number, default: 100 },

  energy: { type: Number, default: 100 },
  maxEnergy: { type: Number, default: 100 },

  xp: { type: Number, default: 0 },
  level: { type: Number, default: 1 },

  money: { type: Number, default: 0 },

  // POSITION
  x: { type: Number, default: 0 },
  y: { type: Number, default: 0 },

  // INVENTORY (за Модул 37+)
  inventory: { type: Array, default: [] },

  // ACTIVE MISSIONS (за Модул 36+)
  missions: { type: Array, default: [] },

  // TIMERS (за dayTick / nightTick)
  lastDayTick: { type: Number, default: 0 },
  lastNightTick: { type: Number, default: 0 }
});

module.exports = mongoose.model("Player", PlayerSchema);