const express = require("express");
const router = express.Router();
const engine = require("./levelEngine");
const auth = require("../../src/middleware/authMiddleware");

router.post("/addXP", auth, async (req, res) => {
  const { userId, amount } = req.body;
  const user = await engine.addXP(userId, amount);
  res.json(user);
});

router.post("/setLevel", auth, async (req, res) => {
  const { userId, level } = req.body;
  const user = await engine.setLevel(userId, level);
  res.json(user);
});

router.post("/setXP", auth, async (req, res) => {
  const { userId, xp } = req.body;
  const user = await engine.setXP(userId, xp);
  res.json(user);
});

module.exports = router;