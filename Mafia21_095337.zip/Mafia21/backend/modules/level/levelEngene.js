const User = require("../../src/models/User");

module.exports = {
  addXP: async (userId, amount) => {
    const user = await User.findById(userId);
    if (!user) throw new Error("User not found");

    user.xp += amount;

    // Level up logic
    const needed = user.level * 100; // пример: всяко ниво = 100 * level XP

    if (user.xp >= needed) {
      user.level++;
      user.points += 5; // точки за ниво
      user.xp -= needed;
    }

    await user.save();
    return user;
  },

  setLevel: async (userId, level) => {
    const user = await User.findById(userId);
    user.level = level;
    await user.save();
    return user;
  },

  setXP: async (userId, xp) => {
    const user = await User.findById(userId);
    user.xp = xp;
    await user.save();
    return user;
  }
};