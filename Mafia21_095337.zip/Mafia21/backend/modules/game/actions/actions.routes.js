const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./actions.engine");

// START MISSION
router.post("/startMission", godAccess, async (req, res) => {
  const { playerId, mission } = req.body;
  res.json(await engine.startMission(playerId, mission));
});

// DAY TICK
router.post("/dayTick", godAccess, async (req, res) => {
  res.json(await engine.dayTick());
});

// NIGHT TICK
router.post("/nightTick", godAccess, async (req, res) => {
  res.json(await engine.nightTick());
});

// REFRESH PLAYER STATE
router.get("/refresh/:playerId", godAccess, async (req, res) => {
  res.json(await engine.refreshState(req.params.playerId));
});

module.exports = router;