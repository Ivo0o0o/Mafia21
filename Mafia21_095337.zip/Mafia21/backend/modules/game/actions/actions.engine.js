const missionEngine = require("../../npc/missionEngine/mission.engine");
const sessionEngine = require("../session/session.engine");
const playerStateEngine = require("../playerState/playerState.engine");

async function startMission(playerId, mission) {
  return await missionEngine.runMission(mission, playerId);
}

async function dayTick() {
  return await sessionEngine.dayTick();
}

async function nightTick() {
  return await sessionEngine.nightTick();
}

async function refreshState(playerId) {
  return await playerStateEngine.getPlayerState(playerId);
}

module.exports = {
  startMission,
  dayTick,
  nightTick,
  refreshState
};