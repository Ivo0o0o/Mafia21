const GameSession = require("./session.model");
const { v4: uuidv4 } = require("uuid");

const overseerEngine = require("../../npc/overseer/overseer.engine");
const missionEngine = require("../../npc/missionEngine/mission.engine");
const rankEngine = require("../../player/progression/rank.engine");
const economyEngine = require("../../player/economy/economy.engine");
const prisonEngine = require("../../player/prison/prison.engine");

// 1. Вземи или създай сесия
async function getSession(playerId) {
  let s = await GameSession.findOne({ playerId, state: { $ne: "ended" } });
  if (!s) {
    s = await GameSession.create({
      playerId,
      sessionId: uuidv4(),
      state: "day",
      dayCount: 1
    });
  }
  return s;
}

// 2. Game Tick – един „ден“ в света
async function gameDayTick(playerId) {
  const s = await getSession(playerId);

  s.state = "day";
  s.dayCount += 1;
  s.lastTick = new Date();
  await s.save();

  // 1) Overseer
  const overseerResult = await overseerEngine.overseerTick();

  // 2) Mission suggestion → мисия
  const suggestion = overseerResult.action;
  let mission = null;
  if (suggestion && suggestion.type !== "none" && !suggestion.rejectedByRule1) {
    mission = await missionEngine.createMissionFromSuggestion(suggestion);
  }

  // 3) Player progression
  const rank = await rankEngine.progressionTick(playerId);

  // 4) Economy tick
  const eco = await economyEngine.economyTick(playerId);

  // 5) Prison tick
  const prison = await prisonEngine.prisonTick(playerId);

  return {
    session: s,
    overseer: overseerResult,
    mission,
    rank,
    economy: eco,
    prison
  };
}

// 3. Night Tick – „нощен“ цикъл
async function gameNightTick(playerId) {
  const s = await getSession(playerId);

  s.state = "night";
  s.lastTick = new Date();
  await s.save();

  // нощта може да бъде по-опасна, но тук само маркираме
  const overseerResult = await overseerEngine.overseerTick();
  const prison = await prisonEngine.prisonTick(playerId);

  return {
    session: s,
    overseer: overseerResult,
    prison
  };
}

// 4. End Session
async function endSession(playerId) {
  const s = await getSession(playerId);
  s.state = "ended";
  await s.save();
  return s;
}

module.exports = {
  getSession,
  gameDayTick,
  gameNightTick,
  endSession
};