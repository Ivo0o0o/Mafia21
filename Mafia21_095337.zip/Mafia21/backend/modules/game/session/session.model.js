const mongoose = require("mongoose");

const sessionSchema = new mongoose.Schema({
  playerId: { type: String, required: true },

  sessionId: { type: String, required: true },
  state: {
    type: String,
    enum: ["idle", "day", "night", "paused", "ended"],
    default: "idle"
  },

  dayCount: { type: Number, default: 0 },
  lastTick: { type: Date, default: Date.now },

  flags: {
    tutorialDone: { type: Boolean, default: false },
    firstArrest: { type: Boolean, default: false },
    firstTerritory: { type: Boolean, default: false }
  }

}, { timestamps: true });

module.exports = mongoose.model("GameSession", sessionSchema);