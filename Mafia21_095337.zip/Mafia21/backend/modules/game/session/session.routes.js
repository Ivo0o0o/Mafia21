const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./session.engine");

// GOD: view session
router.get("/:playerId", godAccess, async (req, res) => {
  res.json(await engine.getSession(req.params.playerId));
});

// GOD: day tick
router.post("/dayTick", godAccess, async (req, res) => {
  res.json(await engine.gameDayTick(req.body.playerId));
});

// GOD: night tick
router.post("/nightTick", godAccess, async (req, res) => {
  res.json(await engine.gameNightTick(req.body.playerId));
});

// GOD: end session
router.post("/end", godAccess, async (req, res) => {
  res.json(await engine.endSession(req.body.playerId));
});

module.exports = router;