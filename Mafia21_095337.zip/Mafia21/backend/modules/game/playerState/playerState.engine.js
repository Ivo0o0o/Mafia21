const rankEngine = require("../../player/progression/rank.engine");
const economyEngine = require("../../player/economy/economy.engine");
const territoryEngine = require("../../player/territory/territory.engine");
const prisonEngine = require("../../player/prison/prison.engine");
const courtEngine = require("../../player/justice/court.engine");
const sessionEngine = require("../session/session.engine");
const missionEngine = require("../../npc/missionEngine/mission.engine");
const overseerEngine = require("../../npc/overseer/overseer.engine");

// VIP
const VIP = require("../../vip/vip.model");
const effects = require("../../vip/vip.effects");
const User = require("../../../models/User");

// Взимаме VIP ефектите
async function getVipEffects(userId) {
  const vip = await VIP.findOne({ userId });
  if (!vip || !vip.level) return null;
  return effects[vip.level] || null;
}

// Даваме XP (с VIP boost)
async function addXP(userId, amount) {
  const user = await User.findById(userId);
  if (!user) return;

  const vip = await getVipEffects(userId);
  if (vip?.xpBoost) {
    amount = Math.floor(amount * vip.xpBoost);
  }

  user.xp = (user.xp || 0) + amount;
  await user.save();

  return user.xp;
}

// Даваме пари (с VIP money boost)
async function addMoney(userId, amount) {
  const user = await User.findById(userId);
  if (!user) return;

  const vip = await getVipEffects(userId);
  if (vip?.moneyBoost) {
    amount = Math.floor(amount * vip.moneyBoost);
  }

  user.money = (user.money || 0) + amount;
  await user.save();

  return user.money;
}

// Даваме награда от престъпление (VIP boost за XP + Money)
async function addCrimeReward(userId, money, xp) {
  const user = await User.findById(userId);
  if (!user) return;

  const vip = await getVipEffects(userId);

  // VIP boost за пари
  if (vip?.moneyBoost) {
    money = Math.floor(money * vip.moneyBoost);
  }

  // VIP boost за XP
  if (vip?.xpBoost) {
    xp = Math.floor(xp * vip.xpBoost);
  }

  user.money = (user.money || 0) + money;
  user.xp = (user.xp || 0) + xp;

  await user.save();

  return {
    money: user.money,
    xp: user.xp
  };
}

// агрегирано състояние на играча
async function getPlayerState(playerId) {
  const [rank, economy, territory, prison, session] = await Promise.all([
    rankEngine.getRank(playerId),
    economyEngine.getEconomy(playerId),
    territoryEngine.getTerritory(playerId),
    prisonEngine.getPrisonProfile(playerId),
    sessionEngine.getSession(playerId)
  ]);

  const court = await courtEngine.getCase(playerId);
  const missions = await missionEngine.listMissions();
  const overseer = await overseerEngine.overseerTick();

  return {
    playerId,
    rank,
    economy,
    territory,
    prison,
    court,
    session,
    missions,
    overseer,

    xp: rank.xp || 0,
    money: economy.money || 0
  };
}

module.exports = {
  getPlayerState,
  addXP,
  addMoney,
  addCrimeReward
};