const express = require("express");
const router = express.Router();
const { godAccess } = require("../../../src/middleware/godAccess");
const engine = require("./playerState.engine");

// GOD / FRONTEND: пълен player state
router.get("/:playerId", godAccess, async (req, res) => {
  res.json(await engine.getPlayerState(req.params.playerId));
});

module.exports = router;