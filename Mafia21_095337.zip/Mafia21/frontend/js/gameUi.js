// ===============================================
// MAFIA 21st CENTURY — GAME UI (FINAL PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Основен UI на играта — статуси, AI панел,
// sidebar, интеграция с всички нови модули.
// ===============================================

import { Utils } from "./utils.js";
import { HUD } from "./hud.js";

// UI MODULES
import { showCrimePanel } from "./crimeUI.js";
import { showPolicePanel } from "./policeUI.js";
import { showCityLifePanel } from "./cityLifeUI.js";
import { showBlackMarketPanel } from "./blackMarketUI.js";
import { showDistrictDangerPanel } from "./districtDangerUI.js";

import { showSkillsPanel } from "./skillsUI.js";
import { showMissionsPanel } from "./missionsUI.js";
import { showInfluencePanel } from "./influenceUI.js";
import { showNPCPanel } from "./npcUI.js";
import { showPlayerPanel } from "./playerUI.js";
import { showWorldEventsPanel } from "./worldEventsUI.js";
import { showDistrictPanel } from "./districtPanelUI.js";

// ⭐ NEW — HEAT UI
import { showHeatPanel } from "./heatUI.js";

// ===============================================
// ИНИЦИАЛИЗАЦИЯ НА GAME UI
// ===============================================

export function initGameUI(health, aiState) {
  const app = Utils.qs("#app");

  const ui = Utils.create("div", "panel");
  ui.innerHTML = `
    <h2>Мафия от 21ви век — Game UI</h2>

    <div class="info-box">
      <strong>Статус на сървъра:</strong>
      <span class="gta-text">${health.server}</span>
    </div>

    <div class="info-box">
      <strong>AI състояние:</strong><br>
      Емоция: <span style="color: var(--neon-purple)">${aiState.emotion}</span><br>
      Решение: <span style="color: var(--neon-pink)">${aiState.decision}</span><br>
      Интензитет: <span style="color: var(--mafia-gold)">${aiState.intensity}</span>
    </div>

    <button class="btn" id="refreshAI">Обнови AI</button>
  `;

  app.appendChild(ui);

  // Обновяване на AI
  Utils.qs("#refreshAI").addEventListener("click", () => {
    const newAI = Utils.npcBehaviorAI();
    Utils.neonFlash(ui, "#ff007c");

    ui.querySelector(".info-box:nth-child(2)").innerHTML = `
      <strong>AI състояние:</strong><br>
      Емоция: <span style="color: var(--neon-purple)">${newAI.emotion}</span><br>
      Решение: <span style="color: var(--neon-pink)">${newAI.decision}</span><br>
      Интензитет: <span style="color: var(--mafia-gold)">${newAI.intensity}</span>
    `;
  });

  Utils.log("Game UI зареден успешно.");
}

// ===============================================
// SIDEBAR — FINAL PRO VERSION
// ===============================================

export function initSidebar() {
  const sidebar = document.getElementById("sidebar");

  const openBtn = document.getElementById("sidebarOpen");
  const closeBtn = document.getElementById("sidebarClose");

  openBtn.addEventListener("click", () => sidebar.classList.add("open"));
  closeBtn.addEventListener("click", () => sidebar.classList.remove("open"));

  const modules = [
    ["btnCrime", showCrimePanel],
    ["btnPolice", showPolicePanel],
    ["btnCityLife", showCityLifePanel],
    ["btnBlackMarket", showBlackMarketPanel],
    ["btnDistrictDanger", showDistrictDangerPanel],
    ["btnSkills", showSkillsPanel],
    ["btnMissions", showMissionsPanel],
    ["btnInfluence", showInfluencePanel],
    ["btnNPC", showNPCPanel],
    ["btnPlayer", showPlayerPanel],
    ["btnWorldEvents", showWorldEventsPanel],
    ["btnDistrictPanel", showDistrictPanel],

    // ⭐ NEW — HEAT PANEL
    ["btnHeat", showHeatPanel]
  ];

  modules.forEach(([btnId, handler]) => {
    const btn = document.getElementById(btnId);
    if (btn) {
      btn.addEventListener("click", () => {
        handler();
        sidebar.classList.remove("open");
      });
    }
  });
}