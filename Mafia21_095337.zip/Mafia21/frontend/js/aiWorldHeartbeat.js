// ===============================================
// MAFIA 21st CENTURY — AI WORLD HEARTBEAT (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централен пулс на света: синхронизация на всички
// AI системи, ритъм, време, цикли, координация.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

export function initAIWorldHeartbeat() {
  Utils.log("AI World Heartbeat стартира…");

  const HeartbeatState = {
    beat: 0,
    worldTime: 0,
    dayCycle: "day",
    beatInterval: 2000, // 2 секунди
    modules: [
      "aiGameplayEngine",
      "aiWorldReactions",
      "aiEconomyEngine",
      "aiNPCPersonalities",
      "aiPoliceIntelligence",
      "aiDistrictEvolution",
      "aiWorldEventsEngine",
      "aiGlobalBalancer",
      "aiWorldOptimizer"
    ]
  };

  // ===============================================
  // MAIN HEARTBEAT LOOP
  // ===============================================
  setInterval(async () => {
    HeartbeatState.beat++;
    HeartbeatState.worldTime++;

    // ===============================================
    // DAY/NIGHT CYCLE
    // ===============================================
    if (HeartbeatState.worldTime % 30 === 0) {
      HeartbeatState.dayCycle =
        HeartbeatState.dayCycle === "day" ? "night" : "day";

      Utils.log(`HEARTBEAT: Светът преминава към ${HeartbeatState.dayCycle}.`);
      await ApiClient.updateWorldCycle(HeartbeatState.dayCycle);
    }

    // ===============================================
    // SYNCHRONIZE ALL AI MODULES
    // ===============================================
    await ApiClient.syncAIModules(HeartbeatState.modules);

    // ===============================================
    // WORLD PULSE EVENTS
    // ===============================================
    if (HeartbeatState.beat % 10 === 0) {
      Utils.log("HEARTBEAT: Световен пулс → малки динамични промени.");
      await ApiClient.worldPulse();
    }

    // ===============================================
    // NIGHT EFFECTS
    // ===============================================
    if (HeartbeatState.dayCycle === "night") {
      await ApiClient.applyNightEffects();
    }

    // ===============================================
    // DAY EFFECTS
    // ===============================================
    if (HeartbeatState.dayCycle === "day") {
      await ApiClient.applyDayEffects();
    }

    Utils.log(`HEARTBEAT: Beat=${HeartbeatState.beat}, Time=${HeartbeatState.worldTime}, Cycle=${HeartbeatState.dayCycle}`);

  }, HeartbeatState.beatInterval);

  Utils.log("AI World Heartbeat работи.");
}