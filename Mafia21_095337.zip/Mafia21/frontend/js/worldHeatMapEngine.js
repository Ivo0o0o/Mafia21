// ===============================================
// MAFIA 21st CENTURY — WORLD HEAT MAP ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Симулация на heat нива, престъпност,
// риск, опасни зони, прогнози, динамика.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { EventBus } from "./eventBus.js"; // ⭐ добавено

export const worldHeatMapEngine = {
  async simulate() {
    EventBus.emit("heatmap_sim_tick", {}); // ⭐

    try {
      const districts = await ApiClient.getDistricts();
      const heatLevels = await ApiClient.getHeatLevels();
      const events = await ApiClient.getWorldEvents();

      const result = {
        hottestDistrict: null,
        safestDistrict: null,
        averageHeat: 0,
        dangerZones: [],
        forecast: "",
        recommendation: ""
      };

      // Най-опасен район (heat + crime)
      result.hottestDistrict = districts
        .sort((a, b) => (b.heat + b.crime) - (a.heat + a.crime))[0]?.name;

      // Най-безопасен район
      result.safestDistrict = districts.sort((a, b) => a.heat - b.heat)[0]?.name;

      // Средно heat ниво
      result.averageHeat =
        heatLevels.reduce((sum, h) => sum + h.level, 0) / heatLevels.length;

      EventBus.emit("heatmap_update", {
        hottest: result.hottestDistrict,
        safest: result.safestDistrict,
        averageHeat: result.averageHeat
      }); // ⭐

      // Опасни зони
      result.dangerZones = districts
        .filter(d => d.heat > 70 || d.crime > 60)
        .map(d => d.name);

      EventBus.emit("heatmap_zone_risk", {
        zones: result.dangerZones
      }); // ⭐

      // Прогноза според събития
      const conflictEvents = events.filter(e =>
        ["gang_fight", "riot", "police_operation"].includes(e.type)
      );

      if (conflictEvents.length > 5) {
        result.forecast = "Очаква се рязко покачване на heat нивата.";
      } else if (conflictEvents.length > 0) {
        result.forecast = "Възможни са локални повишения на heat.";
      } else {
        result.forecast = "Heat нивата ще останат стабилни.";
      }

      EventBus.emit("heatmap_forecast", {
        forecast: result.forecast,
        conflictEvents
      }); // ⭐

      // Препоръка
      if (result.averageHeat > 70) {
        result.recommendation =
          "Избягвай опасните райони — рискът е много висок.";
      } else if (result.averageHeat > 40) {
        result.recommendation =
          "Планирай действията си внимателно — heat е нестабилен.";
      } else {
        result.recommendation =
          "Градът е спокоен — идеално време за операции.";
      }

      EventBus.emit("heatmap_recommendation", {
        recommendation: result.recommendation
      }); // ⭐

      Utils.log("World Heat Map Engine — симулация завършена.");
      return result;

    } catch (err) {
      console.error("❌ HeatMapEngine ERROR:", err);
      EventBus.emit("heatmap_error", { error: err }); // ⭐
    }
  }
};