// ===============================================
// MAFIA 21st CENTURY — NPC ENGINE (ULTIMATE VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централна NPC система:
// ✔ граждани, гангстери, търговци, информатори
// ✔ динамично поведение
// ✔ реакции към player
// ✔ реакции към world
// ✔ AI анализ от бекенд (npcAI.engine.js)
// ✔ синхронизация с WorldState
// ✔ синхронизация с PlayerStatsCore
// ===============================================

import { ApiClient } from "./apiClient.js";
import { PlayerStatsCore } from "./playerStatsCore.js";
import { WorldState } from "./worldState.js";
import { Utils } from "./utils.js";
import { EventBus } from "./eventBus.js"; // ⭐ добавено

export const NPCEngine = {
  npcs: [],
  interval: null,
  rate: 3000, // NPC са динамични

  async init() {
    Utils.log("NPCEngine — стартиране...");

    await this.loadNPCs();
    this.interval = setInterval(() => this.tick(), this.rate);

    Utils.log("NPCEngine — активен.");
  },

  // ---------------------------------------------
  // Зареждане на NPC от API
  // ---------------------------------------------
  async loadNPCs() {
    this.npcs = await ApiClient.getCitizens();
  },

  // ---------------------------------------------
  // Основен NPC tick
  // ---------------------------------------------
  async tick() {
    try {
      await this.applyBackendAI();
      await this.reactToPlayer();
      await this.reactToWorld();
      await this.syncToAPI();

      Utils.log("NPCEngine — tick завършен.");
    } catch (err) {
      console.error("❌ NPCEngine ERROR:", err);

      // ⭐ изпращаме събитие за грешка
      EventBus.emit("npc_error", { error: err });
    }
  },

  // ---------------------------------------------
  // AI анализ от бекенд (npcAI.engine.js)
  // ---------------------------------------------
  async applyBackendAI() {
    for (let npc of this.npcs) {
      const ai = await ApiClient.getNPCBehavior(npc._id);

      npc.emotion = ai.emotion;
      npc.intensity = ai.intensity;
      npc.action = ai.action;
      npc.hostility = ai.hostility;
      npc.fear = ai.fear;
      npc.suspicion = ai.suspicion;

      // ⭐ изпращаме събитие за AI обновяване
      EventBus.emit("npc_ai_updated", { npc });
    }
  },

  // ---------------------------------------------
  // Реакция към играча
  // ---------------------------------------------
  async reactToPlayer() {
    const player = PlayerStatsCore.get();

    this.npcs.forEach(npc => {
      if (player.reputation > 300) npc.respect = (npc.respect || 0) + 1;
      if (player.heat > 70) npc.fear = (npc.fear || 0) + 2;

      if (player.reputation > 600 && player.heat > 80) {
        npc.action = "avoid_player";
      }

      // ⭐ изпращаме събитие за реакция към играча
      EventBus.emit("npc_player_react", { npc, player });
    });
  },

  // ---------------------------------------------
  // Реакция към света
  // ---------------------------------------------
  async reactToWorld() {
    const world = WorldState.get();

    this.npcs.forEach(npc => {
      world.zones.forEach(zone => {
        if (zone.risk > 80 && npc.location === zone.name) {
          npc.action = "leave_zone";
        }
      });

      world.events.forEach(event => {
        if (event.type === "riot") npc.action = "panic";
        if (event.type === "police_operation") npc.action = "hide";
        if (event.type === "gang_fight") npc.action = "run";
      });

      // ⭐ изпращаме събитие за реакция към света
      EventBus.emit("npc_world_react", { npc, world });
    });
  },

  // ---------------------------------------------
  // Синхронизация към API
  // ---------------------------------------------
  async syncToAPI() {
    await ApiClient.updateCitizens(this.npcs);

    // ⭐ изпращаме събитие за обновяване на NPC
    EventBus.emit("npc_updated", this.npcs);
  },

  getNPCs() {
    return this.npcs;
  }
};

NPCEngine.init();