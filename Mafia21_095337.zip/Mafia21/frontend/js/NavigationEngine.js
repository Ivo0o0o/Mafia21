// ===============================================
// MAFIA 21st CENTURY — NAVIGATION ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzов 🍀🐬🪽☁️ 💶
// ===============================================
// Управлява:
// ✔ pathfinding (A* / flow fields)
// ✔ движение на NPC
// ✔ избягване на опасни зони
// ✔ динамични маршрути
// ✔ навигация според heat map
// ✔ навигация според събития
//
// Използва:
// ✔ WorldState
// ✔ EventBus
// ✔ Utils
// ✔ HeatMapEngine
// ===============================================

import { WorldState } from "./worldState.js";
import { EventBus } from "./eventBus.js";
import { Utils } from "./utils.js";

export const NavigationEngine = {
  grid: [],          // навигационна мрежа
  lastUpdate: Date.now(),

  init() {
    Utils.log("NavigationEngine — стартиране...");

    this.buildGrid();
    setInterval(() => this.update(), 1500);

    EventBus.on("world:updated", () => this.onWorldUpdate());
  },

  // ---------------------------------------------
  // СТРОИ НАВИГАЦИОННА МРЕЖА ОТ ЗОНИ
  // ---------------------------------------------
  buildGrid() {
    const zones = WorldState.data.zones;

    this.grid = zones.map(z => ({
      id: z.id,
      neighbors: z.neighbors || [],
      danger: 0,
      blocked: false
    }));

    Utils.log("NavigationEngine — grid готов.");
  },

  // ---------------------------------------------
  // UPDATE LOOP
  // ---------------------------------------------
  update() {
    const world = WorldState.get();

    this.updateDanger(world);
    this.updateBlocked(world);
    this.lastUpdate = Date.now();
  },

  // ---------------------------------------------
  // ОБНОВЯВА ОПАСНОСТТА НА ВСЯКА ЗОНА
  // ---------------------------------------------
  updateDanger(world) {
    world.heat.forEach(h => {
      const cell = this.grid.find(c => c.id === h.zoneId);
      if (!cell) return;

      cell.danger = h.level;
    });
  },

  // ---------------------------------------------
  // БЛОКИРАНИ ЗОНИ (пожари, престрелки, катастрофи)
  // ---------------------------------------------
  updateBlocked(world) {
    world.events.forEach(e => {
      if (e.type === "fire" || e.type === "shootout" || e.type === "crash") {
        const cell = this.grid.find(c => c.id === e.zone.id);
        if (cell) cell.blocked = true;
      }
    });
  },

  // ---------------------------------------------
  // ПЪТFINDING (A* simplified)
  // ---------------------------------------------
  findPath(startZoneId, endZoneId) {
    const open = [];
    const closed = new Set();

    const start = this.grid.find(c => c.id === startZoneId);
    const end = this.grid.find(c => c.id === endZoneId);

    if (!start || !end) return [];

    open.push({
      zone: start,
      cost: 0,
      path: [start.id]
    });

    while (open.length > 0) {
      open.sort((a, b) => a.cost - b.cost);
      const current = open.shift();

      if (current.zone.id === end.id) {
        return current.path;
      }

      closed.add(current.zone.id);

      current.zone.neighbors.forEach(nId => {
        if (closed.has(nId)) return;

        const neighbor = this.grid.find(c => c.id === nId);
        if (!neighbor || neighbor.blocked) return;

        const dangerPenalty = neighbor.danger / 10;
        const cost = current.cost + 1 + dangerPenalty;

        open.push({
          zone: neighbor,
          cost,
          path: [...current.path, neighbor.id]
        });
      });
    }

    return [];
  },

  // ---------------------------------------------
  // NPC ПОЛУЧАВА МАРШРУТ
  // ---------------------------------------------
  getRoute(npc, targetZoneId) {
    return this.findPath(npc.zone, targetZoneId);
  },

  // ---------------------------------------------
  // NPC РЕАГИРА НА ПРОМЕНИ В СВЕТА
  // ---------------------------------------------
  onWorldUpdate() {
    const world = WorldState.get();

    world.citizens.forEach(c => {
      const zoneHeat = world.heat.find(h => h.zoneId === c.zone);
      if (zoneHeat && zoneHeat.level > 70) {
        const safeZone = Utils.randomItem(
          world.zones.filter(z => {
            const h = world.heat.find(hh => hh.zoneId === z.id);
            return h && h.level < 30;
          })
        );

        if (safeZone) {
          c.target = safeZone.id;
          c.route = this.getRoute(c, safeZone.id);
        }
      }
    });
  }
};

// Автоматично стартиране
NavigationEngine.init();