// ===============================================
// MAFIA 21st CENTURY — WORLD SOUND ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// NPC шумове, полиция сирени, градски фон,
// ден/нощ ефекти, динамични звуци.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

export function initWorldSoundEngine() {
  Utils.log("World Sound Engine стартира…");

  const SoundState = {
    tick: 0,
    cycle: "day",
    crimeLevel: 0,
    npcActivity: 0,
    policeIntensity: 0,
    ambientVolume: 0.5,
    sounds: {
      ambientDay: new Audio("./sounds/ambient_day.mp3"),
      ambientNight: new Audio("./sounds/ambient_night.mp3"),
      policeSiren: new Audio("./sounds/police_siren.mp3"),
      npcCrowd: new Audio("./sounds/npc_crowd.mp3"),
      crimeAlert: new Audio("./sounds/crime_alert.mp3"),
      districtDanger: new Audio("./sounds/district_danger.mp3")
    }
  };

  // Loop ambient sounds
  SoundState.sounds.ambientDay.loop = true;
  SoundState.sounds.ambientNight.loop = true;
  SoundState.sounds.npcCrowd.loop = true;

  // ===============================================
  // MAIN SOUND LOOP
  // ===============================================
  setInterval(async () => {
    SoundState.tick++;

    const cycle = await ApiClient.getWorldCycle();
    const crime = await ApiClient.getCrimePulse();
    const npc = await ApiClient.getNPCActivity();
    const police = await ApiClient.getPoliceStatus();
    const districts = await ApiClient.getDistricts();

    SoundState.cycle = cycle;
    SoundState.crimeLevel = crime.level;
    SoundState.npcActivity = npc.activity;
    SoundState.policeIntensity = police.patrols;

    // ===============================================
    // AMBIENT DAY/NIGHT
    // ===============================================
    if (cycle === "day") {
      fadeIn(SoundState.sounds.ambientDay);
      fadeOut(SoundState.sounds.ambientNight);
    } else {
      fadeIn(SoundState.sounds.ambientNight);
      fadeOut(SoundState.sounds.ambientDay);
    }

    // ===============================================
    // NPC CROWD SOUND
    // ===============================================
    if (npc.activity > 50) {
      fadeIn(SoundState.sounds.npcCrowd);
    } else {
      fadeOut(SoundState.sounds.npcCrowd);
    }

    // ===============================================
    // POLICE SIRENS
    // ===============================================
    if (police.patrols > 4 || crime.level > 70) {
      playOnce(SoundState.sounds.policeSiren);
    }

    // ===============================================
    // CRIME ALERT
    // ===============================================
    if (crime.level > 80) {
      playOnce(SoundState.sounds.crimeAlert);
    }

    // ===============================================
    // DISTRICT DANGER SOUND
    // ===============================================
    const dangerousDistricts = districts.filter(d => d.danger > 70);
    if (dangerousDistricts.length > 0) {
      playOnce(SoundState.sounds.districtDanger);
    }

    Utils.log(`SOUND: Cycle=${cycle}, Crime=${crime.level}, NPC=${npc.activity}, Police=${police.patrols}`);

  }, 3000); // 3 секунди звук

  Utils.log("World Sound Engine работи.");
}

// ===============================================
// SOUND HELPERS
// ===============================================
function fadeIn(sound) {
  sound.volume = Math.min(1, sound.volume + 0.05);
  if (sound.paused) sound.play();
}

function fadeOut(sound) {
  sound.volume = Math.max(0, sound.volume - 0.05);
  if (sound.volume === 0 && !sound.paused) sound.pause();
}

function playOnce(sound) {
  sound.currentTime = 0;
  sound.play();
}