// ===============================================
// MAFIA 21st CENTURY — OPERATIONS AI CORE (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// AI анализ за мисии, операции, риск, екипи,
// награди, провал/успех, приоритизация.
// ===============================================

export const OperationsAICore = {
  operationsAI({ operations, teams }) {
    const totalOps = operations.length;
    const activeOps = operations.filter(o => o.status === "active").length;
    const failedOps = operations.filter(o => o.status === "failed").length;
    const successOps = operations.filter(o => o.status === "success").length;

    const riskScore =
      operations.reduce((sum, o) => sum + (o.risk || 0), 0) || 0;

    const avgRisk = totalOps ? (riskScore / totalOps).toFixed(1) : 0;

    const topRewardOp =
      operations
        .slice()
        .sort((a, b) => (b.reward || 0) - (a.reward || 0))[0] || null;

    const forecast =
      avgRisk > 7
        ? "Висок риск — препоръчва се ограничаване на активните операции."
        : avgRisk > 4
        ? "Умерен риск — възможни добри печалби при внимателен подбор."
        : "Нисък риск — подходящ момент за разширяване на операциите.";

    const recommendation =
      failedOps > successOps
        ? "Намали броя на паралелните мисии и подсили екипите."
        : "Запази текущия темп, но следи внимателно високорисковите операции.";

    return {
      totalOps,
      activeOps,
      failedOps,
      successOps,
      avgRisk,
      topRewardOpName: topRewardOp ? topRewardOp.name : "Няма",
      forecast,
      recommendation,
    };
  },

  operationAI(operation) {
    const risk = operation.risk || 0;
    const reward = operation.reward || 0;
    const duration = operation.duration || 0;

    let efficiency;
    if (!duration) {
      efficiency = "Неясна (липсва продължителност)";
    } else {
      const ratio = reward / duration;
      efficiency =
        ratio > 1000
          ? "Много висока"
          : ratio > 500
          ? "Висока"
          : ratio > 200
          ? "Средна"
          : "Ниска";
    }

    const recommendation =
      risk >= 8
        ? "Само най-силните екипи, с резервен план и готовност за оттегляне."
        : risk >= 5
        ? "Подходящо за добре балансиран екип с опит."
        : "Добра мисия за трениране на по-слаби екипи.";

    return {
      efficiency,
      recommendation,
    };
  },

  teamAI(team) {
    const power = team.power || 0;
    const experience = team.experience || 0;
    const reliability = team.reliability || 0;

    const score = power * 0.4 + experience * 0.3 + reliability * 0.3;

    const efficiency =
      score > 80
        ? "Елитен екип"
        : score > 60
        ? "Силен екип"
        : score > 40
        ? "Среден екип"
        : "Рисков екип";

    const recommendation =
      reliability < 50
        ? "Внимавай с този екип — възможни са провали и предателства."
        : "Екипът е стабилен, подходящ за важни операции.";

    return {
      efficiency,
      recommendation,
    };
  },
};