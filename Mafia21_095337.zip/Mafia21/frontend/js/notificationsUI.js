// ===============================================
// MAFIA 21st CENTURY — NOTIFICATIONS UI (PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Системни съобщения, alerts, popups,
// AI оценка на важност и риск.
// ===============================================

import { Utils } from "./utils.js";

export const NotificationsUI = {
  // Показване на съобщение
  show(message, type = "info") {
    const app = Utils.qs("#app");

    // AI оценка на съобщението
    const ai = Utils.notificationAI(message);

    // Премахваме старо съобщение
    const old = Utils.qs("#notificationPopup");
    if (old) old.remove();

    // Създаваме popup
    const popup = Utils.create("div", "notification-popup");
    popup.id = "notificationPopup";

    popup.innerHTML = `
      <div class="notification-header" style="color: var(--mafia-gold);">
        ${type.toUpperCase()}
      </div>

      <div class="notification-body">
        ${message}
      </div>

      <div class="notification-ai">
        <strong>AI оценка:</strong><br>
        Важност: <span style="color: var(--neon-blue)">${ai.importance}</span><br>
        Риск: <span style="color: var(--neon-pink)">${ai.risk}</span><br>
        Реакция: <span style="color: var(--mafia-gold)">${ai.reaction}</span>
      </div>

      <button class="btn" id="closeNotification">Затвори</button>
    `;

    app.appendChild(popup);

    // Neon ефект
    Utils.neonPulse(popup, "#00c8ff");

    // Автоматично затваряне при ниска важност
    if (ai.importance === "ниска") {
      setTimeout(() => {
        popup.remove();
      }, 2500);
    }

    // Затваряне
    Utils.qs("#closeNotification").addEventListener("click", () => {
      Utils.neonFlash(popup, "#ff007c");
      setTimeout(() => popup.remove(), 250);
    });
  },

  // Бързи съобщения
  success(msg) {
    this.show(`<span style="color: var(--mafia-gold)">${msg}</span>`, "success");
  },

  error(msg) {
    this.show(`<span style="color: var(--mafia-red)">${msg}</span>`, "error");
  },

  warning(msg) {
    this.show(`<span style="color: var(--neon-pink)">${msg}</span>`, "warning");
  },

  info(msg) {
    this.show(`<span style="color: var(--neon-blue)">${msg}</span>`, "info");
  }
};