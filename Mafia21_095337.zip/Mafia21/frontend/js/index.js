// ===============================================
// MAFIA 21st CENTURY — INDEX (CENTRAL CONTROLLER)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централен контролер:
// ✔ Авто зареждане на играча
// ✔ AI анализ
// ✔ Свързване на всички панели
// ✔ Стартиране на GameEngine
// ✔ Стартиране на HUB (неонов HUD)
// ✔ Пълна синхронизация с EventBus
// ===============================================

import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";
import { Utils } from "./utils.js";

import { HUD } from "./hub.js";
import { GameEngine } from "./gameEngine.js";
import { WorldSimulation } from "./worldSimulation.js";
import { PlayerStatsCore } from "./playerStatsCore.js";
import { EventBus } from "./eventBus.js";

// ===============================================
// CORE UI PANELS
// ===============================================
import { showCrimePanel } from "./crimeUI.js";
import { showPolicePanel } from "./policeUI.js";
import { showCityLifePanel } from "./cityLifeUI.js";
import { showBlackMarketPanel } from "./blackMarketUI.js";
import { showDistrictDangerPanel } from "./districtDangerUI.js";
import { showDistrictDetailsPanel } from "./districtPanelUI.js";
import { showMapPanel } from "./mapUI.js";
import { showSkillsPanel } from "./skillsUI.js";
import { showInventoryPanel } from "./inventoryUI.js";
import { showMissionsPanel } from "./missionsUI.js";
import { showInfluencePanel } from "./influenceUI.js";
import { showNPCPanel } from "./npcUI.js";

// ===============================================
// PLAYER & ORGANIZATION PANELS
// ===============================================
import { showPlayerStatsPanel } from "./playerStatsUI.js";
import { showOrganizationPanel } from "./organizationUI.js";

// ===============================================
// ADVANCED WORLD SYSTEM PANELS
// ===============================================
import { showWorldEventsPanel } from "./worldEventsUI.js";
import { showHeatPanel } from "./heatUI.js";
import { showGangWarsPanel } from "./gangWarsUI.js";
import { showTerritoryControlPanel } from "./territoryControlUI.js";

// ===============================================
// ECONOMY & LOGISTICS PANELS
// ===============================================
import { showEconomyPanel } from "./economyUI.js";
import { showTransportPanel } from "./transportUI.js";

// ===============================================
// COMBAT & ILLEGAL OPERATIONS PANELS
// ===============================================
import { showWeaponsPanel } from "./weaponsUI.js";
import { showDrugLabPanel } from "./drugLabUI.js";
import { showSafehousePanel } from "./safehouseUI.js";
import { showIntelPanel } from "./intelUI.js";

// ===============================================
// AUTO INIT — зарежда играча + AI анализ
// ===============================================
async function autoInit() {
  const player = await ApiClient.getPlayer();
  const skills = await ApiClient.getSkills();
  const missions = await ApiClient.getMissions();

  const aiPlayer = AICore.playerAI({ player, skills, missions });

  // HUD UPDATE (старият HUD — оставям го за съвместимост)
  Utils.qs("#hudLevel").innerText = player.level;
  Utils.qs("#hudHeat").innerText = player.heat;
  Utils.qs("#hudXP").innerText = player.xp || 0;
  Utils.qs("#hudMoney").innerText = player.money || 0;

  console.log("AUTO INIT — Player AI:", aiPlayer);

  // ⭐ NEW — PlayerStatsCore sync
  PlayerStatsCore.update(player);

  // ⭐ NEW — EventBus broadcast
  EventBus.emit("player_synced", player);
}

autoInit();

// ===============================================
// ROUTER — свързва бутони с панели
// ===============================================
const routes = {
  // CORE
  btnCrime: showCrimePanel,
  btnPolice: showPolicePanel,
  btnCityLife: showCityLifePanel,
  btnBlackMarket: showBlackMarketPanel,
  btnDistrictDanger: showDistrictDangerPanel,
  btnDistrictPanel: showDistrictDetailsPanel,
  btnMap: showMapPanel,
  btnSkills: showSkillsPanel,
  btnInventory: showInventoryPanel,
  btnMissions: showMissionsPanel,
  btnInfluence: showInfluencePanel,
  btnNPC: showNPCPanel,

  // PLAYER & ORG
  btnPlayerStats: showPlayerStatsPanel,
  btnOrganization: showOrganizationPanel,

  // WORLD SYSTEMS
  btnWorldEvents: showWorldEventsPanel,
  btnHeat: showHeatPanel,
  btnGangWars: showGangWarsPanel,
  btnTerritory: showTerritoryControlPanel,

  // ECONOMY & LOGISTICS
  btnEconomy: showEconomyPanel,
  btnTransport: showTransportPanel,

  // COMBAT & ILLEGAL OPS
  btnWeapons: showWeaponsPanel,
  btnDrugLab: showDrugLabPanel,
  btnSafehouse: showSafehousePanel,
  btnIntel: showIntelPanel
};

// ===============================================
// AUTO-BIND BUTTONS
// ===============================================
Object.keys(routes).forEach(id => {
  const btn = Utils.qs(`#${id}`);
  if (btn) {
    btn.addEventListener("click", () => {
      Utils.neonFlash(btn, "#00eaff");
      routes[id]();
    });
  }
});

// ===============================================
// GLOBAL REFRESH BUTTON
// ===============================================
const refreshBtn = Utils.qs("#btn-refreshAll");
if (refreshBtn) {
  refreshBtn.addEventListener("click", async () => {
    Utils.neonFlash(refreshBtn, "#ff007c");
    await autoInit();
  });
}

// ===============================================
// GLOBAL CLOSE ALL PANELS
// ===============================================
const closeAllBtn = Utils.qs("#btn-closeAll");
if (closeAllBtn) {
  closeAllBtn.addEventListener("click", () => {
    Utils.neonFlash(closeAllBtn, "#9b00ff");
    document.querySelectorAll(".ui-panel").forEach(p => p.remove());
  });
}

// ===============================================
// ⭐ NEW — AUTO START GAME ENGINE + HUB + WORLD SIM
// ===============================================
GameEngine.start();
WorldSimulation.start();
HUD.init();

console.log("MAFIA 21st CENTURY — FULL SYSTEM ONLINE");