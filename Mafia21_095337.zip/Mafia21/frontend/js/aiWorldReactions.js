// ===============================================
// MAFIA 21st CENTURY — AI WORLD REACTIONS (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Реакции на света към играча, NPC, полиция,
// престъпления, влияние, икономика, събития.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

export function initAIWorldReactions() {
  Utils.log("AI World Reactions стартира…");

  setInterval(async () => {
    const player = await ApiClient.getPlayer();
    const heat = player.heat;
    const money = player.money;

    const npc = await ApiClient.getNPCActivity();
    const police = await ApiClient.getPoliceStatus();
    const crime = await ApiClient.getCrimePulse();
    const districts = await ApiClient.getDistricts();
    const bm = await ApiClient.getBlackMarketPulse();

    // ===============================================
    // PLAYER → NPC REACTION
    // ===============================================
    if (heat > 50) {
      Utils.log("NPC реагират: играчът е твърде горещ.");
      await ApiClient.npcAvoidPlayer();
    }

    if (heat < 10) {
      Utils.log("NPC реагират: играчът е незабележим.");
      await ApiClient.npcApproachPlayer();
    }

    // ===============================================
    // PLAYER → POLICE REACTION
    // ===============================================
    if (crime.level > 70) {
      Utils.log("Полицията реагира: престъпленията са високи.");
      await ApiClient.policeIncreasePatrols();
    }

    if (heat > 80) {
      Utils.log("Полицията реагира: играчът е приоритет.");
      await ApiClient.policeFocusPlayer();
    }

    // ===============================================
    // PLAYER → DISTRICT REACTION
    // ===============================================
    districts.forEach(async (d) => {
      if (d.control < 30) {
        Utils.log(`Район реагира: ${d.name} е нестабилен.`);
        await ApiClient.districtIncreaseDanger(d.id);
      }

      if (d.control > 70) {
        Utils.log(`Район реагира: ${d.name} е под стабилен контрол.`);
        await ApiClient.districtRewardPlayer(d.id);
      }
    });

    // ===============================================
    // PLAYER → BLACK MARKET REACTION
    // ===============================================
    if (money > 50000) {
      Utils.log("Черен пазар реагира: играчът е богат.");
      await ApiClient.blackMarketOfferRareItems();
    }

    if (money < 500) {
      Utils.log("Черен пазар реагира: играчът е беден.");
      await ApiClient.blackMarketOfferCheapDeals();
    }

    // ===============================================
    // NPC → POLICE REACTION
    // ===============================================
    if (npc.activity > 60 && police.patrols < 3) {
      Utils.log("Полицията реагира: NPC активността е висока.");
      await ApiClient.policeIncreasePatrols();
    }

    // ===============================================
    // CRIME → WORLD EVENTS
    // ===============================================
    if (crime.level > 80) {
      Utils.log("Събитие: Масово престъпление.");
      await ApiClient.triggerWorldEvent("mass_crime");
    }

    if (crime.level < 20) {
      Utils.log("Събитие: Спокойствие в града.");
      await ApiClient.triggerWorldEvent("calm_city");
    }

  }, 4000); // 4 секунди реакции

  Utils.log("AI World Reactions работи.");
}