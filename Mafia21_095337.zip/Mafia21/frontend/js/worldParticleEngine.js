// ===============================================
// MAFIA 21st CENTURY — WORLD PARTICLE ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Дим, огън, искри, прах, експлозии, светлинни ефекти,
// динамични частици при събития и симулации.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

export function initWorldParticleEngine() {
  Utils.log("World Particle Engine стартира…");

  const canvas = Utils.qs("#particleCanvas");
  const ctx = canvas.getContext("2d");

  resizeCanvas(canvas);

  const ParticleState = {
    tick: 0,
    particles: [],
    weather: "clear",
    crimeLevel: 0,
    stormIntensity: 0
  };

  // ===============================================
  // MAIN PARTICLE LOOP
  // ===============================================
  setInterval(async () => {
    ParticleState.tick++;

    const weather = await ApiClient.getWeather();
    const crime = await ApiClient.getCrimePulse();
    const events = await ApiClient.getWorldEventsPulse();

    ParticleState.weather = weather.type;
    ParticleState.stormIntensity = weather.intensity;
    ParticleState.crimeLevel = crime.level;

    // ===============================================
    // GENERATE WEATHER PARTICLES
    // ===============================================
    if (weather.type === "storm") {
      generateLightning(ParticleState);
    }

    if (weather.type === "rain") {
      generateRainMist(ParticleState);
    }

    if (weather.type === "fog") {
      generateFogParticles(ParticleState);
    }

    // ===============================================
    // GENERATE CRIME PARTICLES
    // ===============================================
    if (crime.level > 70) {
      generateSmoke(ParticleState);
    }

    if (crime.level > 90) {
      generateFire(ParticleState);
    }

    // ===============================================
    // GENERATE EVENT PARTICLES
    // ===============================================
    if (events.count > 0) {
      generateEventSparks(ParticleState);
    }

    // ===============================================
    // UPDATE PARTICLES
    // ===============================================
    updateParticles(ParticleState);

    // ===============================================
    // DRAW PARTICLES
    // ===============================================
    drawParticles(ctx, ParticleState);

  }, 100); // 0.1 секунда за smooth ефекти

  Utils.log("World Particle Engine работи.");
}

// ===============================================
// CANVAS RESIZE
// ===============================================
function resizeCanvas(canvas) {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}

// ===============================================
// PARTICLE GENERATORS
// ===============================================
function generateLightning(state) {
  state.particles.push({
    x: Math.random() * window.innerWidth,
    y: 0,
    size: 2,
    color: "rgba(255,255,255,0.9)",
    life: 5,
    type: "lightning"
  });
}

function generateRainMist(state) {
  for (let i = 0; i < 10; i++) {
    state.particles.push({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      size: 1,
      color: "rgba(200,200,255,0.2)",
      life: 50,
      type: "mist"
    });
  }
}

function generateFogParticles(state) {
  state.particles.push({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    size: 20,
    color: "rgba(220,220,220,0.1)",
    life: 100,
    type: "fog"
  });
}

function generateSmoke(state) {
  state.particles.push({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    size: 10,
    color: "rgba(100,100,100,0.4)",
    life: 80,
    type: "smoke"
  });
}

function generateFire(state) {
  state.particles.push({
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
    size: 6,
    color: "rgba(255,100,0,0.7)",
    life: 40,
    type: "fire"
  });
}

function generateEventSparks(state) {
  for (let i = 0; i < 5; i++) {
    state.particles.push({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      size: 3,
      color: "rgba(255,255,0,0.8)",
      life: 30,
      type: "spark"
    });
  }
}

// ===============================================
// UPDATE PARTICLES
// ===============================================
function updateParticles(state) {
  for (const p of state.particles) {
    p.life--;

    if (p.type === "smoke") p.y -= 0.5;
    if (p.type === "fire") p.y -= 1;
    if (p.type === "spark") p.y -= 2;
    if (p.type === "mist") p.y -= 0.2;
    if (p.type === "fog") p.y += 0.1;

    p.size *= 0.98;
  }

  state.particles = state.particles.filter(p => p.life > 0);
}

// ===============================================
// DRAW PARTICLES
// ===============================================
function drawParticles(ctx, state) {
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);

  for (const p of state.particles) {
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
  }
}