// ===============================================
// MAFIA 21st CENTURY — WORLD NIGHT LIFE ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Симулация на нощен живот, клубове, барове,
// престъпност, активност, риск, динамика.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { EventBus } from "./eventBus.js"; // ⭐ добавено

export const worldNightLifeEngine = {
  async simulate() {
    EventBus.emit("nightlife_sim_tick", {}); // ⭐

    try {
      const districts = await ApiClient.getDistricts();
      const events = await ApiClient.getWorldEvents();

      const result = {
        hottestDistrict: null,
        quietestDistrict: null,
        nightlifeLevel: 0,
        crimeHotspots: [],
        forecast: "",
        recommendation: ""
      };

      // Най-активен нощен район
      result.hottestDistrict = districts.sort((a, b) => b.nightlife - a.nightlife)[0]?.name;

      // Най-спокоен район през нощта
      result.quietestDistrict = districts.sort((a, b) => a.nightlife - b.nightlife)[0]?.name;

      // Средно ниво на нощен живот
      result.nightlifeLevel =
        districts.reduce((sum, d) => sum + d.nightlife, 0) / districts.length;

      EventBus.emit("nightlife_density_update", {
        level: result.nightlifeLevel,
        hottest: result.hottestDistrict,
        quietest: result.quietestDistrict
      }); // ⭐

      // Горещи точки на престъпност през нощта
      result.crimeHotspots = districts
        .filter(d => d.nightlife > 60 && d.crime > 50)
        .map(d => d.name);

      EventBus.emit("nightlife_crime_hotspots", {
        hotspots: result.crimeHotspots
      }); // ⭐

      // Прогноза според събития
      const nightEvents = events.filter(e =>
        ["club_party", "night_festival", "underground_event"].includes(e.type)
      );

      if (nightEvents.length > 3) {
        result.forecast = "Очаква се масивен нощен трафик и висока активност.";
      } else if (nightEvents.length > 0) {
        result.forecast = "Възможни са локални струпвания и повишена активност.";
      } else {
        result.forecast = "Нощният живот ще остане стабилен.";
      }

      EventBus.emit("nightlife_forecast", {
        forecast: result.forecast,
        events: nightEvents
      }); // ⭐

      // Препоръка
      if (result.nightlifeLevel > 70) {
        result.recommendation =
          "Използвай нощния хаос за операции — градът е активен.";
      } else if (result.nightlifeLevel > 40) {
        result.recommendation =
          "Планирай действията си внимателно — активността е умерена.";
      } else {
        result.recommendation =
          "Нощта е спокойна — идеална за дискретни операции.";
      }

      EventBus.emit("nightlife_recommendation", {
        recommendation: result.recommendation
      }); // ⭐

      Utils.log("World Night Life Engine — симулация завършена.");
      return result;

    } catch (err) {
      console.error("❌ NightLifeEngine ERROR:", err);
      EventBus.emit("nightlife_error", { error: err }); // ⭐
    }
  }
};