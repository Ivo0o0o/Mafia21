// ===============================================
// MAFIA 21st CENTURY — AI ECONOMY EXPANSION ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Анализ на икономика, приходи, разходи,
// инвестиции, пазари, прогнози, растеж.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";

export const aiEconomyExpansion = {
  async analyze() {
    const economy = await ApiClient.getEconomyOverview();
    const markets = await ApiClient.getMarkets();
    const player = await ApiClient.getPlayer();

    const result = {
      bestMarket: null,
      worstMarket: null,
      investmentTarget: null,
      riskLevel: null,
      forecast: "",
      recommendation: ""
    };

    // Най-печеливш пазар
    result.bestMarket = markets.sort((a, b) => b.profit - a.profit)[0]?.name;

    // Най-слаб пазар
    result.worstMarket = markets.sort((a, b) => a.profit - b.profit)[0]?.name;

    // Най-добра инвестиция
    result.investmentTarget = markets.sort((a, b) => b.growth - a.growth)[0]?.name;

    // Риск
    result.riskLevel =
      economy.risk > 70
        ? "Висок"
        : economy.risk > 40
        ? "Среден"
        : "Нисък";

    // Прогноза
    if (economy.trend > 70) {
      result.forecast = "Очаква се силен икономически растеж.";
    } else if (economy.trend > 40) {
      result.forecast = "Пазарът е стабилен с умерен растеж.";
    } else {
      result.forecast = "Икономиката е нестабилна.";
    }

    // Препоръка
    if (economy.trend > 70) {
      result.recommendation = "Инвестирай агресивно в растящите пазари.";
    } else if (economy.trend > 40) {
      result.recommendation = "Разшири бизнеса си постепенно.";
    } else {
      result.recommendation = "Намали риска и стабилизирай приходите.";
    }

    Utils.log("AI Economy Expansion — анализ завършен.");
    return result;
  }
};