// ===============================================
// MAFIA 21st CENTURY — DISTRICT PANEL UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Детайли за район, ресурси, heat, влияние,
// AI анализ, AI препоръки, опасност,
// синергии с организацията.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showDistrictDetailsPanel(districtId) {
  Utils.log("Зареждаме детайли за район…");

  const app = Utils.qs("#app");

  const oldPanel = Utils.qs("#districtPanelDynamic");
  if (oldPanel) oldPanel.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "districtPanelDynamic";

  // Вземаме район
  const district = await ApiClient.getDistrict(districtId);

  // AI анализ
  const ai = AICore.districtAI(district);
  const mapAI = AICore.mapAI(district);

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-district" style="margin-right:8px;"></span>
      Район: ${district.name}
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Влияние:</strong>
      <span class="neon-blue">${ai.influence}</span><br>

      <strong>Репутация:</strong>
      <span class="neon-gold">${ai.reputation}</span><br>

      <strong>Heat:</strong>
      <span class="neon-red">${ai.heat}</span><br>

      <strong>Ресурси:</strong>
      <span class="neon-purple">${ai.resources}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-pink">${ai.recommendation}</span>
    </div>

    <!-- MAP AI -->
    <div class="section-title">Карта — AI анализ</div>
    <div class="info-box">
      <strong>Опасност:</strong>
      <span class="neon-red">${mapAI.danger}</span><br>

      <strong>Полиция:</strong>
      <span class="neon-blue">${mapAI.police}</span><br>

      <strong>Черен пазар:</strong>
      <span class="neon-gold">${mapAI.blackMarket}</span><br>

      <strong>Heat:</strong>
      <span class="neon-red">${mapAI.heat}</span><br>

      <strong>Ресурси:</strong>
      <span class="neon-purple">${mapAI.resources}</span>
    </div>

    <!-- DESCRIPTION -->
    <div class="section-title">Описание</div>
    <div class="info-box">
      ${district.description || "Няма описание"}
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshDistrict">Обнови</button>
      <button class="btn" id="closeDistrictPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // REFRESH
  Utils.qs("#refreshDistrict").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showDistrictDetailsPanel(districtId);
  });

  // CLOSE
  Utils.qs("#closeDistrictPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}