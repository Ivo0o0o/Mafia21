// ===============================================
// MAFIA 21st CENTURY — DISTRICT UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Детайлна визуализация на районите — влияние,
// контрол, NPC присъствие, икономика, престъпност.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";

export async function showDistrictDetails(district) {
  Utils.log(`Отваряме район: ${district.name}`);

  const app = Utils.qs("#app");

  // Remove old panel
  const oldPanel = Utils.qs("#districtDetailsPanel");
  if (oldPanel) oldPanel.remove();

  // Create panel
  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "districtDetailsPanel";

  // Fetch influence
  const influence = await ApiClient.getInfluence(district._id);

  // Mini AI
  const ai = Utils.npcBehaviorAI();

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-districts" style="margin-right:8px;"></span>
      Район — ${district.name}
    </div>

    <!-- BASIC INFO -->
    <div class="section-title">Основна информация</div>

    <div class="info-box">
      <strong>Тип район:</strong>
      <span class="neon-gold">${district.type}</span>
    </div>

    <div class="info-box">
      <strong>Ниво:</strong>
      <span class="neon-purple">${district.level}</span>
    </div>

    <div class="info-box">
      <strong>Контрол:</strong>
      <span class="neon-pink">${district.control}%</span>
    </div>

    <!-- INFLUENCE -->
    <div class="section-title">Влияние</div>

    <div class="info-box">
      <strong>Мафия:</strong>
      <span class="neon-red">${influence.mafia}%</span><br>

      <strong>Полиция:</strong>
      <span class="neon-blue">${influence.police}%</span><br>

      <strong>Граждани:</strong>
      <span class="neon-gold">${influence.civilians}%</span>
    </div>

    <!-- AI REACTION -->
    <div class="section-title">AI реакция</div>

    <div class="info-box">
      <strong>Емоция:</strong>
      <span class="neon-purple">${ai.emotion}</span><br>

      <strong>Решение:</strong>
      <span class="neon-pink">${ai.decision}</span><br>

      <strong>Интензитет:</strong>
      <span class="neon-gold">${ai.intensity}</span>
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="closeDistrictPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);

  // Neon animation
  Utils.neonPulse(panel, "#00c8ff");

  // Close button
  Utils.qs("#closeDistrictPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}