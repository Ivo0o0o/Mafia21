// ===============================================
// MAFIA 21st CENTURY — WORLD STATE CORE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централен state на света:
// ✔ citizens
// ✔ police
// ✔ gangs
// ✔ territories
// ✔ zones
// ✔ traffic
// ✔ events
// ✔ danger levels
// ✔ heat map
// ✔ world time
//
// Използва се от:
// ✔ WorldSimulation
// ✔ AIDirector
// ✔ UI панели
// ✔ Missions
// ✔ AI Engines
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";
import { EventBus } from "./eventBus.js"; // ⭐ добавено

export const WorldState = {
  data: {
    citizens: [],
    police: [],
    gangs: [],
    territories: [],
    zones: [],
    traffic: {},
    events: [],
    heat: [],
    time: {
      hour: 12,
      day: 1,
      cycle: "day" // day / night
    }
  },

  listeners: [],

  async init() {
    Utils.log("WorldState — зареждане...");

    await this.refreshAll();

    // Автоматичен refresh на всеки 5 секунди
    setInterval(() => this.refreshAll(), 5000);

    Utils.log("WorldState — готов.");
  },

  // ---------------------------------------------
  // ПЪЛЕН REFRESH НА СВЕТА
  // ---------------------------------------------
  async refreshAll() {
    this.data.citizens = await ApiClient.getCitizens();
    EventBus.emit("citizens_updated", this.data.citizens);

    this.data.police = await ApiClient.getPoliceUnits();
    EventBus.emit("police_updated", this.data.police);

    this.data.gangs = await ApiClient.getGangs();
    EventBus.emit("gangs_updated", this.data.gangs);

    this.data.territories = await ApiClient.getTerritories();
    EventBus.emit("territories_updated", this.data.territories);

    this.data.zones = await ApiClient.getZones();
    EventBus.emit("zones_updated", this.data.zones);

    this.data.traffic = await ApiClient.getTrafficStatus();
    EventBus.emit("traffic_updated", this.data.traffic);

    this.data.events = await ApiClient.getWorldEvents();
    EventBus.emit("events_updated", this.data.events);

    this.data.heat = await ApiClient.getHeatLevels();
    EventBus.emit("heat_updated", this.data.heat);

    this.updateTime();
    this.notify();

    // ⭐ глобално събитие за пълен refresh
    EventBus.emit("world_state_updated", this.data);
  },

  // ---------------------------------------------
  // ВРЪЩА ЦЕЛИЯ WORLD STATE
  // ---------------------------------------------
  get() {
    return this.data;
  },

  // ---------------------------------------------
  // ОБНОВЯВА ЧАСТ ОТ WORLD STATE
  // ---------------------------------------------
  update(partial) {
    Object.assign(this.data, partial);
    this.notify();

    // ⭐ събитие за частична промяна
    EventBus.emit("world_state_updated", this.data);
  },

  // ---------------------------------------------
  // СЛУШАТЕЛИ — UI, AI, WORLD системи
  // ---------------------------------------------
  onChange(callback) {
    this.listeners.push(callback);
  },

  notify() {
    this.listeners.forEach(cb => cb(this.data));
  },

  // ---------------------------------------------
  // ДИНАМИКА НА ВРЕМЕТО — ден/нощ цикъл
  // ---------------------------------------------
  updateTime() {
    this.data.time.hour++;

    if (this.data.time.hour >= 24) {
      this.data.time.hour = 0;
      this.data.time.day++;
    }

    this.data.time.cycle =
      this.data.time.hour >= 6 && this.data.time.hour < 20
        ? "day"
        : "night";

    // ⭐ изпращаме събитие за промяна на времето
    EventBus.emit("time_updated", this.data.time);
  }
};

// Автоматично стартиране
WorldState.init();