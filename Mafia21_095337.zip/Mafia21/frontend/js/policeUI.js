// ===============================================
// MAFIA 21st CENTURY — POLICE UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Полиция, патрули, акции, риск,
// AI анализ, AI прогнози, AI препоръки,
// автоматично зареждане.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showPolicePanel() {
  Utils.log("Зареждаме панела с полиция…");

  const app = Utils.qs("#app");

  const oldPanel = Utils.qs("#policePanelDynamic");
  if (oldPanel) oldPanel.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "policePanelDynamic";

  // Вземаме полицейски единици и действия
  const units = await ApiClient.getPoliceUnits() || [];
  const actions = await ApiClient.getPoliceActions() || [];

  // AI анализ на полицията
  const aiSummary = {
    totalUnits: units.length,
    avgAggression:
      Math.floor(
        units.reduce((sum, u) => sum + (u.aggression || 0), 0) /
        (units.length || 1)
      ),
    avgRisk:
      Math.floor(
        units.reduce((sum, u) => sum + (u.risk || 0), 0) /
        (units.length || 1)
      ),
    recommendation:
      units.length === 0
        ? "Няма активни полицейски единици"
        : units.length < 3
        ? "Полицията е слаба — възможност за престъпления"
        : "Полицията е активна — внимавай с heat"
  };

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-police" style="margin-right:8px;"></span>
      Полиция — Контролен Център
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Активни единици:</strong>
      <span class="neon-blue">${aiSummary.totalUnits}</span><br>

      <strong>Средна агресия:</strong>
      <span class="neon-red">${aiSummary.avgAggression}%</span><br>

      <strong>Среден риск:</strong>
      <span class="neon-purple">${aiSummary.avgRisk}%</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-gold">${aiSummary.recommendation}</span>
    </div>

    <!-- POLICE UNITS -->
    <div class="section-title">Полицейски единици</div>
    <div id="policeUnitsList">
      ${
        units.length === 0
          ? `<div class="info-box">Няма налични единици.</div>`
          : units
              .map(
                u => `
        <div class="info-box police-entry" data-id="${u._id}" style="cursor:pointer;">
          <strong>${u.name}</strong><br>
          Агресия: <span class="neon-red">${u.aggression}</span><br>
          Риск: <span class="neon-purple">${u.risk}</span><br>
          Патрул: <span class="neon-blue">${u.patrolZone}</span>
        </div>
      `
              )
              .join("")
      }
    </div>

    <!-- POLICE ACTIONS -->
    <div class="section-title">Полицейски акции</div>
    <div id="policeActionsList">
      ${
        actions.length === 0
          ? `<div class="info-box">Няма активни акции.</div>`
          : actions
              .map(
                a => `
        <div class="info-box police-action-entry" data-id="${a._id}" style="cursor:pointer;">
          <strong>${a.title}</strong><br>
          Опасност: <span class="neon-red">${a.danger}</span><br>
          Район: <span class="neon-blue">${a.district}</span>
        </div>
      `
              )
              .join("")
      }
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshPolice">Обнови</button>
      <button class="btn" id="closePolicePanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // -----------------------------------------------
  // CLICK → Детайли за полицейска единица
  // -----------------------------------------------
  panel.querySelectorAll("#policeUnitsList .police-entry").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const unit = units.find(u => u._id === id);

      Utils.neonFlash(box, "#ff007c");

      const ai = AICore.combatAI(unit);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-police" style="margin-right:8px;"></span>
          ${unit.name}
        </div>

        <div class="section-title">AI Анализ</div>
        <div class="info-box">
          <strong>Агресия:</strong>
          <span class="neon-red">${ai.aggression}</span><br>

          <strong>Риск:</strong>
          <span class="neon-purple">${ai.risk}</span><br>

          <strong>Стратегия:</strong>
          <span class="neon-blue">${ai.strategy}</span><br>

          <strong>Патрул зона:</strong>
          <span class="neon-gold">${unit.patrolZone}</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="backToPolice">Назад</button>
          <button class="btn" id="closePolicePanel">Затвори</button>
        </div>
      `;

      Utils.qs("#backToPolice").addEventListener("click", () => {
        showPolicePanel();
      });

      Utils.qs("#closePolicePanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // -----------------------------------------------
  // CLICK → Детайли за полицейска акция
  // -----------------------------------------------
  panel.querySelectorAll("#policeActionsList .police-action-entry").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const action = actions.find(a => a._id === id);

      Utils.neonFlash(box, "#9b00ff");

      const ai = AICore.worldEventAI(action);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-police" style="margin-right:8px;"></span>
          Акция: ${action.title}
        </div>

        <div class="section-title">AI Анализ</div>
        <div class="info-box">
          <strong>Опасност:</strong>
          <span class="neon-red">${ai.danger}</span><br>

          <strong>Ефект:</strong>
          <span class="neon-gold">${ai.effect}</span><br>

          <strong>Прогноза:</strong>
          <span class="neon-purple">${ai.forecast}</span><br>

          <strong>Препоръка:</strong>
          <span class="neon-blue">${ai.recommendation}</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="startPoliceAction">Изпълни</button>
          <button class="btn" id="backToPolice">Назад</button>
          <button class="btn" id="closePolicePanel">Затвори</button>
        </div>
      `;

      Utils.qs("#startPoliceAction").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.policeAction(id);
        showPolicePanel();
      });

      Utils.qs("#backToPolice").addEventListener("click", () => {
        showPolicePanel();
      });

      Utils.qs("#closePolicePanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // REFRESH
  Utils.qs("#refreshPolice").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showPolicePanel();
  });

  // CLOSE
  Utils.qs("#closePolicePanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}