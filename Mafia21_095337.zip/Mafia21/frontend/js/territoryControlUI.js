// ===============================================
// MAFIA 21st CENTURY — TERRITORY CONTROL UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Териториален контрол, зони, влияние, конфликти,
// AI анализ, AI прогнози, AI препоръки.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showTerritoryControlPanel() {
  Utils.log("Зареждаме Territory Control панела…");

  const app = Utils.qs("#app");

  // Премахваме стар панел, ако има
  const oldPanel = Utils.qs("#territoryControlPanelDynamic");
  if (oldPanel) oldPanel.remove();

  // Създаваме нов панел
  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "territoryControlPanelDynamic";

  // Данни от бекенда
  const territories = await ApiClient.getTerritories();      // всички територии
  const influence = await ApiClient.getInfluence();          // глобално влияние
  const wars = await ApiClient.getGangWars();                // активни конфликти

  // AI анализ
  const ai = AICore.territoryControlAI({ territories, influence, wars });

  // ===============================================
  // MAIN PANEL TEMPLATE
  // ===============================================
  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-territory" style="margin-right:8px;"></span>
      Териториален контрол — Зони, влияние, конфликти
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Най-важна територия:</strong>
      <span class="neon-gold">${ai.keyTerritory}</span><br>

      <strong>Най-слаб район:</strong>
      <span class="neon-blue">${ai.weakTerritory}</span><br>

      <strong>Най-опасен конфликт:</strong>
      <span class="neon-red">${ai.hotConflict}</span><br>

      <strong>Прогноза:</strong>
      <span class="neon-purple">${ai.forecast}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-pink">${ai.recommendation}</span>
    </div>

    <!-- TERRITORY LIST -->
    <div class="section-title">Територии</div>
    <div id="territoryList">
      ${
        territories.length === 0
          ? `<div class="info-box">Няма дефинирани територии.</div>`
          : territories
              .map(
                t => `
        <div class="info-box territory-entry" data-id="${t._id}" style="cursor:pointer;">
          <div class="territory-title">${t.name}</div>

          <div class="territory-meta">
            <span>Район: <span class="neon-blue">${t.district}</span></span>
            <span>Контрол: <span class="neon-gold">${t.control}</span></span>
            <span>Влияние: <span class="neon-purple">${t.influence}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshTerritoryControl">Обнови</button>
      <button class="btn" id="closeTerritoryControlPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // ===============================================
  // CLICK → Детайли за територия
  // ===============================================
  panel.querySelectorAll("#territoryList .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const territory = await ApiClient.getTerritory(id);

      Utils.neonFlash(box, "#ff007c");

      const territoryAI = AICore.singleTerritoryAI(territory);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-territory" style="margin-right:8px;"></span>
          Територия — ${territory.name}
        </div>

        <div class="section-title">AI Анализ</div>
        <div class="info-box">
          <strong>Контрол:</strong>
          <span class="neon-gold">${territory.control}</span><br>

          <strong>Влияние:</strong>
          <span class="neon-purple">${territory.influence}</span><br>

          <strong>Опасност:</strong>
          <span class="neon-red">${territoryAI.danger}</span><br>

          <strong>Прогноза:</strong>
          <span class="neon-blue">${territoryAI.forecast}</span><br>

          <strong>Препоръка:</strong>
          <span class="neon-pink">${territoryAI.recommendation}</span>
        </div>

        <div class="section-title">Описание</div>
        <div class="info-box">
          ${territory.description || "Няма описание."}
        </div>

        <div class="panel-buttons">
          <button class="btn" id="backToTerritoryControl">Назад</button>
          <button class="btn" id="closeTerritoryControlPanel">Затвори</button>
        </div>
      `;

      Utils.qs("#backToTerritoryControl").addEventListener("click", () => {
        showTerritoryControlPanel();
      });

      Utils.qs("#closeTerritoryControlPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // REFRESH
  // ===============================================
  Utils.qs("#refreshTerritoryControl").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showTerritoryControlPanel();
  });

  // ===============================================
  // CLOSE
  // ===============================================
  Utils.qs("#closeTerritoryControlPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}