// ===============================================
// MAFIA 21st CENTURY — GANGS UI (PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Кланове, рангове, територии, влияние,
// членове, ресурси, AI динамика.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";

export async function showGangsPanel() {
  Utils.log("Зареждаме панела с кланове…");

  const app = Utils.qs("#app");

  // Премахваме стария панел
  const oldPanel = Utils.qs("#gangsPanelDynamic");
  if (oldPanel) oldPanel.remove();

  // Създаваме нов панел
  const panel = Utils.create("div", "panel");
  panel.id = "gangsPanelDynamic";

  // Вземаме кланове от бекенда
  const gangs = await ApiClient.getGangs();

  // AI динамика
  const ai = Utils.npcBehaviorAI();

  panel.innerHTML = `
    <h2>Кланове</h2>

    <div class="info-box">
      <strong>AI динамика:</strong><br>
      Емоция: <span style="color: var(--neon-purple)">${ai.emotion}</span><br>
      Решение: <span style="color: var(--neon-pink)">${ai.decision}</span><br>
      Интензитет: <span style="color: var(--mafia-gold)">${ai.intensity}</span>
    </div>

    <div class="info-box">
      <strong>Списък кланове:</strong>
      <ul id="gangsList" style="margin-top:10px; padding-left:20px;">
        ${gangs.map(g => `
          <li style="margin-bottom:10px; cursor:pointer;" data-id="${g._id}">
            <span style="color: var(--mafia-gold)">${g.name}</span> —
            <span style="color: var(--neon-blue)">${g.power}</span> сила
          </li>
        `).join("")}
      </ul>
    </div>

    <button class="btn" id="refreshGangs">Обнови</button>
    <button class="btn" id="closeGangsPanel" style="margin-left:10px;">Затвори</button>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // -----------------------------------------------
  // CLICK → Детайли за клан
  // -----------------------------------------------
  panel.querySelectorAll("#gangsList li").forEach(li => {
    li.addEventListener("click", async () => {
      const gangId = li.dataset.id;
      const gang = await ApiClient.getGang(gangId);

      Utils.neonFlash(li, "#ff007c");

      panel.innerHTML = `
        <h2>${gang.name}</h2>

        <div class="info-box">
          <strong>Сила:</strong>
          <span style="color: var(--neon-blue)">${gang.power}</span>
        </div>

        <div class="info-box">
          <strong>Територия:</strong>
          <span style="color: var(--mafia-gold)">${gang.territory}</span>
        </div>

        <div class="info-box">
          <strong>Ресурси:</strong>
          <span style="color: var(--neon-purple)">${gang.resources}</span>
        </div>

        <div class="info-box">
          <strong>Членове:</strong>
          <ul style="padding-left:20px;">
            ${gang.members.map(m => `
              <li style="margin-bottom:6px;">
                <span style="color: var(--neon-blue)">${m.name}</span> —
                <span style="color: var(--mafia-gold)">${m.rank}</span>
              </li>
            `).join("")}
          </ul>
        </div>

        <div class="info-box">
          <strong>AI оценка:</strong><br>
          Агресия: <span style="color: var(--mafia-red)">${gang.ai.aggression}</span><br>
          Лоялност: <span style="color: var(--mafia-gold)">${gang.ai.loyalty}</span><br>
          Риск: <span style="color: var(--neon-pink)">${gang.ai.risk}</span>
        </div>

        <button class="btn" id="upgradeGang">Ъпгрейд</button>
        <button class="btn" id="backToGangs" style="margin-left:10px;">Назад</button>
        <button class="btn" id="closeGangsPanel" style="margin-left:10px;">Затвори</button>
      `;

      // Ъпгрейд на клан
      Utils.qs("#upgradeGang").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.upgradeGang(gangId);
        showGangsPanel();
      });

      // Назад
      Utils.qs("#backToGangs").addEventListener("click", () => {
        showGangsPanel();
      });

      // Затваряне
      Utils.qs("#closeGangsPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // -----------------------------------------------
  // REFRESH
  // -----------------------------------------------
  Utils.qs("#refreshGangs").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showGangsPanel();
  });

  // -----------------------------------------------
  // CLOSE
  // -----------------------------------------------
  Utils.qs("#closeGangsPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}