// ===============================================
// MAFIA 21st CENTURY — DISTRICT DANGER UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Опасност, heat, криминална активност,
// AI анализ, AI препоръки, AI контрол,
// автоматично зареждане.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";
import { AICore } from "./aiCore.js";

export async function showDistrictDangerPanel() {
  Utils.log("Зареждаме панела за опасност по райони…");

  const app = Utils.qs("#app");

  const oldPanel = Utils.qs("#districtDangerPanelDynamic");
  if (oldPanel) oldPanel.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "districtDangerPanelDynamic";

  // Вземаме всички райони
  const districts = await ApiClient.getDistricts() || [];

  // AI анализ на всички райони
  const dangerAI = AICore.districtDangerAI(districts);

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-danger" style="margin-right:8px;"></span>
      Опасност по райони — AI Контрол
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Общ Анализ</div>
    <div class="info-box">
      <strong>Среден риск:</strong>
      <span class="neon-red">${dangerAI.avgRisk}</span><br>

      <strong>Среден heat:</strong>
      <span class="neon-purple">${dangerAI.avgHeat}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-gold">${dangerAI.recommendation}</span>
    </div>

    <!-- DISTRICTS LIST -->
    <div class="section-title">Списък райони</div>
    <div id="districtDangerList">
      ${
        districts.length === 0
          ? `<div class="info-box">Няма данни за райони.</div>`
          : districts
              .map(
                d => `
        <div class="info-box danger-entry" data-id="${d._id}" style="cursor:pointer;">
          <strong>${d.name}</strong><br>
          Опасност: <span class="neon-red">${d.danger || 0}</span><br>
          Heat: <span class="neon-pink">${d.heat || 0}</span><br>
          Криминална активност: <span class="neon-blue">${d.crimeLevel || 0}</span>
        </div>
      `
              )
              .join("")
      }
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshDistrictDanger">Обнови</button>
      <button class="btn" id="closeDistrictDangerPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#ff007c");

  // -----------------------------------------------
  // CLICK → Детайли за район + AI контрол
  // -----------------------------------------------
  panel.querySelectorAll("#districtDangerList .danger-entry").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const district = await ApiClient.getDistrict(id);

      Utils.neonFlash(box, "#9b00ff");

      const ai = AICore.districtAI(district);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-danger" style="margin-right:8px;"></span>
          ${district.name} — AI Контрол
        </div>

        <div class="section-title">AI Анализ</div>
        <div class="info-box">
          <strong>Опасност:</strong>
          <span class="neon-red">${ai.heat}</span><br>

          <strong>Heat:</strong>
          <span class="neon-pink">${ai.heat}</span><br>

          <strong>Репутация:</strong>
          <span class="neon-blue">${ai.reputation}</span><br>

          <strong>Ресурси:</strong>
          <span class="neon-purple">${ai.resources}</span><br>

          <strong>Препоръка:</strong>
          <span class="neon-gold">${ai.recommendation}</span>
        </div>

        <div class="section-title">AI Контрол на риска</div>
        <div class="info-box">
          <label>Целеви риск:</label>
          <input type="range" id="targetRisk" min="0" max="100" value="${district.danger || 0}" />
          <br>
          <label>Целеви heat:</label>
          <input type="range" id="targetHeat" min="0" max="100" value="${district.heat || 0}" />
        </div>

        <div class="panel-buttons">
          <button class="btn" id="applyRiskSettings">Приложи</button>
          <button class="btn" id="backToDistrictDanger">Назад</button>
          <button class="btn" id="closeDistrictDangerPanel">Затвори</button>
        </div>
      `;

      // APPLY AI SETTINGS
      Utils.qs("#applyRiskSettings").addEventListener("click", async () => {
        const targetRisk = Number(Utils.qs("#targetRisk").value);
        const targetHeat = Number(Utils.qs("#targetHeat").value);

        Utils.neonFlash(panel, "#00c8ff");

        await ApiClient.updateDistrictRisk(id, {
          danger: targetRisk,
          heat: targetHeat
        });

        showDistrictDangerPanel();
      });

      // BACK
      Utils.qs("#backToDistrictDanger").addEventListener("click", () => {
        showDistrictDangerPanel();
      });

      // CLOSE
      Utils.qs("#closeDistrictDangerPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // REFRESH
  Utils.qs("#refreshDistrictDanger").addEventListener("click", () => {
    Utils.neonFlash(panel, "#00c8ff");
    showDistrictDangerPanel();
  });

  // CLOSE
  Utils.qs("#closeDistrictDangerPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}