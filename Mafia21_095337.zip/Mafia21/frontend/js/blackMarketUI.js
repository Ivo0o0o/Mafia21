// ===============================================
// MAFIA 21st CENTURY — BLACK MARKET UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Черен пазар, сделки, риск, печалба,
// AI анализ, AI препоръки, автоматично зареждане.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showBlackMarketPanel() {
  Utils.log("Зареждаме Черния Пазар…");

  const app = Utils.qs("#app");

  const oldPanel = Utils.qs("#blackMarketPanelDynamic");
  if (oldPanel) oldPanel.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "blackMarketPanelDynamic";

  // Вземаме оферти от черния пазар
  const offers = await ApiClient.getBlackMarket() || [];

  // AI анализ на всички оферти
  const aiSummary = {
    avgRisk:
      Math.floor(
        offers.reduce((sum, o) => sum + (o.risk || 0), 0) /
        (offers.length || 1)
      ),
    avgProfit:
      Math.floor(
        offers.reduce((sum, o) => sum + (o.profit || 0), 0) /
        (offers.length || 1)
      ),
    bestDeal:
      offers.length === 0
        ? "Няма"
        : offers.reduce((best, o) => (o.profit > best.profit ? o : best), offers[0]).name,
    recommendation:
      offers.length === 0
        ? "Няма налични сделки"
        : offers.length < 3
        ? "Изчакай по-добри оферти"
        : "Избери оферта с нисък риск и висока печалба"
  };

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-blackmarket" style="margin-right:8px;"></span>
      Черен Пазар — AI Контрол
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Общ Анализ</div>
    <div class="info-box">
      <strong>Среден риск:</strong>
      <span class="neon-red">${aiSummary.avgRisk}%</span><br>

      <strong>Средна печалба:</strong>
      <span class="neon-gold">${aiSummary.avgProfit} 💶</span><br>

      <strong>Най-добра оферта:</strong>
      <span class="neon-blue">${aiSummary.bestDeal}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-purple">${aiSummary.recommendation}</span>
    </div>

    <!-- OFFERS LIST -->
    <div class="section-title">Оферти</div>
    <div id="blackMarketList">
      ${
        offers.length === 0
          ? `<div class="info-box">Няма налични оферти.</div>`
          : offers
              .map(
                o => `
        <div class="info-box offer-entry" data-id="${o._id}" style="cursor:pointer;">
          <div class="offer-title">${o.name}</div>

          <div class="offer-meta">
            <span>Риск: <span class="neon-red">${o.risk}%</span></span>
            <span>Печалба: <span class="neon-gold">${o.profit} 💶</span></span>
            <span>Категория: <span class="neon-blue">${o.category}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshBlackMarket">Обнови</button>
      <button class="btn" id="closeBlackMarketPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // -----------------------------------------------
  // CLICK → Детайли за оферта + AI анализ
  // -----------------------------------------------
  panel.querySelectorAll("#blackMarketList .offer-entry").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const offer = offers.find(o => o._id === id);

      Utils.neonFlash(box, "#ff007c");

      const ai = AICore.blackMarketOfferAI(offer);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-blackmarket" style="margin-right:8px;"></span>
          ${offer.name}
        </div>

        <div class="section-title">AI Анализ</div>
        <div class="info-box">
          <strong>Риск:</strong>
          <span class="neon-red">${ai.risk}%</span><br>

          <strong>Печалба:</strong>
          <span class="neon-gold">${ai.profit} 💶</span><br>

          <strong>Препоръка:</strong>
          <span class="neon-blue">${ai.recommendation}</span>
        </div>

        <div class="section-title">Описание</div>
        <div class="info-box">${offer.description || "Няма описание"}</div>

        <div class="panel-buttons">
          <button class="btn" id="sellItem">Продай</button>
          <button class="btn" id="backToBlackMarket">Назад</button>
          <button class="btn" id="closeBlackMarketPanel">Затвори</button>
        </div>
      `;

      // SELL ITEM
      Utils.qs("#sellItem").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.sellItem(id);
        showBlackMarketPanel();
      });

      // BACK
      Utils.qs("#backToBlackMarket").addEventListener("click", () => {
        showBlackMarketPanel();
      });

      // CLOSE
      Utils.qs("#closeBlackMarketPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // REFRESH
  Utils.qs("#refreshBlackMarket").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showBlackMarketPanel();
  });

  // CLOSE
  Utils.qs("#closeBlackMarketPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}