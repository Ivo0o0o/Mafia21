// ===============================================
// MAFIA 21st CENTURY — WORLD UI (PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Визуализация на световните събития — динамика,
// промени, реакции, мини AI за света.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";

export async function showWorldPanel() {
  Utils.log("Зареждаме световните събития…");

  const app = Utils.qs("#app");

  // Премахваме стария динамичен панел, ако има
  const oldPanel = Utils.qs("#worldPanelDynamic");
  if (oldPanel) oldPanel.remove();

  // Създаваме нов панел
  const panel = Utils.create("div", "panel");
  panel.id = "worldPanelDynamic";

  // Вземаме световни събития от бекенда
  const events = await ApiClient.getWorldEvents();

  // Мини AI за световна динамика
  const ai = Utils.npcBehaviorAI();

  panel.innerHTML = `
    <h2>Световни събития</h2>

    <div class="info-box">
      <strong>AI динамика на света:</strong><br>
      Емоция: <span style="color: var(--neon-purple)">${ai.emotion}</span><br>
      Решение: <span style="color: var(--neon-pink)">${ai.decision}</span><br>
      Интензитет: <span style="color: var(--mafia-gold)">${ai.intensity}</span>
    </div>

    <div class="info-box">
      <strong>Последни събития:</strong>
      <ul id="worldEventsList" style="margin-top:10px; padding-left:20px;">
        ${events.map(ev => `
          <li style="margin-bottom:8px;">
            <span style="color: var(--mafia-gold)">${ev.type}</span> —
            <span style="color: var(--neon-blue)">${ev.description}</span>
          </li>
        `).join("")}
      </ul>
    </div>

    <button class="btn" id="refreshWorld">Обнови света</button>
    <button class="btn" id="closeWorldPanel" style="margin-left:10px;">Затвори</button>
  `;

  app.appendChild(panel);

  // Неонов ефект при отваряне
  Utils.neonPulse(panel, "#00c8ff");

  // -----------------------------------------------
  // ОБНОВЯВАНЕ НА СВЕТОВНИТЕ СЪБИТИЯ
  // -----------------------------------------------
  Utils.qs("#refreshWorld").addEventListener("click", async () => {
    Utils.neonFlash(panel, "#ff007c");

    const newEvents = await ApiClient.getWorldEvents();
    const newAI = Utils.npcBehaviorAI();

    panel.innerHTML = `
      <h2>Световни събития</h2>

      <div class="info-box">
        <strong>AI динамика на света:</strong><br>
        Емоция: <span style="color: var(--neon-purple)">${newAI.emotion}</span><br>
        Решение: <span style="color: var(--neon-pink)">${newAI.decision}</span><br>
        Интензитет: <span style="color: var(--mafia-gold)">${newAI.intensity}</span>
      </div>

      <div class="info-box">
        <strong>Последни събития:</strong>
        <ul id="worldEventsList" style="margin-top:10px; padding-left:20px;">
          ${newEvents.map(ev => `
            <li style="margin-bottom:8px;">
              <span style="color: var(--mafia-gold)">${ev.type}</span> —
              <span style="color: var(--neon-blue)">${ev.description}</span>
            </li>
          `).join("")}
        </ul>
      </div>

      <button class="btn" id="refreshWorld">Обнови света</button>
      <button class="btn" id="closeWorldPanel" style="margin-left:10px;">Затвори</button>
    `;
  });

  // -----------------------------------------------
  // ЗАТВАРЯНЕ НА ПАНЕЛА
  // -----------------------------------------------
  Utils.qs("#closeWorldPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}