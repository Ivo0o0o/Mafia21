// ===============================================
// MAFIA 21st CENTURY — DIALOGUE UI (PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// NPC диалози, избори, реакции, настроение,
// лоялност, branching система.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";

export async function showDialogue(npcId) {
  Utils.log(`Отваряме диалог с NPC ID: ${npcId}`);

  const app = Utils.qs("#app");

  // Премахваме стария панел
  const oldPanel = Utils.qs("#dialoguePanelDynamic");
  if (oldPanel) oldPanel.remove();

  // Създаваме нов панел
  const panel = Utils.create("div", "panel");
  panel.id = "dialoguePanelDynamic";

  // Вземаме NPC данни
  const npc = await ApiClient.getNPC(npcId);

  // Вземаме диалог от бекенда
  const dialogue = await ApiClient.getDialogue(npcId);

  // AI динамика
  const ai = Utils.npcBehaviorAI();

  panel.innerHTML = `
    <h2>Диалог с ${npc.name}</h2>

    <div class="info-box">
      <strong>Настроение:</strong>
      <span style="color: var(--neon-purple)">${npc.mood}</span><br>
      <strong>Лоялност:</strong>
      <span style="color: var(--mafia-gold)">${npc.loyalty}%</span><br>
      <strong>AI:</strong>
      <span style="color: var(--neon-pink)">${ai.emotion}</span> /
      <span style="color: var(--neon-blue)">${ai.decision}</span>
    </div>

    <div class="info-box" id="dialogueText">
      <strong>${npc.name} казва:</strong><br>
      <span style="color:#fff;">${dialogue.text}</span>
    </div>

    <div class="info-box">
      <strong>Твоите отговори:</strong>
      <ul id="dialogueOptions" style="padding-left:20px; margin-top:10px;">
        ${dialogue.options.map(opt => `
          <li data-id="${opt.id}" style="margin-bottom:8px; cursor:pointer;">
            <span style="color: var(--neon-blue)">${opt.text}</span>
          </li>
        `).join("")}
      </ul>
    </div>

    <button class="btn" id="closeDialogue" style="margin-top:10px;">Затвори</button>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#9b00ff");

  // -----------------------------------------------
  // CLICK → Избор на отговор
  // -----------------------------------------------
  panel.querySelectorAll("#dialogueOptions li").forEach(li => {
    li.addEventListener("click", async () => {
      const optionId = li.dataset.id;

      Utils.neonFlash(li, "#ff007c");

      // Вземаме следващата реплика
      const next = await ApiClient.getDialogueNext(npcId, optionId);

      // Обновяваме текста
      Utils.qs("#dialogueText").innerHTML = `
        <strong>${npc.name} отговаря:</strong><br>
        <span style="color:#fff;">${next.text}</span>
      `;

      // Обновяваме опциите
      const optionsBox = Utils.qs("#dialogueOptions");
      optionsBox.innerHTML = next.options.map(opt => `
        <li data-id="${opt.id}" style="margin-bottom:8px; cursor:pointer;">
          <span style="color: var(--neon-blue)">${opt.text}</span>
        </li>
      `).join("");

      // Добавяме нови listeners
      optionsBox.querySelectorAll("li").forEach(newLi => {
        newLi.addEventListener("click", async () => {
          const nextId = newLi.dataset.id;
          Utils.neonFlash(newLi, "#ff007c");

          const nextStep = await ApiClient.getDialogueNext(npcId, nextId);

          Utils.qs("#dialogueText").innerHTML = `
            <strong>${npc.name} казва:</strong><br>
            <span style="color:#fff;">${nextStep.text}</span>
          `;

          optionsBox.innerHTML = nextStep.options.map(opt => `
            <li data-id="${opt.id}" style="margin-bottom:8px; cursor:pointer;">
              <span style="color: var(--neon-blue)">${opt.text}</span>
            </li>
          `).join("");
        });
      });
    });
  });

  // -----------------------------------------------
  // CLOSE
  // -----------------------------------------------
  Utils.qs("#closeDialogue").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}