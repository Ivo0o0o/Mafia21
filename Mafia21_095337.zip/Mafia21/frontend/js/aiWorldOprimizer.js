// ===============================================
// MAFIA 21st CENTURY — AI WORLD OPTIMIZER (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Оптимизация на всички AI системи, намаляване на
// натоварването, динамично разпределение на ресурси,
// стабилен FPS, стабилен AI, стабилен свят.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

export function initAIWorldOptimizer() {
  Utils.log("AI World Optimizer стартира…");

  const OptimizerState = {
    tick: 0,
    load: 0,
    fps: 60,
    aiLoad: 0,
    lastLagSpike: 0,
    modules: [
      "aiGameplayEngine",
      "aiWorldReactions",
      "aiEconomyEngine",
      "aiNPCPersonalities",
      "aiPoliceIntelligence",
      "aiDistrictEvolution",
      "aiWorldEventsEngine",
      "aiGlobalBalancer"
    ]
  };

  // ===============================================
  // MAIN OPTIMIZER LOOP
  // ===============================================
  setInterval(async () => {
    OptimizerState.tick++;

    // ===============================================
    // GET SYSTEM LOAD
    // ===============================================
    const sys = await ApiClient.getSystemLoad();
    OptimizerState.load = sys.load;
    OptimizerState.fps = sys.fps;
    OptimizerState.aiLoad = sys.aiLoad;

    // ===============================================
    // DETECT LAG SPIKES
    // ===============================================
    if (OptimizerState.fps < 40) {
      OptimizerState.lastLagSpike = Date.now();
      Utils.log("OPTIMIZER: Засечен лаг → оптимизация.");
      await reduceAILoad(OptimizerState);
    }

    // ===============================================
    // DETECT AI OVERLOAD
    // ===============================================
    if (OptimizerState.aiLoad > 0.8) {
      Utils.log("OPTIMIZER: AI натоварване високо → регулиране.");
      await regulateAIIntervals(OptimizerState);
    }

    // ===============================================
    // DETECT SYSTEM OVERLOAD
    // ===============================================
    if (OptimizerState.load > 0.75) {
      Utils.log("OPTIMIZER: Системно натоварване високо → пауза на второстепенни модули.");
      await pauseSecondaryModules(OptimizerState);
    }

    // ===============================================
    // AUTO‑RECOVERY
    // ===============================================
    if (OptimizerState.fps > 55 && OptimizerState.aiLoad < 0.5) {
      Utils.log("OPTIMIZER: Системата е стабилна → възстановяване.");
      await restoreModules(OptimizerState);
    }

    Utils.log(`OPTIMIZER: FPS=${OptimizerState.fps}, Load=${OptimizerState.load}, AI=${OptimizerState.aiLoad}`);

  }, 5000); // 5 секунди цикъл

  Utils.log("AI World Optimizer работи.");
}

// ===============================================
// REDUCE AI LOAD
// ===============================================
async function reduceAILoad(state) {
  await ApiClient.aiReduceIntensity();
}

// ===============================================
// REGULATE AI INTERVALS
// ===============================================
async function regulateAIIntervals(state) {
  await ApiClient.aiRegulateIntervals();
}

// ===============================================
// PAUSE SECONDARY MODULES
// ===============================================
async function pauseSecondaryModules(state) {
  await ApiClient.aiPauseSecondary();
}

// ===============================================
// RESTORE MODULES
// ===============================================
async function restoreModules(state) {
  await ApiClient.aiRestoreModules();
}