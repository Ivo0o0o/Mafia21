// ===============================================
// MAFIA 21st CENTURY — WORLD WEATHER ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Дъжд, буря, мъгла, слънце, вятър, гръмотевици,
// влияние върху NPC, полиция, престъпления.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";
import { EventBus } from "./eventBus.js"; // ⭐ добавено

export function initWorldWeatherEngine() {
  Utils.log("World Weather Engine стартира…");
  EventBus.emit("weather_init", {}); // ⭐

  const WeatherState = {
    tick: 0,
    current: "clear",
    intensity: 0,
    cycle: "day",
    weatherList: ["clear", "rain", "storm", "fog", "wind"],
    canvas: Utils.qs("#weatherCanvas"),
    ctx: null
  };

  WeatherState.ctx = WeatherState.canvas.getContext("2d");
  resizeCanvas(WeatherState.canvas);

  // ===============================================
  // MAIN WEATHER LOOP
  // ===============================================
  setInterval(async () => {
    WeatherState.tick++;
    EventBus.emit("weather_tick", { tick: WeatherState.tick }); // ⭐

    const cycle = await ApiClient.getWorldCycle();
    const crime = await ApiClient.getCrimePulse();
    const npc = await ApiClient.getNPCActivity();
    const police = await ApiClient.getPoliceStatus();

    WeatherState.cycle = cycle;

    EventBus.emit("weather_cycle_update", {
      cycle,
      crime,
      npc,
      police
    }); // ⭐

    // ===============================================
    // RANDOM WEATHER CHANGE
    // ===============================================
    if (WeatherState.tick % 20 === 0) {
      WeatherState.current = randomWeather(WeatherState.weatherList);
      WeatherState.intensity = Math.random();

      await ApiClient.updateWeather(WeatherState.current, WeatherState.intensity);

      EventBus.emit("weather_change", {
        weather: WeatherState.current,
        intensity: WeatherState.intensity
      }); // ⭐

      Utils.log(`WEATHER: ${WeatherState.current} (${WeatherState.intensity.toFixed(2)})`);
    }

    // ===============================================
    // WEATHER EFFECTS ON NPC
    // ===============================================
    if (WeatherState.current === "rain") {
      await ApiClient.npcReduceActivity();
      EventBus.emit("weather_npc_effect", { effect: "reduce_activity" }); // ⭐
    }

    if (WeatherState.current === "fog") {
      await ApiClient.npcConfusionEffect();
      EventBus.emit("weather_npc_effect", { effect: "confusion" }); // ⭐
    }

    if (WeatherState.current === "storm") {
      await ApiClient.npcHideIndoors();
      EventBus.emit("weather_npc_effect", { effect: "hide_indoors" }); // ⭐
    }

    // ===============================================
    // WEATHER EFFECTS ON POLICE
    // ===============================================
    if (WeatherState.current === "wind") {
      await ApiClient.policeSlowPatrols();
      EventBus.emit("weather_police_effect", { effect: "slow_patrols" }); // ⭐
    }

    if (WeatherState.current === "storm") {
      await ApiClient.policeShelterUnits();
      EventBus.emit("weather_police_effect", { effect: "shelter_units" }); // ⭐
    }

    // ===============================================
    // WEATHER EFFECTS ON CRIME
    // ===============================================
    if (WeatherState.current === "rain") {
      await ApiClient.crimeDecrease();
      EventBus.emit("weather_crime_effect", { effect: "crime_decrease" }); // ⭐
    }

    if (WeatherState.current === "fog") {
      await ApiClient.crimeIncreaseStealth();
      EventBus.emit("weather_crime_effect", { effect: "crime_stealth_increase" }); // ⭐
    }

    if (WeatherState.current === "storm") {
      await ApiClient.crimeChaosBoost();
      EventBus.emit("weather_crime_effect", { effect: "crime_chaos_boost" }); // ⭐
    }

    // ===============================================
    // DRAW WEATHER
    // ===============================================
    drawWeather(WeatherState);
    EventBus.emit("weather_draw", {
      weather: WeatherState.current,
      intensity: WeatherState.intensity
    }); // ⭐

  }, 3000); // 3 секунди цикъл

  Utils.log("World Weather Engine работи.");
  EventBus.emit("weather_ready", {}); // ⭐
}

// ===============================================
// RANDOM WEATHER
// ===============================================
function randomWeather(list) {
  return list[Math.floor(Math.random() * list.length)];
}

// ===============================================
// CANVAS RESIZE
// ===============================================
function resizeCanvas(canvas) {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}

// ===============================================
// DRAW WEATHER EFFECTS
// ===============================================
function drawWeather(state) {
  const ctx = state.ctx;
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);

  if (state.current === "rain") drawRain(ctx, state.intensity);
  if (state.current === "fog") drawFog(ctx, state.intensity);
  if (state.current === "storm") drawStorm(ctx, state.intensity);
  if (state.current === "wind") drawWind(ctx, state.intensity);
}

// ===============================================
// RAIN
// ===============================================
function drawRain(ctx, intensity) {
  ctx.fillStyle = "rgba(0,0,255,0.3)";
  for (let i = 0; i < intensity * 200; i++) {
    ctx.fillRect(Math.random() * ctx.canvas.width, Math.random() * ctx.canvas.height, 2, 10);
  }
}

// ===============================================
// FOG
// ===============================================
function drawFog(ctx, intensity) {
  ctx.fillStyle = `rgba(200,200,200,${intensity * 0.5})`;
  ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);
}

// ===============================================
// STORM
// ===============================================
function drawStorm(ctx, intensity) {
  drawRain(ctx, intensity * 2);
  if (Math.random() < intensity * 0.1) {
    ctx.fillStyle = "rgba(255,255,255,0.8)";
    ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  }
}

// ===============================================
// WIND
// ===============================================
function drawWind(ctx, intensity) {
  ctx.fillStyle = `rgba(150,150,150,${intensity * 0.2})`;
  ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);
}