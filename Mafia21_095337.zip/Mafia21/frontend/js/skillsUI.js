// ===============================================
// MAFIA 21st CENTURY — SKILLS UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Умения, прогрес, ефективност, AI анализ,
// динамични подобрения, автоматично зареждане.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showSkillsPanel() {
  Utils.log("Зареждаме панела с умения…");

  const app = Utils.qs("#app");

  const oldPanel = Utils.qs("#skillsPanelDynamic");
  if (oldPanel) oldPanel.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "skillsPanelDynamic";

  // Вземаме умения
  const skills = await ApiClient.getSkills() || [];

  // AI анализ на всички умения
  const aiSummary = {
    avgEfficiency:
      Math.floor(
        skills.reduce((sum, s) => sum + (AICore.skillAI(s).efficiency || 0), 0) /
        (skills.length || 1)
      ),
    avgProgress:
      Math.floor(
        skills.reduce((sum, s) => sum + (AICore.skillAI(s).progress || 0), 0) /
        (skills.length || 1)
      ),
    recommendation:
      skills.length === 0
        ? "Няма умения за анализ"
        : skills.length < 3
        ? "Развий още умения"
        : "Продължавай да подобряваш ключовите умения"
  };

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-skills" style="margin-right:8px;"></span>
      Умения — Контролен Център
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Средна ефективност:</strong>
      <span class="neon-blue">${aiSummary.avgEfficiency}%</span><br>

      <strong>Среден прогрес:</strong>
      <span class="neon-gold">${aiSummary.avgProgress}%</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-purple">${aiSummary.recommendation}</span>
    </div>

    <!-- SKILLS LIST -->
    <div class="section-title">Списък умения</div>
    <div id="skillsList">
      ${
        skills.length === 0
          ? `<div class="info-box">Няма налични умения.</div>`
          : skills
              .map(s => {
                const ai = AICore.skillAI(s);
                return `
          <div class="info-box skill-entry" data-id="${s._id}" style="cursor:pointer;">
            <div class="skill-title">${s.name}</div>

            <div class="skill-meta">
              <span>Ефективност: <span class="neon-blue">${ai.efficiency}%</span></span>
              <span>Прогрес: <span class="neon-gold">${ai.progress}%</span></span>
              <span>Ниво: <span class="neon-pink">${s.level}</span></span>
            </div>
          </div>
        `;
              })
              .join("")
      }
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshSkills">Обнови</button>
      <button class="btn" id="closeSkillsPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // -----------------------------------------------
  // CLICK → Детайли за умение + AI анализ
  // -----------------------------------------------
  panel.querySelectorAll("#skillsList .skill-entry").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const skill = skills.find(s => s._id === id);

      Utils.neonFlash(box, "#ff007c");

      const ai = AICore.skillAI(skill);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-skills" style="margin-right:8px;"></span>
          ${skill.name}
        </div>

        <div class="section-title">AI Анализ</div>
        <div class="info-box">
          <strong>Ефективност:</strong>
          <span class="neon-blue">${ai.efficiency}%</span><br>

          <strong>Прогрес:</strong>
          <span class="neon-gold">${ai.progress}%</span><br>

          <strong>Ниво:</strong>
          <span class="neon-pink">${skill.level}</span><br>

          <strong>Описание:</strong>
          <span class="neon-purple">${skill.description || "Няма описание"}</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="backToSkills">Назад</button>
          <button class="btn" id="closeSkillsPanel">Затвори</button>
        </div>
      `;

      Utils.qs("#backToSkills").addEventListener("click", () => {
        showSkillsPanel();
      });

      Utils.qs("#closeSkillsPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // REFRESH
  Utils.qs("#refreshSkills").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showSkillsPanel();
  });

  // CLOSE
  Utils.qs("#closeSkillsPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}