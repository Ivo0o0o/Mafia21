// ===============================================
// MAFIA 21st CENTURY — WORLD MAP ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централен модул за визуализация на света:
// ✔ трафик
// ✔ престъпност
// ✔ heat
// ✔ територии
// ✔ опасни зони
// ✔ събития
// ✔ динамични слоеве
// ===============================================

import { ApiClient } from "./apiClient.js";
import { EventBus } from "./eventBus.js";
import { Utils } from "./utils.js";

export const worldMapEngine = {
  mapData: {
    districts: [],
    traffic: [],
    crime: [],
    heat: [],
    territories: [],
    events: []
  },

  async simulate() {
    EventBus.emit("world_map_tick", {}); // ⭐

    try {
      // Зареждане на всички слоеве
      const districts = await ApiClient.getDistricts();
      const traffic = await ApiClient.getTrafficStatus();
      const crime = await ApiClient.getCrimeReports();
      const heat = await ApiClient.getHeatLevels();
      const territories = await ApiClient.getTerritories();
      const events = await ApiClient.getWorldEvents();

      this.mapData = {
        districts,
        traffic,
        crime,
        heat,
        territories,
        events
      };

      // Основно обновяване
      EventBus.emit("world_map_update", {
        districts,
        traffic,
        crime,
        heat,
        territories,
        events
      });

      // Отделни слоеве
      EventBus.emit("world_map_layer_update", {
        layer: "traffic",
        data: traffic
      });

      EventBus.emit("world_map_layer_update", {
        layer: "crime",
        data: crime
      });

      EventBus.emit("world_map_layer_update", {
        layer: "heat",
        data: heat
      });

      EventBus.emit("world_map_layer_update", {
        layer: "territories",
        data: territories
      });

      EventBus.emit("world_map_layer_update", {
        layer: "events",
        data: events
      });

      Utils.log("World Map Engine — обновяване завършено.");
      return this.mapData;

    } catch (err) {
      console.error("❌ WorldMapEngine ERROR:", err);
      EventBus.emit("world_map_error", { error: err });
    }
  },

  getMapData() {
    return this.mapData;
  }
};