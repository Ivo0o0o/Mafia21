// ===============================================
// MAFIA 21st CENTURY — WORLD GANG TERRITORY ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Симулация на територии, банди, влияние,
// конфликти, риск, динамика, прогнози.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { EventBus } from "./eventBus.js"; // ⭐ добавено

export const worldGangTerritoryEngine = {
  async simulate() {
    EventBus.emit("territory_sim_tick", {}); // ⭐

    try {
      const territories = await ApiClient.getTerritories();
      const gangs = await ApiClient.getGangs();
      const heat = await ApiClient.getHeatLevels();

      const result = {
        dominantGang: null,
        weakestGang: null,
        mostContestedTerritory: null,
        takeoverRiskZones: [],
        globalConflictLevel: 0,
        forecast: "",
        recommendation: ""
      };

      // Доминираща банда (общо влияние)
      result.dominantGang = gangs
        .sort((a, b) => b.influence - a.influence)[0]?.name;

      // Най-слаба банда
      result.weakestGang = gangs
        .sort((a, b) => a.influence - b.influence)[0]?.name;

      EventBus.emit("territory_update", {
        dominantGang: result.dominantGang,
        weakestGang: result.weakestGang
      }); // ⭐

      // Най-оспорвана територия
      result.mostContestedTerritory = territories
        .sort((a, b) => b.conflict - a.conflict)[0]?.name;

      // Зони с висок риск от превземане
      result.takeoverRiskZones = territories
        .filter(t => t.conflict > 60 || t.control < 40)
        .map(t => t.name);

      EventBus.emit("territory_conflict", {
        contested: result.mostContestedTerritory,
        riskZones: result.takeoverRiskZones
      }); // ⭐

      // Глобално ниво на конфликт
      result.globalConflictLevel =
        territories.reduce((sum, t) => sum + t.conflict, 0) / territories.length;

      // Прогноза според heat
      const avgHeat =
        heat.reduce((sum, h) => sum + h.level, 0) / heat.length;

      if (avgHeat > 70) {
        result.forecast = "Очаква се масивна война за територии.";
      } else if (avgHeat > 40) {
        result.forecast = "Възможни са локални сблъсъци.";
      } else {
        result.forecast = "Териториите ще останат относително стабилни.";
      }

      EventBus.emit("territory_forecast", {
        forecast: result.forecast,
        heat: avgHeat
      }); // ⭐

      // Препоръка
      if (avgHeat > 70) {
        result.recommendation = "Укрепи слабите територии и подготви защита.";
      } else if (avgHeat > 40) {
        result.recommendation = "Разшири влиянието си в ниско защитените зони.";
      } else {
        result.recommendation = "Идеално време за агресивно разширяване.";
      }

      EventBus.emit("territory_recommendation", {
        recommendation: result.recommendation
      }); // ⭐

      Utils.log("World Gang Territory Engine — симулация завършена.");
      return result;

    } catch (err) {
      console.error("❌ TerritoryEngine ERROR:", err);
      EventBus.emit("territory_error", { error: err }); // ⭐
    }
  }
};