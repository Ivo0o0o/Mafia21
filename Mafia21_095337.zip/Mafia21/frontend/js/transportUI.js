// ===============================================
// MAFIA 21st CENTURY — TRANSPORT UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Превозни средства, доставки, логистика,
// AI анализ, AI препоръки, риск и печалба.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showTransportPanel() {
  Utils.log("Зареждаме Transport панела…");

  const app = Utils.qs("#app");

  // Премахваме стар панел
  const oldPanel = Utils.qs("#transportPanelDynamic");
  if (oldPanel) oldPanel.remove();

  // Създаваме нов панел
  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "transportPanelDynamic";

  // Данни от бекенда
  const vehicles = await ApiClient.getVehicles();          // всички превозни средства
  const deliveries = await ApiClient.getDeliveries();      // активни доставки
  const logistics = await ApiClient.getLogistics();        // логистични данни

  // AI анализ
  const ai = AICore.transportAI({ vehicles, deliveries, logistics });

  // ===============================================
  // MAIN PANEL TEMPLATE
  // ===============================================
  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-transport" style="margin-right:8px;"></span>
      Транспорт — Превозни средства и логистика
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Най-рискова доставка:</strong>
      <span class="neon-red">${ai.mostDangerous}</span><br>

      <strong>Най-печеливша доставка:</strong>
      <span class="neon-gold">${ai.mostProfitable}</span><br>

      <strong>Най-бързо превозно средство:</strong>
      <span class="neon-blue">${ai.fastestVehicle}</span><br>

      <strong>Прогноза:</strong>
      <span class="neon-purple">${ai.forecast}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-pink">${ai.recommendation}</span>
    </div>

    <!-- VEHICLES -->
    <div class="section-title">Превозни средства</div>
    <div id="vehicleList">
      ${
        vehicles.length === 0
          ? `<div class="info-box">Няма налични превозни средства.</div>`
          : vehicles
              .map(
                v => `
        <div class="info-box vehicle-entry" data-id="${v._id}" style="cursor:pointer;">
          <div class="vehicle-title">${v.name}</div>

          <div class="vehicle-meta">
            <span>Скорост: <span class="neon-blue">${v.speed}</span></span>
            <span>Капацитет: <span class="neon-gold">${v.capacity}</span></span>
            <span>Риск: <span class="neon-red">${v.risk}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <!-- DELIVERIES -->
    <div class="section-title">Активни доставки</div>
    <div id="deliveryList">
      ${
        deliveries.length === 0
          ? `<div class="info-box">Няма активни доставки.</div>`
          : deliveries
              .map(
                d => `
        <div class="info-box delivery-entry" data-id="${d._id}" style="cursor:pointer;">
          <div class="delivery-title">${d.type}</div>

          <div class="delivery-meta">
            <span>Печалба: <span class="neon-gold">${Utils.formatMoney(d.profit)}</span></span>
            <span>Риск: <span class="neon-red">${d.risk}</span></span>
            <span>Време: <span class="neon-blue">${d.time} мин</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshTransport">Обнови</button>
      <button class="btn" id="closeTransportPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // ===============================================
  // CLICK → Детайли за превозно средство
  // ===============================================
  panel.querySelectorAll("#vehicleList .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const vehicle = await ApiClient.getVehicle(id);

      Utils.neonFlash(box, "#ff007c");

      const vehicleAI = AICore.vehicleAI(vehicle);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-transport" style="margin-right:8px;"></span>
          ${vehicle.name}
        </div>

        <div class="info-box">
          <strong>Скорост:</strong>
          <span class="neon-blue">${vehicle.speed}</span><br>

          <strong>Капацитет:</strong>
          <span class="neon-gold">${vehicle.capacity}</span><br>

          <strong>Риск:</strong>
          <span class="neon-red">${vehicle.risk}</span><br>

          <strong>AI оценка:</strong><br>
          Ефективност: <span class="neon-purple">${vehicleAI.efficiency}</span><br>
          Препоръка: <span class="neon-pink">${vehicleAI.recommendation}</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="backToTransport">Назад</button>
          <button class="btn" id="closeTransportPanel">Затвори</button>
        </div>
      `;

      Utils.qs("#backToTransport").addEventListener("click", () => {
        showTransportPanel();
      });

      Utils.qs("#closeTransportPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // CLICK → Детайли за доставка
  // ===============================================
  panel.querySelectorAll("#deliveryList .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const delivery = await ApiClient.getDelivery(id);

      Utils.neonFlash(box, "#9b00ff");

      const deliveryAI = AICore.deliveryAI(delivery);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-transport" style="margin-right:8px;"></span>
          Доставка — ${delivery.type}
        </div>

        <div class="info-box">
          <strong>Печалба:</strong>
          <span class="neon-gold">${Utils.formatMoney(delivery.profit)}</span><br>

          <strong>Риск:</strong>
          <span class="neon-red">${delivery.risk}</span><br>

          <strong>Време:</strong>
          <span class="neon-blue">${delivery.time} мин</span><br>

          <strong>AI оценка:</strong><br>
          Успеваемост: <span class="neon-purple">${deliveryAI.successRate}</span><br>
          Препоръка: <span class="neon-pink">${deliveryAI.recommendation}</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="startDelivery">Започни</button>
          <button class="btn" id="backToTransport" style="margin-left:10px;">Назад</button>
          <button class="btn" id="closeTransportPanel" style="margin-left:10px;">Затвори</button>
        </div>
      `;

      Utils.qs("#startDelivery").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.startDelivery(id);
        showTransportPanel();
      });

      Utils.qs("#backToTransport").addEventListener("click", () => {
        showTransportPanel();
      });

      Utils.qs("#closeTransportPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // REFRESH
  // ===============================================
  Utils.qs("#refreshTransport").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showTransportPanel();
  });

  // ===============================================
  // CLOSE
  // ===============================================
  Utils.qs("#closeTransportPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}