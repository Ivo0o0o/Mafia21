// ===============================================
// MAFIA 21st CENTURY — COMBAT UI (PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Бойна система, атаки, защита, критични удари,
// щети, AI бойно поведение.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";

export async function showCombatPanel(enemyId) {
  Utils.log(`Започваме бой с Enemy ID: ${enemyId}`);

  const app = Utils.qs("#app");

  // Премахваме стария панел
  const oldPanel = Utils.qs("#combatPanelDynamic");
  if (oldPanel) oldPanel.remove();

  // Създаваме нов панел
  const panel = Utils.create("div", "panel");
  panel.id = "combatPanelDynamic";

  // Вземаме враг от бекенда
  const enemy = await ApiClient.getEnemy(enemyId);

  // AI бойно поведение
  const ai = Utils.combatAI(enemy);

  panel.innerHTML = `
    <h2>Бой с ${enemy.name}</h2>

    <div class="info-box">
      <strong>Здраве на врага:</strong>
      <span style="color: var(--mafia-red)">${enemy.health}</span>
    </div>

    <div class="info-box">
      <strong>AI бойно поведение:</strong><br>
      Агресия: <span style="color: var(--neon-pink)">${ai.aggression}</span><br>
      Риск: <span style="color: var(--neon-blue)">${ai.risk}</span><br>
      Стратегия: <span style="color: var(--mafia-gold)">${ai.strategy}</span>
    </div>

    <div class="info-box">
      <strong>Твоето здраве:</strong>
      <span id="playerHealth" style="color: var(--neon-purple)">???</span>
    </div>

    <button class="btn" id="attackBtn">Атака</button>
    <button class="btn" id="defendBtn" style="margin-left:10px;">Защита</button>
    <button class="btn" id="escapeBtn" style="margin-left:10px;">Бягство</button>
    <button class="btn" id="closeCombatPanel" style="margin-left:10px;">Затвори</button>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#ff007c");

  // Вземаме здравето на играча
  const player = await ApiClient.getPlayer();
  Utils.qs("#playerHealth").textContent = player.health;

  // -----------------------------------------------
  // АТАКА
  // -----------------------------------------------
  Utils.qs("#attackBtn").addEventListener("click", async () => {
    Utils.neonFlash(panel, "#ff007c");

    const result = await ApiClient.attackEnemy(enemyId);

    panel.innerHTML += `
      <div class="info-box">
        <strong>Ти нанесе щета:</strong>
        <span style="color: var(--mafia-gold)">${result.damage}</span>
      </div>
    `;

    if (result.enemyDefeated) {
      panel.innerHTML += `
        <div class="info-box">
          <strong style="color: var(--neon-blue)">Врагът е победен!</strong>
        </div>
      `;
      return;
    }

    // AI контра-атака
    const counter = await ApiClient.enemyAttack(enemyId);

    panel.innerHTML += `
      <div class="info-box">
        <strong>${enemy.name} контра-атакува:</strong>
        <span style="color: var(--mafia-red)">${counter.damage}</span>
      </div>
    `;

    Utils.qs("#playerHealth").textContent = counter.playerHealth;

    if (counter.playerDefeated) {
      panel.innerHTML += `
        <div class="info-box">
          <strong style="color: var(--mafia-red)">Ти беше победен!</strong>
        </div>
      `;
    }
  });

  // -----------------------------------------------
  // ЗАЩИТА
  // -----------------------------------------------
  Utils.qs("#defendBtn").addEventListener("click", async () => {
    Utils.neonFlash(panel, "#00c8ff");

    const result = await ApiClient.defend(enemyId);

    panel.innerHTML += `
      <div class="info-box">
        <strong>Ти се защити:</strong>
        <span style="color: var(--neon-blue)">${result.block}% блок</span>
      </div>
    `;

    // AI реакция
    const counter = await ApiClient.enemyAttack(enemyId);

    panel.innerHTML += `
      <div class="info-box">
        <strong>${enemy.name} атакува:</strong>
        <span style="color: var(--mafia-red)">${counter.damage}</span>
      </div>
    `;

    Utils.qs("#playerHealth").textContent = counter.playerHealth;
  });

  // -----------------------------------------------
  // БЯГСТВО
  // -----------------------------------------------
  Utils.qs("#escapeBtn").addEventListener("click", async () => {
    Utils.neonFlash(panel, "#9b00ff");

    const escape = await ApiClient.escape(enemyId);

    if (escape.success) {
      panel.innerHTML += `
        <div class="info-box">
          <strong style="color: var(--neon-purple)">Успешно избяга!</strong>
        </div>
      `;
    } else {
      panel.innerHTML += `
        <div class="info-box">
          <strong style="color: var(--mafia-red)">Не успя да избягаш!</strong>
        </div>
      `;
    }
  });

  // -----------------------------------------------
  // CLOSE
  // -----------------------------------------------
  Utils.qs("#closeCombatPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}