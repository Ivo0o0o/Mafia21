// ===============================================
// MAFIA 21st CENTURY — EVENT BUS (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централен event dispatcher за целия свят:
// ✔ глобални събития
// ✔ async dispatch
// ✔ wildcard listeners (*)
// ✔ unsubscribe
// ✔ канали по име
//
// Използва се от:
// ✔ WorldState
// ✔ AIDirector
// ✔ HeatMapEngine
// ✔ TrafficEngine
// ✔ Missions
// ✔ UI Panels
// ✔ AI Engines
// ===============================================

export const EventBus = {
  listeners: {},

  // ---------------------------------------------
  // РЕГИСТРАЦИЯ НА СЛУШАТЕЛ
  // ---------------------------------------------
  on(eventName, callback) {
    if (!this.listeners[eventName]) {
      this.listeners[eventName] = [];
    }
    this.listeners[eventName].push(callback);

    return () => this.off(eventName, callback); // auto-unsubscribe handle
  },

  // ---------------------------------------------
  // ОТКАЗ ОТ СЛУШАТЕЛ
  // ---------------------------------------------
  off(eventName, callback) {
    if (!this.listeners[eventName]) return;

    this.listeners[eventName] = this.listeners[eventName].filter(
      cb => cb !== callback
    );
  },

  // ---------------------------------------------
  // ИЗПРАЩА СЪБИТИЕ (ASYNC)
  // ---------------------------------------------
  emit(eventName, payload = {}) {
    const calls = [];

    // Точни listeners
    if (this.listeners[eventName]) {
      calls.push(...this.listeners[eventName]);
    }

    // Wildcard listeners: "*"
    if (this.listeners["*"]) {
      calls.push(...this.listeners["*"]);
    }

    // Изпълнява всички listeners асинхронно
    calls.forEach(cb => {
      setTimeout(() => cb({ event: eventName, payload }), 0);
    });
  }
};