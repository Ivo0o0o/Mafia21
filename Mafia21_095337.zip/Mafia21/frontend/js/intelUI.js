// ===============================================
// MAFIA 21st CENTURY — INTEL NETWORK UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Разузнаване, информатори, наблюдение,
// AI анализ, риск, мрежи, операции.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showIntelPanel() {
  Utils.log("Зареждаме Intel Network панела…");

  const app = Utils.qs("#app");

  // Премахваме стар панел
  const oldPanel = Utils.qs("#intelPanelDynamic");
  if (oldPanel) oldPanel.remove();

  // Създаваме нов панел
  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "intelPanelDynamic";

  // Данни от бекенда
  const intel = await ApiClient.getIntelOverview();
  const informers = await ApiClient.getInformers();
  const operations = await ApiClient.getIntelOperations();

  // AI анализ
  const ai = AICore.intelAI({ intel, informers, operations });

  // ===============================================
  // MAIN PANEL TEMPLATE
  // ===============================================
  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-intel" style="margin-right:8px;"></span>
      Intel Network — Разузнаване и AI анализ
    </div>

    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Ниво на информираност:</strong>
      <span class="neon-blue">${ai.intelLevel}</span><br>

      <strong>Най-рискова зона:</strong>
      <span class="neon-red">${ai.hotZone}</span><br>

      <strong>Най-ценен информатор:</strong>
      <span class="neon-gold">${ai.bestInformer}</span><br>

      <strong>Прогноза:</strong>
      <span class="neon-purple">${ai.forecast}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-pink">${ai.recommendation}</span>
    </div>

    <div class="section-title">Мрежа за разузнаване</div>
    <div class="info-box">
      <strong>Обхват:</strong>
      <span class="neon-gold">${intel.coverage}</span><br>

      <strong>Активни точки:</strong>
      <span class="neon-blue">${intel.activeNodes}</span><br>

      <strong>Риск:</strong>
      <span class="neon-purple">${intel.risk}</span><br>

      <strong>Описание:</strong>
      <div>${intel.description}</div>
    </div>

    <div class="section-title">Информатори</div>
    <div id="informersList">
      ${
        informers.length === 0
          ? `<div class="info-box">Няма информатори.</div>`
          : informers
              .map(
                i => `
        <div class="info-box informer-entry" data-id="${i._id}" style="cursor:pointer;">
          <div class="informer-title">${i.name}</div>

          <div class="informer-meta">
            <span>Лоялност: <span class="neon-gold">${i.loyalty}</span></span>
            <span>Достъп: <span class="neon-blue">${i.access}</span></span>
            <span>Риск: <span class="neon-red">${i.risk}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <div class="section-title">Операции</div>
    <div id="operationsList">
      ${
        operations.length === 0
          ? `<div class="info-box">Няма активни операции.</div>`
          : operations
              .map(
                o => `
        <div class="info-box operation-entry" data-id="${o._id}" style="cursor:pointer;">
          <div class="operation-title">${o.name}</div>

          <div class="operation-meta">
            <span>Статус: <span class="neon-blue">${o.status}</span></span>
            <span>Риск: <span class="neon-red">${o.risk}</span></span>
            <span>Награда: <span class="neon-gold">${Utils.formatMoney(o.reward)}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <div class="panel-buttons">
      <button class="btn" id="refreshIntel">Обнови</button>
      <button class="btn" id="closeIntelPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00ff9d");

  // ===============================================
  // CLICK → Детайли за информатор
  // ===============================================
  panel.querySelectorAll("#informersList .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const informer = await ApiClient.getInformer(id);

      Utils.neonFlash(box, "#ff007c");

      const informerAI = AICore.informerAI(informer);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-intel" style="margin-right:8px;"></span>
          Информатор — ${informer.name}
        </div>

        <div class="info-box">
          <strong>Лоялност:</strong>
          <span class="neon-gold">${informer.loyalty}</span><br>

          <strong>Достъп:</strong>
          <span class="neon-blue">${informer.access}</span><br>

          <strong>Риск:</strong>
          <span class="neon-red">${informer.risk}</span><br>

          <strong>AI оценка:</strong><br>
          Надеждност: <span class="neon-gold">${informerAI.reliability}</span><br>
          Препоръка: <span class="neon-pink">${informerAI.recommendation}</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="recruitInformer">Вербувай</button>
          <button class="btn" id="backToIntel" style="margin-left:10px;">Назад</button>
          <button class="btn" id="closeIntelPanel" style="margin-left:10px;">Затвори</button>
        </div>
      `;

      Utils.qs("#recruitInformer").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.recruitInformer(id);
        showIntelPanel();
      });

      Utils.qs("#backToIntel").addEventListener("click", () => {
        showIntelPanel();
      });

      Utils.qs("#closeIntelPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // CLICK → Детайли за операция
  // ===============================================
  panel.querySelectorAll("#operationsList .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const operation = await ApiClient.getIntelOperation(id);

      Utils.neonFlash(box, "#9b00ff");

      const operationAI = AICore.operationAI(operation);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-intel" style="margin-right:8px;"></span>
          Операция — ${operation.name}
        </div>

        <div class="info-box">
          <strong>Статус:</strong>
          <span class="neon-blue">${operation.status}</span><br>

          <strong>Риск:</strong>
          <span class="neon-red">${operation.risk}</span><br>

          <strong>Награда:</strong>
          <span class="neon-gold">${Utils.formatMoney(operation.reward)}</span><br>

          <strong>AI оценка:</strong><br>
          Успеваемост: <span class="neon-gold">${operationAI.successRate}</span><br>
          Препоръка: <span class="neon-pink">${operationAI.recommendation}</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="startOperation">Започни</button>
          <button class="btn" id="backToIntel" style="margin-left:10px;">Назад</button>
          <button class="btn" id="closeIntelPanel" style="margin-left:10px;">Затвори</button>
        </div>
      `;

      Utils.qs("#startOperation").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.startIntelOperation(id);
        showIntelPanel();
      });

      Utils.qs("#backToIntel").addEventListener("click", () => {
        showIntelPanel();
      });

      Utils.qs("#closeIntelPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // REFRESH
  // ===============================================
  Utils.qs("#refreshIntel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showIntelPanel();
  });

  // ===============================================
  // CLOSE
  // ===============================================
  Utils.qs("#closeIntelPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}