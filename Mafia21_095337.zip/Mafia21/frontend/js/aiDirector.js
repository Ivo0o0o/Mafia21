// ===============================================
// MAFIA 21st CENTURY — AI DIRECTOR (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централен мозък на всички AI системи:
// ✔ NPC AI
// ✔ Combat AI
// ✔ Mission AI
// ✔ Territory AI
// ✔ Economy AI
// ✔ Weapon Market AI
// ✔ Drug Lab AI
// ✔ Safehouse Security AI
// ✔ Intel Network AI
//
// Диригент на цялата AI екосистема.
// ===============================================

import { AICore } from "./aiCore.js";

import { aiGangWarEngine } from "./aiGangWarEngine.js";
import { aiTerritoryControl } from "./aiTerritoryControl.js";
import { aiEconomyExpansion } from "./aiEconomyExpansion.js";
import { aiWeaponMarketEngine } from "./aiWeaponMarketEngine.js";
import { aiDrugLabEngine } from "./aiDrugLabEngine.js";
import { aiSafehouseSecurity } from "./aiSafehouseSecurity.js";
import { aiIntelNetwork } from "./aiIntelNetwork.js";

import { PlayerStatsCore } from "./playerStatsCore.js";
import { Utils } from "./utils.js";
import { EventBus } from "./eventBus.js"; // ⭐ добавено

export const AIDirector = {
  interval: null,
  rate: 4000, // AI работи на всеки 4 секунди

  async init() {
    Utils.log("AIDirector — стартиране...");

    // ⭐ изпращаме събитие за стартиране
    EventBus.emit("ai_director_started", { rate: this.rate });

    // Автоматичен AI loop
    this.interval = setInterval(() => this.tick(), this.rate);

    Utils.log("AIDirector — активен.");
  },

  async tick() {
    try {
      const player = PlayerStatsCore.get();

      // ⭐ глобален AI tick
      EventBus.emit("ai_tick", { player });

      // ============================================
      // NPC AI — поведение на граждани, гангстери, NPC
      // ============================================
      AICore.npcBehavior();
      EventBus.emit("ai_decision", { system: "npcBehavior" });

      // ============================================
      // Combat AI — реакции на полиция, банди, NPC
      // ============================================
      AICore.combatAI(player);
      EventBus.emit("ai_decision", { system: "combatAI" });

      // ============================================
      // Mission AI — трудност, риск, шанс за успех
      // ============================================
      AICore.missionAI({
        level: player.level,
        heat: player.heat,
        reputation: player.reputation
      });
      EventBus.emit("ai_decision", { system: "missionAI" });

      // ============================================
      // Territory AI — контрол, конфликти, разширяване
      // ============================================
      await aiTerritoryControl.simulate();
      EventBus.emit("ai_decision", { system: "territoryAI" });

      // ============================================
      // Gang War AI — войни, атаки, защита
      // ============================================
      await aiGangWarEngine.simulate();
      EventBus.emit("ai_decision", { system: "gangWarAI" });

      // ============================================
      // Economy AI — пазари, цени, влияние
      // ============================================
      await aiEconomyExpansion.simulate();
      EventBus.emit("ai_decision", { system: "economyAI" });

      // ============================================
      // Weapon Market AI — оръжия, доставки, цени
      // ============================================
      await aiWeaponMarketEngine.simulate();
      EventBus.emit("ai_decision", { system: "weaponMarketAI" });

      // ============================================
      // Drug Lab AI — производство, риск, печалба
      // ============================================
      await aiDrugLabEngine.simulate();
      EventBus.emit("ai_decision", { system: "drugLabAI" });

      // ============================================
      // Safehouse Security AI — защита, риск, нападения
      // ============================================
      await aiSafehouseSecurity.simulate();
      EventBus.emit("ai_decision", { system: "safehouseSecurityAI" });

      // ============================================
      // Intel Network AI — информация, шпионаж, риск
      // ============================================
      await aiIntelNetwork.simulate();
      EventBus.emit("ai_decision", { system: "intelNetworkAI" });

      Utils.log("AIDirector — tick завършен.");

    } catch (err) {
      console.error("❌ AIDirector ERROR:", err);

      // ⭐ изпращаме събитие за грешка
      EventBus.emit("ai_error", { error: err });
    }
  }
};

// Автоматично стартиране
AIDirector.init();