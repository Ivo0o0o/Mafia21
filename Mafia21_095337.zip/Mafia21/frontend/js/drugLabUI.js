// ===============================================
// MAFIA 21st CENTURY — DRUG LAB UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Производство, качество, риск, печалба,
// AI анализ, оптимизация, рецепти.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showDrugLabPanel() {
  Utils.log("Зареждаме Drug Lab панела…");

  const app = Utils.qs("#app");

  // Премахваме стар панел
  const oldPanel = Utils.qs("#drugLabPanelDynamic");
  if (oldPanel) oldPanel.remove();

  // Създаваме нов панел
  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "drugLabPanelDynamic";

  // Данни от бекенда
  const lab = await ApiClient.getDrugLab();
  const recipes = await ApiClient.getDrugRecipes();
  const materials = await ApiClient.getDrugMaterials();

  // AI анализ
  const ai = AICore.drugLabAI({ lab, recipes, materials });

  // ===============================================
  // MAIN PANEL TEMPLATE
  // ===============================================
  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-druglab" style="margin-right:8px;"></span>
      Лаборатория — Производство и AI анализ
    </div>

    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Най-печеливша рецепта:</strong>
      <span class="neon-gold">${ai.bestRecipe}</span><br>

      <strong>Най-рисков материал:</strong>
      <span class="neon-red">${ai.mostDangerousMaterial}</span><br>

      <strong>Най-ефективна комбинация:</strong>
      <span class="neon-blue">${ai.bestCombo}</span><br>

      <strong>Прогноза:</strong>
      <span class="neon-purple">${ai.forecast}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-pink">${ai.recommendation}</span>
    </div>

    <div class="section-title">Рецепти</div>
    <div id="recipeList">
      ${
        recipes.length === 0
          ? `<div class="info-box">Няма рецепти.</div>`
          : recipes
              .map(
                r => `
        <div class="info-box recipe-entry" data-id="${r._id}" style="cursor:pointer;">
          <div class="recipe-title">${r.name}</div>

          <div class="recipe-meta">
            <span>Печалба: <span class="neon-gold">${Utils.formatMoney(r.profit)}</span></span>
            <span>Риск: <span class="neon-red">${r.risk}</span></span>
            <span>Време: <span class="neon-blue">${r.time} мин</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <div class="section-title">Материали</div>
    <div id="materialList">
      ${
        materials.length === 0
          ? `<div class="info-box">Няма материали.</div>`
          : materials
              .map(
                m => `
        <div class="info-box material-entry" data-id="${m._id}" style="cursor:pointer;">
          <div class="material-title">${m.name}</div>

          <div class="material-meta">
            <span>Цена: <span class="neon-gold">${Utils.formatMoney(m.price)}</span></span>
            <span>Риск: <span class="neon-red">${m.risk}</span></span>
            <span>Качество: <span class="neon-blue">${m.quality}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <div class="panel-buttons">
      <button class="btn" id="refreshDrugLab">Обнови</button>
      <button class="btn" id="closeDrugLabPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // ===============================================
  // CLICK → Детайли за рецепта
  // ===============================================
  panel.querySelectorAll("#recipeList .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const recipe = await ApiClient.getDrugRecipe(id);

      Utils.neonFlash(box, "#ff007c");

      const recipeAI = AICore.singleRecipeAI(recipe);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-druglab" style="margin-right:8px;"></span>
          Рецепта — ${recipe.name}
        </div>

        <div class="info-box">
          <strong>Печалба:</strong>
          <span class="neon-gold">${Utils.formatMoney(recipe.profit)}</span><br>

          <strong>Риск:</strong>
          <span class="neon-red">${recipe.risk}</span><br>

          <strong>Време:</strong>
          <span class="neon-blue">${recipe.time} мин</span><br>

          <strong>AI оценка:</strong><br>
          Ефективност: <span class="neon-purple">${recipeAI.efficiency}</span><br>
          Препоръка: <span class="neon-pink">${recipeAI.recommendation}</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="startRecipe">Започни производство</button>
          <button class="btn" id="backToDrugLab" style="margin-left:10px;">Назад</button>
          <button class="btn" id="closeDrugLabPanel" style="margin-left:10px;">Затвори</button>
        </div>
      `;

      Utils.qs("#startRecipe").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.startDrugRecipe(id);
        showDrugLabPanel();
      });

      Utils.qs("#backToDrugLab").addEventListener("click", () => {
        showDrugLabPanel();
      });

      Utils.qs("#closeDrugLabPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // CLICK → Детайли за материал
  // ===============================================
  panel.querySelectorAll("#materialList .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const material = await ApiClient.getDrugMaterial(id);

      Utils.neonFlash(box, "#9b00ff");

      const materialAI = AICore.singleMaterialAI(material);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-druglab" style="margin-right:8px;"></span>
          Материал — ${material.name}
        </div>

        <div class="info-box">
          <strong>Цена:</strong>
          <span class="neon-gold">${Utils.formatMoney(material.price)}</span><br>

          <strong>Риск:</strong>
          <span class="neon-red">${material.risk}</span><br>

          <strong>Качество:</strong>
          <span class="neon-blue">${material.quality}</span><br>

          <strong>AI оценка:</strong><br>
          Ефективност: <span class="neon-purple">${materialAI.efficiency}</span><br>
          Препоръка: <span class="neon-pink">${materialAI.recommendation}</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="buyMaterial">Купи</button>
          <button class="btn" id="backToDrugLab" style="margin-left:10px;">Назад</button>
          <button class="btn" id="closeDrugLabPanel" style="margin-left:10px;">Затвори</button>
        </div>
      `;

      Utils.qs("#buyMaterial").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.buyDrugMaterial(id);
        showDrugLabPanel();
      });

      Utils.qs("#backToDrugLab").addEventListener("click", () => {
        showDrugLabPanel();
      });

      Utils.qs("#closeDrugLabPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // REFRESH
  // ===============================================
  Utils.qs("#refreshDrugLab").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showDrugLabPanel();
  });

  // ===============================================
  // CLOSE
  // ===============================================
  Utils.qs("#closeDrugLabPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}