// ===============================================
// MAFIA 21st CENTURY — ORGANIZATION UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Организация, членове, рангове, влияние,
// доходи, AI анализ, AI препоръки,
// автоматично зареждане.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showOrganizationPanel() {
  Utils.log("Зареждаме Организацията…");

  const app = Utils.qs("#app");

  const oldPanel = Utils.qs("#organizationPanelDynamic");
  if (oldPanel) oldPanel.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "organizationPanelDynamic";

  // Вземаме организацията
  const org = await ApiClient.getOrganization() || {};
  const members = org.members || [];

  // AI анализ на организацията
  const ai = AICore.organizationAI(org);

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-organization" style="margin-right:8px;"></span>
      Организация — AI Контрол
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Общ Анализ</div>
    <div class="info-box">
      <strong>Влияние:</strong>
      <span class="neon-blue">${ai.influence}</span><br>

      <strong>Репутация:</strong>
      <span class="neon-gold">${ai.reputation}</span><br>

      <strong>Доходи:</strong>
      <span class="neon-purple">${ai.income} 💶</span><br>

      <strong>Стабилност:</strong>
      <span class="neon-red">${ai.stability}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-pink">${ai.recommendation}</span>
    </div>

    <!-- MEMBERS LIST -->
    <div class="section-title">Членове</div>
    <div id="organizationMembersList">
      ${
        members.length === 0
          ? `<div class="info-box">Няма членове в организацията.</div>`
          : members
              .map(
                m => `
        <div class="info-box member-entry" data-id="${m._id}" style="cursor:pointer;">
          <strong>${m.name}</strong><br>
          Ранг: <span class="neon-blue">${m.rank}</span><br>
          Лоялност: <span class="neon-gold">${m.loyalty}%</span><br>
          Ефективност: <span class="neon-purple">${m.efficiency}%</span>
        </div>
      `
              )
              .join("")
      }
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshOrganization">Обнови</button>
      <button class="btn" id="closeOrganizationPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // -----------------------------------------------
  // CLICK → Детайли за член + AI анализ
  // -----------------------------------------------
  panel.querySelectorAll("#organizationMembersList .member-entry").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const member = members.find(m => m._id === id);

      Utils.neonFlash(box, "#ff007c");

      const aiMember = AICore.memberAI(member);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-organization" style="margin-right:8px;"></span>
          ${member.name}
        </div>

        <div class="section-title">AI Анализ</div>
        <div class="info-box">
          <strong>Лоялност:</strong>
          <span class="neon-gold">${aiMember.loyalty}%</span><br>

          <strong>Ефективност:</strong>
          <span class="neon-purple">${aiMember.efficiency}%</span><br>

          <strong>Риск:</strong>
          <span class="neon-red">${aiMember.risk}%</span><br>

          <strong>Препоръка:</strong>
          <span class="neon-blue">${aiMember.recommendation}</span>
        </div>

        <div class="section-title">Настройки</div>
        <div class="info-box">
          <label>Лоялност:</label>
          <input type="range" id="memberLoyalty" min="0" max="100" value="${member.loyalty}" />
          <br>
          <label>Ефективност:</label>
          <input type="range" id="memberEfficiency" min="0" max="100" value="${member.efficiency}" />
        </div>

        <div class="panel-buttons">
          <button class="btn" id="applyMemberSettings">Приложи</button>
          <button class="btn" id="backToOrganization">Назад</button>
          <button class="btn" id="closeOrganizationPanel">Затвори</button>
        </div>
      `;

      // APPLY MEMBER SETTINGS
      Utils.qs("#applyMemberSettings").addEventListener("click", async () => {
        const loyalty = Number(Utils.qs("#memberLoyalty").value);
        const efficiency = Number(Utils.qs("#memberEfficiency").value);

        Utils.neonFlash(panel, "#00c8ff");

        await ApiClient.updateMember(id, {
          loyalty,
          efficiency
        });

        showOrganizationPanel();
      });

      // BACK
      Utils.qs("#backToOrganization").addEventListener("click", () => {
        showOrganizationPanel();
      });

      // CLOSE
      Utils.qs("#closeOrganizationPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // REFRESH
  Utils.qs("#refreshOrganization").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showOrganizationPanel();
  });

  // CLOSE
  Utils.qs("#closeOrganizationPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}