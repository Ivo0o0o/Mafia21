// ===============================================
// MAFIA 21st CENTURY — WORLD CINEMATIC ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Камера движения, zoom, shake, cutscenes,
// ефекти при събития, престъпления, буря.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

export function initWorldCinematicEngine() {
  Utils.log("World Cinematic Engine стартира…");

  const canvas = Utils.qs("#cinematicCanvas");
  const ctx = canvas.getContext("2d");

  resizeCanvas(canvas);

  const CamState = {
    x: 0,
    y: 0,
    zoom: 1,
    shakeIntensity: 0,
    shakeTime: 0,
    cutsceneActive: false,
    cutsceneStep: 0
  };

  // ===============================================
  // MAIN CINEMATIC LOOP
  // ===============================================
  setInterval(async () => {
    const events = await ApiClient.getWorldEventsPulse();
    const crime = await ApiClient.getCrimePulse();
    const weather = await ApiClient.getWeather();

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // ===============================================
    // CAMERA SHAKE (експлозии, престъпления, буря)
    // ===============================================
    if (crime.level > 80 || weather.type === "storm") {
      CamState.shakeIntensity = 10;
      CamState.shakeTime = 10;
    }

    if (CamState.shakeTime > 0) {
      CamState.shakeTime--;
      CamState.x = (Math.random() - 0.5) * CamState.shakeIntensity;
      CamState.y = (Math.random() - 0.5) * CamState.shakeIntensity;
    } else {
      CamState.x = 0;
      CamState.y = 0;
    }

    // ===============================================
    // CAMERA ZOOM (при събития)
    // ===============================================
    if (events.count > 0) {
      CamState.zoom = 1.2;
    } else {
      CamState.zoom = 1;
    }

    // ===============================================
    // CUTSCENE TRIGGER
    // ===============================================
    if (events.latest === "legendary_item_drop") {
      CamState.cutsceneActive = true;
      CamState.cutsceneStep = 0;
    }

    if (CamState.cutsceneActive) {
      playCutscene(ctx, CamState);
    }

    // ===============================================
    // DRAW CINEMATIC OVERLAY
    // ===============================================
    drawCinematicOverlay(ctx, CamState);

  }, 100); // smooth cinematic loop

  Utils.log("World Cinematic Engine работи.");
}

// ===============================================
// CANVAS RESIZE
// ===============================================
function resizeCanvas(canvas) {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}

// ===============================================
// CUTSCENE LOGIC
// ===============================================
function playCutscene(ctx, cam) {
  cam.cutsceneStep++;

  ctx.fillStyle = "rgba(0,0,0,0.5)";
  ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);

  ctx.fillStyle = "white";
  ctx.font = "40px Arial";
  ctx.fillText("Легендарен предмет се появи!", 50, 100);

  if (cam.cutsceneStep > 50) {
    cam.cutsceneActive = false;
  }
}

// ===============================================
// CINEMATIC OVERLAY
// ===============================================
function drawCinematicOverlay(ctx, cam) {
  ctx.save();
  ctx.translate(cam.x, cam.y);
  ctx.scale(cam.zoom, cam.zoom);

  ctx.fillStyle = "rgba(0,0,0,0.2)";
  ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);

  ctx.restore();
}