// ===============================================
// MAFIA 21st CENTURY — GAME MAIN CONTROLLER (ULTRA PRO MAX)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Главен контролер на фронтенда — стартира играта,
// зарежда UI, карта, AI, HUB, Game Engine,
// World Simulation, Player Progression, EventBus.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

import { initGameUI, initSidebar } from "./gameUI.js";
import { initMapUI } from "./mapUI.js";

import { GameEngine } from "./gameEngine.js";
import { WorldSimulation } from "./worldSimulation.js";

// ❗ ВАЖНО: използваме hub.js, не HUD.js
import { HUD } from "./hub.js";

import { PlayerProgression } from "./playerProgression.js";

// ⭐ NEW MODULES
import { WorldClock } from "./worldClock.js";
import { PlayerStatsCore } from "./playerStatsCore.js";
import { worldMapEngine } from "./worldMapEngine.js";
import { worldHeatMapEngine } from "./worldHeatMapEngine.js";
import { worldGangTerritoryEngine } from "./worldGangTerritoryEngine.js";
import { EventBus } from "./eventBus.js";

export async function startGame() {
  Utils.log("Играта стартира…");

  // -----------------------------------------------
  // HEALTH CHECK
  // -----------------------------------------------
  const health = await ApiClient.health();
  Utils.log(`Backend status: ${health.server}`);

  // -----------------------------------------------
  // DISTRICTS
  // -----------------------------------------------
  const districts = await ApiClient.getDistricts();
  Utils.log(`Заредени райони: ${districts.length}`);

  // -----------------------------------------------
  // PLAYER INFO
  // -----------------------------------------------
  const player = await PlayerProgression.load();
  Utils.log(`Играч: ${player.username} | Ниво: ${player.level} | Титла: ${player.title}`);

  // -----------------------------------------------
  // MINI AI START REACTION
  // -----------------------------------------------
  const aiState = Utils.npcBehaviorAI();
  Utils.log(`NPC AI стартово състояние: ${aiState.emotion} / ${aiState.decision}`);

  // -----------------------------------------------
  // UI INIT
  // -----------------------------------------------
  initGameUI(health, aiState);

  // -----------------------------------------------
  // SIDEBAR INIT
  // -----------------------------------------------
  initSidebar();

  // -----------------------------------------------
  // MAP INIT
  // -----------------------------------------------
  initMapUI(districts);

  // -----------------------------------------------
  // HUB INIT (неонов HUD)
  // -----------------------------------------------
  HUD.init();
  Utils.log("NEON HUB е активиран.");

  // -----------------------------------------------
  // GAME ENGINE
  // -----------------------------------------------
  GameEngine.start();
  Utils.log("Game Engine Core стартира.");

  // -----------------------------------------------
  // WORLD SIMULATION
  // -----------------------------------------------
  WorldSimulation.start();
  Utils.log("World Simulation стартира.");

  // -----------------------------------------------
  // NEON EFFECT
  // -----------------------------------------------
  const app = Utils.qs("#app");
  Utils.neonPulse(app, "#9b00ff");

  Utils.log("Играта е напълно заредена и работи.");

  // ============================================================
  // ⭐ ULTRA PRO MAX — ДОБАВЕНИ НОВИ МОДУЛИ
  // ============================================================

  // WORLD CLOCK
  Utils.log("WorldClock — активиране…");
  WorldClock.init();

  // PLAYER STATS CORE
  Utils.log("PlayerStatsCore — зареждане…");
  PlayerStatsCore.init();

  // WORLD MAP ENGINE
  Utils.log("WorldMapEngine — стартиране…");
  worldMapEngine.simulate();

  // HEAT MAP ENGINE
  Utils.log("HeatMapEngine — стартиране…");
  worldHeatMapEngine.simulate();

  // TERRITORY ENGINE
  Utils.log("TerritoryEngine — стартиране…");
  worldGangTerritoryEngine.simulate();

  // EVENTBUS START SIGNAL
  EventBus.emit("game_started", {
    player,
    districts,
    aiState,
    time: WorldClock.getTime()
  });

  Utils.log("ULTRA PRO MAX — всички системи са активни.");
}