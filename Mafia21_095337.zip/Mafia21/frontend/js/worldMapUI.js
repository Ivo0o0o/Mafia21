// ===============================================
// MAFIA 21st CENTURY — WORLD MAP UI (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// UI панел за визуализация на:
// ✔ трафик
// ✔ престъпност
// ✔ heat
// ✔ територии
// ✔ събития
// ✔ динамични слоеве
// ===============================================

import { EventBus } from "./eventBus.js";
import { Utils } from "./utils.js";

export const WorldMapUI = {
  state: {
    districts: [],
    traffic: [],
    crime: [],
    heat: [],
    territories: [],
    events: [],
    activeLayer: "none"
  },

  init() {
    Utils.log("WorldMapUI — активиран.");

    // Основно обновяване
    EventBus.on("world_map_update", data => {
      this.state.districts = data.districts;
      this.state.traffic = data.traffic;
      this.state.crime = data.crime;
      this.state.heat = data.heat;
      this.state.territories = data.territories;
      this.state.events = data.events;

      this.render();
    });

    // Обновяване на слоеве
    EventBus.on("world_map_layer_update", ({ layer, data }) => {
      this.state.activeLayer = layer;
      this.state[layer] = data;
      this.renderLayer(layer);
    });

    // Грешки
    EventBus.on("world_map_error", err => {
      console.error("❌ WorldMapUI ERROR:", err);
    });
  },

  render() {
    // Основно визуализиране на картата
    Utils.log("WorldMapUI — render()");
    // Тук добавяш твоя DOM/Canvas/Mapbox/Leaflet логика
  },

  renderLayer(layer) {
    Utils.log(`WorldMapUI — renderLayer(${layer})`);
    // Тук визуализираш конкретния слой
    // Пример: heat overlay, crime dots, traffic lines, territory borders
  }
};