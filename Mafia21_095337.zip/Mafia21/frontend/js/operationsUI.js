// ===============================================
// MAFIA 21st CENTURY — OPERATIONS COMMAND UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Мисии, операции, екипи, риск,
// AI анализ, контрол, изпълнение.
// ===============================================

import { Utils } from "./utils.js";
import { OperationsNetwork } from "./operationsNetwork.js";
import { OperationsAICore } from "./operationsAICore.js";

export async function showOperationsPanel() {
  Utils.log("Зареждаме Operations панела…");

  const app = Utils.qs("#app");

  const oldPanel = Utils.qs("#operationsPanelDynamic");
  if (oldPanel) oldPanel.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "operationsPanelDynamic";

  const operations = await OperationsNetwork.getOperations();
  const teams = await OperationsNetwork.getTeams();

  const ai = OperationsAICore.operationsAI({ operations, teams });

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-operations" style="margin-right:8px;"></span>
      Операции — Команден център и AI анализ
    </div>

    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Общо операции:</strong>
      <span class="neon-gold">${ai.totalOps}</span><br>

      <strong>Активни:</strong>
      <span class="neon-blue">${ai.activeOps}</span><br>

      <strong>Успешни:</strong>
      <span class="neon-green">${ai.successOps}</span><br>

      <strong>Провалени:</strong>
      <span class="neon-red">${ai.failedOps}</span><br>

      <strong>Среден риск:</strong>
      <span class="neon-purple">${ai.avgRisk}</span><br>

      <strong>Най-добра операция по награда:</strong>
      <span class="neon-gold">${ai.topRewardOpName}</span><br>

      <strong>Прогноза:</strong>
      <span class="neon-purple">${ai.forecast}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-pink">${ai.recommendation}</span>
    </div>

    <div class="section-title">Операции</div>
    <div id="operationList">
      ${
        operations.length === 0
          ? `<div class="info-box">Няма налични операции.</div>`
          : operations
              .map(
                o => `
        <div class="info-box operation-entry" data-id="${o._id}" style="cursor:pointer;">
          <div class="operation-title">${o.name}</div>

          <div class="operation-meta">
            <span>Статус: <span class="neon-blue">${o.status}</span></span>
            <span>Риск: <span class="neon-red">${o.risk}</span></span>
            <span>Награда: <span class="neon-gold">${Utils.formatMoney(
              o.reward
            )}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <div class="section-title">Екипи</div>
    <div id="teamList">
      ${
        teams.length === 0
          ? `<div class="info-box">Няма налични екипи.</div>`
          : teams
              .map(
                t => `
        <div class="info-box team-entry" data-id="${t._id}" style="cursor:pointer;">
          <div class="team-title">${t.name}</div>

          <div class="team-meta">
            <span>Сила: <span class="neon-red">${t.power}</span></span>
            <span>Опит: <span class="neon-blue">${t.experience}</span></span>
            <span>Надеждност: <span class="neon-purple">${t.reliability}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <div class="panel-buttons">
      <button class="btn" id="refreshOperations">Обнови</button>
      <button class="btn" id="closeOperationsPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // CLICK → Детайли за операция
  panel.querySelectorAll("#operationList .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const operation = await OperationsNetwork.getOperation(id);

      Utils.neonFlash(box, "#ff007c");

      const opAI = OperationsAICore.operationAI(operation);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-operations" style="margin-right:8px;"></span>
          Операция — ${operation.name}
        </div>

        <div class="info-box">
          <strong>Статус:</strong>
          <span class="neon-blue">${operation.status}</span><br>

          <strong>Риск:</strong>
          <span class="neon-red">${operation.risk}</span><br>

          <strong>Награда:</strong>
          <span class="neon-gold">${Utils.formatMoney(operation.reward)}</span><br>

          <strong>Продължителност:</strong>
          <span class="neon-purple">${operation.duration} мин.</span><br>

          <strong>AI оценка:</strong><br>
          Ефективност: <span class="neon-gold">${opAI.efficiency}</span><br>
          Препоръка: <span class="neon-pink">${opAI.recommendation}</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="startOperation">Стартирай</button>
          <button class="btn" id="cancelOperation" style="margin-left:10px;">Отмени</button>
          <button class="btn" id="backToOperations" style="margin-left:10px;">Назад</button>
          <button class="btn" id="closeOperationsPanel" style="margin-left:10px;">Затвори</button>
        </div>
      `;

      Utils.qs("#startOperation").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await OperationsNetwork.startOperation(id);
        showOperationsPanel();
      });

      Utils.qs("#cancelOperation").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#ff007c");
        await OperationsNetwork.cancelOperation(id);
        showOperationsPanel();
      });

      Utils.qs("#backToOperations").addEventListener("click", () => {
        showOperationsPanel();
      });

      Utils.qs("#closeOperationsPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // CLICK → Детайли за екип
  panel.querySelectorAll("#teamList .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const team = await OperationsNetwork.getTeam(id);

      Utils.neonFlash(box, "#9b00ff");

      const teamAI = OperationsAICore.teamAI(team);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-operations" style="margin-right:8px;"></span>
          Екип — ${team.name}
        </div>

        <div class="info-box">
          <strong>Сила:</strong>
          <span class="neon-red">${team.power}</span><br>

          <strong>Опит:</strong>
          <span class="neon-blue">${team.experience}</span><br>

          <strong>Надеждност:</strong>
          <span class="neon-purple">${team.reliability}</span><br>

          <strong>AI оценка:</strong><br>
          Ефективност: <span class="neon-gold">${teamAI.efficiency}</span><br>
          Препоръка: <span class="neon-pink">${teamAI.recommendation}</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="backToOperations">Назад</button>
          <button class="btn" id="closeOperationsPanel" style="margin-left:10px;">Затвори</button>
        </div>
      `;

      Utils.qs("#backToOperations").addEventListener("click", () => {
        showOperationsPanel();
      });

      Utils.qs("#closeOperationsPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // REFRESH
  Utils.qs("#refreshOperations").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showOperationsPanel();
  });

  // CLOSE
  Utils.qs("#closeOperationsPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}