// ===============================================
// MAFIA 21st CENTURY — AI GANG WAR ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Анализ на банди, територии, риск,
// прогнози, симулации, препоръки.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";

export const aiGangWarEngine = {
  async analyze() {
    const gangs = await ApiClient.getGangs();
    const territories = await ApiClient.getTerritories();
    const heat = await ApiClient.getHeatLevels();

    const result = {
      strongestGang: null,
      weakestGang: null,
      mostContestedTerritory: null,
      warForecast: "",
      recommendation: ""
    };

    // Най-силна банда
    result.strongestGang = gangs.sort((a, b) => b.power - a.power)[0]?.name;

    // Най-слаба банда
    result.weakestGang = gangs.sort((a, b) => a.power - b.power)[0]?.name;

    // Най-оспорвана територия
    result.mostContestedTerritory = territories.sort((a, b) => b.conflict - a.conflict)[0]?.name;

    // Прогноза
    const heatAvg = heat.reduce((a, b) => a + b.level, 0) / heat.length;
    result.warForecast =
      heatAvg > 70
        ? "Очаква се масивен сблъсък между банди."
        : heatAvg > 40
        ? "Напрежението расте, възможни локални конфликти."
        : "Ситуацията е спокойна, но нестабилна.";

    // Препоръка
    if (heatAvg > 70) {
      result.recommendation = "Укрепи териториите и подготви охрана.";
    } else if (heatAvg > 40) {
      result.recommendation = "Разшири влиянието си в слабите зони.";
    } else {
      result.recommendation = "Време е за стратегическо разширение.";
    }

    Utils.log("AI Gang War Engine — анализ завършен.");
    return result;
  }
};