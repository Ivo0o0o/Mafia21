// ===============================================
// MAFIA 21st CENTURY — PLAYER UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Статистики, прогресия, умения, мисии,
// heat, пари, AI анализ, прогнози, препоръки.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showPlayerPanel() {
  Utils.log("Зареждаме Player панела…");

  const app = Utils.qs("#app");

  const oldPanel = Utils.qs("#playerPanelDynamic");
  if (oldPanel) oldPanel.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "playerPanelDynamic";

  // Данни за играча
  const player = await ApiClient.getPlayer();
  const skills = await ApiClient.getSkills();
  const missions = await ApiClient.getMissions();

  // AI анализ
  const ai = AICore.playerAI({
    player,
    skills,
    missions
  });

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-player" style="margin-right:8px;"></span>
      Играч — Профил и Прогресия
    </div>

    <!-- AI ANALYSIS -->
    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Стил на игра:</strong>
      <span class="neon-blue">${ai.playstyle}</span><br>

      <strong>Сила:</strong>
      <span class="neon-gold">${ai.power}</span><br>

      <strong>Слабост:</strong>
      <span class="neon-pink">${ai.weakness}</span><br>

      <strong>Прогноза:</strong>
      <span class="neon-purple">${ai.forecast}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-gold">${ai.recommendation}</span>
    </div>

    <!-- PLAYER STATS -->
    <div class="section-title">Основни данни</div>
    <div class="info-box">
      <strong>Ниво:</strong>
      <span class="neon-blue">${player.level}</span><br>

      <strong>XP:</strong>
      <span class="neon-purple">${player.xp}</span> /
      <span class="neon-gold">${player.xpNeeded}</span><br>

      <strong>Пари:</strong>
      <span class="neon-gold">${Utils.formatMoney(player.money)}</span><br>

      <strong>Heat:</strong>
      <span class="neon-red">${player.heat}</span>
    </div>

    <!-- SKILLS -->
    <div class="section-title">Умения</div>
    <div class="info-box">
      <ul class="skills-list">
        ${skills
          .map(
            s => `
          <li class="skill-entry">
            <span class="neon-blue">${s.name}</span>
            <span class="neon-gold">${s.level} lvl</span>
          </li>
        `
          )
          .join("")}
      </ul>
    </div>

    <!-- MISSIONS -->
    <div class="section-title">Активни мисии</div>
    <div class="info-box">
      <ul class="missions-list">
        ${
          missions.filter(m => m.status === "active").length === 0
            ? `<li class="neon-pink">Няма активни мисии.</li>`
            : missions
                .filter(m => m.status === "active")
                .map(
                  m => `
          <li class="mission-entry">
            <span class="neon-gold">${m.title}</span>
          </li>
        `
                )
                .join("")
        }
      </ul>
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="levelUpPlayer">Ъпгрейд ниво</button>
      <button class="btn" id="reduceHeat">Намали Heat</button>
      <button class="btn" id="closePlayerPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // LEVEL UP
  Utils.qs("#levelUpPlayer").addEventListener("click", async () => {
    Utils.neonFlash(panel, "#00c8ff");
    await ApiClient.levelUpPlayer();
    showPlayerPanel();
  });

  // REDUCE HEAT
  Utils.qs("#reduceHeat").addEventListener("click", async () => {
    Utils.neonFlash(panel, "#ff007c");
    await ApiClient.reduceHeat();
    showPlayerPanel();
  });

  // CLOSE
  Utils.qs("#closePlayerPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}