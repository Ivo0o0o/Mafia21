// ===============================================
// MAFIA 21st CENTURY — WORLD INTERACTION ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// NPC диалози, реакции, избори, мини-сцени,
// интеракции с райони, полиция, черен пазар.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

export function initWorldInteractionEngine() {
  Utils.log("World Interaction Engine стартира…");

  const InteractState = {
    tick: 0,
    activeDialogue: null,
    interactionQueue: [],
    playerLocation: null
  };

  // ===============================================
  // MAIN INTERACTION LOOP
  // ===============================================
  setInterval(async () => {
    InteractState.tick++;

    const player = await ApiClient.getPlayer();
    const npcs = await ApiClient.getAllNPCs();
    const districts = await ApiClient.getDistricts();
    const events = await ApiClient.getWorldEventsPulse();

    InteractState.playerLocation = player.location;

    // ===============================================
    // NPC INTERACTION TRIGGERS
    // ===============================================
    for (const npc of npcs) {
      if (isNear(player, npc)) {
        const dialogue = generateDialogue(npc, player);
        InteractState.interactionQueue.push(dialogue);
      }
    }

    // ===============================================
    // DISTRICT INTERACTION TRIGGERS
    // ===============================================
    for (const d of districts) {
      if (isInside(player, d)) {
        const interaction = generateDistrictInteraction(d, player);
        InteractState.interactionQueue.push(interaction);
      }
    }

    // ===============================================
    // EVENT INTERACTION TRIGGERS
    // ===============================================
    if (events.count > 0) {
      const interaction = generateEventInteraction(events.latest);
      InteractState.interactionQueue.push(interaction);
    }

    // ===============================================
    // PROCESS INTERACTION QUEUE
    // ===============================================
    if (!InteractState.activeDialogue && InteractState.interactionQueue.length > 0) {
      InteractState.activeDialogue = InteractState.interactionQueue.shift();
      await showDialogue(InteractState.activeDialogue);
    }

    Utils.log(`INTERACTION: Queue=${InteractState.interactionQueue.length}`);

  }, 1500); // smooth interaction loop

  Utils.log("World Interaction Engine работи.");
}

// ===============================================
// POSITION HELPERS
// ===============================================
function isNear(player, npc) {
  if (!npc.position) return false;
  const dx = player.x - npc.position.x;
  const dy = player.y - npc.position.y;
  return Math.sqrt(dx * dy) < 20;
}

function isInside(player, district) {
  return (
    player.x > district.x &&
    player.x < district.x + district.width &&
    player.y > district.y &&
    player.y < district.y + district.height
  );
}

// ===============================================
// DIALOGUE GENERATOR
// ===============================================
function generateDialogue(npc, player) {
  return {
    type: "npc",
    npc: npc.name,
    text: pick([
      "Ей, шефе… как върви бизнеса?",
      "Полицията е навън, внимавай.",
      "Чух, че си направил голям удар.",
      "Имам информация… но не е безплатна.",
      "Този район става опасен."
    ])
  };
}

// ===============================================
// DISTRICT INTERACTION GENERATOR
// ===============================================
function generateDistrictInteraction(d, player) {
  return {
    type: "district",
    district: d.name,
    text: pick([
      "Тук напрежението расте.",
      "Хората са неспокойни.",
      "Полицията следи района.",
      "Черният пазар е активен.",
      "Опасността е висока."
    ])
  };
}

// ===============================================
// EVENT INTERACTION GENERATOR
// ===============================================
function generateEventInteraction(event) {
  return {
    type: "event",
    event,
    text: `Световно събитие: ${event}`
  };
}

// ===============================================
// SHOW DIALOGUE
// ===============================================
async function showDialogue(dialogue) {
  const box = Utils.qs("#interactionBox");
  box.innerHTML = `
    <div class="interaction">
      <strong>${dialogue.type.toUpperCase()}</strong><br>
      ${dialogue.text}
    </div>
  `;

  box.style.display = "block";

  await Utils.sleep(3000);

  box.style.display = "none";
}