// ===============================================
// MAFIA 21st CENTURY — MISSIONS UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showMissionsPanel() {
  Utils.log("Зареждаме панела с мисии…");

  const app = Utils.qs("#app");

  const oldPanel = Utils.qs("#missionsPanelDynamic");
  if (oldPanel) oldPanel.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "missionsPanelDynamic";

  // Вземаме мисии
  const missions = await ApiClient.getMissions() || [];

  // AI анализ на всички мисии
  const ai = AICore.missionsAI(missions);

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-missions" style="margin-right:8px;"></span>
      Мисии — Контролен Център
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Най-лесна мисия:</strong>
      <span class="neon-blue">${ai.easy}</span><br>

      <strong>Най-трудна мисия:</strong>
      <span class="neon-red">${ai.hard}</span><br>

      <strong>Най-печеливша мисия:</strong>
      <span class="neon-gold">${ai.bestReward}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-purple">${ai.recommendation}</span>
    </div>

    <!-- MISSIONS LIST -->
    <div class="section-title">Списък мисии</div>
    <div id="missionsList">
      ${
        missions.length === 0
          ? `<div class="info-box">Няма активни мисии.</div>`
          : missions
              .map(
                m => `
        <div class="info-box mission-entry" data-id="${m._id}" style="cursor:pointer;">
          <div class="mission-title">${m.title}</div>

          <div class="mission-meta">
            <span>Трудност: <span class="neon-pink">${m.difficulty}</span></span>
            <span>Награда: <span class="neon-gold">${m.reward} 💶</span></span>
            <span>Heat: <span class="neon-red">${m.heat}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="generateMission">Генерирай AI мисия</button>
      <button class="btn" id="refreshMissions">Обнови</button>
      <button class="btn" id="closeMissionsPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // -----------------------------------------------
  // CLICK → Детайли за мисия + AI анализ
  // -----------------------------------------------
  panel.querySelectorAll("#missionsList .mission-entry").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const mission = await ApiClient.getMission(id);

      Utils.neonFlash(box, "#ff007c");

      const missionAI = AICore.missionAI(mission);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-missions" style="margin-right:8px;"></span>
          ${mission.title}
        </div>

        <div class="section-title">AI Анализ</div>
        <div class="info-box">
          <strong>Трудност:</strong>
          <span class="neon-pink">${missionAI.difficulty}</span><br>

          <strong>Печалба:</strong>
          <span class="neon-gold">${missionAI.profit}</span><br>

          <strong>Heat:</strong>
          <span class="neon-red">${missionAI.heat}</span><br>

          <strong>Препоръка:</strong>
          <span class="neon-blue">${missionAI.recommendation}</span>
        </div>

        <div class="section-title">Описание</div>
        <div class="info-box">${mission.description}</div>

        <div class="section-title">Награда</div>
        <div class="info-box">
          <span class="neon-gold">${mission.reward} 💶</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="startMission">Започни</button>
          <button class="btn" id="backToMissions">Назад</button>
          <button class="btn" id="closeMissionsPanel">Затвори</button>
        </div>
      `;

      Utils.qs("#startMission").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.startMission(id);
        showMissionsPanel();
      });

      Utils.qs("#backToMissions").addEventListener("click", () => {
        showMissionsPanel();
      });

      Utils.qs("#closeMissionsPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // -----------------------------------------------
  // AI генератор на мисии
  // -----------------------------------------------
  Utils.qs("#generateMission").addEventListener("click", async () => {
    Utils.neonFlash(panel, "#9b00ff");

    const newMission = await ApiClient.generateMissionAI();

    panel.innerHTML = `
      <div class="panel-title">
        <span class="icon-missions" style="margin-right:8px;"></span>
        AI генерирана мисия
      </div>

      <div class="info-box">
        <strong>${newMission.title}</strong><br>
        Трудност: <span class="neon-pink">${newMission.difficulty}</span><br>
        Награда: <span class="neon-gold">${newMission.reward} 💶</span><br>
        Heat: <span class="neon-red">${newMission.heat}</span>
      </div>

      <div class="section-title">Описание</div>
      <div class="info-box">${newMission.description}</div>

      <div class="panel-buttons">
        <button class="btn" id="acceptAIMission">Приеми</button>
        <button class="btn" id="backToMissions">Назад</button>
        <button class="btn" id="closeMissionsPanel">Затвори</button>
      </div>
    `;

    Utils.qs("#acceptAIMission").addEventListener("click", async () => {
      Utils.neonFlash(panel, "#00c8ff");
      await ApiClient.acceptMission(newMission._id);
      showMissionsPanel();
    });

    Utils.qs("#backToMissions").addEventListener("click", () => {
      showMissionsPanel();
    });

    Utils.qs("#closeMissionsPanel").addEventListener("click", () => {
      Utils.neonFlash(panel, "#ff007c");
      setTimeout(() => panel.remove(), 250);
    });
  });

  // REFRESH
  Utils.qs("#refreshMissions").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showMissionsPanel();
  });

  // CLOSE
  Utils.qs("#closeMissionsPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}