// ===============================================
// MAFIA 21st CENTURY — AI WORLD EVENTS ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Масови събития, кризи, бедствия, бонуси,
// редки събития, динамични промени в света.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

export function initAIWorldEventsEngine() {
  Utils.log("AI World Events Engine стартира…");

  const WorldState = {
    tick: 0,
    eventChance: 0.05,
    rareEventChance: 0.01,
    crisisChance: 0.02,
    lastEvent: null
  };

  // ===============================================
  // MAIN WORLD EVENTS LOOP
  // ===============================================
  setInterval(async () => {
    WorldState.tick++;

    const crime = await ApiClient.getCrimePulse();
    const police = await ApiClient.getPoliceStatus();
    const npc = await ApiClient.getNPCActivity();
    const economy = await ApiClient.getInflation();
    const player = await ApiClient.getPlayer();
    const districts = await ApiClient.getDistricts();

    // ===============================================
    // COMMON EVENTS (чести)
    // ===============================================
    if (Math.random() < WorldState.eventChance) {
      const event = triggerCommonEvent(crime, police, npc, economy, player);
      WorldState.lastEvent = event;
      Utils.log(`Световно събитие: ${event}`);
      await ApiClient.triggerWorldEvent(event);
    }

    // ===============================================
    // RARE EVENTS (редки)
    // ===============================================
    if (Math.random() < WorldState.rareEventChance) {
      const event = triggerRareEvent();
      WorldState.lastEvent = event;
      Utils.log(`Редко събитие: ${event}`);
      await ApiClient.triggerWorldEvent(event);
    }

    // ===============================================
    // CRISIS EVENTS (опасни)
    // ===============================================
    if (Math.random() < WorldState.crisisChance) {
      const event = triggerCrisisEvent(crime, economy, districts);
      WorldState.lastEvent = event;
      Utils.log(`КРИЗА: ${event}`);
      await ApiClient.triggerWorldEvent(event);
    }

  }, 7000); // 7 секунди цикъл

  Utils.log("AI World Events Engine работи.");
}

// ===============================================
// COMMON EVENTS
// ===============================================
function triggerCommonEvent(crime, police, npc, economy, player) {
  const events = [];

  if (crime.level > 60) events.push("crime_wave");
  if (police.patrols > 4) events.push("police_operation");
  if (npc.activity > 50) events.push("npc_gathering");
  if (economy < 1.0) events.push("market_boom");
  if (player.money > 30000) events.push("rich_player_bonus");

  if (events.length === 0) events.push("calm_day");

  return events[Math.floor(Math.random() * events.length)];
}

// ===============================================
// RARE EVENTS
// ===============================================
function triggerRareEvent() {
  const rare = [
    "legendary_item_drop",
    "secret_black_market",
    "district_rebellion",
    "npc_hero_appears",
    "police_corruption_exposed",
    "mysterious_stranger_event"
  ];

  return rare[Math.floor(Math.random() * rare.length)];
}

// ===============================================
// CRISIS EVENTS
// ===============================================
function triggerCrisisEvent(crime, economy, districts) {
  const crisis = [];

  if (crime.level > 80) crisis.push("citywide_crime_crisis");
  if (economy > 1.5) crisis.push("inflation_crisis");

  const dangerousDistricts = districts.filter(d => d.danger > 70);
  if (dangerousDistricts.length > 2) crisis.push("district_war");

  if (crisis.length === 0) crisis.push("minor_crisis");

  return crisis[Math.floor(Math.random() * crisis.length)];
}