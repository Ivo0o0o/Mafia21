// ===============================================
// MAFIA 21st CENTURY — AI ECONOMY ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Динамична икономика: пари, влияние, черен пазар,
// растеж, спад, реакция към играча и света.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

export function initAIEconomyEngine() {
  Utils.log("AI Economy Engine стартира…");

  const EconomyState = {
    tick: 0,
    inflation: 1.0,
    blackMarketIntensity: 1.0,
    districtWealth: {},
    playerWealthTrend: [],
  };

  // ===============================================
  // MAIN ECONOMY LOOP
  // ===============================================
  setInterval(async () => {
    EconomyState.tick++;

    const player = await ApiClient.getPlayer();
    const districts = await ApiClient.getDistricts();
    const bm = await ApiClient.getBlackMarketPulse();
    const crime = await ApiClient.getCrimePulse();

    // ===============================================
    // PLAYER ECONOMY TREND
    // ===============================================
    EconomyState.playerWealthTrend.push(player.money);
    if (EconomyState.playerWealthTrend.length > 10) {
      EconomyState.playerWealthTrend.shift();
    }

    const trend = calculateTrend(EconomyState.playerWealthTrend);

    if (trend > 0) {
      Utils.log("Икономика: Играчът забогатява.");
      await ApiClient.blackMarketOfferInvestments();
    } else {
      Utils.log("Икономика: Играчът обеднява.");
      await ApiClient.blackMarketOfferSurvivalDeals();
    }

    // ===============================================
    // DISTRICT WEALTH
    // ===============================================
    districts.forEach(async (d) => {
      if (!EconomyState.districtWealth[d.id]) {
        EconomyState.districtWealth[d.id] = 1000;
      }

      // Район богатее или обеднява според престъпленията
      if (crime.level > 60) {
        EconomyState.districtWealth[d.id] -= 50;
      } else {
        EconomyState.districtWealth[d.id] += 20;
      }

      await ApiClient.updateDistrictEconomy(d.id, EconomyState.districtWealth[d.id]);
    });

    // ===============================================
    // BLACK MARKET INTENSITY
    // ===============================================
    if (bm.intensity > 70) {
      EconomyState.blackMarketIntensity += 0.1;
      Utils.log("Черен пазар: Интензивността расте.");
      await ApiClient.blackMarketAddRareItems();
    } else {
      EconomyState.blackMarketIntensity -= 0.05;
      Utils.log("Черен пазар: Интензивността пада.");
    }

    // ===============================================
    // INFLATION
    // ===============================================
    if (crime.level > 80) {
      EconomyState.inflation += 0.02;
    } else {
      EconomyState.inflation -= 0.01;
    }

    EconomyState.inflation = Math.max(0.5, Math.min(2.0, EconomyState.inflation));

    await ApiClient.updateInflation(EconomyState.inflation);

    Utils.log(`Инфлация: ${EconomyState.inflation.toFixed(2)}`);

  }, 5000); // 5 секунди икономически цикъл

  Utils.log("AI Economy Engine работи.");
}

// ===============================================
// TREND CALCULATOR
// ===============================================
function calculateTrend(arr) {
  if (arr.length < 2) return 0;
  return arr[arr.length - 1] - arr[0];
}