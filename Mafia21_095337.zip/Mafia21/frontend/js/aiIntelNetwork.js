// ===============================================
// MAFIA 21st CENTURY — AI INTEL NETWORK ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Анализ на информатори, операции, риск,
// разузнавателни мрежи, прогнози, препоръки.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";

export const aiIntelNetwork = {
  async analyze() {
    const intel = await ApiClient.getIntelOverview();
    const informers = await ApiClient.getInformers();
    const operations = await ApiClient.getIntelOperations();

    const result = {
      bestInformer: null,
      worstInformer: null,
      riskiestOperation: null,
      safestOperation: null,
      intelLevel: null,
      forecast: "",
      recommendation: ""
    };

    // Най-ценен информатор (лоялност + достъп)
    result.bestInformer = informers
      .sort((a, b) => (b.loyalty + b.access) - (a.loyalty + a.access))[0]?.name;

    // Най-слаб информатор
    result.worstInformer = informers
      .sort((a, b) => (a.loyalty + a.access) - (b.loyalty + b.access))[0]?.name;

    // Най-рискова операция
    result.riskiestOperation = operations.sort((a, b) => b.risk - a.risk)[0]?.name;

    // Най-безопасна операция
    result.safestOperation = operations.sort((a, b) => a.risk - b.risk)[0]?.name;

    // Ниво на информираност
    result.intelLevel =
      intel.coverage > 80
        ? "Много високо"
        : intel.coverage > 50
        ? "Средно"
        : "Ниско";

    // Прогноза според риск и активност
    if (intel.risk > 70) {
      result.forecast = "Очакват се пробиви в мрежата за разузнаване.";
    } else if (intel.risk > 40) {
      result.forecast = "Мрежата е нестабилна, възможни са загуби на информация.";
    } else {
      result.forecast = "Разузнаването е стабилно и ефективно.";
    }

    // Препоръка
    if (intel.risk > 70) {
      result.recommendation = "Укрепи мрежата — вербувай нови информатори и подобри сигурността.";
    } else if (intel.risk > 40) {
      result.recommendation = "Разшири достъпа и подобри качеството на информаторите.";
    } else {
      result.recommendation = "Време е за агресивни операции — мрежата е стабилна.";
    }

    Utils.log("AI Intel Network — анализ завършен.");
    return result;
  }
};