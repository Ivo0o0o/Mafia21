// ===============================================
// MAFIA 21st CENTURY — WORLD CROWD ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Симулация на тълпи, социална активност,
// събирания, риск, динамика на населението.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { EventBus } from "./eventBus.js"; // ⭐ добавено

export const worldCrowdEngine = {
  async simulate() {
    EventBus.emit("crowd_sim_tick", {}); // ⭐

    try {
      const districts = await ApiClient.getDistricts();
      const events = await ApiClient.getWorldEvents();

      const result = {
        mostCrowded: null,
        leastCrowded: null,
        crowdLevel: 0,
        dangerZones: [],
        forecast: "",
        recommendation: ""
      };

      // Най-пренаселен район
      result.mostCrowded = districts.sort((a, b) => b.crowd - a.crowd)[0]?.name;

      // Най-празен район
      result.leastCrowded = districts.sort((a, b) => a.crowd - b.crowd)[0]?.name;

      // Средно ниво на тълпи
      result.crowdLevel =
        districts.reduce((sum, d) => sum + d.crowd, 0) / districts.length;

      EventBus.emit("crowd_density_update", {
        level: result.crowdLevel,
        mostCrowded: result.mostCrowded,
        leastCrowded: result.leastCrowded
      }); // ⭐

      // Опасни зони (тълпи + престъпност)
      result.dangerZones = districts
        .filter(d => d.crowd > 70 && d.crime > 50)
        .map(d => d.name);

      EventBus.emit("crowd_danger_zones", {
        zones: result.dangerZones
      }); // ⭐

      // Прогноза според събития
      const socialEvents = events.filter(
        e => e.type === "concert" || e.type === "festival"
      );

      if (socialEvents.length > 3) {
        result.forecast = "Очакват се масивни събирания и пренаселени райони.";
      } else if (socialEvents.length > 0) {
        result.forecast = "Възможни са локални струпвания на хора.";
      } else {
        result.forecast = "Тълпите ще останат стабилни.";
      }

      EventBus.emit("crowd_forecast", {
        forecast: result.forecast,
        events: socialEvents
      }); // ⭐

      // Препоръка
      if (result.crowdLevel > 70) {
        result.recommendation =
          "Избягвай пренаселените райони — рискът е висок.";
      } else if (result.crowdLevel > 40) {
        result.recommendation = "Планирай придвижването внимателно.";
      } else {
        result.recommendation = "Градът е спокоен — движението е свободно.";
      }

      EventBus.emit("crowd_recommendation", {
        recommendation: result.recommendation
      }); // ⭐

      Utils.log("World Crowd Engine — симулация завършена.");
      return result;

    } catch (err) {
      console.error("❌ CrowdEngine ERROR:", err);
      EventBus.emit("crowd_error", { error: err }); // ⭐
    }
  }
};