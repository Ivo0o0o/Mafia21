// ===============================================
// MAFIA 21st CENTURY — PLAYER STATS UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Живот, енергия, heat, риск, пари,
// XP, level, ранг, AI анализ,
// автоматично зареждане.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showPlayerStatsPanel() {
  Utils.log("Зареждаме Player Stats…");

  const app = Utils.qs("#app");

  const oldPanel = Utils.qs("#playerStatsPanelDynamic");
  if (oldPanel) oldPanel.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "playerStatsPanelDynamic";

  // Вземаме играча
  const player = await ApiClient.getPlayer();

  // AI анализ на играча
  const ai = AICore.playerAI(player);

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-player" style="margin-right:8px;"></span>
      Профил на Играч — AI Анализ
    </div>

    <!-- BASIC STATS -->
    <div class="section-title">Основни Статистики</div>
    <div class="info-box">
      <strong>Име:</strong>
      <span class="neon-blue">${player.name}</span><br>

      <strong>Level:</strong>
      <span class="neon-gold">${player.level}</span><br>

      <strong>XP:</strong>
      <span class="neon-purple">${player.xp}</span><br>

      <strong>Ранг:</strong>
      <span class="neon-blue">${player.rank}</span><br>

      <strong>Пари:</strong>
      <span class="neon-gold">${player.money} 💶</span>
    </div>

    <!-- HEALTH / ENERGY -->
    <div class="section-title">Живот и Енергия</div>
    <div class="info-box">
      <strong>Живот:</strong>
      <span class="neon-red">${player.health}%</span><br>

      <strong>Енергия:</strong>
      <span class="neon-blue">${player.energy}%</span>
    </div>

    <!-- HEAT / RISK -->
    <div class="section-title">Heat & Риск</div>
    <div class="info-box">
      <strong>Heat:</strong>
      <span class="neon-pink">${player.heat}%</span><br>

      <strong>Риск:</strong>
      <span class="neon-red">${player.risk}%</span>
    </div>

    <!-- AI ANALYSIS -->
    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Състояние:</strong>
      <span class="neon-blue">${ai.status}</span><br>

      <strong>Опасност:</strong>
      <span class="neon-red">${ai.danger}</span><br>

      <strong>Прогноза:</strong>
      <span class="neon-purple">${ai.forecast}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-gold">${ai.recommendation}</span>
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshPlayerStats">Обнови</button>
      <button class="btn" id="closePlayerStatsPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // REFRESH
  Utils.qs("#refreshPlayerStats").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showPlayerStatsPanel();
  });

  // CLOSE
  Utils.qs("#closePlayerStatsPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}