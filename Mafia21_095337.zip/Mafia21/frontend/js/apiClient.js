// ===============================================
// MAFIA 21st CENTURY — API CLIENT (AUTO-LOAD READY)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централизиран fetch wrapper + стабилни endpoint-и
// ===============================================

const API_BASE = "http://localhost:4000";

// -----------------------------------------------
// CENTRAL SAFE FETCH WRAPPER
// -----------------------------------------------
async function safeFetch(url, options = {}) {
  try {
    const res = await fetch(url, options);
    if (!res.ok) {
      console.warn("API WARNING:", url, "Status:", res.status);
    }
    return await res.json().catch(() => ({}));
  } catch (err) {
    console.error("API ERROR:", url, err);
    return {};
  }
}

export const ApiClient = {

  // -----------------------------------------------
  // HEALTH
  // -----------------------------------------------
  async health() {
    return await safeFetch(`${API_BASE}/health`);
  },

  // -----------------------------------------------
  // PLAYER
  // -----------------------------------------------
  async getPlayer() {
    return await safeFetch(`${API_BASE}/api/player`);
  },

  async levelUpPlayer() {
    return await safeFetch(`${API_BASE}/api/player/levelup`, { method: "POST" });
  },

  async reduceHeat() {
    return await safeFetch(`${API_BASE}/api/player/reduceHeat`, { method: "POST" });
  },

  // -----------------------------------------------
  // NPC
  // -----------------------------------------------
  async getNPCs() {
    return await safeFetch(`${API_BASE}/api/npc`);
  },

  async getNPC(id) {
    return await safeFetch(`${API_BASE}/api/npc/${id}`);
  },

  // -----------------------------------------------
  // DISTRICTS
  // -----------------------------------------------
  async getDistricts() {
    return await safeFetch(`${API_BASE}/api/districts`);
  },

  async getDistrict(id) {
    return await safeFetch(`${API_BASE}/api/districts/${id}`);
  },

  async updateDistrict(id, data) {
    return await safeFetch(`${API_BASE}/api/districts/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
  },

  // ⭐ AI Risk Control
  async updateDistrictRisk(id, data) {
    return await safeFetch(`${API_BASE}/api/districts/${id}/risk`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
  },

  // -----------------------------------------------
  // INFLUENCE
  // -----------------------------------------------
  async getInfluence() {
    return await safeFetch(`${API_BASE}/api/influence`);
  },

  async updateDistrictInfluence(id, data) {
    return await safeFetch(`${API_BASE}/api/influence/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
  },

  // -----------------------------------------------
  // WORLD EVENTS
  // -----------------------------------------------
  async getWorldEvents() {
    return await safeFetch(`${API_BASE}/api/worldEvents`);
  },

  async getWorldEvent(id) {
    return await safeFetch(`${API_BASE}/api/worldEvents/${id}`);
  },

  // -----------------------------------------------
  // MISSIONS
  // -----------------------------------------------
  async getMissions() {
    return await safeFetch(`${API_BASE}/api/missions`);
  },

  async getMission(id) {
    return await safeFetch(`${API_BASE}/api/missions/${id}`);
  },

  async generateMissionAI() {
    return await safeFetch(`${API_BASE}/api/missions/generateAI`, { method: "POST" });
  },

  async acceptMission(id) {
    return await safeFetch(`${API_BASE}/api/missions/${id}/accept`, { method: "POST" });
  },

  async startMission(id) {
    return await safeFetch(`${API_BASE}/api/missions/${id}/start`, { method: "POST" });
  },

  // -----------------------------------------------
  // SKILLS
  // -----------------------------------------------
  async getSkills() {
    return await safeFetch(`${API_BASE}/api/skills`);
  },

  // -----------------------------------------------
  // CITY LIFE
  // -----------------------------------------------
  async getCityLifeEvents() {
    return await safeFetch(`${API_BASE}/api/cityLife`);
  },

  async getCitizens() {
    return await safeFetch(`${API_BASE}/api/cityLife/citizens`);
  },

  async getShops() {
    return await safeFetch(`${API_BASE}/api/cityLife/shops`);
  },

  async getTraffic() {
    return await safeFetch(`${API_BASE}/api/cityLife/traffic`);
  },

  async getBlackMarket() {
    return await safeFetch(`${API_BASE}/api/cityLife/blackMarket`);
  },

  // -----------------------------------------------
  // CRIME
  // -----------------------------------------------
  async getCrimes() {
    return await safeFetch(`${API_BASE}/api/crime`);
  },

  async getCrimeReports() {
    return await safeFetch(`${API_BASE}/api/crime`);
  },

  async commitCrime(id) {
    return await safeFetch(`${API_BASE}/api/crime/${id}/commit`, { method: "POST" });
  },

  // -----------------------------------------------
  // POLICE
  // -----------------------------------------------
  async getPoliceUnits() {
    return await safeFetch(`${API_BASE}/api/police/units`);
  },

  async getPoliceActions() {
    return await safeFetch(`${API_BASE}/api/police`);
  },

  async policeAction(id) {
    return await safeFetch(`${API_BASE}/api/police/${id}/action`, { method: "POST" });
  },

  // -----------------------------------------------
  // BLACK MARKET
  // -----------------------------------------------
  async getBlackMarketOffers() {
    return await safeFetch(`${API_BASE}/api/blackMarket/offers`);
  },

  async getBlackMarketOffer(id) {
    return await safeFetch(`${API_BASE}/api/blackMarket/offers/${id}`);
  },

  async buyBlackMarketOffer(id) {
    return await safeFetch(`${API_BASE}/api/blackMarket/offers/${id}/buy`, {
      method: "POST"
    });
  },

  async updateBlackMarketOfferRisk(id, targetRisk) {
    return await safeFetch(`${API_BASE}/api/blackMarket/offers/${id}/risk`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ risk: targetRisk })
    });
  }
};