// ===============================================
// MAFIA 21st CENTURY — AI NPC PERSONALITIES (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Характер, агресия, страх, лоялност, реактивност,
// морал, алчност, доверие, омраза, уважение.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

export function initAINPCPersonalities() {
  Utils.log("AI NPC Personalities стартира…");

  const PersonalityState = {
    tick: 0,
    npcProfiles: {}
  };

  // ===============================================
  // MAIN PERSONALITY LOOP
  // ===============================================
  setInterval(async () => {
    PersonalityState.tick++;

    const npcs = await ApiClient.getAllNPCs();
    const player = await ApiClient.getPlayer();

    for (const npc of npcs) {
      if (!PersonalityState.npcProfiles[npc.id]) {
        PersonalityState.npcProfiles[npc.id] = generatePersonality();
      }

      const profile = PersonalityState.npcProfiles[npc.id];

      // ===============================================
      // PERSONALITY REACTIONS
      // ===============================================

      // Агресия → реагира на Heat
      if (player.heat > 60 && profile.aggression > 0.7) {
        Utils.log(`NPC ${npc.name} става агресивен.`);
        await ApiClient.npcActAggressive(npc.id);
      }

      // Страх → реагира на престъпления
      if (profile.fear > 0.6 && npc.nearCrime) {
        Utils.log(`NPC ${npc.name} се страхува.`);
        await ApiClient.npcAvoidCrime(npc.id);
      }

      // Лоялност → реагира на действия на играча
      if (profile.loyalty > 0.8 && player.money > 20000) {
        Utils.log(`NPC ${npc.name} става лоялен.`);
        await ApiClient.npcAssistPlayer(npc.id);
      }

      // Алчност → реагира на богатството на играча
      if (profile.greedy > 0.7 && player.money > 50000) {
        Utils.log(`NPC ${npc.name} иска пари.`);
        await ApiClient.npcDemandMoney(npc.id);
      }

      // Уважение → реагира на контрол над районите
      if (profile.respect > 0.8 && npc.districtControl > 70) {
        Utils.log(`NPC ${npc.name} уважава играча.`);
        await ApiClient.npcOfferHelp(npc.id);
      }

      // Омраза → реагира на Heat + престъпления
      if (profile.hate > 0.6 && player.heat > 80) {
        Utils.log(`NPC ${npc.name} мрази играча.`);
        await ApiClient.npcSabotagePlayer(npc.id);
      }

      // ===============================================
      // PERSONALITY EVOLUTION
      // ===============================================
      evolvePersonality(profile);
    }

  }, 4500); // 4.5 секунди цикъл

  Utils.log("AI NPC Personalities работи.");
}

// ===============================================
// PERSONALITY GENERATOR
// ===============================================
function generatePersonality() {
  return {
    aggression: Math.random(),
    fear: Math.random(),
    loyalty: Math.random(),
    greedy: Math.random(),
    respect: Math.random(),
    hate: Math.random(),
    morality: Math.random(),
    risk: Math.random()
  };
}

// ===============================================
// PERSONALITY EVOLUTION
// ===============================================
function evolvePersonality(p) {
  // NPC стават по-агресивни при висока престъпност
  p.aggression += (Math.random() - 0.5) * 0.05;

  // NPC стават по-лоялни при стабилни райони
  p.loyalty += (Math.random() - 0.5) * 0.03;

  // NPC стават по-алчни при висока инфлация
  p.greedy += (Math.random() - 0.5) * 0.04;

  // NPC стават по-уважителни при силен играч
  p.respect += (Math.random() - 0.5) * 0.02;

  // NPC омразата расте при хаос
  p.hate += (Math.random() - 0.5) * 0.05;

  // Ограничения
  for (const key in p) {
    p[key] = Math.max(0, Math.min(1, p[key]));
  }
}