// ===============================================
// MAFIA 21st CENTURY — INFLUENCE UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Влияние, репутация, територии, контрол,
// AI анализ, AI препоръки, AI прогнози.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showInfluencePanel() {
  Utils.log("Зареждаме панела с влияние…");

  const app = Utils.qs("#app");

  const oldPanel = Utils.qs("#influencePanelDynamic");
  if (oldPanel) oldPanel.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "influencePanelDynamic";

  // Данни от бекенда
  const influence = await ApiClient.getInfluence();
  const districts = await ApiClient.getDistricts();

  // AI анализ
  const ai = AICore.influenceAI({
    total: influence.total,
    reputation: influence.reputation,
    districts
  });

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-influence" style="margin-right:8px;"></span>
      Влияние — Контрол и Репутация
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Общо влияние:</strong>
      <span class="neon-gold">${ai.total}</span><br>

      <strong>Репутация:</strong>
      <span class="neon-blue">${ai.reputation}</span><br>

      <strong>Най-силен район:</strong>
      <span class="neon-purple">${ai.bestDistrict}</span><br>

      <strong>Най-слаб район:</strong>
      <span class="neon-pink">${ai.weakDistrict}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-gold">${ai.recommendation}</span>
    </div>

    <!-- DISTRICTS LIST -->
    <div class="section-title">Райони</div>
    <div id="influenceDistrictList">
      ${
        districts.length === 0
          ? `<div class="info-box">Няма райони.</div>`
          : districts
              .map(
                d => `
        <div class="info-box district-entry" data-id="${d._id}" style="cursor:pointer;">
          <div class="district-title">${d.name}</div>

          <div class="district-meta">
            <span>Влияние: <span class="neon-gold">${d.influence}</span></span>
            <span>Репутация: <span class="neon-blue">${d.reputation}</span></span>
            <span>Heat: <span class="neon-red">${d.heat}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshInfluence">Обнови</button>
      <button class="btn" id="closeInfluencePanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // -----------------------------------------------
  // CLICK → Детайли за район + AI анализ + контрол
  // -----------------------------------------------
  panel.querySelectorAll("#influenceDistrictList .district-entry").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const district = await ApiClient.getDistrict(id);

      Utils.neonFlash(box, "#ff007c");

      const districtAI = AICore.influenceDistrictAI(district);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-influence" style="margin-right:8px;"></span>
          ${district.name}
        </div>

        <div class="section-title">AI Анализ</div>
        <div class="info-box">
          <strong>Влияние:</strong>
          <span class="neon-gold">${districtAI.influence}</span><br>

          <strong>Репутация:</strong>
          <span class="neon-blue">${districtAI.reputation}</span><br>

          <strong>Heat:</strong>
          <span class="neon-red">${districtAI.heat}</span><br>

          <strong>Прогноза:</strong>
          <span class="neon-purple">${districtAI.forecast}</span><br>

          <strong>Препоръка:</strong>
          <span class="neon-pink">${districtAI.recommendation}</span>
        </div>

        <div class="section-title">AI Контрол на влияние</div>
        <div class="info-box">
          <label>Целево влияние:</label>
          <input type="range" id="targetInfluence" min="0" max="100" value="${district.influence}" />

          <label>Целева репутация:</label>
          <input type="range" id="targetReputation" min="0" max="100" value="${district.reputation}" />
        </div>

        <div class="panel-buttons">
          <button class="btn" id="applyInfluenceSettings">Приложи AI настройки</button>
          <button class="btn" id="backToInfluence">Назад</button>
          <button class="btn" id="closeInfluencePanel">Затвори</button>
        </div>
      `;

      // APPLY AI SETTINGS
      Utils.qs("#applyInfluenceSettings").addEventListener("click", async () => {
        const targetInfluence = Number(Utils.qs("#targetInfluence").value);
        const targetReputation = Number(Utils.qs("#targetReputation").value);

        Utils.neonFlash(panel, "#00c8ff");

        await ApiClient.updateDistrictInfluence(id, {
          influence: targetInfluence,
          reputation: targetReputation
        });

        showInfluencePanel();
      });

      // BACK
      Utils.qs("#backToInfluence").addEventListener("click", () => {
        showInfluencePanel();
      });

      // CLOSE
      Utils.qs("#closeInfluencePanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // REFRESH
  Utils.qs("#refreshInfluence").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showInfluencePanel();
  });

  // CLOSE
  Utils.qs("#closeInfluencePanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}