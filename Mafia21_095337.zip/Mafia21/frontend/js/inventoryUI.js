// ===============================================
// MAFIA 21st CENTURY — INVENTORY UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Инвентар, предмети, категории, AI анализ,
// стойност, риск, синергии, авто-зареждане.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showInventoryPanel() {
  Utils.log("Зареждаме панела с инвентар…");

  const app = Utils.qs("#app");

  const oldPanel = Utils.qs("#inventoryPanelDynamic");
  if (oldPanel) oldPanel.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "inventoryPanelDynamic";

  // Вземаме играча (инвентарът е вътре)
  const player = await ApiClient.getPlayer() || {};
  const inventory = player.inventory || [];

  // AI анализ на всички предмети
  const aiSummary = {
    totalValue: inventory.reduce((sum, item) => sum + (item.value || 0), 0),
    avgRisk:
      Math.floor(
        inventory.reduce((sum, item) => sum + (item.risk || 0), 0) /
        (inventory.length || 1)
      ),
    recommendation:
      inventory.length === 0
        ? "Инвентарът е празен"
        : inventory.length < 3
        ? "Събери още предмети"
        : "Използвай предметите стратегически"
  };

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-inventory" style="margin-right:8px;"></span>
      Инвентар — Контролен Център
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Обща стойност:</strong>
      <span class="neon-gold">${aiSummary.totalValue} 💶</span><br>

      <strong>Среден риск:</strong>
      <span class="neon-red">${aiSummary.avgRisk}%</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-purple">${aiSummary.recommendation}</span>
    </div>

    <!-- INVENTORY LIST -->
    <div class="section-title">Предмети</div>
    <div id="inventoryList">
      ${
        inventory.length === 0
          ? `<div class="info-box">Няма предмети.</div>`
          : inventory
              .map(item => {
                const ai = AICore.blackMarketOfferAI(item);
                return `
          <div class="info-box inventory-entry" data-id="${item._id}" style="cursor:pointer;">
            <div class="inventory-title">${item.name}</div>

            <div class="inventory-meta">
              <span>Стойност: <span class="neon-gold">${item.value} 💶</span></span>
              <span>Риск: <span class="neon-red">${ai.risk}%</span></span>
              <span>Категория: <span class="neon-blue">${item.category}</span></span>
            </div>
          </div>
        `;
              })
              .join("")
      }
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshInventory">Обнови</button>
      <button class="btn" id="closeInventoryPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // -----------------------------------------------
  // CLICK → Детайли за предмет + AI анализ
  // -----------------------------------------------
  panel.querySelectorAll("#inventoryList .inventory-entry").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const item = inventory.find(i => i._id === id);

      Utils.neonFlash(box, "#ff007c");

      const ai = AICore.blackMarketOfferAI(item);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-inventory" style="margin-right:8px;"></span>
          ${item.name}
        </div>

        <div class="section-title">AI Анализ</div>
        <div class="info-box">
          <strong>Риск:</strong>
          <span class="neon-red">${ai.risk}%</span><br>

          <strong>Потенциална печалба:</strong>
          <span class="neon-gold">${ai.profit} 💶</span><br>

          <strong>Препоръка:</strong>
          <span class="neon-purple">${ai.recommendation}</span>
        </div>

        <div class="section-title">Категория</div>
        <div class="info-box">${item.category}</div>

        <div class="section-title">Описание</div>
        <div class="info-box">${item.description || "Няма описание"}</div>

        <div class="panel-buttons">
          <button class="btn" id="backToInventory">Назад</button>
          <button class="btn" id="closeInventoryPanel">Затвори</button>
        </div>
      `;

      Utils.qs("#backToInventory").addEventListener("click", () => {
        showInventoryPanel();
      });

      Utils.qs("#closeInventoryPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // REFRESH
  Utils.qs("#refreshInventory").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showInventoryPanel();
  });

  // CLOSE
  Utils.qs("#closeInventoryPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}