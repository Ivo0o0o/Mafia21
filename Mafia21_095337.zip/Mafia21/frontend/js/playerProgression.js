// ===============================================
// MAFIA 21st CENTURY — PLAYER PROGRESSION MODULE
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Нива, XP, титли, репутация, престиж,
// AI оценка на прогреса.
// ===============================================

import { AICore } from "./aiCore.js";
import { ApiClient } from "./apiClient.js";
import { NotificationsUI } from "./notificationsUI.js";

export const PlayerProgression = {
  async load() {
    const player = await ApiClient.getPlayer();
    return player;
  },

  async addXP(amount) {
    const player = await this.load();
    const newXP = player.xp + amount;

    await ApiClient.updatePlayerXP(newXP);

    NotificationsUI.info(`Получаваш ${amount} XP.`);

    await this.checkLevelUp();
  },

  async checkLevelUp() {
    const player = await this.load();

    if (player.xp >= player.xpNeeded) {
      const newLevel = player.level + 1;
      const newXP = player.xp - player.xpNeeded;
      const newXPNeeded = Math.floor(player.xpNeeded * 1.4);

      await ApiClient.updatePlayerLevel(newLevel, newXP, newXPNeeded);

      NotificationsUI.success(`Ново ниво! ${newLevel}`);

      this.assignTitle(newLevel);
      this.updateReputation(newLevel);
    }
  },

  async assignTitle(level) {
    let title = "Новак";

    if (level >= 5) title = "Уличен играч";
    if (level >= 10) title = "Оперативен";
    if (level >= 20) title = "Капо";
    if (level >= 30) title = "Дон";
    if (level >= 40) title = "Кръстник";
    if (level >= 50) title = "Легенда";

    await ApiClient.updatePlayerTitle(title);

    NotificationsUI.info(`Получаваш титла: ${title}`);
  },

  async updateReputation(level) {
    const repGain = Math.floor(level * 2.5);

    await ApiClient.updatePlayerReputation(repGain);

    NotificationsUI.info(`Репутацията ти се увеличава с ${repGain}.`);
  },

  async prestige() {
    const player = await this.load();

    if (player.level < 50) {
      NotificationsUI.error("Трябва да си поне ниво 50 за престиж.");
      return;
    }

    await ApiClient.prestigePlayer();

    NotificationsUI.success("Преминаваш в PRESTIGE MODE!");
  },

  async aiEvaluate() {
    const player = await this.load();
    const ai = AICore.skillAI(player);

    return {
      efficiency: ai.efficiency,
      progress: ai.progress,
      status:
        ai.progress > 80
          ? "Бърз напредък"
          : ai.progress > 40
          ? "Нормален напредък"
          : "Бавен напредък"
    };
  }
};