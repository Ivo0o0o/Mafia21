// ===============================================
// MAFIA 21st CENTURY — WORLD SIMULATION ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// NPC движение, полиция патрули, динамика на районите,
// реално време, маршрути, зони, синхронизация.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

export function initWorldSimulationEngine() {
  Utils.log("World Simulation Engine стартира…");

  const SimState = {
    tick: 0,
    npcPositions: {},
    policePositions: {},
    districtDynamics: {},
    worldTime: 0
  };

  // ===============================================
  // MAIN SIMULATION LOOP
  // ===============================================
  setInterval(async () => {
    SimState.tick++;
    SimState.worldTime++;

    const npcs = await ApiClient.getAllNPCs();
    const police = await ApiClient.getPoliceUnits();
    const districts = await ApiClient.getDistricts();
    const heartbeat = await ApiClient.getWorldCycle();

    // ===============================================
    // NPC MOVEMENT
    // ===============================================
    for (const npc of npcs) {
      if (!SimState.npcPositions[npc.id]) {
        SimState.npcPositions[npc.id] = generateStartPosition();
      }

      SimState.npcPositions[npc.id] = moveNPC(SimState.npcPositions[npc.id], heartbeat);

      await ApiClient.updateNPCPosition(npc.id, SimState.npcPositions[npc.id]);
    }

    // ===============================================
    // POLICE PATROL MOVEMENT
    // ===============================================
    for (const unit of police) {
      if (!SimState.policePositions[unit.id]) {
        SimState.policePositions[unit.id] = generateStartPosition();
      }

      SimState.policePositions[unit.id] = movePolice(SimState.policePositions[unit.id], heartbeat);

      await ApiClient.updatePolicePosition(unit.id, SimState.policePositions[unit.id]);
    }

    // ===============================================
    // DISTRICT DYNAMICS
    // ===============================================
    for (const d of districts) {
      if (!SimState.districtDynamics[d.id]) {
        SimState.districtDynamics[d.id] = generateDistrictDynamics();
      }

      SimState.districtDynamics[d.id] = updateDistrictDynamics(
        SimState.districtDynamics[d.id],
        heartbeat,
        d.danger,
        d.control
      );

      await ApiClient.updateDistrictDynamics(d.id, SimState.districtDynamics[d.id]);
    }

    Utils.log(`SIM: NPC=${npcs.length}, Police=${police.length}, Districts=${districts.length}`);

  }, 3000); // 3 секунди симулация

  Utils.log("World Simulation Engine работи.");
}

// ===============================================
// NPC MOVEMENT LOGIC
// ===============================================
function moveNPC(pos, cycle) {
  const speed = cycle === "night" ? 2 : 1;
  pos.x += (Math.random() - 0.5) * speed;
  pos.y += (Math.random() - 0.5) * speed;
  return pos;
}

// ===============================================
// POLICE MOVEMENT LOGIC
// ===============================================
function movePolice(pos, cycle) {
  const speed = cycle === "night" ? 1.5 : 1;
  pos.x += (Math.random() - 0.5) * speed;
  pos.y += (Math.random() - 0.5) * speed;
  return pos;
}

// ===============================================
// DISTRICT DYNAMICS
// ===============================================
function updateDistrictDynamics(dyn, cycle, danger, control) {
  dyn.activity += (Math.random() - 0.5) * 0.1;

  if (cycle === "night") dyn.activity += 0.05;
  if (danger > 70) dyn.activity += 0.1;
  if (control > 80) dyn.activity -= 0.1;

  dyn.activity = Math.max(0, Math.min(1, dyn.activity));
  return dyn;
}

// ===============================================
// GENERATORS
// ===============================================
function generateStartPosition() {
  return {
    x: Math.random() * 100,
    y: Math.random() * 100
  };
}

function generateDistrictDynamics() {
  return {
    activity: Math.random()
  };
}