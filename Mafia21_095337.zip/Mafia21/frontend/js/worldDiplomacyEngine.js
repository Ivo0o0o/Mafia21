// ===============================================
// MAFIA 21st CENTURY — WORLD DIPLOMACY ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Фракции, репутация, влияние, отношения,
// мир, напрежение, конфликти, съюзи.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { EventBus } from "./eventBus.js";

export const worldDiplomacyEngine = {
  async simulate() {
    EventBus.emit("diplomacy_tick", {}); // ⭐

    try {
      const factions = await ApiClient.getFactions();
      const worldEvents = await ApiClient.getWorldEvents();

      const result = {
        relationsMatrix: [],
        tensionMap: [],
        mostTensePair: null,
        mostStablePair: null,
        globalTensionLevel: 0,
        forecast: "",
        recommendation: ""
      };

      // Матрица на отношенията между фракции
      result.relationsMatrix = buildRelationsMatrix(factions);

      EventBus.emit("diplomacy_relations_update", {
        relations: result.relationsMatrix
      }); // ⭐

      // Карта на напрежението
      result.tensionMap = result.relationsMatrix.map(r => ({
        pair: `${r.factionA} - ${r.factionB}`,
        tension: r.tension,
        trust: r.trust
      }));

      // Най-напрегната двойка
      result.mostTensePair = result.tensionMap
        .sort((a, b) => b.tension - a.tension)[0]?.pair;

      // Най-стабилна двойка
      result.mostStablePair = result.tensionMap
        .sort((a, b) => a.tension - b.tension)[0]?.pair;

      // Глобално ниво на напрежение
      result.globalTensionLevel =
        result.tensionMap.reduce((sum, t) => sum + t.tension, 0) /
        (result.tensionMap.length || 1);

      EventBus.emit("diplomacy_tension_map", {
        tensionMap: result.tensionMap,
        globalTension: result.globalTensionLevel,
        mostTensePair: result.mostTensePair,
        mostStablePair: result.mostStablePair
      }); // ⭐

      // Прогноза според световните събития
      const conflictEvents = worldEvents.filter(e =>
        ["sanction", "trade_dispute", "political_crisis"].includes(e.type)
      );

      if (conflictEvents.length > 5 || result.globalTensionLevel > 70) {
        result.forecast = "Очаква се високо дипломатическо напрежение и риск от конфликти.";
      } else if (conflictEvents.length > 0 || result.globalTensionLevel > 40) {
        result.forecast = "Има локални дипломатически напрежения — нужни са внимателни ходове.";
      } else {
        result.forecast = "Дипломатическата среда е стабилна — нисък риск от ескалация.";
      }

      EventBus.emit("diplomacy_forecast", {
        forecast: result.forecast,
        conflictEvents,
        globalTension: result.globalTensionLevel
      }); // ⭐

      // Препоръка (стратегическа)
      if (result.globalTensionLevel > 70) {
        result.recommendation =
          "Избягвай агресивни действия — дипломатическото напрежение е критично.";
      } else if (result.globalTensionLevel > 40) {
        result.recommendation =
          "Търси съюзи и компромиси — балансът е нестабилен.";
      } else {
        result.recommendation =
          "Средата е благоприятна за дългосрочни договори и съюзи.";
      }

      EventBus.emit("diplomacy_recommendation", {
        recommendation: result.recommendation
      }); // ⭐

      Utils.log("World Diplomacy Engine — симулация завършена.");
      return result;

    } catch (err) {
      console.error("❌ DiplomacyEngine ERROR:", err);
      EventBus.emit("diplomacy_error", { error: err }); // ⭐
    }
  }
};

// ===============================================
// Relations Matrix Builder
// ===============================================
function buildRelationsMatrix(factions) {
  const matrix = [];
  for (let i = 0; i < factions.length; i++) {
    for (let j = i + 1; j < factions.length; j++) {
      const a = factions[i];
      const b = factions[j];

      const baseTension =
        Math.abs(a.ambition - b.ambition) +
        Math.abs(a.power - b.power);

      const trust =
        (a.reputation + b.reputation) / 2;

      const tension = Math.min(100, Math.max(0, baseTension - trust));

      matrix.push({
        factionA: a.name,
        factionB: b.name,
        tension,
        trust
      });
    }
  }
  return matrix;
}