// ===============================================
// MAFIA 21st CENTURY — CITY LIFE UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Градски живот, NPC активност, събития,
// heat, danger, AI анализ, AI прогнози,
// автоматично зареждане.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showCityLifePanel() {
  Utils.log("Зареждаме панела City Life…");

  const app = Utils.qs("#app");

  const oldPanel = Utils.qs("#cityLifePanelDynamic");
  if (oldPanel) oldPanel.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "cityLifePanelDynamic";

  // Вземаме градски събития
  const events = await ApiClient.getCityEvents() || [];

  // AI анализ на градския живот
  const aiSummary = AICore.cityLifeAI(events);

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-citylife" style="margin-right:8px;"></span>
      Градски Живот — AI Контрол
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Общ Анализ</div>
    <div class="info-box">
      <strong>Активност:</strong>
      <span class="neon-blue">${aiSummary.activity}</span><br>

      <strong>Heat:</strong>
      <span class="neon-red">${aiSummary.heat}</span><br>

      <strong>Опасност:</strong>
      <span class="neon-purple">${aiSummary.danger}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-gold">${aiSummary.recommendation}</span>
    </div>

    <!-- EVENTS LIST -->
    <div class="section-title">Градски Събития</div>
    <div id="cityEventsList">
      ${
        events.length === 0
          ? `<div class="info-box">Няма активни събития.</div>`
          : events
              .map(
                e => `
        <div class="info-box event-entry" data-id="${e._id}" style="cursor:pointer;">
          <strong>${e.title}</strong><br>
          Heat: <span class="neon-red">${e.heat}</span><br>
          Опасност: <span class="neon-purple">${e.danger}</span><br>
          Район: <span class="neon-blue">${e.district}</span>
        </div>
      `
              )
              .join("")
      }
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshCityLife">Обнови</button>
      <button class="btn" id="closeCityLifePanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // -----------------------------------------------
  // CLICK → Детайли за събитие + AI анализ
  // -----------------------------------------------
  panel.querySelectorAll("#cityEventsList .event-entry").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const event = events.find(e => e._id === id);

      Utils.neonFlash(box, "#ff007c");

      const ai = AICore.worldEventAI(event);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-citylife" style="margin-right:8px;"></span>
          ${event.title}
        </div>

        <div class="section-title">AI Анализ</div>
        <div class="info-box">
          <strong>Heat:</strong>
          <span class="neon-red">${ai.heat}</span><br>

          <strong>Опасност:</strong>
          <span class="neon-purple">${ai.danger}</span><br>

          <strong>Ефект:</strong>
          <span class="neon-gold">${ai.effect}</span><br>

          <strong>Прогноза:</strong>
          <span class="neon-blue">${ai.forecast}</span><br>

          <strong>Препоръка:</strong>
          <span class="neon-pink">${ai.recommendation}</span>
        </div>

        <div class="section-title">Описание</div>
        <div class="info-box">${event.description || "Няма описание"}</div>

        <div class="panel-buttons">
          <button class="btn" id="backToCityLife">Назад</button>
          <button class="btn" id="closeCityLifePanel">Затвори</button>
        </div>
      `;

      Utils.qs("#backToCityLife").addEventListener("click", () => {
        showCityLifePanel();
      });

      Utils.qs("#closeCityLifePanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // REFRESH
  Utils.qs("#refreshCityLife").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showCityLifePanel();
  });

  // CLOSE
  Utils.qs("#closeCityLifePanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}