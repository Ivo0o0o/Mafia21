// ===============================================
// MAFIA 21st CENTURY — POLICE ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централна полицейска система:
// ✔ патрули
// ✔ преследвания
// ✔ heat ескалация
// ✔ операции
// ✔ разузнаване
// ✔ реакция на престъпления
// ✔ синхронизация с AI Engines
// ✔ синхронизация с WorldSimulation
// ===============================================

import { ApiClient } from "./apiClient.js";
import { PlayerStatsCore } from "./playerStatsCore.js";
import { WorldState } from "./worldState.js";
import { AICore } from "./aiCore.js";
import { Utils } from "./utils.js";
import { EventBus } from "./eventBus.js"; // ⭐ добавено

export const PoliceEngine = {
  units: [],
  interval: null,
  rate: 4000, // 4 секунди

  async init() {
    Utils.log("PoliceEngine — стартиране...");

    await this.loadUnits();
    this.interval = setInterval(() => this.tick(), this.rate);

    Utils.log("PoliceEngine — активен.");
  },

  // ---------------------------------------------
  // Зареждане на полицейските единици
  // ---------------------------------------------
  async loadUnits() {
    this.units = await ApiClient.getPoliceUnits();
  },

  // ---------------------------------------------
  // Основен police tick
  // ---------------------------------------------
  async tick() {
    try {
      EventBus.emit("police_tick", { units: this.units }); // ⭐

      await this.patrol();
      await this.scanCrimes();
      await this.reactToHeat();
      await this.runOperations();
      await this.syncToAPI();

      Utils.log("PoliceEngine — tick завършен.");
    } catch (err) {
      console.error("❌ PoliceEngine ERROR:", err);

      EventBus.emit("police_error", { error: err }); // ⭐
    }
  },

  // ---------------------------------------------
  // Патрулиране
  // ---------------------------------------------
  async patrol() {
    this.units.forEach(unit => {
      const ai = AICore.combatAI(unit);

      if (ai.aggression > 60) {
        unit.mode = "aggressive_patrol";
      } else {
        unit.mode = "normal_patrol";
      }

      EventBus.emit("police_patrol", { unit }); // ⭐
    });
  },

  // ---------------------------------------------
  // Сканиране на престъпления
  // ---------------------------------------------
  async scanCrimes() {
    const crimes = await ApiClient.getCrimeReports();

    crimes.forEach(crime => {
      const ai = AICore.missionAI(crime);

      if (ai.risk > 70) {
        this.dispatchUnits(crime.location);

        EventBus.emit("police_scan", { crime }); // ⭐
      }
    });
  },

  // ---------------------------------------------
  // Heat реакция
  // ---------------------------------------------
  async reactToHeat() {
    const player = PlayerStatsCore.get();

    if (player.heat > 50) {
      this.units.forEach(u => (u.mode = "alert"));
    }

    if (player.heat > 80) {
      this.units.forEach(u => (u.mode = "operation"));
    }

    EventBus.emit("police_heat_react", { heat: player.heat }); // ⭐
  },

  // ---------------------------------------------
  // Полицейски операции
  // ---------------------------------------------
  async runOperations() {
    const zones = WorldState.get().zones;

    zones.forEach(zone => {
      const ai = AICore.baseAI(zone);

      if (ai.risk > 85) {
        this.dispatchUnits(zone.name);

        EventBus.emit("police_operation", { zone }); // ⭐
      }
    });
  },

  // ---------------------------------------------
  // Изпращане на полицейски единици
  // ---------------------------------------------
  dispatchUnits(location) {
    this.units.forEach(unit => {
      unit.target = location;
      unit.mode = "pursuit";

      EventBus.emit("police_pursuit", { unit, location }); // ⭐
    });
  },

  // ---------------------------------------------
  // Синхронизация към API
  // ---------------------------------------------
  async syncToAPI() {
    await ApiClient.updatePoliceUnits(this.units);

    EventBus.emit("police_updated", { units: this.units }); // ⭐
  },

  // ---------------------------------------------
  // Връщане на полицейските единици
  // ---------------------------------------------
  getUnits() {
    return this.units;
  }
};

// Автоматично стартиране
PoliceEngine.init();