// ===============================================
// MAFIA 21st CENTURY — HEAT UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Heat система: риск, полиция, засичане,
// AI анализ, AI прогнози, AI препоръки.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showHeatPanel() {
  Utils.log("Зареждаме Heat панела…");

  const app = Utils.qs("#app");

  // Премахваме стар панел
  const old = Utils.qs("#heatPanelDynamic");
  if (old) old.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "heatPanelDynamic";

  // Данни от бекенда
  const heatData = await ApiClient.getHeat();
  const districtHeat = await ApiClient.getDistrictHeat();

  // AI анализ
  const ai = AICore.heatAI(heatData, districtHeat);

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-heat" style="margin-right:8px;"></span>
      HEAT — Полицейско внимание и риск
    </div>

    <!-- GLOBAL HEAT -->
    <div class="section-title">Глобален Heat</div>
    <div class="info-box">
      <strong>Текущ Heat:</strong>
      <span class="neon-red">${heatData.total}</span><br>

      <strong>Риск от засичане:</strong>
      <span class="neon-gold">${ai.catchRisk}</span><br>

      <strong>Полицейска активност:</strong>
      <span class="neon-blue">${ai.policeActivity}</span><br>

      <strong>Прогноза:</strong>
      <span class="neon-purple">${ai.forecast}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-pink">${ai.recommendation}</span>
    </div>

    <!-- DISTRICT HEAT -->
    <div class="section-title">Heat по райони</div>
    <div id="heatDistrictList">
      ${
        districtHeat.length === 0
          ? `<div class="info-box">Няма данни за райони.</div>`
          : districtHeat
              .map(
                d => `
        <div class="info-box heat-entry" data-id="${d.district}" style="cursor:pointer;">
          <div class="heat-district-title">${d.district}</div>

          <div class="heat-meta">
            <span>Heat: <span class="neon-red">${d.heat}</span></span>
            <span>Полиция: <span class="neon-blue">${d.police}</span></span>
            <span>Опасност: <span class="neon-gold">${d.danger}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshHeatPanel">Обнови</button>
      <button class="btn" id="closeHeatPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#ff004c");

  // ===============================================
  // CLICK → Детайли за район
  // ===============================================
  panel.querySelectorAll("#heatDistrictList .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const district = box.dataset.id;
      const data = await ApiClient.getDistrictHeatDetails(district);

      Utils.neonFlash(box, "#ff007c");

      const districtAI = AICore.districtHeatAI(data);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-heat" style="margin-right:8px;"></span>
          Heat — ${district}
        </div>

        <div class="section-title">AI Анализ</div>
        <div class="info-box">
          <strong>Heat:</strong>
          <span class="neon-red">${data.heat}</span><br>

          <strong>Полиция:</strong>
          <span class="neon-blue">${data.police}</span><br>

          <strong>Опасност:</strong>
          <span class="neon-gold">${districtAI.danger}</span><br>

          <strong>Прогноза:</strong>
          <span class="neon-purple">${districtAI.forecast}</span><br>

          <strong>Препоръка:</strong>
          <span class="neon-pink">${districtAI.recommendation}</span>
        </div>

        <div class="section-title">Описание</div>
        <div class="info-box">
          ${data.description || "Няма описание."}
        </div>

        <div class="panel-buttons">
          <button class="btn" id="backToHeatPanel">Назад</button>
          <button class="btn" id="closeHeatPanel">Затвори</button>
        </div>
      `;

      Utils.qs("#backToHeatPanel").addEventListener("click", () => {
        showHeatPanel();
      });

      Utils.qs("#closeHeatPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // REFRESH
  // ===============================================
  Utils.qs("#refreshHeatPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showHeatPanel();
  });

  // ===============================================
  // CLOSE
  // ===============================================
  Utils.qs("#closeHeatPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}