// ===============================================
// MAFIA 21st CENTURY — AI DRUG LAB ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Анализ на рецепти, материали, риск,
// печалба, ефективност, оптимизация.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";

export const aiDrugLabEngine = {
  async analyze() {
    const recipes = await ApiClient.getDrugRecipes();
    const materials = await ApiClient.getDrugMaterials();
    const lab = await ApiClient.getDrugLab();

    const result = {
      bestRecipe: null,
      worstRecipe: null,
      mostDangerousMaterial: null,
      cheapestMaterial: null,
      forecast: "",
      recommendation: ""
    };

    // Най-печеливша рецепта
    result.bestRecipe = recipes.sort((a, b) => b.profit - a.profit)[0]?.name;

    // Най-лоша рецепта
    result.worstRecipe = recipes.sort((a, b) => a.profit - b.profit)[0]?.name;

    // Най-опасен материал
    result.mostDangerousMaterial = materials.sort((a, b) => b.risk - a.risk)[0]?.name;

    // Най-евтин материал
    result.cheapestMaterial = materials.sort((a, b) => a.price - b.price)[0]?.name;

    // Прогноза според качеството на лабораторията
    if (lab.quality > 80) {
      result.forecast = "Очаква се висок добив и нисък риск.";
    } else if (lab.quality > 50) {
      result.forecast = "Добивът е стабилен, но рискът е умерен.";
    } else {
      result.forecast = "Лабораторията е нестабилна — възможни загуби.";
    }

    // Препоръка
    if (lab.quality > 80) {
      result.recommendation = "Произвеждай най-печелившите рецепти — лабораторията е в топ форма.";
    } else if (lab.quality > 50) {
      result.recommendation = "Фокусирай се върху рецепти с нисък риск.";
    } else {
      result.recommendation = "Подобри оборудването преди масово производство.";
    }

    Utils.log("AI Drug Lab Engine — анализ завършен.");
    return result;
  }
};