// ===============================================
// MAFIA 21st CENTURY — ECONOMY UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Пари, доходи, бизнеси, черен пазар,
// инвестиции, AI икономическа динамика.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showEconomyPanel() {
  Utils.log("Зареждаме икономическия панел…");

  const app = Utils.qs("#app");

  // Премахваме стария панел
  const oldPanel = Utils.qs("#economyPanelDynamic");
  if (oldPanel) oldPanel.remove();

  // Създаваме нов панел
  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "economyPanelDynamic";

  // Вземаме икономически данни
  const economy = await ApiClient.getEconomy();
  const businesses = await ApiClient.getBusinesses();
  const blackMarket = await ApiClient.getBlackMarket();

  // AI икономическа оценка (поправено)
  const ai = AICore.economyAI(economy);

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-economy" style="margin-right:8px;"></span>
      Икономика — Финансов контрол и AI анализ
    </div>

    <div class="section-title">Финансово състояние</div>
    <div class="info-box">
      <strong>Баланс:</strong>
      <span class="neon-gold">${Utils.formatMoney(economy.balance)}</span>
    </div>

    <div class="info-box">
      <strong>Доходи:</strong>
      <span class="neon-blue">${Utils.formatMoney(economy.income)}</span> / ден
    </div>

    <div class="info-box">
      <strong>Разходи:</strong>
      <span class="neon-red">${Utils.formatMoney(economy.expenses)}</span> / ден
    </div>

    <div class="section-title">AI Икономически анализ</div>
    <div class="info-box">
      <strong>Риск:</strong> <span class="neon-pink">${ai.risk}</span><br>
      <strong>Печалба:</strong> <span class="neon-gold">${ai.profit}</span><br>
      <strong>Стабилност:</strong> <span class="neon-blue">${ai.stability}</span><br>
      <strong>Препоръка:</strong> <span class="neon-purple">${ai.recommendation}</span>
    </div>

    <div class="section-title">Бизнеси</div>
    <div class="info-box">
      <ul id="businessList" style="padding-left:20px; margin-top:10px;">
        ${businesses.map(b => `
          <li style="margin-bottom:10px; cursor:pointer;" data-id="${b._id}">
            <span class="neon-gold">${b.name}</span> —
            <span class="neon-blue">${Utils.formatMoney(b.income)}</span> / ден
          </li>
        `).join("")}
      </ul>
    </div>

    <div class="section-title">Черен пазар</div>
    <div class="info-box">
      <ul id="blackMarketList" style="padding-left:20px; margin-top:10px;">
        ${blackMarket.map(item => `
          <li style="margin-bottom:10px; cursor:pointer;" data-id="${item._id}">
            <span class="neon-purple">${item.name}</span> —
            <span class="neon-gold">${Utils.formatMoney(item.price)}</span>
          </li>
        `).join("")}
      </ul>
    </div>

    <div class="panel-buttons">
      <button class="btn" id="refreshEconomy">Обнови</button>
      <button class="btn" id="closeEconomyPanel" style="margin-left:10px;">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // ===============================================
  // CLICK → Детайли за бизнес
  // ===============================================
  panel.querySelectorAll("#businessList li").forEach(li => {
    li.addEventListener("click", async () => {
      const businessId = li.dataset.id;
      const business = await ApiClient.getBusiness(businessId);

      Utils.neonFlash(li, "#ff007c");

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-economy" style="margin-right:8px;"></span>
          ${business.name}
        </div>

        <div class="info-box">
          <strong>Доход:</strong>
          <span class="neon-blue">${Utils.formatMoney(business.income)}</span> / ден
        </div>

        <div class="info-box">
          <strong>Разходи:</strong>
          <span class="neon-red">${Utils.formatMoney(business.expenses)}</span> / ден
        </div>

        <div class="info-box">
          <strong>Ниво:</strong>
          <span class="neon-purple">${business.level}</span>
        </div>

        <div class="info-box">
          <strong>AI оценка:</strong><br>
          Риск: <span class="neon-pink">${business.ai.risk}</span><br>
          Печалба: <span class="neon-gold">${business.ai.profit}</span><br>
          Стабилност: <span class="neon-blue">${business.ai.stability}</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="upgradeBusiness">Ъпгрейд</button>
          <button class="btn" id="backToEconomy" style="margin-left:10px;">Назад</button>
          <button class="btn" id="closeEconomyPanel" style="margin-left:10px;">Затвори</button>
        </div>
      `;

      Utils.qs("#upgradeBusiness").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.upgradeBusiness(businessId);
        showEconomyPanel();
      });

      Utils.qs("#backToEconomy").addEventListener("click", () => {
        showEconomyPanel();
      });

      Utils.qs("#closeEconomyPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // CLICK → Черен пазар
  // ===============================================
  panel.querySelectorAll("#blackMarketList li").forEach(li => {
    li.addEventListener("click", async () => {
      const itemId = li.dataset.id;
      const item = await ApiClient.getBlackMarketItem(itemId);

      Utils.neonFlash(li, "#9b00ff");

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-blackmarket" style="margin-right:8px;"></span>
          ${item.name}
        </div>

        <div class="info-box">
          <strong>Цена:</strong>
          <span class="neon-gold">${Utils.formatMoney(item.price)}</span>
        </div>

        <div class="info-box">
          <strong>Описание:</strong>
          <div>${item.description}</div>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="buyItem">Купи</button>
          <button class="btn" id="backToEconomy" style="margin-left:10px;">Назад</button>
          <button class="btn" id="closeEconomyPanel" style="margin-left:10px;">Затвори</button>
        </div>
      `;

      Utils.qs("#buyItem").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.buyBlackMarketItem(itemId);
        showEconomyPanel();
      });

      Utils.qs("#backToEconomy").addEventListener("click", () => {
        showEconomyPanel();
      });

      Utils.qs("#closeEconomyPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // REFRESH
  // ===============================================
  Utils.qs("#refreshEconomy").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showEconomyPanel();
  });

  // ===============================================
  // CLOSE
  // ===============================================
  Utils.qs("#closeEconomyPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}