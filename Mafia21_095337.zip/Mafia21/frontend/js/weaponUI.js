// ===============================================
// MAFIA 21st CENTURY — WEAPONS UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Оръжия, модификации, качество, риск,
// AI анализ, препоръки, черен пазар.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showWeaponsPanel() {
  Utils.log("Зареждаме Weapons панела…");

  const app = Utils.qs("#app");

  // Премахваме стар панел
  const oldPanel = Utils.qs("#weaponsPanelDynamic");
  if (oldPanel) oldPanel.remove();

  // Създаваме нов панел
  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "weaponsPanelDynamic";

  // Данни от бекенда
  const weapons = await ApiClient.getWeapons();
  const mods = await ApiClient.getWeaponMods();
  const blackMarket = await ApiClient.getBlackMarketWeapons();

  // AI анализ
  const ai = AICore.weaponsAI({ weapons, mods, blackMarket });

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-weapons" style="margin-right:8px;"></span>
      Оръжия — Арсенал и AI анализ
    </div>

    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Най-опасно оръжие:</strong>
      <span class="neon-red">${ai.mostDangerous}</span><br>

      <strong>Най-точно оръжие:</strong>
      <span class="neon-blue">${ai.mostAccurate}</span><br>

      <strong>Най-печеливша покупка:</strong>
      <span class="neon-gold">${ai.bestDeal}</span><br>

      <strong>Прогноза:</strong>
      <span class="neon-purple">${ai.forecast}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-pink">${ai.recommendation}</span>
    </div>

    <div class="section-title">Оръжия</div>
    <div id="weaponList">
      ${
        weapons.length === 0
          ? `<div class="info-box">Няма налични оръжия.</div>`
          : weapons
              .map(
                w => `
        <div class="info-box weapon-entry" data-id="${w._id}" style="cursor:pointer;">
          <div class="weapon-title">${w.name}</div>

          <div class="weapon-meta">
            <span>Щета: <span class="neon-red">${w.damage}</span></span>
            <span>Точност: <span class="neon-blue">${w.accuracy}</span></span>
            <span>Риск: <span class="neon-purple">${w.risk}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <div class="section-title">Модификации</div>
    <div id="modList">
      ${
        mods.length === 0
          ? `<div class="info-box">Няма модификации.</div>`
          : mods
              .map(
                m => `
        <div class="info-box mod-entry" data-id="${m._id}" style="cursor:pointer;">
          <div class="mod-title">${m.name}</div>

          <div class="mod-meta">
            <span>Точност: <span class="neon-blue">+${m.accuracy}</span></span>
            <span>Щета: <span class="neon-red">+${m.damage}</span></span>
            <span>Цена: <span class="neon-gold">${Utils.formatMoney(m.price)}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <div class="section-title">Черен пазар — Оръжия</div>
    <div id="blackMarketWeapons">
      ${
        blackMarket.length === 0
          ? `<div class="info-box">Няма оръжия на черния пазар.</div>`
          : blackMarket
              .map(
                bm => `
        <div class="info-box blackmarket-entry" data-id="${bm._id}" style="cursor:pointer;">
          <div class="bm-title">${bm.name}</div>

          <div class="bm-meta">
            <span>Цена: <span class="neon-gold">${Utils.formatMoney(bm.price)}</span></span>
            <span>Риск: <span class="neon-red">${bm.risk}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <div class="panel-buttons">
      <button class="btn" id="refreshWeapons">Обнови</button>
      <button class="btn" id="closeWeaponsPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // ===============================================
  // CLICK → Детайли за оръжие
  // ===============================================
  panel.querySelectorAll("#weaponList .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const weapon = await ApiClient.getWeapon(id);

      Utils.neonFlash(box, "#ff007c");

      const weaponAI = AICore.singleWeaponAI(weapon);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-weapons" style="margin-right:8px;"></span>
          ${weapon.name}
        </div>

        <div class="info-box">
          <strong>Щета:</strong>
          <span class="neon-red">${weapon.damage}</span><br>

          <strong>Точност:</strong>
          <span class="neon-blue">${weapon.accuracy}</span><br>

          <strong>Риск:</strong>
          <span class="neon-purple">${weapon.risk}</span><br>

          <strong>AI оценка:</strong><br>
          Ефективност: <span class="neon-gold">${weaponAI.efficiency}</span><br>
          Препоръка: <span class="neon-pink">${weaponAI.recommendation}</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="backToWeapons">Назад</button>
          <button class="btn" id="closeWeaponsPanel">Затвори</button>
        </div>
      `;

      Utils.qs("#backToWeapons").addEventListener("click", () => {
        showWeaponsPanel();
      });

      Utils.qs("#closeWeaponsPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // CLICK → Детайли за модификация
  // ===============================================
  panel.querySelectorAll("#modList .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const mod = await ApiClient.getWeaponMod(id);

      Utils.neonFlash(box, "#9b00ff");

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-weapons" style="margin-right:8px;"></span>
          Модификация — ${mod.name}
        </div>

        <div class="info-box">
          <strong>Точност:</strong>
          <span class="neon-blue">+${mod.accuracy}</span><br>

          <strong>Щета:</strong>
          <span class="neon-red">+${mod.damage}</span><br>

          <strong>Цена:</strong>
          <span class="neon-gold">${Utils.formatMoney(mod.price)}</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="buyMod">Купи</button>
          <button class="btn" id="backToWeapons" style="margin-left:10px;">Назад</button>
          <button class="btn" id="closeWeaponsPanel" style="margin-left:10px;">Затвори</button>
        </div>
      `;

      Utils.qs("#buyMod").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.buyWeaponMod(id);
        showWeaponsPanel();
      });

      Utils.qs("#backToWeapons").addEventListener("click", () => {
        showWeaponsPanel();
      });

      Utils.qs("#closeWeaponsPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // CLICK → Черен пазар оръжия
  // ===============================================
  panel.querySelectorAll("#blackMarketWeapons .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const item = await ApiClient.getBlackMarketWeapon(id);

      Utils.neonFlash(box, "#ff007c");

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-blackmarket" style="margin-right:8px;"></span>
          ${item.name}
        </div>

        <div class="info-box">
          <strong>Цена:</strong>
          <span class="neon-gold">${Utils.formatMoney(item.price)}</span><br>

          <strong>Риск:</strong>
          <span class="neon-red">${item.risk}</span><br>

          <strong>Описание:</strong>
          <div>${item.description}</div>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="buyWeapon">Купи</button>
          <button class="btn" id="backToWeapons" style="margin-left:10px;">Назад</button>
          <button class="btn" id="closeWeaponsPanel" style="margin-left:10px;">Затвори</button>
        </div>
      `;

      Utils.qs("#buyWeapon").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.buyBlackMarketWeapon(id);
        showWeaponsPanel();
      });

      Utils.qs("#backToWeapons").addEventListener("click", () => {
        showWeaponsPanel();
      });

      Utils.qs("#closeWeaponsPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // REFRESH
  // ===============================================
  Utils.qs("#refreshWeapons").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showWeaponsPanel();
  });

  // ===============================================
  // CLOSE
  // ===============================================
  Utils.qs("#closeWeaponsPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}