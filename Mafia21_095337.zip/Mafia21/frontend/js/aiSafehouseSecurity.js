// ===============================================
// MAFIA 21st CENTURY — AI SAFEHOUSE SECURITY ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Анализ на охрана, защита, риск,
// пробиви, слабости, подобрения.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";

export const aiSafehouseSecurity = {
  async analyze() {
    const safehouse = await ApiClient.getSafehouse();
    const guards = await ApiClient.getGuards();
    const upgrades = await ApiClient.getSafehouseUpgrades();

    const result = {
      weakestGuard: null,
      strongestGuard: null,
      bestUpgrade: null,
      securityLevel: null,
      breachRisk: "",
      recommendation: ""
    };

    // Най-слаб охранител
    result.weakestGuard = guards.sort((a, b) => a.power - b.power)[0]?.name;

    // Най-силен охранител
    result.strongestGuard = guards.sort((a, b) => b.power - a.power)[0]?.name;

    // Най-добър ъпгрейд
    result.bestUpgrade = upgrades.sort((a, b) => (b.security + b.capacity) - (a.security + a.capacity))[0]?.name;

    // Ниво на сигурност
    result.securityLevel =
      safehouse.security > 80
        ? "Много висока"
        : safehouse.security > 50
        ? "Средна"
        : "Ниска";

    // Риск от пробив
    if (safehouse.security > 80) {
      result.breachRisk = "Минимален риск от пробив.";
    } else if (safehouse.security > 50) {
      result.breachRisk = "Умерен риск — възможни са атаки.";
    } else {
      result.breachRisk = "Висок риск — скривалището е уязвимо.";
    }

    // Препоръка
    if (safehouse.security > 80) {
      result.recommendation = "Разшири капацитета и добави стратегически ъпгрейди.";
    } else if (safehouse.security > 50) {
      result.recommendation = "Наеми по-силни охранители и подобри защитата.";
    } else {
      result.recommendation = "Спешно подобри сигурността — скривалището е изложено.";
    }

    Utils.log("AI Safehouse Security — анализ завършен.");
    return result;
  }
};