// ===============================================
// MAFIA 21st CENTURY — GAME ENGINE CORE (PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централен цикъл, AI ticks, economy ticks,
// combat ticks, world events, notifications,
// player progression, influence.
// ===============================================

import { AICore } from "./aiCore.js";
import { ApiClient } from "./apiClient.js";
import { NotificationsUI } from "./notificationsUI.js";
import { PlayerProgression } from "./playerProgression.js";

// ⭐ NEW IMPORTS (добавени, без да махам нищо)
import { WorldClock } from "./worldClock.js";
import { PlayerStatsCore } from "./playerStatsCore.js";
import { WorldSimulation } from "./worldSimulation.js";
import { EventBus } from "./eventBus.js";
import { Utils } from "./utils.js";

export const GameEngine = {
  tickInterval: null,
  tickRate: 3000, // 3 секунди — оптимално за браузър игра

  start() {
    console.log("⚡ GAME ENGINE STARTED — MAFIA 21st CENTURY");

    if (this.tickInterval) clearInterval(this.tickInterval);

    this.tickInterval = setInterval(() => {
      this.tick();
    }, this.tickRate);

    NotificationsUI.info("Игровият двигател е активиран.");

    // ⭐ NEW: EventBus сигнал
    EventBus.emit("game_engine_started", {
      time: WorldClock.getTime()
    });

    // ⭐ NEW: Performance лог
    Utils.log("GameEngine: ULTRA PRO MAX режим активиран.");
  },

  stop() {
    if (this.tickInterval) {
      clearInterval(this.tickInterval);
      this.tickInterval = null;
      NotificationsUI.warning("Игровият двигател е спрян.");
    }

    // ⭐ NEW
    EventBus.emit("game_engine_stopped", {});
  },

  async tick() {
    console.log("🔄 GAME TICK EXECUTED");

    try {
      await this.aiTick();
      await this.economyTick();
      await this.worldTick();
      await this.npcTick();
      await this.gangTick();
      await this.baseTick();
      await this.missionTick();
      await this.playerTick();        
      await this.playerInfluenceTick();

      // ⭐ NEW: World Simulation Sync
      this.worldSimulationTick();

      // ⭐ NEW: Player Stats Sync
      this.playerStatsTick();

      // ⭐ NEW: Performance Monitor
      this.performanceTick();

      // ⭐ NEW: EventBus broadcast
      EventBus.emit("game_tick", {
        time: WorldClock.getTime(),
        player: PlayerStatsCore.get()
      });

    } catch (err) {
      console.error("❌ GAME ENGINE ERROR:", err);
      NotificationsUI.error("Грешка в игровия двигател.");
    }
  },

  // ---------------------------------------------
  // AI TICK — централна AI логика
  // ---------------------------------------------
  async aiTick() {
    const aiPulse = AICore.npcBehavior();
    console.log("🤖 AI Pulse:", aiPulse);

    if (aiPulse.intensity > 85) {
      NotificationsUI.warning("AI засича висока активност в района.");
    }

    // ⭐ NEW
    EventBus.emit("ai_tick", aiPulse);
  },

  // ---------------------------------------------
  // ECONOMY TICK — доходи, разходи, баланс
  // ---------------------------------------------
  async economyTick() {
    const economy = await ApiClient.getEconomy();
    const ai = AICore.economyAI(economy);

    console.log("💰 Economy Tick:", ai);

    if (ai.profit < 0) {
      NotificationsUI.warning("Икономиката ти е нестабилна.");
    }

    if (ai.profit > 500) {
      NotificationsUI.success("Получаваш висок пасивен доход!");
    }

    // ⭐ NEW
    EventBus.emit("economy_tick", ai);
  },

  // ---------------------------------------------
  // WORLD TICK — събития в света
  // ---------------------------------------------
  async worldTick() {
    const events = await ApiClient.getWorldEvents();

    if (events.length > 0) {
      const event = events[Math.floor(Math.random() * events.length)];
      NotificationsUI.info(`Световно събитие: ${event.title}`);
    }

    // ⭐ NEW
    EventBus.emit("world_tick", events);
  },

  // ---------------------------------------------
  // NPC TICK — NPC поведение
  // ---------------------------------------------
  async npcTick() {
    const npcs = await ApiClient.getNPCList();

    npcs.forEach(npc => {
      const ai = AICore.npcBehavior();

      if (ai.decision === "атакува" && ai.intensity > 70) {
        NotificationsUI.warning(`${npc.name} изглежда агресивен.`);
      }
    });

    // ⭐ NEW
    EventBus.emit("npc_tick", npcs);
  },

  // ---------------------------------------------
  // GANG TICK — кланове
  // ---------------------------------------------
  async gangTick() {
    const gangs = await ApiClient.getGangs();

    gangs.forEach(gang => {
      const ai = AICore.gangAI(gang);

      if (ai.aggression > 80) {
        NotificationsUI.warning(`Кланът ${gang.name} повишава агресията.`);
      }
    });

    // ⭐ NEW
    EventBus.emit("gang_tick", gangs);
  },

  // ---------------------------------------------
  // BASE TICK — бази
  // ---------------------------------------------
  async baseTick() {
    const bases = await ApiClient.getBases();

    bases.forEach(base => {
      const ai = AICore.baseAI(base);

      if (ai.vulnerability > 70) {
        NotificationsUI.warning(`Базата ${base.name} е уязвима.`);
      }
    });

    // ⭐ NEW
    EventBus.emit("base_tick", bases);
  },

  // ---------------------------------------------
  // MISSION TICK — мисии
  // ---------------------------------------------
  async missionTick() {
    const missions = await ApiClient.getMissions();

    missions.forEach(mission => {
      const ai = AICore.missionAI(mission);

      if (ai.difficulty > 80) {
        NotificationsUI.info(`Мисията "${mission.title}" става по-трудна.`);
      }
    });

    // ⭐ NEW
    EventBus.emit("mission_tick", missions);
  },

  // ---------------------------------------------
  // PLAYER TICK — прогрес, XP, титли
  // ---------------------------------------------
  async playerTick() {
    const ai = await PlayerProgression.aiEvaluate();

    if (ai.status === "Бърз напредък") {
      NotificationsUI.success("Напредваш бързо!");
    }

    if (ai.status === "Бавен напредък") {
      NotificationsUI.warning("Напредъкът ти е бавен.");
    }

    // ⭐ NEW
    EventBus.emit("player_progress_tick", ai);
  },

  // ---------------------------------------------
  // PLAYER INFLUENCE TICK — репутация, влияние
  // ---------------------------------------------
  async playerInfluenceTick() {
    const player = await PlayerProgression.load();

    if (player.reputation > 100) {
      NotificationsUI.info("Гражданите започват да говорят за теб.");
    }

    if (player.reputation > 300) {
      NotificationsUI.warning("Полицията следи действията ти.");
    }

    if (player.reputation > 600) {
      NotificationsUI.error("Клановете те смятат за заплаха.");
    }

    // ⭐ NEW
    EventBus.emit("player_influence_tick", player);
  },

  // ---------------------------------------------
  // ⭐ NEW — WORLD SIMULATION TICK
  // ---------------------------------------------
  worldSimulationTick() {
    WorldSimulation.tick(WorldClock.getTime());
  },

  // ---------------------------------------------
  // ⭐ NEW — PLAYER STATS CORE TICK
  // ---------------------------------------------
  playerStatsTick() {
    const player = PlayerStatsCore.get();

    // Passive stamina regen
    if (player.stamina < player.maxStamina) {
      player.stamina += 0.3;
    }

    // Passive heat decay
    if (player.heat > 0) {
      player.heat -= 0.05;
    }

    PlayerStatsCore.update(player);
  },

  // ---------------------------------------------
  // ⭐ NEW — PERFORMANCE MONITOR
  // ---------------------------------------------
  performanceTick() {
    const perf = {
      fps: Utils.getFPS(),
      latency: Utils.getLatency(),
      load: Utils.getSystemLoad()
    };

    EventBus.emit("performance_tick", perf);
  }
};