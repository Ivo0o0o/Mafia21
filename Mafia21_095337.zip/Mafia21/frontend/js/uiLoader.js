// ===============================================
// MAFIA 21st CENTURY — UI LOADER (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzов 🍀🐬🪽☁️ 💶
// ===============================================
// Автоматично свързване на UI панели към бутони.
// Няма ръчни настройки. Няма дублиране.
// Добавяш модул → Loader го активира.
// ===============================================

import { showSafehousePanel } from "./safehouseUI.js";
import { showIntelPanel } from "./intelUI.js";
import { showOperationsPanel } from "./operationsUI.js";
import { showInventoryPanel } from "./inventoryUI.js";
import { showMarketPanel } from "./marketUI.js";
import { showCrewPanel } from "./crewUI.js";
import { showTerritoryPanel } from "./territoryUI.js";
import { showEconomyPanel } from "./economyUI.js";
import { showVehiclesPanel } from "./vehiclesUI.js";
import { showWeaponsPanel } from "./weaponsUI.js";
import { showDrugLabPanel } from "./drugLabUI.js";
import { showBlackMarketPanel } from "./blackMarketUI.js";
import { showContactsPanel } from "./contactsUI.js";
import { showMapPanel } from "./mapUI.js";
import { showProfilePanel } from "./profileUI.js";

// Ако добавиш нов UI модул → просто го импортни тук.
// Loader-ът го активира автоматично.

const UI_MAP = {
  btnSafehouse: showSafehousePanel,
  btnIntel: showIntelPanel,
  btnOperations: showOperationsPanel,
  btnInventory: showInventoryPanel,
  btnMarket: showMarketPanel,
  btnCrew: showCrewPanel,
  btnTerritory: showTerritoryPanel,
  btnEconomy: showEconomyPanel,
  btnVehicles: showVehiclesPanel,
  btnWeapons: showWeaponsPanel,
  btnDrugLab: showDrugLabPanel,
  btnBlackMarket: showBlackMarketPanel,
  btnContacts: showContactsPanel,
  btnMap: showMapPanel,
  btnProfile: showProfilePanel,
};

export function initUILoader() {
  Object.entries(UI_MAP).forEach(([btnId, handler]) => {
    const btn = document.getElementById(btnId);
    if (!btn) return;

    btn.addEventListener("click", () => {
      handler();
    });
  });
}