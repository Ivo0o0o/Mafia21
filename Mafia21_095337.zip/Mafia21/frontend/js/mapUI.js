// ===============================================
// MAFIA 21st CENTURY — MAP UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Интерактивна карта, AI danger overlay,
// AI police overlay, AI influence overlay,
// реални координати, динамично обновяване,
// връзка с District Panel.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showMapPanel() {
  Utils.log("Зареждаме картата…");

  const app = Utils.qs("#app");

  const oldPanel = Utils.qs("#mapPanelDynamic");
  if (oldPanel) oldPanel.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "mapPanelDynamic";

  // Вземаме всички райони
  const districts = await ApiClient.getDistricts() || [];

  // AI анализ на картата
  const mapAI = AICore.mapAI(districts);

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-map" style="margin-right:8px;"></span>
      Карта — AI Контрол
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Анализ на Картата</div>
    <div class="info-box">
      <strong>Средна опасност:</strong>
      <span class="neon-red">${mapAI.avgDanger}</span><br>

      <strong>Среден heat:</strong>
      <span class="neon-pink">${mapAI.avgHeat}</span><br>

      <strong>Полиция:</strong>
      <span class="neon-blue">${mapAI.avgPolice}</span><br>

      <strong>Черни пазари:</strong>
      <span class="neon-gold">${mapAI.avgBlackMarket}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-purple">${mapAI.recommendation}</span>
    </div>

    <!-- MAP CANVAS -->
    <div class="section-title">Интерактивна Карта</div>
    <canvas id="mapCanvas" width="900" height="500" class="map-canvas"></canvas>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshMap">Обнови</button>
      <button class="btn" id="closeMapPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // -----------------------------------------------
  // CANVAS РЕНДЕР
  // -----------------------------------------------
  const canvas = Utils.qs("#mapCanvas");
  const ctx = canvas.getContext("2d");

  function renderMap() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    districts.forEach(d => {
      const ai = AICore.districtAI(d);

      // Координати
      const x = d.x || Math.random() * 800;
      const y = d.y || Math.random() * 400;

      // Danger overlay
      const dangerColor = `rgba(255, 0, 0, ${ai.heat / 100})`;

      ctx.fillStyle = dangerColor;
      ctx.beginPath();
      ctx.arc(x, y, 40, 0, Math.PI * 2);
      ctx.fill();

      // District name
      ctx.fillStyle = "#fff";
      ctx.font = "16px Arial";
      ctx.fillText(d.name, x - 30, y - 50);

      // Click zones
      d._mapX = x;
      d._mapY = y;
    });
  }

  renderMap();

  // -----------------------------------------------
  // CLICK → ОТВАРЯНЕ НА DISTRICT PANEL
  // -----------------------------------------------
  canvas.addEventListener("click", e => {
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;

    for (const d of districts) {
      const dx = mx - d._mapX;
      const dy = my - d._mapY;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist < 40) {
        Utils.neonFlash(canvas, "#ff007c");
        import("./districtPanel.js").then(module => {
          module.showDistrictDetailsPanel(d._id);
        });
        break;
      }
    }
  });

  // -----------------------------------------------
  // REFRESH
  // -----------------------------------------------
  Utils.qs("#refreshMap").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showMapPanel();
  });

  // -----------------------------------------------
  // CLOSE
  // -----------------------------------------------
  Utils.qs("#closeMapPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}