// ===============================================
// MAFIA 21st CENTURY — SAFEHOUSE UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Скривалище, охрана, защита, ресурси,
// AI анализ, сигурност, подобрения.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showSafehousePanel() {
  Utils.log("Зареждаме Safehouse панела…");

  const app = Utils.qs("#app");

  // Премахваме стар панел
  const oldPanel = Utils.qs("#safehousePanelDynamic");
  if (oldPanel) oldPanel.remove();

  // Създаваме нов панел
  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "safehousePanelDynamic";

  // Данни от бекенда
  const safehouse = await ApiClient.getSafehouse();
  const guards = await ApiClient.getGuards();
  const upgrades = await ApiClient.getSafehouseUpgrades();

  // AI анализ
  const ai = AICore.safehouseAI({ safehouse, guards, upgrades });

  // ===============================================
  // MAIN PANEL TEMPLATE
  // ===============================================
  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-safehouse" style="margin-right:8px;"></span>
      Скривалище — Защита и AI анализ
    </div>

    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Ниво на сигурност:</strong>
      <span class="neon-blue">${ai.securityLevel}</span><br>

      <strong>Най-слаб сектор:</strong>
      <span class="neon-red">${ai.weakSector}</span><br>

      <strong>Най-добър ъпгрейд:</strong>
      <span class="neon-gold">${ai.bestUpgrade}</span><br>

      <strong>Прогноза:</strong>
      <span class="neon-purple">${ai.forecast}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-pink">${ai.recommendation}</span>
    </div>

    <div class="section-title">Скривалище</div>
    <div class="info-box">
      <strong>Ниво:</strong>
      <span class="neon-gold">${safehouse.level}</span><br>

      <strong>Сигурност:</strong>
      <span class="neon-blue">${safehouse.security}</span><br>

      <strong>Капацитет:</strong>
      <span class="neon-purple">${safehouse.capacity}</span><br>

      <strong>Описание:</strong>
      <div>${safehouse.description}</div>
    </div>

    <div class="section-title">Охрана</div>
    <div id="guardList">
      ${
        guards.length === 0
          ? `<div class="info-box">Няма охрана.</div>`
          : guards
              .map(
                g => `
        <div class="info-box guard-entry" data-id="${g._id}" style="cursor:pointer;">
          <div class="guard-title">${g.name}</div>

          <div class="guard-meta">
            <span>Сила: <span class="neon-red">${g.power}</span></span>
            <span>Точност: <span class="neon-blue">${g.accuracy}</span></span>
            <span>Риск: <span class="neon-purple">${g.risk}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <div class="section-title">Ъпгрейди</div>
    <div id="upgradeList">
      ${
        upgrades.length === 0
          ? `<div class="info-box">Няма налични ъпгрейди.</div>`
          : upgrades
              .map(
                u => `
        <div class="info-box upgrade-entry" data-id="${u._id}" style="cursor:pointer;">
          <div class="upgrade-title">${u.name}</div>

          <div class="upgrade-meta">
            <span>Цена: <span class="neon-gold">${Utils.formatMoney(u.price)}</span></span>
            <span>Сигурност: <span class="neon-blue">+${u.security}</span></span>
            <span>Капацитет: <span class="neon-purple">+${u.capacity}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <div class="panel-buttons">
      <button class="btn" id="refreshSafehouse">Обнови</button>
      <button class="btn" id="closeSafehousePanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // ===============================================
  // CLICK → Детайли за охрана
  // ===============================================
  panel.querySelectorAll("#guardList .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const guard = await ApiClient.getGuard(id);

      Utils.neonFlash(box, "#ff007c");

      const guardAI = AICore.guardAI(guard);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-safehouse" style="margin-right:8px;"></span>
          Охрана — ${guard.name}
        </div>

        <div class="info-box">
          <strong>Сила:</strong>
          <span class="neon-red">${guard.power}</span><br>

          <strong>Точност:</strong>
          <span class="neon-blue">${guard.accuracy}</span><br>

          <strong>Риск:</strong>
          <span class="neon-purple">${guard.risk}</span><br>

          <strong>AI оценка:</strong><br>
          Ефективност: <span class="neon-gold">${guardAI.efficiency}</span><br>
          Препоръка: <span class="neon-pink">${guardAI.recommendation}</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="hireGuard">Наеми</button>
          <button class="btn" id="backToSafehouse" style="margin-left:10px;">Назад</button>
          <button class="btn" id="closeSafehousePanel" style="margin-left:10px;">Затвори</button>
        </div>
      `;

      Utils.qs("#hireGuard").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.hireGuard(id);
        showSafehousePanel();
      });

      Utils.qs("#backToSafehouse").addEventListener("click", () => {
        showSafehousePanel();
      });

      Utils.qs("#closeSafehousePanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // CLICK → Детайли за ъпгрейд
  // ===============================================
  panel.querySelectorAll("#upgradeList .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const upgrade = await ApiClient.getSafehouseUpgrade(id);

      Utils.neonFlash(box, "#9b00ff");

      const upgradeAI = AICore.upgradeAI(upgrade);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-safehouse" style="margin-right:8px;"></span>
          Ъпгрейд — ${upgrade.name}
        </div>

        <div class="info-box">
          <strong>Цена:</strong>
          <span class="neon-gold">${Utils.formatMoney(upgrade.price)}</span><br>

          <strong>Сигурност:</strong>
          <span class="neon-blue">+${upgrade.security}</span><br>

          <strong>Капацитет:</strong>
          <span class="neon-purple">+${upgrade.capacity}</span><br>

          <strong>AI оценка:</strong><br>
          Ефективност: <span class="neon-gold">${upgradeAI.efficiency}</span><br>
          Препоръка: <span class="neon-pink">${upgradeAI.recommendation}</span>
        </div>

        <div class="panel-buttons">
          <button class="btn" id="buyUpgrade">Купи</button>
          <button class="btn" id="backToSafehouse" style="margin-left:10px;">Назад</button>
          <button class="btn" id="closeSafehousePanel" style="margin-left:10px;">Затвори</button>
        </div>
      `;

      Utils.qs("#buyUpgrade").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.buySafehouseUpgrade(id);
        showSafehousePanel();
      });

      Utils.qs("#backToSafehouse").addEventListener("click", () => {
        showSafehousePanel();
      });

      Utils.qs("#closeSafehousePanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // REFRESH
  // ===============================================
  Utils.qs("#refreshSafehouse").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showSafehousePanel();
  });

  // ===============================================
  // CLOSE
  // ===============================================
  Utils.qs("#closeSafehousePanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}