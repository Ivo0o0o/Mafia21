// ===============================================
// MAFIA 21st CENTURY — SETTINGS UI (PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Настройки: звук, графика, интерфейс, акаунт,
// производителност, AI препоръки.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";

export async function showSettingsPanel() {
  Utils.log("Зареждаме панела с настройки…");

  const app = Utils.qs("#app");

  // Премахваме стария панел
  const oldPanel = Utils.qs("#settingsPanelDynamic");
  if (oldPanel) oldPanel.remove();

  // Създаваме нов панел
  const panel = Utils.create("div", "panel");
  panel.id = "settingsPanelDynamic";

  // Вземаме настройки от бекенда
  const settings = await ApiClient.getSettings();

  // AI препоръки
  const ai = Utils.settingsAI(settings);

  panel.innerHTML = `
    <h2>Настройки</h2>

    <div class="info-box">
      <strong>AI препоръки:</strong><br>
      Производителност: <span style="color: var(--neon-blue)">${ai.performance}</span><br>
      Графика: <span style="color: var(--neon-purple)">${ai.graphics}</span><br>
      Звук: <span style="color: var(--neon-pink)">${ai.sound}</span><br>
      Интерфейс: <span style="color: var(--mafia-gold)">${ai.ui}</span>
    </div>

    <div class="info-box">
      <strong>Звук:</strong><br>
      <label>Гласност: ${settings.soundVolume}%</label>
      <input type="range" id="soundVolume" min="0" max="100" value="${settings.soundVolume}" style="width:100%; margin-top:10px;">
    </div>

    <div class="info-box">
      <strong>Графика:</strong><br>
      <label>Качество: ${settings.graphicsQuality}</label>
      <select id="graphicsQuality" class="btn" style="margin-top:10px;">
        <option value="Low" ${settings.graphicsQuality === "Low" ? "selected" : ""}>Low</option>
        <option value="Medium" ${settings.graphicsQuality === "Medium" ? "selected" : ""}>Medium</option>
        <option value="High" ${settings.graphicsQuality === "High" ? "selected" : ""}>High</option>
        <option value="Ultra" ${settings.graphicsQuality === "Ultra" ? "selected" : ""}>Ultra</option>
      </select>
    </div>

    <div class="info-box">
      <strong>Интерфейс:</strong><br>
      <label>Размер текст: ${settings.uiScale}%</label>
      <input type="range" id="uiScale" min="50" max="150" value="${settings.uiScale}" style="width:100%; margin-top:10px;">
    </div>

    <div class="info-box">
      <strong>Акаунт:</strong><br>
      <div>Потребител: <span style="color: var(--neon-blue)">${settings.username}</span></div>
      <div>ID: <span style="color: var(--mafia-gold)">${settings.userId}</span></div>
    </div>

    <button class="btn" id="saveSettings">Запази</button>
    <button class="btn" id="closeSettingsPanel" style="margin-left:10px;">Затвори</button>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // -----------------------------------------------
  // SAVE SETTINGS
  // -----------------------------------------------
  Utils.qs("#saveSettings").addEventListener("click", async () => {
    Utils.neonFlash(panel, "#00c8ff");

    const newSettings = {
      soundVolume: Utils.qs("#soundVolume").value,
      graphicsQuality: Utils.qs("#graphicsQuality").value,
      uiScale: Utils.qs("#uiScale").value
    };

    await ApiClient.saveSettings(newSettings);

    Utils.notify.success("Настройките са запазени!");
  });

  // -----------------------------------------------
  // CLOSE
  // -----------------------------------------------
  Utils.qs("#closeSettingsPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}