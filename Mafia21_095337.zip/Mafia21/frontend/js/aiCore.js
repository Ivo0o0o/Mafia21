// ===============================================
// MAFIA 21st CENTURY — AI CORE MODULE (AUTO-LOAD READY)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Всички AI функции са стабилизирани за autoInit()
// и автоматично зареждане от index.js
// ===============================================

export const AICore = {

  // ---------------------------------------------
  // NPC AI — настроение, решения, интензитет
  // ---------------------------------------------
  npcBehavior() {
    const emotions = ["спокоен", "нервен", "агресивен", "подозрителен", "лоялен", "враждебен"];
    const decisions = ["наблюдава", "атакува", "избягва", "лъже", "помага", "манипулира"];
    const intensity = Math.floor(Math.random() * 100);

    return {
      emotion: emotions[Math.floor(Math.random() * emotions.length)],
      decision: decisions[Math.floor(Math.random() * decisions.length)],
      intensity
    };
  },

  // ---------------------------------------------
  // NPC AI — детайлен анализ
  // ---------------------------------------------
  npcAI(npc = {}) {
    return {
      loyalty: npc.loyalty || 0,
      danger: Math.floor(Math.random() * 100),
      efficiency: Math.floor(Math.random() * 100),
      forecast: ["стабилен", "нестабилен", "опасен", "печеливш"][Math.floor(Math.random() * 4)],
      recommendation: (npc.loyalty || 0) > 50 ? "Поддържай връзка" : "Следи внимателно"
    };
  },

  // ---------------------------------------------
  // NPC LIST AI — анализ на всички NPC
  // ---------------------------------------------
  npcListAI(npcs = []) {
    if (!Array.isArray(npcs) || npcs.length === 0) {
      return {
        topLoyal: "няма",
        dangerous: "няма",
        useful: "няма",
        recommendation: "Няма NPC данни",
        forecast: "Няма промени"
      };
    }

    const topLoyal = [...npcs].sort((a, b) => (b.loyalty || 0) - (a.loyalty || 0))[0]?.name || "няма";
    const dangerous = npcs[Math.floor(Math.random() * npcs.length)]?.name || "няма";
    const useful = npcs[Math.floor(Math.random() * npcs.length)]?.name || "няма";

    return {
      topLoyal,
      dangerous,
      useful,
      recommendation: "Поддържай баланс между лоялност и ефективност",
      forecast: "Очаква се промяна в NPC поведението"
    };
  },

  // ---------------------------------------------
  // PLAYER AI — анализ на играча
  // ---------------------------------------------
  playerAI({ player = {}, skills = [], missions = [] }) {
    const heat = player.heat || 0;
    const level = player.level || 1;

    const playstyle = heat > 50 ? "агресивен" : "стратегически";
    const power = level * 10 + skills.length * 5;
    const weakness = heat > 70 ? "твърде много heat" : "ниска репутация";

    return {
      playstyle,
      power,
      weakness,
      forecast: level > 10 ? "Бърз прогрес" : "Бавен растеж",
      recommendation: heat > 50 ? "Намали heat" : "Продължавай да се развиваш"
    };
  },

  // ---------------------------------------------
  // WORLD EVENTS AI — анализ на всички събития
  // ---------------------------------------------
  worldEventsAI(events = []) {
    if (events.length === 0) {
      return {
        mostDangerous: "няма",
        mostProfitable: "няма",
        rare: "няма",
        forecast: "Няма събития",
        recommendation: "Няма препоръки"
      };
    }

    return {
      mostDangerous: [...events].sort((a, b) => (b.danger || 0) - (a.danger || 0))[0]?.title || "няма",
      mostProfitable: [...events].sort((a, b) => (b.effect || 0) - (a.effect || 0))[0]?.title || "няма",
      rare: events[Math.floor(Math.random() * events.length)]?.title || "няма",
      forecast: "Очаква се промяна в световните събития",
      recommendation: "Следи опасните събития"
    };
  },

  // ---------------------------------------------
  // WORLD EVENT AI — детайлен анализ
  // ---------------------------------------------
  worldEventAI(event = {}) {
    return {
      danger: event.danger || 0,
      profit: event.effect || 0,
      effect: event.effect || 0,
      forecast: ["стабилно", "нестабилно", "опасно"][Math.floor(Math.random() * 3)],
      recommendation: (event.danger || 0) > 50 ? "Избягвай района" : "Възползвай се"
    };
  },

  // ---------------------------------------------
  // DISTRICTS AI — анализ на всички райони
  // ---------------------------------------------
  districtsAI(districts = []) {
    if (districts.length === 0) {
      return {
        bestProfit: "няма",
        mostDangerous: "няма",
        stable: "няма",
        forecast: "Няма данни",
        recommendation: "Няма препоръки"
      };
    }

    return {
      bestProfit: [...districts].sort((a, b) => (b.resources || 0) - (a.resources || 0))[0]?.name || "няма",
      mostDangerous: [...districts].sort((a, b) => (b.heat || 0) - (a.heat || 0))[0]?.name || "няма",
      stable: [...districts].sort((a, b) => (b.reputation || 0) - (a.reputation || 0))[0]?.name || "няма",
      forecast: "Очаква се промяна в районите",
      recommendation: "Укрепи районите с ниска репутация"
    };
  },

  // ---------------------------------------------
  // DISTRICT AI — детайлен анализ
  // ---------------------------------------------
  districtAI(district = {}) {
    return {
      influence: district.influence || 0,
      reputation: district.reputation || 0,
      heat: district.heat || 0,
      resources: district.resources || 0,
      forecast: ["стабилен", "нестабилен", "опасен"][Math.floor(Math.random() * 3)],
      recommendation: (district.heat || 0) > 50 ? "Намали heat" : "Увеличи влияние"
    };
  },

  // ---------------------------------------------
  // COMBAT AI — агресия, риск, стратегия
  // ---------------------------------------------
  combatAI(enemy = {}) {
    const aggression = Math.floor(Math.random() * 100);
    const risk = Math.floor(Math.random() * 100);
    const strategies = ["директна атака", "защита", "контра-удар", "измама", "бягство"];
    const strategy = strategies[Math.floor(Math.random() * strategies.length)];

    return { aggression, risk, strategy };
  },

  // ---------------------------------------------
  // ECONOMY AI — риск, печалба, стабилност
  // ---------------------------------------------
  economyAI(economy = {}) {
    const income = economy.income || 0;
    const expenses = economy.expenses || 0;

    const risk = expenses > income ? "висок" : "нисък";
    const profit = income - expenses;
    const stability = profit > 0 ? "стабилна" : "нестабилна";

    return { risk, profit, stability };
  },

  // ---------------------------------------------
  // SKILL AI — ефективност, прогрес
  // ---------------------------------------------
  skillAI(skill = {}) {
    return {
      efficiency: Math.floor(Math.random() * 100),
      progress: Math.floor(Math.random() * 100)
    };
  },

  // ---------------------------------------------
  // MISSION AI — трудност, шанс за успех
  // ---------------------------------------------
  missionAI(mission = {}) {
    return {
      difficulty: Math.floor(Math.random() * 100),
      successChance: Math.floor(Math.random() * 100)
    };
  },

  // ---------------------------------------------
  // CITY LIFE AI — активност, опасност, трафик
  // ---------------------------------------------
  cityLifeAI(data = {}) {
    const activity = Math.floor(((data.citizens || 0) + (data.shops || 0)) / 2);
    const danger = Math.floor(data.danger || 0);
    const traffic = Math.floor(data.traffic || 0);

    let recommendation = "Градът е стабилен";

    if (danger > 70) recommendation = "Опасна зона — избягвай";
    else if (traffic > 60) recommendation = "Трафикът е висок — внимавай";

    return {
      activity,
      danger,
      traffic,
      recommendation
    };
  },

  // ---------------------------------------------
  // BLACK MARKET AI — общ анализ
  // ---------------------------------------------
  blackMarketAI(data = {}) {
    const activity = Math.floor(data.activity || 0);
    const danger = Math.floor(data.danger || 0);
    const offers = data.offers || 0;

    let recommendation = "Пазарът е стабилен";

    if (danger > 70) recommendation = "Много опасно — избягвай";
    else if (offers > 10) recommendation = "Много оферти — възможност за печалба";

    return {
      activity,
      danger,
      offers,
      recommendation
    };
  },

  // ---------------------------------------------
  // BLACK MARKET OFFER AI — детайлен анализ
  // ---------------------------------------------
  blackMarketOfferAI(offer = {}) {
    const risk = Math.floor(offer.risk || 0);
    const profit = Math.floor((offer.price || 0) * (Math.random() * 2));

    let recommendation = "Неутрално";

    if (risk > 70) recommendation = "Твърде опасно";
    else if (profit > (offer.price || 0)) recommendation = "Печелившо";

    return {
      risk,
      profit,
      recommendation
    };
  },

  // ---------------------------------------------
  // MAP AI — danger, police, black market, heat
  // ---------------------------------------------
  mapAI(district = {}) {
    return {
      danger: Math.floor(Math.random() * 100),
      police: district.policeActivity || 0,
      blackMarket: district.blackMarket || 0,
      heat: district.heat || 0,
      resources: district.resources || 0
    };
  },

  // ---------------------------------------------
  // DISTRICT DANGER AI — общ анализ на всички райони
  // ---------------------------------------------
  districtDangerAI(districts = []) {
    if (districts.length === 0) {
      return {
        avgRisk: 0,
        avgHeat: 0,
        recommendation: "Няма данни"
      };
    }

    const avgRisk = Math.floor(
      districts.reduce((sum, d) => sum + (d.danger || 0), 0) / districts.length
    );

    const avgHeat = Math.floor(
      districts.reduce((sum, d) => sum + (d.heat || 0), 0) / districts.length
    );

    let recommendation = "Поддържай стабилност";

    if (avgRisk > 70 || avgHeat > 70) recommendation = "Намали риска незабавно";
    else if (avgRisk > 40 || avgHeat > 40) recommendation = "Следи внимателно районите";

    return {
      avgRisk,
      avgHeat,
      recommendation
    };
  }
};