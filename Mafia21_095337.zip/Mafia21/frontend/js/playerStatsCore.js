// ===============================================
// MAFIA 21st CENTURY — PLAYER STATS CORE (ULTRA PRO MAX)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централен state на играча:
// ✔ level
// ✔ xp
// ✔ heat
// ✔ money
// ✔ reputation
// ✔ stats (strength, agility, intelligence)
// ✔ inventory
// ✔ skills
// ✔ missions
// ✔ autosync към ApiClient
// ✔ EventBus hooks
// ✔ AI hooks
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";
import { EventBus } from "./eventBus.js";

export const PlayerStatsCore = {
  player: null,
  listeners: [],

  async init() {
    Utils.log("PlayerStatsCore — зареждане...");
    this.player = await ApiClient.getPlayer();

    EventBus.emit("player_loaded", this.player);

    // Автоматичен refresh на всеки 3 секунди
    setInterval(() => this.sync(), 3000);

    Utils.log("PlayerStatsCore — активен.");
  },

  // ---------------------------------------------
  // ВРЪЩА ЦЕЛИЯ PLAYER STATE
  // ---------------------------------------------
  get() {
    return this.player;
  },

  // ---------------------------------------------
  // ОБНОВЯВА PLAYER STATE ЛОКАЛНО
  // ---------------------------------------------
  update(data) {
    Object.assign(this.player, data);
    this.notify();

    EventBus.emit("player_updated", this.player);
  },

  // ---------------------------------------------
  // СИНХРОНИЗАЦИЯ С API
  // ---------------------------------------------
  async sync() {
    const latest = await ApiClient.getPlayer();

    if (JSON.stringify(latest) !== JSON.stringify(this.player)) {
      this.player = latest;
      this.notify();

      EventBus.emit("player_synced", this.player);
    }
  },

  // ---------------------------------------------
  // ЗАПИСВА ПРОМЕНИТЕ В API
  // ---------------------------------------------
  async save() {
    await ApiClient.updatePlayer(this.player);
    this.notify();

    EventBus.emit("player_saved", this.player);
  },

  // ---------------------------------------------
  // LISTENERS — UI, AI, WORLD системи
  // ---------------------------------------------
  onChange(callback) {
    this.listeners.push(callback);
  },

  notify() {
    this.listeners.forEach(cb => cb(this.player));
  },

  // ---------------------------------------------
  // БЪРЗИ МЕТОДИ ЗА ПРОМЕНИ
  // ---------------------------------------------
  addXP(amount) {
    this.player.xp += amount;

    // Level up логика
    if (this.player.xp >= this.player.xpToNextLevel) {
      this.player.xp -= this.player.xpToNextLevel;
      this.player.level++;
      this.player.xpToNextLevel = Math.floor(this.player.xpToNextLevel * 1.25);

      EventBus.emit("player_level_up", {
        level: this.player.level
      });
    }

    this.save();
  },

  addMoney(amount) {
    this.player.money += amount;
    EventBus.emit("player_money_change", this.player.money);
    this.save();
  },

  addHeat(amount) {
    this.player.heat += amount;
    EventBus.emit("player_heat_change", this.player.heat);
    this.save();
  },

  addReputation(amount) {
    this.player.reputation += amount;
    EventBus.emit("player_reputation_change", this.player.reputation);
    this.save();
  },

  levelUp() {
    this.player.level++;
    EventBus.emit("player_level_up", { level: this.player.level });
    this.save();
  },

  // ---------------------------------------------
  // INVENTORY
  // ---------------------------------------------
  addItem(item) {
    this.player.inventory.push(item);

    EventBus.emit("player_inventory_add", item);
    this.save();
  },

  removeItem(itemId) {
    this.player.inventory = this.player.inventory.filter(i => i.id !== itemId);

    EventBus.emit("player_inventory_remove", itemId);
    this.save();
  },

  // ---------------------------------------------
  // SKILLS
  // ---------------------------------------------
  addSkill(skill) {
    this.player.skills.push(skill);

    EventBus.emit("player_skill_add", skill);
    this.save();
  },

  upgradeSkill(skillId) {
    const skill = this.player.skills.find(s => s.id === skillId);
    if (!skill) return;

    skill.level++;
    EventBus.emit("player_skill_upgrade", skill);
    this.save();
  },

  // ---------------------------------------------
  // MISSIONS
  // ---------------------------------------------
  addMission(mission) {
    this.player.missions.push(mission);

    EventBus.emit("player_mission_add", mission);
    this.save();
  },

  completeMission(missionId) {
    const mission = this.player.missions.find(m => m.id === missionId);
    if (!mission) return;

    mission.completed = true;

    EventBus.emit("player_mission_complete", mission);
    this.save();
  }
};

// Автоматично стартиране
PlayerStatsCore.init();