// ===============================================
// MAFIA 21st CENTURY — AI POLICE INTELLIGENCE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Патрули, разузнаване, преследване, анализ,
// засади, динамични решения, Heat реакция.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

export function initAIPoliceIntelligence() {
  Utils.log("AI Police Intelligence стартира…");

  const PoliceState = {
    tick: 0,
    patrolAggression: 1.0,
    pursuitIntensity: 1.0,
    intelligenceLevel: 1.0,
    lastPlayerLocation: null
  };

  // ===============================================
  // MAIN POLICE LOOP
  // ===============================================
  setInterval(async () => {
    PoliceState.tick++;

    const player = await ApiClient.getPlayer();
    const crime = await ApiClient.getCrimePulse();
    const districts = await ApiClient.getDistricts();
    const npc = await ApiClient.getNPCActivity();

    // ===============================================
    // HEAT → POLICE RESPONSE
    // ===============================================
    if (player.heat > 70) {
      PoliceState.pursuitIntensity += 0.1;
      Utils.log("Полицията: Heat е висок → преследване.");
      await ApiClient.policeStartPursuit(player.id);
    } else {
      PoliceState.pursuitIntensity -= 0.05;
    }

    // ===============================================
    // CRIME → PATROL RESPONSE
    // ===============================================
    if (crime.level > 60) {
      PoliceState.patrolAggression += 0.1;
      Utils.log("Полицията: престъпленията растат → повече патрули.");
      await ApiClient.policeIncreasePatrols();
    } else {
      PoliceState.patrolAggression -= 0.05;
    }

    // ===============================================
    // NPC ACTIVITY → INTELLIGENCE RESPONSE
    // ===============================================
    if (npc.activity > 50) {
      PoliceState.intelligenceLevel += 0.1;
      Utils.log("Полицията: NPC активност → разузнаване.");
      await ApiClient.policeGatherIntel();
    } else {
      PoliceState.intelligenceLevel -= 0.05;
    }

    // ===============================================
    // DISTRICT DANGER → POLICE DEPLOYMENT
    // ===============================================
    for (const d of districts) {
      if (d.danger > 70) {
        Utils.log(`Полицията: район ${d.name} е опасен → изпраща се екип.`);
        await ApiClient.policeDeployToDistrict(d.id);
      }
    }

    // ===============================================
    // PLAYER LOCATION TRACKING
    // ===============================================
    if (PoliceState.lastPlayerLocation !== player.location) {
      PoliceState.lastPlayerLocation = player.location;
      Utils.log(`Полицията: ново местоположение на играча.`);
      await ApiClient.policeTrackPlayer(player.location);
    }

    // ===============================================
    // POLICE AMBUSH LOGIC
    // ===============================================
    if (player.heat > 85 && crime.level > 75) {
      Utils.log("Полицията: засадата е активирана.");
      await ApiClient.policeAmbushPlayer(player.id);
    }

    // ===============================================
    // LIMITS
    // ===============================================
    PoliceState.patrolAggression = clamp(PoliceState.patrolAggression);
    PoliceState.pursuitIntensity = clamp(PoliceState.pursuitIntensity);
    PoliceState.intelligenceLevel = clamp(PoliceState.intelligenceLevel);

  }, 4000); // 4 секунди цикъл

  Utils.log("AI Police Intelligence работи.");
}

// ===============================================
// HELPERS
// ===============================================
function clamp(v) {
  return Math.max(0.5, Math.min(2.0, v));
}