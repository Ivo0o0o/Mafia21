// ===============================================
// MAFIA 21st CENTURY — WORLD TRAFFIC ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Симулация на трафик, задръствания,
// движение, риск, динамика на града.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";

export const worldTrafficEngine = {
  async simulate() {
    const districts = await ApiClient.getDistricts();
    const events = await ApiClient.getWorldEvents();

    const result = {
      busiestDistrict: null,
      calmestDistrict: null,
      trafficLevel: 0,
      riskZones: [],
      forecast: "",
      recommendation: ""
    };

    // Най-натоварен район
    result.busiestDistrict = districts.sort((a, b) => b.traffic - a.traffic)[0]?.name;

    // Най-спокоен район
    result.calmestDistrict = districts.sort((a, b) => a.traffic - b.traffic)[0]?.name;

    // Средно ниво на трафик
    result.trafficLevel =
      districts.reduce((sum, d) => sum + d.traffic, 0) / districts.length;

    // Рискови зони (трафик + престъпност)
    result.riskZones = districts
      .filter(d => d.traffic > 70 && d.crime > 50)
      .map(d => d.name);

    // Прогноза според събития
    const activeEvents = events.filter(e => e.type === "protest" || e.type === "accident");

    if (activeEvents.length > 3) {
      result.forecast = "Очакват се масивни задръствания в ключови райони.";
    } else if (activeEvents.length > 0) {
      result.forecast = "Възможни са локални забавяния.";
    } else {
      result.forecast = "Трафикът ще остане стабилен.";
    }

    // Препоръка
    if (result.trafficLevel > 70) {
      result.recommendation = "Използвай алтернативни маршрути и избягвай централните райони.";
    } else if (result.trafficLevel > 40) {
      result.recommendation = "Планирай придвижването внимателно.";
    } else {
      result.recommendation = "Градът е спокоен — придвижването е лесно.";
    }

    Utils.log("World Traffic Engine — симулация завършена.");
    return result;
  }
};