// ===============================================
// MAFIA 21st CENTURY — FRONTEND UTILS (PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Помощни функции, мини AI логика, UI ефекти,
// форматери, DOM helpers — основен utility модул.
// ===============================================

export const Utils = {

  // -----------------------------------------------
  // RANDOM HELPERS
  // -----------------------------------------------
  rand(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  },

  choice(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  },

  // -----------------------------------------------
  // NEON UI EFFECTS
  // -----------------------------------------------
  neonPulse(element, color = "#00c8ff") {
    if (!element) return;
    element.style.boxShadow = `0 0 15px ${color}`;
    setTimeout(() => {
      element.style.boxShadow = "none";
    }, 300);
  },

  neonFlash(element, color = "#ff007c") {
    if (!element) return;
    element.style.transition = "0.2s";
    element.style.filter = `drop-shadow(0 0 10px ${color})`;
    setTimeout(() => {
      element.style.filter = "none";
    }, 250);
  },

  // -----------------------------------------------
  // LOGGING (MAFIA STYLE)
  // -----------------------------------------------
  log(message) {
    console.log(`💶 MAFIA21 LOG: ${message}`);
  },

  warn(message) {
    console.warn(`⚠️ MAFIA21 WARNING: ${message}`);
  },

  error(message) {
    console.error(`❌ MAFIA21 ERROR: ${message}`);
  },

  // -----------------------------------------------
  // MINI AI — NPC REACTION SIMULATOR
  // -----------------------------------------------
  npcEmotionAI() {
    const emotions = [
      "aggressive",
      "neutral",
      "curious",
      "hostile",
      "friendly",
      "calculating",
      "paranoid",
      "confident"
    ];
    return this.choice(emotions);
  },

  npcDecisionAI() {
    const decisions = [
      "observe",
      "follow",
      "attack",
      "retreat",
      "negotiate",
      "hide",
      "scan_area",
      "call_backup"
    ];
    return this.choice(decisions);
  },

  npcBehaviorAI() {
    return {
      emotion: this.npcEmotionAI(),
      decision: this.npcDecisionAI(),
      intensity: this.rand(1, 10)
    };
  },

  // -----------------------------------------------
  // FORMATTERS
  // -----------------------------------------------
  formatPercent(value) {
    return `${value.toFixed(1)}%`;
  },

  formatMoney(value) {
    return `${value.toLocaleString()} 💶`;
  },

  // -----------------------------------------------
  // DOM HELPERS
  // -----------------------------------------------
  qs(selector) {
    return document.querySelector(selector);
  },

  create(tag, className = "") {
    const el = document.createElement(tag);
    if (className) el.className = className;
    return el;
  },

  // -----------------------------------------------
  // PANEL SWITCHER (FIXED)
  // -----------------------------------------------
  showPanel(id) {
    document.querySelectorAll("#app > *").forEach(el => el.style.display = "none");
    this.qs("#" + id).style.display = "block";
  }
};