// ===============================================
// MAFIA 21st CENTURY — ADMIN GOD PANEL (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централен контрол на играта: NPC, полиция,
// икономика, райони, AI, логове, debug.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";

export function initAdminUI() {
  Utils.log("Admin Panel зареден…");

  const app = Utils.qs("#app");

  // Създаваме главния контейнер
  const adminRoot = Utils.create("div", "admin-panel");
  adminRoot.id = "adminApp";
  app.appendChild(adminRoot);

  // ===============================================
  // HEADER
  // ===============================================
  adminRoot.innerHTML = `
    <h2>ADMIN GOD PANEL</h2>
    <p style="color: var(--admin-gold); font-weight: 600;">
      Пълен контрол над света на Мафия от 21ви век
    </p>
  `;

  // ===============================================
  // NPC CONTROL PANEL
  // ===============================================
  const npcPanel = Utils.create("div", "admin-panel");
  npcPanel.innerHTML = `
    <h2>NPC Контрол</h2>

    <button class="admin-btn" id="adminSpawnNPC">Създай NPC</button>
    <button class="admin-btn" id="adminBoostNPC">Boost NPC</button>

    <div class="admin-log" id="npcLog">NPC Log:</div>
  `;
  adminRoot.appendChild(npcPanel);

  // ===============================================
  // POLICE CONTROL PANEL
  // ===============================================
  const policePanel = Utils.create("div", "admin-panel");
  policePanel.innerHTML = `
    <h2>Полиция</h2>

    <button class="admin-btn" id="adminSpawnPolice">Прати патрул</button>
    <button class="admin-btn" id="adminHeatReset">Reset Heat</button>

    <div class="admin-log" id="policeLog">Police Log:</div>
  `;
  adminRoot.appendChild(policePanel);

  // ===============================================
  // DISTRICT CONTROL PANEL
  // ===============================================
  const districtPanel = Utils.create("div", "admin-panel");
  districtPanel.innerHTML = `
    <h2>Райони</h2>

    <button class="admin-btn" id="adminRefreshDistricts">Обнови районите</button>

    <div class="admin-log" id="districtLog">District Log:</div>
  `;
  adminRoot.appendChild(districtPanel);

  // ===============================================
  // ECONOMY CONTROL PANEL
  // ===============================================
  const economyPanel = Utils.create("div", "admin-panel");
  economyPanel.innerHTML = `
    <h2>Икономика</h2>

    <input class="admin-input" id="adminMoneyInput" placeholder="Сума…" />
    <button class="admin-btn" id="adminGiveMoney">Дай пари на играча</button>

    <div class="admin-log" id="economyLog">Economy Log:</div>
  `;
  adminRoot.appendChild(economyPanel);

  // ===============================================
  // EVENT LISTENERS
  // ===============================================

  Utils.qs("#adminSpawnNPC").addEventListener("click", async () => {
    const npc = await ApiClient.spawnNPC();
    Utils.appendLog("#npcLog", `NPC създаден: ${npc.name}`);
  });

  Utils.qs("#adminBoostNPC").addEventListener("click", async () => {
    await ApiClient.boostNPC();
    Utils.appendLog("#npcLog", "NPC Boost изпълнен.");
  });

  Utils.qs("#adminSpawnPolice").addEventListener("click", async () => {
    await ApiClient.spawnPolice();
    Utils.appendLog("#policeLog", "Полиция изпратена.");
  });

  Utils.qs("#adminHeatReset").addEventListener("click", async () => {
    await ApiClient.resetHeat();
    Utils.appendLog("#policeLog", "Heat reset.");
  });

  Utils.qs("#adminRefreshDistricts").addEventListener("click", async () => {
    const d = await ApiClient.getDistricts();
    Utils.appendLog("#districtLog", `Обновени райони: ${d.length}`);
  });

  Utils.qs("#adminGiveMoney").addEventListener("click", async () => {
    const amount = Number(Utils.qs("#adminMoneyInput").value);
    await ApiClient.giveMoney(amount);
    Utils.appendLog("#economyLog", `Играчът получи ${amount}€`);
  });

  Utils.log("Admin Panel готов.");
}
const adminRoot = Utils.create("div", "admin-panel");
adminRoot.id = "adminApp";
app.appendChild(adminRoot);