// ===============================================
// MAFIA 21st CENTURY — HEAT MAP ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Управлява:
// ✔ danger zones
// ✔ heat escalation
// ✔ police response zones
// ✔ gang activity zones
// ✔ citizen panic levels
// ✔ dynamic world heat map
//
// Използва:
// ✔ WorldState
// ✔ AIDirector
// ✔ Utils
// ===============================================

import { WorldState } from "./worldState.js";
import { Utils } from "./utils.js";

export const HeatMapEngine = {
  lastUpdate: Date.now(),

  init() {
    Utils.log("HeatMapEngine — стартиране...");
    setInterval(() => this.update(), 4000);
  },

  // ---------------------------------------------
  // ГЛАВЕН UPDATE LOOP
  // ---------------------------------------------
  update() {
    const world = WorldState.get();

    this.recalculateHeat(world);
    this.applyHeatEffects(world);

    this.lastUpdate = Date.now();
  },

  // ---------------------------------------------
  // ПРЕИЗЧИСЛЯВА HEAT ЗА ВСЯКА ЗОНА
  // ---------------------------------------------
  recalculateHeat(world) {
    world.heat = world.zones.map(zone => {
      const crimes = world.events.filter(e => e.zone.id === zone.id);
      const gangs = world.gangs.filter(g => g.zone === zone.id);
      const police = world.police.filter(p => p.zone === zone.id);

      let level = 0;

      level += crimes.length * 5;
      level += gangs.length * 3;
      level -= police.length * 2;

      level = Utils.clamp(level, 0, 100);

      return {
        zoneId: zone.id,
        level,
        status:
          level < 20 ? "calm" :
          level < 50 ? "tense" :
          level < 80 ? "danger" :
          "critical"
      };
    });

    Utils.log("HeatMapEngine — heat recalculated.");
  },

  // ---------------------------------------------
  // ПРИЛАГА ЕФЕКТИ СПОРЕД HEAT LEVEL
  // ---------------------------------------------
  applyHeatEffects(world) {
    world.heat.forEach(h => {
      const zone = world.zones.find(z => z.id === h.zoneId);

      if (!zone) return;

      switch (h.status) {
        case "calm":
          zone.citizenMood = "relaxed";
          zone.spawnRate = 1;
          break;

        case "tense":
          zone.citizenMood = "alert";
          zone.spawnRate = 1.2;
          break;

        case "danger":
          zone.citizenMood = "scared";
          zone.spawnRate = 1.5;
          break;

        case "critical":
          zone.citizenMood = "panic";
          zone.spawnRate = 2;
          break;
      }
    });
  }
};

// Автоматично стартиране
HeatMapEngine.init();