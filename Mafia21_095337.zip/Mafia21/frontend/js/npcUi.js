// ===============================================
// MAFIA 21st CENTURY — NPC UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// NPC визуализация, настроение, лоялност,
// статус, умения, AI анализ, AI препоръки,
// AI поведение, AI прогнози.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showNPCPanel() {
  Utils.log("Зареждаме NPC панела…");

  const app = Utils.qs("#app");

  const oldPanel = Utils.qs("#npcPanelDynamic");
  if (oldPanel) oldPanel.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "npcPanelDynamic";

  // Вземаме NPC от бекенда
  const npcs = await ApiClient.getNPCs();

  // AI анализ на всички NPC
  const ai = AICore.npcListAI(npcs);

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-npc" style="margin-right:8px;"></span>
      NPC Панел — Контрол и Поведение
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Най-лоялен NPC:</strong>
      <span class="neon-gold">${ai.topLoyal}</span><br>

      <strong>Най-опасен NPC:</strong>
      <span class="neon-red">${ai.dangerous}</span><br>

      <strong>Най-полезен NPC:</strong>
      <span class="neon-blue">${ai.useful}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-purple">${ai.recommendation}</span>
    </div>

    <!-- NPC LIST -->
    <div class="section-title">Списък NPC</div>
    <div class="info-box">
      <ul id="npcList" class="npc-list">
        ${npcs
          .map(
            npc => `
          <li class="npc-entry" data-id="${npc._id}">
            <span class="neon-gold">${npc.name}</span>
            <span class="neon-blue">${npc.role}</span>
            <span class="neon-pink">(${npc.mood})</span>
          </li>
        `
          )
          .join("")}
      </ul>
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshNPC">Обнови NPC</button>
      <button class="btn" id="closeNPCPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // -----------------------------------------------
  // CLICK → NPC детайли + AI анализ
  // -----------------------------------------------
  panel.querySelectorAll("#npcList .npc-entry").forEach(li => {
    li.addEventListener("click", async () => {
      const npcId = li.dataset.id;
      const npc = await ApiClient.getNPC(npcId);

      Utils.neonFlash(li, "#ff007c");

      const npcAI = AICore.npcAI(npc);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-npc" style="margin-right:8px;"></span>
          ${npc.name}
        </div>

        <!-- AI ANALYSIS -->
        <div class="section-title">AI Анализ</div>
        <div class="info-box">
          <strong>Лоялност:</strong>
          <span class="neon-gold">${npcAI.loyalty}</span><br>

          <strong>Опасност:</strong>
          <span class="neon-red">${npcAI.danger}</span><br>

          <strong>Ефективност:</strong>
          <span class="neon-blue">${npcAI.efficiency}</span><br>

          <strong>Прогноза:</strong>
          <span class="neon-purple">${npcAI.forecast}</span><br>

          <strong>Препоръка:</strong>
          <span class="neon-pink">${npcAI.recommendation}</span>
        </div>

        <!-- NPC DETAILS -->
        <div class="section-title">Детайли</div>

        <div class="info-box">
          <strong>Роля:</strong>
          <span class="neon-blue">${npc.role}</span>
        </div>

        <div class="info-box">
          <strong>Настроение:</strong>
          <span class="neon-purple">${npc.mood}</span>
        </div>

        <div class="info-box">
          <strong>Лоялност:</strong>
          <span class="neon-gold">${npc.loyalty}%</span>
        </div>

        <div class="info-box">
          <strong>Статус:</strong>
          <span class="neon-red">${npc.status}</span>
        </div>

        <!-- SKILLS -->
        <div class="section-title">Умения</div>
        <div class="info-box">
          <ul class="npc-skills">
            ${npc.skills
              .map(
                s => `
              <li class="npc-skill">
                <span class="neon-blue">${s}</span>
              </li>
            `
              )
              .join("")}
          </ul>
        </div>

        <!-- BUTTONS -->
        <div class="panel-buttons">
          <button class="btn" id="backToNPCList">Назад</button>
          <button class="btn" id="closeNPCPanel">Затвори</button>
        </div>
      `;

      Utils.qs("#backToNPCList").addEventListener("click", () => {
        showNPCPanel();
      });

      Utils.qs("#closeNPCPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // -----------------------------------------------
  // REFRESH NPC LIST
  // -----------------------------------------------
  Utils.qs("#refreshNPC").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showNPCPanel();
  });

  // -----------------------------------------------
  // CLOSE PANEL
  // -----------------------------------------------
  Utils.qs("#closeNPCPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}