// ===============================================
// MAFIA 21st CENTURY — WORLD EMERGENCY ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Симулация на аварии, инциденти,
// полиция, линейки, пожарни,
// риск, реакция, динамика.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { EventBus } from "./eventBus.js"; // ⭐ добавено

export const worldEmergencyEngine = {
  async simulate() {
    EventBus.emit("emergency_tick", {}); // ⭐

    try {
      const districts = await ApiClient.getDistricts();
      const emergencies = await ApiClient.getEmergencies();

      const result = {
        mostCriticalDistrict: null,
        safestDistrict: null,
        emergencyLevel: 0,
        activeEmergencies: [],
        forecast: "",
        recommendation: ""
      };

      // Най-критичен район (инциденти + престъпност)
      result.mostCriticalDistrict = districts
        .sort((a, b) => (b.emergency + b.crime) - (a.emergency + a.crime))[0]?.name;

      // Най-безопасен район
      result.safestDistrict = districts.sort((a, b) => a.emergency - b.emergency)[0]?.name;

      // Средно ниво на аварийни ситуации
      result.emergencyLevel =
        districts.reduce((sum, d) => sum + d.emergency, 0) / districts.length;

      EventBus.emit("emergency_risk_update", {
        level: result.emergencyLevel,
        critical: result.mostCriticalDistrict,
        safe: result.safestDistrict
      }); // ⭐

      // Активни инциденти
      result.activeEmergencies = emergencies.map(e => ({
        type: e.type,
        district: e.district,
        severity: e.severity
      }));

      EventBus.emit("emergency_dispatch", {
        active: result.activeEmergencies
      }); // ⭐

      // Прогноза според тежестта на инцидентите
      const severeCount = emergencies.filter(e => e.severity > 70).length;

      if (severeCount > 5) {
        result.forecast = "Очаква се масивна вълна от инциденти.";
      } else if (severeCount > 0) {
        result.forecast = "Възможни са локални критични ситуации.";
      } else {
        result.forecast = "Градът е стабилен — нисък риск.";
      }

      EventBus.emit("emergency_forecast", {
        forecast: result.forecast,
        severeCount
      }); // ⭐

      // Препоръка
      if (result.emergencyLevel > 70) {
        result.recommendation = "Избягвай критичните райони — рискът е много висок.";
      } else if (result.emergencyLevel > 40) {
        result.recommendation = "Планирай действията си внимателно — възможни са инциденти.";
      } else {
        result.recommendation = "Градът е спокоен — идеално време за операции.";
      }

      EventBus.emit("emergency_recommendation", {
        recommendation: result.recommendation
      }); // ⭐

      Utils.log("World Emergency Engine — симулация завършена.");
      return result;

    } catch (err) {
      console.error("❌ EmergencyEngine ERROR:", err);
      EventBus.emit("emergency_error", { error: err }); // ⭐
    }
  }
};