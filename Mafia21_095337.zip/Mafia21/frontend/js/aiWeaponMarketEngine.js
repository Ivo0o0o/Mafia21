// ===============================================
// MAFIA 21st CENTURY — AI WEAPON MARKET ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Анализ на оръжия, цени, риск,
// черен пазар, прогнози, препоръки.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";

export const aiWeaponMarketEngine = {
  async analyze() {
    const weapons = await ApiClient.getWeapons();
    const blackMarket = await ApiClient.getBlackMarketWeapons();
    const heat = await ApiClient.getHeatLevels();

    const result = {
      bestDeal: null,
      worstDeal: null,
      mostDangerousWeapon: null,
      cheapestWeapon: null,
      forecast: "",
      recommendation: ""
    };

    // Най-добра сделка (цена/щета)
    result.bestDeal = weapons
      .sort((a, b) => (b.damage / b.price) - (a.damage / a.price))[0]?.name;

    // Най-лоша сделка
    result.worstDeal = weapons
      .sort((a, b) => (a.damage / a.price) - (b.damage / b.price))[0]?.name;

    // Най-опасно оръжие
    result.mostDangerousWeapon = weapons.sort((a, b) => b.risk - a.risk)[0]?.name;

    // Най-евтино оръжие
    result.cheapestWeapon = weapons.sort((a, b) => a.price - b.price)[0]?.name;

    // Прогноза според heat
    const avgHeat = heat.reduce((a, b) => a + b.level, 0) / heat.length;

    if (avgHeat > 70) {
      result.forecast = "Очаква се рязко покачване на цените на оръжия.";
    } else if (avgHeat > 40) {
      result.forecast = "Пазарът е нестабилен, възможни са промени.";
    } else {
      result.forecast = "Пазарът е спокоен, цените ще останат стабилни.";
    }

    // Препоръка
    if (avgHeat > 70) {
      result.recommendation = "Купи оръжия сега — цените ще скочат.";
    } else if (avgHeat > 40) {
      result.recommendation = "Следи пазара и купувай само добри сделки.";
    } else {
      result.recommendation = "Време е за масови покупки — пазарът е спокоен.";
    }

    Utils.log("AI Weapon Market Engine — анализ завършен.");
    return result;
  }
};