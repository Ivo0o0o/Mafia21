// ===============================================
// MAFIA 21st CENTURY — OPERATIONS NETWORK (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Връзка с бекенда за операции, мисии, екипи.
// ===============================================

import { ApiClient } from "./apiClient.js";

export const OperationsNetwork = {
  async getOperations() {
    return await ApiClient.getOperations();
  },

  async getOperation(id) {
    return await ApiClient.getOperation(id);
  },

  async startOperation(id) {
    return await ApiClient.startOperation(id);
  },

  async cancelOperation(id) {
    return await ApiClient.cancelOperation(id);
  },

  async getTeams() {
    return await ApiClient.getTeams();
  },

  async getTeam(id) {
    return await ApiClient.getTeam(id);
  },

  async assignTeamToOperation(operationId, teamId) {
    return await ApiClient.assignTeamToOperation(operationId, teamId);
  },
};