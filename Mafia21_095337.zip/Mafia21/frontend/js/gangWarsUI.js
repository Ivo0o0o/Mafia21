// ===============================================
// MAFIA 21st CENTURY — GANG WARS UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Бандови войни, териториални конфликти,
// AI анализ, AI прогнози, AI препоръки,
// динамика между организации и NPC фракции.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showGangWarsPanel() {
  Utils.log("Зареждаме Gang Wars панела…");

  const app = Utils.qs("#app");

  // Премахваме стар панел
  const old = Utils.qs("#gangWarsPanelDynamic");
  if (old) old.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "gangWarsPanelDynamic";

  // Данни от бекенда
  const wars = await ApiClient.getGangWars();
  const factions = await ApiClient.getFactions();
  const territories = await ApiClient.getTerritories();

  // AI анализ
  const ai = AICore.gangWarsAI(wars, factions, territories);

  // ===============================================
  // MAIN PANEL TEMPLATE
  // ===============================================
  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-gangwars" style="margin-right:8px;"></span>
      Бандови войни — Териториален контрол
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Най-опасен конфликт:</strong>
      <span class="neon-red">${ai.mostDangerous}</span><br>

      <strong>Най-голяма възможност:</strong>
      <span class="neon-gold">${ai.bestOpportunity}</span><br>

      <strong>Най-слаб район:</strong>
      <span class="neon-blue">${ai.weakDistrict}</span><br>

      <strong>Прогноза:</strong>
      <span class="neon-purple">${ai.forecast}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-pink">${ai.recommendation}</span>
    </div>

    <!-- ACTIVE WARS -->
    <div class="section-title">Активни конфликти</div>
    <div id="gangWarsList">
      ${
        wars.length === 0
          ? `<div class="info-box">Няма активни конфликти.</div>`
          : wars
              .map(
                w => `
        <div class="info-box gang-war-entry" data-id="${w._id}" style="cursor:pointer;">
          <div class="gang-war-title">${w.factionA} vs ${w.factionB}</div>

          <div class="gang-war-meta">
            <span>Район: <span class="neon-blue">${w.district}</span></span>
            <span>Интензитет: <span class="neon-red">${w.intensity}</span></span>
            <span>Награда: <span class="neon-gold">${w.reward}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshGangWars">Обнови</button>
      <button class="btn" id="closeGangWarsPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#ff004c");

  // ===============================================
  // CLICK → Детайли за конфликт
  // ===============================================
  panel.querySelectorAll("#gangWarsList .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const conflict = await ApiClient.getGangWar(id);

      Utils.neonFlash(box, "#ff007c");

      const conflictAI = AICore.singleGangWarAI(conflict);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-gangwars" style="margin-right:8px;"></span>
          ${conflict.factionA} vs ${conflict.factionB}
        </div>

        <div class="section-title">AI Анализ</div>
        <div class="info-box">
          <strong>Интензитет:</strong>
          <span class="neon-red">${conflict.intensity}</span><br>

          <strong>Риск:</strong>
          <span class="neon-blue">${conflictAI.risk}</span><br>

          <strong>Шанс за победа:</strong>
          <span class="neon-gold">${conflictAI.winChance}</span><br>

          <strong>Прогноза:</strong>
          <span class="neon-purple">${conflictAI.forecast}</span><br>

          <strong>Препоръка:</strong>
          <span class="neon-pink">${conflictAI.recommendation}</span>
        </div>

        <div class="section-title">Описание</div>
        <div class="info-box">
          ${conflict.description || "Няма описание."}
        </div>

        <div class="panel-buttons">
          <button class="btn" id="backToGangWars">Назад</button>
          <button class="btn" id="closeGangWarsPanel">Затвори</button>
        </div>
      `;

      Utils.qs("#backToGangWars").addEventListener("click", () => {
        showGangWarsPanel();
      });

      Utils.qs("#closeGangWarsPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // REFRESH
  // ===============================================
  Utils.qs("#refreshGangWars").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showGangWarsPanel();
  });

  // ===============================================
  // CLOSE
  // ===============================================
  Utils.qs("#closeGangWarsPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}