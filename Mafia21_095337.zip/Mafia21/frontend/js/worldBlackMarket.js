// ===============================================
// MAFIA 21st CENTURY — WORLD BLACK MARKET ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { EventBus } from "./eventBus.js";

const CONFIG = {
  risk: {
    highRiskThreshold: 70,
    mediumRiskThreshold: 40
  },
  weights: {
    shadowEconomy: 0.6,
    crime: 0.4
  }
};

function computeDistrictRisk(district) {
  const { shadowEconomy, crime } = district;
  const { shadowEconomy: wShadow, crime: wCrime } = CONFIG.weights;

  const riskScore = Math.round(
    shadowEconomy * wShadow +
    crime * wCrime
  );

  return Utils.clamp(riskScore, 0, 100);
}

function buildRiskHeatmap(districts) {
  return districts.map(d => ({
    district: d.name,
    risk: computeDistrictRisk(d),
    shadowEconomy: d.shadowEconomy,
    crime: d.crime
  }));
}

function buildFactionInfluence(factions) {
  return factions.map(f => ({
    name: f.name,
    influence: f.shadowInfluence,
    reputation: f.reputation,
    powerIndex: Math.round((f.shadowInfluence + f.reputation) / 2)
  }));
}

function computeForecast(riskHeatmap) {
  const highRiskZones = riskHeatmap.filter(h => h.risk >= CONFIG.risk.highRiskThreshold).length;
  const mediumRiskZones = riskHeatmap.filter(h => h.risk >= CONFIG.risk.mediumRiskThreshold && h.risk < CONFIG.risk.highRiskThreshold).length;

  if (highRiskZones > 5) {
    return {
      text: "Сивият сектор е в експанзия — очаква се висока нестабилност.",
      level: "critical",
      highRiskZones,
      mediumRiskZones
    };
  } else if (highRiskZones > 0 || mediumRiskZones > 0) {
    return {
      text: "Има локални рискови зони със засилен сив сектор.",
      level: "elevated",
      highRiskZones,
      mediumRiskZones
    };
  } else {
    return {
      text: "Сивият сектор е под контрол — ниска нестабилност.",
      level: "low",
      highRiskZones,
      mediumRiskZones
    };
  }
}

function computeRecommendation(blackMarketLevel) {
  if (blackMarketLevel >= CONFIG.risk.highRiskThreshold) {
    return {
      text: "Избягвай високорисковите райони — сивият сектор доминира.",
      strategy: "defensive"
    };
  } else if (blackMarketLevel >= CONFIG.risk.mediumRiskThreshold) {
    return {
      text: "Планирай внимателно — баланс между официална и сива икономика.",
      strategy: "balanced"
    };
  } else {
    return {
      text: "Официалната икономика доминира — нисък риск от нестабилност.",
      strategy: "expansion"
    };
  }
}

export const worldBlackMarketEngine = {
  async simulate() {
    EventBus.emit("blackmarket_tick", { ts: Date.now() });

    try {
      const [districts, factions, shadowEconomy] = await Promise.all([
        ApiClient.getDistricts(),
        ApiClient.getFactions(),
        ApiClient.getShadowEconomy()
      ]);

      const result = {
        hottestDistrict: null,
        safestDistrict: null,
        blackMarketLevel: 0,
        factionInfluence: [],
        riskHeatmap: [],
        forecast: null,
        recommendation: null,
        meta: {
          shadowEconomy,
          timestamp: Date.now()
        }
      };

      // Сортиране само веднъж
      const sortedByShadow = [...districts].sort(
        (a, b) => b.shadowEconomy - a.shadowEconomy
      );

      result.hottestDistrict = sortedByShadow[0]?.name || null;
      result.safestDistrict = sortedByShadow[sortedByShadow.length - 1]?.name || null;

      // Средно ниво на сивия сектор
      result.blackMarketLevel = Utils.average(
        districts.map(d => d.shadowEconomy)
      );

      // Heatmap
      result.riskHeatmap = buildRiskHeatmap(districts);

      // Фракции
      result.factionInfluence = buildFactionInfluence(factions);

      // Прогноза
      result.forecast = computeForecast(result.riskHeatmap);

      // Препоръка
      result.recommendation = computeRecommendation(result.blackMarketLevel);

      // Единно събитие + детайлни
      EventBus.emit("blackmarket_snapshot", result);

      EventBus.emit("blackmarket_risk_update", {
        level: result.blackMarketLevel,
        hottest: result.hottestDistrict,
        safest: result.safestDistrict
      });

      EventBus.emit("blackmarket_faction_influence", {
        factions: result.factionInfluence
      });

      EventBus.emit("blackmarket_heatmap", {
        heatmap: result.riskHeatmap
      });

      EventBus.emit("blackmarket_forecast", result.forecast);

      EventBus.emit("blackmarket_recommendation", result.recommendation);

      Utils.log("World Black Market Engine PRO — симулация завършена.");
      return result;

    } catch (err) {
      console.error("❌ BlackMarketEngine PRO ERROR:", err);
      EventBus.emit("blackmarket_error", { error: err, ts: Date.now() });
      throw err;
    }
  }
};