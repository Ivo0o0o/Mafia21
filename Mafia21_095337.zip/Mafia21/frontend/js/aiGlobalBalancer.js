// ===============================================
// MAFIA 21st CENTURY — AI GLOBAL BALANCER (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централен баланс на света: престъпност, полиция,
// NPC, икономика, инфлация, опасност, контрол,
// влияние, събития, растеж, упадък.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

export function initAIGlobalBalancer() {
  Utils.log("AI Global Balancer стартира…");

  const BalanceState = {
    tick: 0,
    globalStability: 1.0,
    chaosLevel: 0.0,
    economyPressure: 1.0,
    policePressure: 1.0,
    npcPressure: 1.0,
    districtPressure: 1.0
  };

  // ===============================================
  // MAIN BALANCER LOOP
  // ===============================================
  setInterval(async () => {
    BalanceState.tick++;

    const crime = await ApiClient.getCrimePulse();
    const police = await ApiClient.getPoliceStatus();
    const npc = await ApiClient.getNPCActivity();
    const economy = await ApiClient.getInflation();
    const player = await ApiClient.getPlayer();
    const districts = await ApiClient.getDistricts();

    // ===============================================
    // CHAOS LEVEL CALCULATION
    // ===============================================
    BalanceState.chaosLevel =
      (crime.level / 100) * 0.4 +
      (npc.activity / 100) * 0.2 +
      (economy - 1.0) * 0.2 +
      (player.heat / 100) * 0.2;

    // ===============================================
    // GLOBAL STABILITY CALCULATION
    // ===============================================
    BalanceState.globalStability =
      1.0 -
      BalanceState.chaosLevel +
      (police.patrols * 0.05);

    BalanceState.globalStability = clamp(BalanceState.globalStability);

    // ===============================================
    // AUTO‑BALANCE: POLICE
    // ===============================================
    if (BalanceState.chaosLevel > 0.6) {
      Utils.log("GLOBAL BALANCER: Полицията се засилва.");
      await ApiClient.policeIncreasePatrols();
    }

    if (BalanceState.chaosLevel < 0.3) {
      Utils.log("GLOBAL BALANCER: Полицията се отпуска.");
      await ApiClient.policeReducePatrols();
    }

    // ===============================================
    // AUTO‑BALANCE: NPC
    // ===============================================
    if (BalanceState.globalStability < 0.4) {
      Utils.log("GLOBAL BALANCER: NPC стават по‑спокойни.");
      await ApiClient.npcCalmDown();
    }

    if (BalanceState.globalStability > 0.7) {
      Utils.log("GLOBAL BALANCER: NPC стават по‑активни.");
      await ApiClient.npcIncreaseActivity();
    }

    // ===============================================
    // AUTO‑BALANCE: ECONOMY
    // ===============================================
    if (economy > 1.4) {
      Utils.log("GLOBAL BALANCER: Инфлацията е висока → стабилизация.");
      await ApiClient.economyStabilize();
    }

    if (economy < 0.9) {
      Utils.log("GLOBAL BALANCER: Икономиката е твърде спокойна → стимулиране.");
      await ApiClient.economyStimulate();
    }

    // ===============================================
    // AUTO‑BALANCE: DISTRICTS
    // ===============================================
    for (const d of districts) {
      if (d.danger > 70) {
        Utils.log(`GLOBAL BALANCER: Район ${d.name} е твърде опасен → стабилизация.`);
        await ApiClient.districtStabilize(d.id);
      }

      if (d.control > 80) {
        Utils.log(`GLOBAL BALANCER: Район ${d.name} е твърде стабилен → динамика.`);
        await ApiClient.districtAddDynamicEvents(d.id);
      }
    }

    // ===============================================
    // PLAYER BALANCE
    // ===============================================
    if (player.heat > 90) {
      Utils.log("GLOBAL BALANCER: Heat е твърде висок → намаляване.");
      await ApiClient.reducePlayerHeat();
    }

    if (player.money > 100000) {
      Utils.log("GLOBAL BALANCER: Играчът е твърде богат → икономически реакции.");
      await ApiClient.economyReactToRichPlayer();
    }

    Utils.log(`GLOBAL BALANCE: Stability=${BalanceState.globalStability.toFixed(2)}, Chaos=${BalanceState.chaosLevel.toFixed(2)}`);

  }, 8000); // 8 секунди цикъл

  Utils.log("AI Global Balancer работи.");
}

// ===============================================
// HELPERS
// ===============================================
function clamp(v) {
  return Math.max(0, Math.min(1, v));
}