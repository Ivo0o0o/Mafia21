// ===============================================
// MAFIA 21st CENTURY — INTEL AI CORE (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// AI анализ за разузнаване, информатори, зони,
// риск, надеждност, приоритизация.
// ===============================================

export const IntelAICore = {
  intelNetworkAI({ sources, zones }) {
    const totalSources = sources.length;
    const activeSources = sources.filter(s => s.status === "active").length;
    const compromisedSources = sources.filter(s => s.status === "compromised").length;

    const avgReliability = totalSources
      ? (
          sources.reduce((sum, s) => sum + (s.reliability || 0), 0) /
          totalSources
        ).toFixed(1)
      : 0;

    const highRiskZones = zones.filter(z => (z.risk || 0) >= 7).length;

    const forecast =
      avgReliability < 50
        ? "Мрежата е нестабилна — висок риск от грешна информация."
        : avgReliability < 75
        ? "Информацията е умерено надеждна — препоръчва се кръстосана проверка."
        : "Мрежата е силна — подходящ момент за сложни операции.";

    const recommendation =
      compromisedSources > 0
        ? "Изолирай компрометираните източници и пренасочи вниманието към надеждните."
        : "Запази текущата структура, но продължи да следиш високорисковите зони.";

    return {
      totalSources,
      activeSources,
      compromisedSources,
      avgReliability,
      highRiskZones,
      forecast,
      recommendation,
    };
  },

  sourceAI(source) {
    const reliability = source.reliability || 0;
    const risk = source.risk || 0;

    const efficiency =
      reliability > 80 && risk < 5
        ? "Елитен информатор"
        : reliability > 60
        ? "Добър информатор"
        : reliability > 40
        ? "Среден информатор"
        : "Рисков информатор";

    const recommendation =
      risk >= 8
        ? "Използвай само за критични случаи и не разкривай ключова информация."
        : reliability < 50
        ? "Потвърждавай информацията от други източници."
        : "Подходящ за регулярни доклади.";

    return {
      efficiency,
      recommendation,
    };
  },

  zoneAI(zone) {
    const risk = zone.risk || 0;
    const activity = zone.activity || 0;

    const status =
      risk >= 8
        ? "Критична зона"
        : risk >= 5
        ? "Високорискова зона"
        : risk >= 3
        ? "Умерен риск"
        : "Нисък риск";

    const recommendation =
      activity > 70 && risk >= 6
        ? "Интензивно наблюдение и готовност за бърза реакция."
        : activity > 40
        ? "Редовно наблюдение и анализ на тенденциите."
        : "Периодична проверка — нисък приоритет.";

    return {
      status,
      recommendation,
    };
  },
};