// ===============================================
// MAFIA 21st CENTURY — AI DISTRICT EVOLUTION (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Растеж, упадък, опасност, контрол, влияние,
// богатство, престъпност, стабилност, динамика.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

export function initAIDistrictEvolution() {
  Utils.log("AI District Evolution стартира…");

  const DistrictState = {
    tick: 0,
    evolution: {}
  };

  // ===============================================
  // MAIN DISTRICT LOOP
  // ===============================================
  setInterval(async () => {
    DistrictState.tick++;

    const districts = await ApiClient.getDistricts();
    const crime = await ApiClient.getCrimePulse();
    const npc = await ApiClient.getNPCActivity();
    const police = await ApiClient.getPoliceStatus();
    const economy = await ApiClient.getInflation();
    const player = await ApiClient.getPlayer();

    for (const d of districts) {
      if (!DistrictState.evolution[d.id]) {
        DistrictState.evolution[d.id] = generateDistrictProfile();
      }

      const evo = DistrictState.evolution[d.id];

      // ===============================================
      // CRIME → DANGER
      // ===============================================
      if (crime.level > 60) {
        evo.danger += 0.05;
      } else {
        evo.danger -= 0.03;
      }

      // ===============================================
      // NPC ACTIVITY → GROWTH
      // ===============================================
      if (npc.activity > 50) {
        evo.growth += 0.04;
      } else {
        evo.growth -= 0.02;
      }

      // ===============================================
      // POLICE → STABILITY
      // ===============================================
      if (police.patrols > 3) {
        evo.stability += 0.05;
      } else {
        evo.stability -= 0.03;
      }

      // ===============================================
      // ECONOMY → WEALTH
      // ===============================================
      if (economy < 1.2) {
        evo.wealth += 0.03;
      } else {
        evo.wealth -= 0.04;
      }

      // ===============================================
      // PLAYER → CONTROL
      // ===============================================
      if (player.influence[d.id] > 70) {
        evo.control += 0.05;
      } else {
        evo.control -= 0.03;
      }

      // ===============================================
      // PLAYER → RESPECT
      // ===============================================
      if (player.heat < 20 && player.money > 20000) {
        evo.respect += 0.04;
      } else {
        evo.respect -= 0.02;
      }

      // ===============================================
      // APPLY LIMITS
      // ===============================================
      clampDistrict(evo);

      // ===============================================
      // UPDATE DISTRICT IN DATABASE
      // ===============================================
      await ApiClient.updateDistrictEvolution(d.id, evo);

      Utils.log(`Район ${d.name}: Danger=${evo.danger.toFixed(2)}, Control=${evo.control.toFixed(2)}`);
    }

  }, 6000); // 6 секунди цикъл

  Utils.log("AI District Evolution работи.");
}

// ===============================================
// DISTRICT PROFILE GENERATOR
// ===============================================
function generateDistrictProfile() {
  return {
    danger: Math.random(),
    growth: Math.random(),
    stability: Math.random(),
    wealth: Math.random(),
    control: Math.random(),
    respect: Math.random()
  };
}

// ===============================================
// LIMITS
// ===============================================
function clampDistrict(e) {
  for (const key in e) {
    e[key] = Math.max(0, Math.min(1, e[key]));
  }
}