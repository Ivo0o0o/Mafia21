// ===============================================
// MAFIA 21st CENTURY — WORLD SIMULATION MODULE (ULTRA PRO HYBRID)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Комбинирана система:
// ✔ FULL PRO симулация (твоя)
// ✔ ULTRA PRO World Engines (нови)
// ✔ AI реактивност
// ✔ Player influence, heat, crime generator
// ✔ Динамика на града
// ===============================================

import { AICore } from "./aiCore.js";
import { ApiClient } from "./apiClient.js";
import { NotificationsUI } from "./notificationsUI.js";
import { PlayerProgression } from "./playerProgression.js";

import { worldTrafficEngine } from "./worldTrafficEngine.js";
import { worldCrowdEngine } from "./worldCrowdEngine.js";
import { worldNightLifeEngine } from "./worldNightLifeEngine.js";
import { worldEmergencyEngine } from "./worldEmergencyEngine.js";
import { worldHeatMapEngine } from "./worldHeatMapEngine.js";
import { worldGangTerritoryEngine } from "./worldGangTerritoryEngine.js";

import { EventBus } from "./eventBus.js";      // ⭐ добавено
import { WorldClock } from "./worldClock.js";  // ⭐ добавено

export const WorldSimulation = {
  interval: null,
  rate: 5000, // 5 секунди — оптимално за симулация

  start() {
    console.log("🌍 WORLD SIMULATION STARTED");

    if (this.interval) clearInterval(this.interval);

    this.interval = setInterval(() => {
      this.simulate();
    }, this.rate);

    NotificationsUI.info("Световната симулация е активирана.");

    EventBus.emit("world_sim_started", { rate: this.rate }); // ⭐
  },

  stop() {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
      NotificationsUI.warning("Световната симулация е спряна.");

      EventBus.emit("world_sim_stopped", {}); // ⭐
    }
  },

  async simulate() {
    console.log("🌐 WORLD SIMULATION TICK");

    EventBus.emit("world_sim_tick", {}); // ⭐

    try {
      // ============================================
      // FULL PRO — твоите оригинални системи
      // ============================================
      await this.citizenActivity();
      await this.policeActivity();
      await this.crimeActivity();
      await this.trafficActivity();
      await this.randomEvents();
      await this.zoneDanger();

      await this.playerInfluence();
      await this.crimeGenerator();
      await this.policeHeatSystem();
      await this.cityLifeSimulation();

      // ============================================
      // ULTRA PRO — новите World Engines
      // ============================================
      await worldTrafficEngine.simulate();
      await worldCrowdEngine.simulate();
      await worldNightLifeEngine.simulate();
      await worldEmergencyEngine.simulate();
      await worldHeatMapEngine.simulate();
      await worldGangTerritoryEngine.simulate();

    } catch (err) {
      console.error("❌ WORLD SIMULATION ERROR:", err);
      NotificationsUI.error("Грешка в световната симулация.");

      EventBus.emit("world_sim_error", { error: err }); // ⭐
    }
  },

  // ---------------------------------------------
  // ГРАЖДАНИ — движение, реакции, страх, паника
  // ---------------------------------------------
  async citizenActivity() {
    const citizens = await ApiClient.getCitizens();

    citizens.forEach(c => {
      const ai = AICore.npcBehavior();

      if (ai.emotion === "подозрителен" && ai.intensity > 60) {
        NotificationsUI.info(`Гражданин ${c.name} изглежда неспокоен.`);
      }

      if (ai.emotion === "враждебен" && ai.intensity > 80) {
        NotificationsUI.warning(`Гражданин ${c.name} може да предизвика проблем.`);
      }
    });

    EventBus.emit("world_citizen_activity", { citizens }); // ⭐
  },

  // ---------------------------------------------
  // ПОЛИЦИЯ — патрули, проверки, преследвания
  // ---------------------------------------------
  async policeActivity() {
    const police = await ApiClient.getPoliceUnits();

    police.forEach(unit => {
      const ai = AICore.combatAI(unit);

      if (ai.aggression > 70) {
        NotificationsUI.warning(`Полицията засилва патрулите в района.`);
      }

      if (ai.strategy === "директна атака" && ai.risk > 60) {
        NotificationsUI.error("Полицията преследва заподозрян!");
      }
    });

    EventBus.emit("world_police_activity", { police }); // ⭐
  },

  // ---------------------------------------------
  // ПРЕСТЪПНОСТ — нападения, кражби, сбивания
  // ---------------------------------------------
  async crimeActivity() {
    const crimes = await ApiClient.getCrimeReports();

    crimes.forEach(crime => {
      const ai = AICore.missionAI(crime);

      if (ai.difficulty > 70) {
        NotificationsUI.warning(`Високорисково престъпление: ${crime.title}`);
      }

      if (ai.successChance < 30) {
        NotificationsUI.info(`Престъпниците вероятно ще се провалят: ${crime.title}`);
      }
    });

    EventBus.emit("world_crime_activity", { crimes }); // ⭐
  },

  // ---------------------------------------------
  // ТРАФИК — задръствания, катастрофи, блокади
  // ---------------------------------------------
  async trafficActivity() {
    const traffic = await ApiClient.getTrafficStatus();

    if (traffic.level > 80) {
      NotificationsUI.warning("Трафикът е тежък — движението е блокирано.");
    }

    // ⭐ правилно world_tick от WorldClock
    EventBus.emit("world_tick", { time: WorldClock.getTime(), traffic });

    if (traffic.accidents > 0) {
      NotificationsUI.error(`Катастрофи в района: ${traffic.accidents}`);
    }

    EventBus.emit("world_traffic_activity", { traffic }); // ⭐
  },

  // ---------------------------------------------
  // СЛУЧАЙНИ СЪБИТИЯ — пожари, протести, аварии
  // ---------------------------------------------
  async randomEvents() {
    const events = await ApiClient.getWorldEvents();

    if (events.length > 0) {
      const event = events[Math.floor(Math.random() * events.length)];

      NotificationsUI.info(`Събитие: ${event.title}`);

      EventBus.emit("world_random_event", { event }); // ⭐
    }
  },

  // ---------------------------------------------
  // ОПАСНИ ЗОНИ — риск, престъпност, полиция
  // ---------------------------------------------
  async zoneDanger() {
    const zones = await ApiClient.getZones();

    zones.forEach(zone => {
      const ai = AICore.baseAI(zone);

      if (ai.vulnerability > 75) {
        NotificationsUI.warning(`Опасна зона: ${zone.name}`);
      }

      if (ai.risk > 85) {
        NotificationsUI.error(`Критичен риск в зона: ${zone.name}`);
      }
    });

    EventBus.emit("world_zone_danger", { zones }); // ⭐
  },

  // ---------------------------------------------
  // PLAYER INFLUENCE — репутация, влияние
  // ---------------------------------------------
  async playerInfluence() {
    const player = await PlayerProgression.load();

    if (player.reputation > 100) {
      NotificationsUI.info("Гражданите започват да говорят за теб.");
    }

    if (player.reputation > 300) {
      NotificationsUI.warning("Полицията следи действията ти.");
    }

    if (player.reputation > 600) {
      NotificationsUI.error("Клановете те смятат за заплаха.");
    }

    EventBus.emit("world_player_influence", { player }); // ⭐
  },

  // ---------------------------------------------
  // CRIME GENERATOR — автоматично генериране на престъпления
  // ---------------------------------------------
  async crimeGenerator() {
    const chance = Math.random() * 100;

    if (chance > 70) {
      const crime = await ApiClient.generateCrime();

      NotificationsUI.warning(`Ново престъпление: ${crime.title}`);

      EventBus.emit("world_crime_generated", { crime }); // ⭐
    }
  },

  // ---------------------------------------------
  // POLICE HEAT SYSTEM — полицията реагира на играча
  // ---------------------------------------------
  async policeHeatSystem() {
    const player = await PlayerProgression.load();

    if (player.heat > 50) {
      NotificationsUI.warning("Полицията е нащрек за теб.");
    }

    if (player.heat > 80) {
      NotificationsUI.error("Полицията започва активни операции срещу теб!");
    }

    EventBus.emit("world_police_heat", { heat: player.heat }); // ⭐
  },

  // ---------------------------------------------
  // CITY LIFE SIMULATION — магазини, движение, шум
  // ---------------------------------------------
  async cityLifeSimulation() {
    const life = await ApiClient.getCityLife();

    if (life.crowd > 70) {
      NotificationsUI.info("Улиците са претъпкани.");
    }

    if (life.noise > 80) {
      NotificationsUI.warning("Шумът в района е висок.");
    }

    if (life.marketActivity > 60) {
      NotificationsUI.info("Черният пазар е активен.");
    }

    EventBus.emit("world_city_life", { life }); // ⭐
  }
};