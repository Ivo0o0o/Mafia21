// ===============================================
// MAFIA 21st CENTURY — WORLD CLOCK (ULTRA PRO MAX)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централен часовник на вселената:
// ✔ глобално време
// ✔ ден/нощ цикъл
// ✔ custom day/night length
// ✔ time acceleration
// ✔ pause / resume
// ✔ world ticks
// ✔ AI ticks
// ✔ event timing
// ✔ синхронизация с WorldState
// ✔ EventBus hook-ове
// ===============================================

import { WorldState } from "./worldState.js";
import { Utils } from "./utils.js";
import { EventBus } from "./eventBus.js";

export const WorldClock = {
  interval: null,

  // Базов tick в реално време (ms)
  baseTickRate: 1000,

  // Ускорение на времето (1 = реално, 60 = 1 мин/сек)
  timeAcceleration: 60,

  // Custom дължина на ден/нощ (в часове)
  config: {
    dayStart: 6,
    nightStart: 20
  },

  paused: false,

  time: {
    hour: 12,
    minute: 0,
    day: 1,
    cycle: "day" // day / night
  },

  listeners: [],

  init() {
    Utils.log("WorldClock — стартиране ULTRA PRO MAX...");

    this.interval = setInterval(() => this.tick(), this.baseTickRate);

    EventBus.emit("world_clock_init", {
      time: this.time,
      acceleration: this.timeAcceleration
    });

    Utils.log("WorldClock — активен.");
  },

  // ---------------------------------------------
  // Основен tick — всяка реална секунда
  // ---------------------------------------------
  tick() {
    if (this.paused) return;

    // Ускорено време
    for (let i = 0; i < this.timeAcceleration; i++) {
      this.advanceMinute();
    }

    this.updateCycle();
    this.syncWorldState();
    this.notify();

    EventBus.emit("world_clock_tick", {
      time: this.time
    });
  },

  // ---------------------------------------------
  // Придвижване на времето с 1 минута (игрова)
  // ---------------------------------------------
  advanceMinute() {
    this.time.minute++;

    if (this.time.minute >= 60) {
      this.time.minute = 0;
      this.time.hour++;
    }

    if (this.time.hour >= 24) {
      this.time.hour = 0;
      this.time.day++;
      EventBus.emit("world_clock_new_day", {
        day: this.time.day
      });
    }
  },

  // ---------------------------------------------
  // Ден/нощ цикъл (custom)
  // ---------------------------------------------
  updateCycle() {
    const h = this.time.hour;

    if (h >= this.config.dayStart && h < this.config.nightStart) {
      if (this.time.cycle !== "day") {
        this.time.cycle = "day";
        EventBus.emit("world_clock_cycle_change", {
          cycle: "day",
          time: this.time
        });
      }
    } else {
      if (this.time.cycle !== "night") {
        this.time.cycle = "night";
        EventBus.emit("world_clock_cycle_change", {
          cycle: "night",
          time: this.time
        });
      }
    }
  },

  // ---------------------------------------------
  // Синхронизация с WorldState
  // ---------------------------------------------
  syncWorldState() {
    WorldState.update({
      time: {
        hour: this.time.hour,
        minute: this.time.minute,
        day: this.time.day,
        cycle: this.time.cycle
      }
    });
  },

  // ---------------------------------------------
  // Listener система — AI, World, UI
  // ---------------------------------------------
  onTick(callback) {
    this.listeners.push(callback);
  },

  notify() {
    this.listeners.forEach(cb => cb(this.time));
  },

  // ---------------------------------------------
  // Контрол на времето
  // ---------------------------------------------
  setAcceleration(multiplier) {
    this.timeAcceleration = Math.max(1, multiplier);

    EventBus.emit("world_clock_acceleration_change", {
      acceleration: this.timeAcceleration
    });

    Utils.log(`WorldClock — acceleration set to x${this.timeAcceleration}`);
  },

  pause() {
    this.paused = true;
    EventBus.emit("world_clock_paused", { time: this.time });
    Utils.log("WorldClock — PAUSED.");
  },

  resume() {
    this.paused = false;
    EventBus.emit("world_clock_resumed", { time: this.time });
    Utils.log("WorldClock — RESUMED.");
  },

  setTime(hour, minute = 0, day = null) {
    this.time.hour = ((hour % 24) + 24) % 24;
    this.time.minute = ((minute % 60) + 60) % 60;
    if (day !== null) this.time.day = day;

    this.updateCycle();
    this.syncWorldState();
    this.notify();

    EventBus.emit("world_clock_time_set", {
      time: this.time
    });

    Utils.log(
      `WorldClock — time set to Day ${this.time.day}, ${this.time.hour}:${this.time.minute}`
    );
  },

  setCycleConfig({ dayStart, nightStart }) {
    if (typeof dayStart === "number") this.config.dayStart = dayStart;
    if (typeof nightStart === "number") this.config.nightStart = nightStart;

    this.updateCycle();

    EventBus.emit("world_clock_cycle_config_change", {
      config: this.config
    });

    Utils.log(
      `WorldClock — cycle config updated: dayStart=${this.config.dayStart}, nightStart=${this.config.nightStart}`
    );
  },

  // ---------------------------------------------
  // Бързи методи
  // ---------------------------------------------
  getTime() {
    return this.time;
  },

  isDay() {
    return this.time.cycle === "day";
  },

  isNight() {
    return this.time.cycle === "night";
  }
};

// Автоматично стартиране
WorldClock.init();