// ===============================================
// MAFIA 21st CENTURY — AI TERRITORY CONTROL ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Анализ на територии, влияние, риск,
// прогнози, разширяване, защита.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";

export const aiTerritoryControl = {
  async analyze() {
    const territories = await ApiClient.getTerritories();
    const gangs = await ApiClient.getGangs();
    const heat = await ApiClient.getHeatLevels();

    const result = {
      weakestTerritory: null,
      strongestTerritory: null,
      expansionTarget: null,
      defensePriority: null,
      forecast: "",
      recommendation: ""
    };

    // Най-слаба територия
    result.weakestTerritory = territories.sort((a, b) => a.control - b.control)[0]?.name;

    // Най-силна територия
    result.strongestTerritory = territories.sort((a, b) => b.control - a.control)[0]?.name;

    // Най-добра територия за разширяване
    result.expansionTarget = territories.sort((a, b) => a.value - b.value)[0]?.name;

    // Най-рискова територия
    result.defensePriority = territories.sort((a, b) => b.conflict - a.conflict)[0]?.name;

    // Прогноза според heat
    const heatAvg = heat.reduce((a, b) => a + b.level, 0) / heat.length;

    if (heatAvg > 70) {
      result.forecast = "Очаква се масивно разместване на територии.";
    } else if (heatAvg > 40) {
      result.forecast = "Възможни са локални конфликти.";
    } else {
      result.forecast = "Ситуацията е стабилна.";
    }

    // Препоръка
    if (heatAvg > 70) {
      result.recommendation = "Укрепи слабите територии и подготви защита.";
    } else if (heatAvg > 40) {
      result.recommendation = "Разшири влиянието си в ниско защитените зони.";
    } else {
      result.recommendation = "Време е за агресивно разширяване.";
    }

    Utils.log("AI Territory Control — анализ завършен.");
    return result;
  }
};