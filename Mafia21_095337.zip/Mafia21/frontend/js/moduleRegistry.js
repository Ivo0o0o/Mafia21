// ===============================================
// MAFIA 21st CENTURY — PLAYER STATS CORE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централен state на играча:
// ✔ level
// ✔ xp
// ✔ heat
// ✔ money
// ✔ reputation
// ✔ stats (strength, agility, intelligence)
// ✔ inventory
// ✔ skills
// ✔ missions
// ✔ autosync към ApiClient
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

export const PlayerStatsCore = {
  player: null,
  listeners: [],

  async init() {
    this.player = await ApiClient.getPlayer();
    Utils.log("PlayerStatsCore — зареден.");

    // Автоматичен refresh на всеки 3 секунди
    setInterval(() => this.sync(), 3000);
  },

  // ---------------------------------------------
  // ВРЪЩА ЦЕЛИЯ PLAYER STATE
  // ---------------------------------------------
  get() {
    return this.player;
  },

  // ---------------------------------------------
  // ОБНОВЯВА PLAYER STATE ЛОКАЛНО
  // ---------------------------------------------
  update(data) {
    Object.assign(this.player, data);
    this.notify();
  },

  // ---------------------------------------------
  // СИНХРОНИЗАЦИЯ С API
  // ---------------------------------------------
  async sync() {
    const latest = await ApiClient.getPlayer();

    // Ако има промени — обнови локално
    if (JSON.stringify(latest) !== JSON.stringify(this.player)) {
      this.player = latest;
      this.notify();
    }
  },

  // ---------------------------------------------
  // ЗАПИСВА ПРОМЕНИТЕ В API
  // ---------------------------------------------
  async save() {
    await ApiClient.updatePlayer(this.player);
    this.notify();
  },

  // ---------------------------------------------
  // LISTENERS — UI, AI, WORLD системи
  // ---------------------------------------------
  onChange(callback) {
    this.listeners.push(callback);
  },

  notify() {
    this.listeners.forEach(cb => cb(this.player));
  },

  // ---------------------------------------------
  // БЪРЗИ МЕТОДИ ЗА ПРОМЕНИ
  // ---------------------------------------------
  addXP(amount) {
    this.player.xp += amount;
    this.save();
  },

  addMoney(amount) {
    this.player.money += amount;
    this.save();
  },

  addHeat(amount) {
    this.player.heat += amount;
    this.save();
  },

  addReputation(amount) {
    this.player.reputation += amount;
    this.save();
  },

  levelUp() {
    this.player.level++;
    this.save();
  }
};

// Автоматично стартиране
PlayerStatsCore.init();