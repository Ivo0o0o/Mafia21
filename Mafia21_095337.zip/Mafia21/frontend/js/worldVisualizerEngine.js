// ===============================================
// MAFIA 21st CENTURY — WORLD VISUALIZER ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Визуализация на NPC, полиция, райони, движение,
// мини-карта, динамични икони, синхронизация.
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";

export function initWorldVisualizerEngine() {
  Utils.log("World Visualizer Engine стартира…");

  const canvas = Utils.qs("#worldCanvas");
  const ctx = canvas.getContext("2d");

  const VisualState = {
    tick: 0,
    npcPositions: {},
    policePositions: {},
    districtDynamics: {},
    cycle: "day"
  };

  resizeCanvas(canvas);

  // ===============================================
  // MAIN VISUAL LOOP
  // ===============================================
  setInterval(async () => {
    VisualState.tick++;

    const npcs = await ApiClient.getAllNPCs();
    const police = await ApiClient.getPoliceUnits();
    const districts = await ApiClient.getDistricts();
    const cycle = await ApiClient.getWorldCycle();

    VisualState.cycle = cycle;

    // ===============================================
    // CLEAR SCREEN
    // ===============================================
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // ===============================================
    // DRAW DISTRICTS
    // ===============================================
    for (const d of districts) {
      drawDistrict(ctx, d);
    }

    // ===============================================
    // DRAW NPC
    // ===============================================
    for (const npc of npcs) {
      const pos = npc.position || { x: 50, y: 50 };
      drawNPC(ctx, pos, npc);
    }

    // ===============================================
    // DRAW POLICE
    // ===============================================
    for (const unit of police) {
      const pos = unit.position || { x: 20, y: 20 };
      drawPolice(ctx, pos, unit);
    }

    // ===============================================
    // DRAW WORLD CYCLE OVERLAY
    // ===============================================
    drawCycleOverlay(ctx, VisualState.cycle);

  }, 1000); // 1 секунда визуализация

  Utils.log("World Visualizer Engine работи.");
}

// ===============================================
// CANVAS RESIZE
// ===============================================
function resizeCanvas(canvas) {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}

// ===============================================
// DRAW NPC
// ===============================================
function drawNPC(ctx, pos, npc) {
  ctx.fillStyle = "yellow";
  ctx.beginPath();
  ctx.arc(pos.x, pos.y, 4, 0, Math.PI * 2);
  ctx.fill();
}

// ===============================================
// DRAW POLICE
// ===============================================
function drawPolice(ctx, pos, unit) {
  ctx.fillStyle = "blue";
  ctx.beginPath();
  ctx.arc(pos.x, pos.y, 5, 0, Math.PI * 2);
  ctx.fill();
}

// ===============================================
// DRAW DISTRICT
// ===============================================
function drawDistrict(ctx, d) {
  ctx.strokeStyle = d.danger > 70 ? "red" : "green";
  ctx.strokeRect(d.x, d.y, d.width, d.height);
}

// ===============================================
// DRAW DAY/NIGHT OVERLAY
// ===============================================
function drawCycleOverlay(ctx, cycle) {
  if (cycle === "night") {
    ctx.fillStyle = "rgba(0,0,50,0.3)";
    ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  }
}