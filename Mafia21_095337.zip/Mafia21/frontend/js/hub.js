// ===============================================
// MAFIA 21st CENTURY — HUB (ULTRA PRO NEON VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Комбиниран HUD + NEON HUD:
// ❤️ Health, ⚡ Energy, 💶 Money
// 🔥 Heat bar, ⭐ Reputation
// 🎯 Mission, 🕒 Time
// 🤖 AI Alerts, 📊 Performance
// 📍 Danger, Quick Panels
// ===============================================

import { ApiClient } from "./apiClient.js";
import { Utils } from "./utils.js";
import { AICore } from "./aiCore.js";

import { PlayerStatsCore } from "./playerStatsCore.js";
import { WorldClock } from "./worldClock.js";
import { EventBus } from "./eventBus.js";
import { PlayerProgression } from "./playerProgression.js";

export const HUD = {
  async init() {
    const hud = Utils.create("div", "hud-overlay neon-hud");
    hud.id = "hudOverlay";

    // ⭐ Комбиниран HUD (твоя + неоновия)
    hud.innerHTML = `
      <div class="hud-top neon-border">
        ❤️ <span id="hudHealth">0</span>
        ⚡ <span id="hudEnergy">0</span>
        💶 <span id="hudMoney">0</span>

        🔥 <span id="hudHeat">0</span>
        <div id="hudHeatBar" class="hud-heat-bar neon-bar"></div>

        ⭐ <span id="hudRep">0</span>

        🎯 <span id="hudMission">None</span>
        🕒 <span id="hudTime">--:--</span>

        📍 <span id="hudDanger">0</span>
      </div>

      <div class="hud-left neon-panel">
        <button class="hud-btn" data-panel="player">Играч</button>
        <button class="hud-btn" data-panel="npc">NPC</button>
        <button class="hud-btn" data-panel="police">Полиция</button>
        <button class="hud-btn" data-panel="missions">Мисии</button>
        <button class="hud-btn" data-panel="influence">Влияние</button>
        <button class="hud-btn" data-panel="blackmarket">Черен пазар</button>
        <button class="hud-btn" data-panel="skills">Умения</button>
        <button class="hud-btn" data-panel="events">Събития</button>
        <button class="hud-btn" data-panel="crime">Престъпления</button>
        <button class="hud-btn" data-panel="city">Град</button>
      </div>

      <div id="hudAlert" class="hud-alert hidden neon-alert"></div>

      <div class="hud-performance neon-border">
        📊 <span id="hudPerf">FPS:0 | Lat:0ms | Load:0%</span>
      </div>
    `;

    document.body.appendChild(hud);

    Utils.neonPulse(hud, "#00c8ff");

    this.update();
    setInterval(() => this.update(), 1000);

    EventBus.on("game_tick", () => this.update());
    EventBus.on("player_updated", () => this.update());
    EventBus.on("player_synced", () => this.update());
    EventBus.on("performance_tick", perf => this.renderPerformance(perf));

    this.initButtons();

    Utils.log("NEON HUB ULTRA PRO MAX е активиран.");
  },

  async update() {
    const player = await ApiClient.getPlayer();
    const district = await ApiClient.getCurrentDistrict();
    const mission = await ApiClient.getActiveMission();
    const world = await ApiClient.getWorldState();

    const ai = AICore.hudAI({
      heat: player.heat,
      money: player.money,
      mission,
      world
    });

    Utils.qs("#hudHealth").textContent = player.health;
    Utils.qs("#hudEnergy").textContent = player.energy;
    Utils.qs("#hudMoney").textContent = Utils.formatMoney(player.money);

    Utils.qs("#hudHeat").textContent = player.heat;
    Utils.qs("#hudHeatBar").style.width = `${player.heat}%`;

    Utils.qs("#hudRep").textContent = player.reputation;
    Utils.qs("#hudDanger").textContent = district.danger;

    Utils.qs("#hudMission").textContent =
      mission ? mission.title : "Няма активна мисия";

    Utils.qs("#hudTime").textContent = world.time;

    if (ai.alert) this.showAlert(ai.alert);

    this.colorizeHeat(player.heat);
    this.colorizeRep(player.reputation);
  },

  showAlert(text) {
    const alert = Utils.qs("#hudAlert");
    alert.textContent = text;
    alert.classList.remove("hidden");

    Utils.neonFlash(alert, "#ff007c");

    setTimeout(() => alert.classList.add("hidden"), 3000);
  },

  initButtons() {
    Utils.qsa(".hud-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        Utils.neonFlash(btn, "#00c8ff");

        const panel = btn.dataset.panel;
        switch (panel) {
          case "player": window.showPlayerPanel(); break;
          case "npc": window.showNPCPanel(); break;
          case "police": window.showPolicePanel(); break;
          case "missions": window.showMissionsPanel(); break;
          case "influence": window.showInfluencePanel(); break;
          case "blackmarket": window.showBlackMarketPanel(); break;
          case "skills": window.showSkillsPanel(); break;
          case "events": window.showWorldEventsPanel(); break;
          case "crime": window.showCrimePanel(); break;
          case "city": window.showCityLifePanel(); break;
        }
      });
    });
  },

  colorizeHeat(heat) {
    const el = Utils.qs("#hudHeat");
    if (!el) return;

    el.style.color =
      heat > 600 ? "#ff0000" :
      heat > 300 ? "#ff6600" :
      "#ffffff";
  },

  colorizeRep(rep) {
    const el = Utils.qs("#hudRep");
    if (!el) return;

    el.style.color =
      rep > 600 ? "#ff0000" :
      rep > 300 ? "#ffaa00" :
      "#ffffff";
  },

  renderPerformance(perf) {
    Utils.qs("#hudPerf").textContent =
      `FPS:${perf.fps} | Lat:${perf.latency}ms | Load:${perf.load}%`;
  }
};