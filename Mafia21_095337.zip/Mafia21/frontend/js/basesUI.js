// ===============================================
// MAFIA 21st CENTURY — BASES UI (PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Бази, охрана, подобрения, ресурси,
// капацитет, AI динамика.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";

export async function showBasesPanel() {
  Utils.log("Зареждаме панела с бази…");

  const app = Utils.qs("#app");

  // Премахваме стария панел
  const oldPanel = Utils.qs("#basesPanelDynamic");
  if (oldPanel) oldPanel.remove();

  // Създаваме нов панел
  const panel = Utils.create("div", "panel");
  panel.id = "basesPanelDynamic";

  // Вземаме бази от бекенда
  const bases = await ApiClient.getBases();

  // AI динамика
  const ai = Utils.npcBehaviorAI();

  panel.innerHTML = `
    <h2>Бази</h2>

    <div class="info-box">
      <strong>AI динамика:</strong><br>
      Емоция: <span style="color: var(--neon-purple)">${ai.emotion}</span><br>
      Решение: <span style="color: var(--neon-pink)">${ai.decision}</span><br>
      Интензитет: <span style="color: var(--mafia-gold)">${ai.intensity}</span>
    </div>

    <div class="info-box">
      <strong>Списък бази:</strong>
      <ul id="basesList" style="margin-top:10px; padding-left:20px;">
        ${bases.map(b => `
          <li style="margin-bottom:10px; cursor:pointer;" data-id="${b._id}">
            <span style="color: var(--mafia-gold)">${b.name}</span> —
            <span style="color: var(--neon-blue)">${b.level}</span> lvl
          </li>
        `).join("")}
      </ul>
    </div>

    <button class="btn" id="refreshBases">Обнови</button>
    <button class="btn" id="closeBasesPanel" style="margin-left:10px;">Затвори</button>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // -----------------------------------------------
  // CLICK → Детайли за база
  // -----------------------------------------------
  panel.querySelectorAll("#basesList li").forEach(li => {
    li.addEventListener("click", async () => {
      const baseId = li.dataset.id;
      const base = await ApiClient.getBase(baseId);

      Utils.neonFlash(li, "#ff007c");

      panel.innerHTML = `
        <h2>${base.name}</h2>

        <div class="info-box">
          <strong>Ниво:</strong>
          <span style="color: var(--neon-blue)">${base.level}</span>
        </div>

        <div class="info-box">
          <strong>Капацитет:</strong>
          <span style="color: var(--neon-purple)">${base.capacity}</span>
        </div>

        <div class="info-box">
          <strong>Ресурси:</strong>
          <span style="color: var(--mafia-gold)">${base.resources}</span>
        </div>

        <div class="info-box">
          <strong>Охрана:</strong>
          <span style="color: var(--mafia-red)">${base.security}</span>
        </div>

        <div class="info-box">
          <strong>Подобрения:</strong>
          <ul style="padding-left:20px;">
            ${base.upgrades.map(u => `
              <li style="margin-bottom:6px;">
                <span style="color: var(--neon-blue)">${u}</span>
              </li>
            `).join("")}
          </ul>
        </div>

        <div class="info-box">
          <strong>AI оценка:</strong><br>
          Риск: <span style="color: var(--neon-pink)">${base.ai.risk}</span><br>
          Стабилност: <span style="color: var(--mafia-gold)">${base.ai.stability}</span><br>
          Уязвимост: <span style="color: var(--mafia-red)">${base.ai.vulnerability}</span>
        </div>

        <button class="btn" id="upgradeBase">Ъпгрейд</button>
        <button class="btn" id="fortifyBase" style="margin-left:10px;">Укрепи</button>
        <button class="btn" id="backToBases" style="margin-left:10px;">Назад</button>
        <button class="btn" id="closeBasesPanel" style="margin-left:10px;">Затвори</button>
      `;

      // Ъпгрейд на база
      Utils.qs("#upgradeBase").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.upgradeBase(baseId);
        showBasesPanel();
      });

      // Укрепване на база
      Utils.qs("#fortifyBase").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#ff007c");
        await ApiClient.fortifyBase(baseId);
        showBasesPanel();
      });

      // Назад
      Utils.qs("#backToBases").addEventListener("click", () => {
        showBasesPanel();
      });

      // Затваряне
      Utils.qs("#closeBasesPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // -----------------------------------------------
  // REFRESH
  // -----------------------------------------------
  Utils.qs("#refreshBases").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showBasesPanel();
  });

  // -----------------------------------------------
  // CLOSE
  // -----------------------------------------------
  Utils.qs("#closeBasesPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}