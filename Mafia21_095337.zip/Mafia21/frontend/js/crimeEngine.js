// ===============================================
// MAFIA 21st CENTURY — CRIME ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централна престъпна система:
// ✔ генериране на престъпления
// ✔ риск, трудност, шанс за успех
// ✔ heat ескалация
// ✔ ганг логика
// ✔ полиция реакция
// ✔ синхронизация с AI Engines
// ✔ синхронизация с WorldSimulation
// ===============================================

import { ApiClient } from "./apiClient.js";
import { PlayerStatsCore } from "./playerStatsCore.js";
import { WorldState } from "./worldState.js";
import { AICore } from "./aiCore.js";
import { Utils } from "./utils.js";
import { EventBus } from "./eventBus.js"; // ⭐ добавено

export const CrimeEngine = {
  crimes: [],
  interval: null,
  rate: 5000, // 5 секунди

  async init() {
    Utils.log("CrimeEngine — стартиране...");

    await this.loadCrimes();
    this.interval = setInterval(() => this.tick(), this.rate);

    Utils.log("CrimeEngine — активен.");
  },

  // ---------------------------------------------
  // Зареждане на престъпления от API
  // ---------------------------------------------
  async loadCrimes() {
    this.crimes = await ApiClient.getCrimeReports();
  },

  // ---------------------------------------------
  // Основен crime tick
  // ---------------------------------------------
  async tick() {
    try {
      EventBus.emit("crime_tick", { crimes: this.crimes }); // ⭐

      await this.generateCrime();
      await this.evaluateCrimes();
      await this.applyPoliceReaction();
      await this.syncToAPI();

      Utils.log("CrimeEngine — tick завършен.");
    } catch (err) {
      console.error("❌ CrimeEngine ERROR:", err);

      EventBus.emit("crime_error", { error: err }); // ⭐
    }
  },

  // ---------------------------------------------
  // Генериране на ново престъпление
  // ---------------------------------------------
  async generateCrime() {
    const chance = Math.random() * 100;

    if (chance > 65) {
      const crime = await ApiClient.generateCrime();
      this.crimes.push(crime);

      Utils.log(`CrimeEngine — ново престъпление: ${crime.title}`);

      EventBus.emit("crime_generated", { crime }); // ⭐
    }
  },

  // ---------------------------------------------
  // Оценка на престъпленията
  // ---------------------------------------------
  async evaluateCrimes() {
    this.crimes.forEach(crime => {
      const ai = AICore.missionAI(crime);

      const oldRisk = crime.risk;

      crime.risk = ai.risk;
      crime.difficulty = ai.difficulty;
      crime.successChance = ai.successChance;

      // ⭐ ако рискът се промени
      if (oldRisk !== crime.risk) {
        EventBus.emit("crime_risk_changed", { crime });
      }

      // Heat ескалация
      if (crime.risk > 70) {
        const player = PlayerStatsCore.get();
        PlayerStatsCore.addHeat(2);
      }

      EventBus.emit("crime_evaluated", { crime }); // ⭐
    });
  },

  // ---------------------------------------------
  // Полицията реагира на престъпления
  // ---------------------------------------------
  async applyPoliceReaction() {
    const police = WorldState.get().police;

    police.forEach(unit => {
      const ai = AICore.combatAI(unit);

      if (ai.aggression > 60) {
        this.crimes.forEach(crime => {
          if (crime.risk > 50) {
            crime.successChance -= 10;

            EventBus.emit("crime_police_react", { crime, unit }); // ⭐
          }
        });
      }
    });
  },

  // ---------------------------------------------
  // Синхронизация към API
  // ---------------------------------------------
  async syncToAPI() {
    await ApiClient.updateCrimes(this.crimes);

    EventBus.emit("crime_updated", { crimes: this.crimes }); // ⭐
  },

  // ---------------------------------------------
  // Връщане на престъпленията
  // ---------------------------------------------
  getCrimes() {
    return this.crimes;
  }
};

// Автоматично стартиране
CrimeEngine.init();