// ===============================================
// MAFIA 21st CENTURY — CRIME UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Престъпления, риск, heat, награди,
// AI анализ, AI препоръки, автоматично зареждане.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showCrimePanel() {
  Utils.log("Зареждаме панела с престъпления…");

  const app = Utils.qs("#app");

  const oldPanel = Utils.qs("#crimePanelDynamic");
  if (oldPanel) oldPanel.remove();

  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "crimePanelDynamic";

  // Вземаме престъпления
  const crimes = await ApiClient.getCrimes() || [];

  // AI анализ на всички престъпления
  const aiSummary = {
    avgRisk:
      Math.floor(
        crimes.reduce((sum, c) => sum + (c.risk || 0), 0) /
        (crimes.length || 1)
      ),
    avgHeat:
      Math.floor(
        crimes.reduce((sum, c) => sum + (c.heat || 0), 0) /
        (crimes.length || 1)
      ),
    bestProfit:
      crimes.length === 0
        ? "Няма"
        : crimes.reduce((best, c) => (c.reward > best.reward ? c : best), crimes[0]).title,
    recommendation:
      crimes.length === 0
        ? "Няма налични престъпления"
        : crimes.length < 3
        ? "Избери нискорискови престъпления"
        : "Комбинирай престъпления с нисък heat"
  };

  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-crime" style="margin-right:8px;"></span>
      Престъпления — Контролен Център
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Среден риск:</strong>
      <span class="neon-red">${aiSummary.avgRisk}%</span><br>

      <strong>Среден heat:</strong>
      <span class="neon-pink">${aiSummary.avgHeat}%</span><br>

      <strong>Най-печелившо:</strong>
      <span class="neon-gold">${aiSummary.bestProfit}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-purple">${aiSummary.recommendation}</span>
    </div>

    <!-- CRIMES LIST -->
    <div class="section-title">Списък престъпления</div>
    <div id="crimeList">
      ${
        crimes.length === 0
          ? `<div class="info-box">Няма налични престъпления.</div>`
          : crimes
              .map(
                c => `
        <div class="info-box crime-entry" data-id="${c._id}" style="cursor:pointer;">
          <div class="crime-title">${c.title}</div>

          <div class="crime-meta">
            <span>Риск: <span class="neon-red">${c.risk}%</span></span>
            <span>Heat: <span class="neon-pink">${c.heat}%</span></span>
            <span>Награда: <span class="neon-gold">${c.reward} 💶</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshCrimes">Обнови</button>
      <button class="btn" id="closeCrimePanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // -----------------------------------------------
  // CLICK → Детайли за престъпление + AI анализ
  // -----------------------------------------------
  panel.querySelectorAll("#crimeList .crime-entry").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const crime = crimes.find(c => c._id === id);

      Utils.neonFlash(box, "#ff007c");

      const ai = AICore.crimeAI(crime);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-crime" style="margin-right:8px;"></span>
          ${crime.title}
        </div>

        <div class="section-title">AI Анализ</div>
        <div class="info-box">
          <strong>Риск:</strong>
          <span class="neon-red">${ai.risk}%</span><br>

          <strong>Heat:</strong>
          <span class="neon-pink">${ai.heat}%</span><br>

          <strong>Печалба:</strong>
          <span class="neon-gold">${ai.profit} 💶</span><br>

          <strong>Препоръка:</strong>
          <span class="neon-blue">${ai.recommendation}</span>
        </div>

        <div class="section-title">Описание</div>
        <div class="info-box">${crime.description || "Няма описание"}</div>

        <div class="panel-buttons">
          <button class="btn" id="startCrime">Започни</button>
          <button class="btn" id="backToCrimes">Назад</button>
          <button class="btn" id="closeCrimePanel">Затвори</button>
        </div>
      `;

      // START CRIME
      Utils.qs("#startCrime").addEventListener("click", async () => {
        Utils.neonFlash(panel, "#00c8ff");
        await ApiClient.startCrime(id);
        showCrimePanel();
      });

      // BACK
      Utils.qs("#backToCrimes").addEventListener("click", () => {
        showCrimePanel();
      });

      // CLOSE
      Utils.qs("#closeCrimePanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // REFRESH
  Utils.qs("#refreshCrimes").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showCrimePanel();
  });

  // CLOSE
  Utils.qs("#closeCrimePanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}