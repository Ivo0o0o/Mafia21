// ===============================================
// MAFIA 21st CENTURY — WORLD EVENTS UI (ULTRA PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Световни събития, динамика, ефекти,
// AI анализ, AI прогнози, AI препоръки.
// ===============================================

import { Utils } from "./utils.js";
import { ApiClient } from "./apiClient.js";
import { AICore } from "./aiCore.js";

export async function showWorldEventsPanel() {
  Utils.log("Зареждаме World Events панела…");

  const app = Utils.qs("#app");

  // Премахваме стар панел, ако има
  const oldPanel = Utils.qs("#worldEventsPanelDynamic");
  if (oldPanel) oldPanel.remove();

  // Създаваме нов панел
  const panel = Utils.create("div", "panel ui-panel");
  panel.id = "worldEventsPanelDynamic";

  // Данни от бекенда
  const events = await ApiClient.getWorldEvents();

  // AI анализ на всички събития
  const ai = AICore.worldEventsAI(events);

  // ===============================================
  // MAIN PANEL TEMPLATE
  // ===============================================
  panel.innerHTML = `
    <div class="panel-title">
      <span class="icon-worldevents" style="margin-right:8px;"></span>
      Световни събития — Глобален Контролен Център
    </div>

    <!-- AI SUMMARY -->
    <div class="section-title">AI Анализ</div>
    <div class="info-box">
      <strong>Най-опасно събитие:</strong>
      <span class="neon-red">${ai.mostDangerous}</span><br>

      <strong>Най-полезно събитие:</strong>
      <span class="neon-gold">${ai.mostProfitable}</span><br>

      <strong>Най-рядко събитие:</strong>
      <span class="neon-blue">${ai.rare}</span><br>

      <strong>Прогноза:</strong>
      <span class="neon-purple">${ai.forecast}</span><br>

      <strong>Препоръка:</strong>
      <span class="neon-pink">${ai.recommendation}</span>
    </div>

    <!-- EVENTS LIST -->
    <div class="section-title">Списък събития</div>
    <div id="worldEventsList">
      ${
        events.length === 0
          ? `<div class="info-box">Няма активни събития.</div>`
          : events
              .map(
                e => `
        <div class="info-box world-event-entry" data-id="${e._id}" style="cursor:pointer;">
          <div class="world-event-title">${e.title}</div>

          <div class="world-event-meta">
            <span>Тип: <span class="neon-blue">${e.type}</span></span>
            <span>Ефект: <span class="neon-gold">${e.effect}</span></span>
            <span>Опасност: <span class="neon-red">${e.danger}</span></span>
          </div>
        </div>
      `
              )
              .join("")
      }
    </div>

    <!-- BUTTONS -->
    <div class="panel-buttons">
      <button class="btn" id="refreshWorldEvents">Обнови</button>
      <button class="btn" id="closeWorldEventsPanel">Затвори</button>
    </div>
  `;

  app.appendChild(panel);
  Utils.neonPulse(panel, "#00c8ff");

  // ===============================================
  // CLICK → Детайли за събитие + AI анализ
  // ===============================================
  panel.querySelectorAll("#worldEventsList .info-box").forEach(box => {
    box.addEventListener("click", async () => {
      const id = box.dataset.id;
      const event = await ApiClient.getWorldEvent(id);

      Utils.neonFlash(box, "#ff007c");

      const eventAI = AICore.worldEventAI(event);

      panel.innerHTML = `
        <div class="panel-title">
          <span class="icon-worldevents" style="margin-right:8px;"></span>
          ${event.title}
        </div>

        <div class="section-title">AI Анализ</div>
        <div class="info-box">
          <strong>Опасност:</strong>
          <span class="neon-red">${eventAI.danger}</span><br>

          <strong>Полза:</strong>
          <span class="neon-gold">${eventAI.profit}</span><br>

          <strong>Ефект:</strong>
          <span class="neon-blue">${eventAI.effect}</span><br>

          <strong>Прогноза:</strong>
          <span class="neon-purple">${eventAI.forecast}</span><br>

          <strong>Препоръка:</strong>
          <span class="neon-pink">${eventAI.recommendation}</span>
        </div>

        <div class="section-title">Описание</div>
        <div class="info-box">
          ${event.description}
        </div>

        <div class="panel-buttons">
          <button class="btn" id="backToWorldEvents">Назад</button>
          <button class="btn" id="closeWorldEventsPanel">Затвори</button>
        </div>
      `;

      Utils.qs("#backToWorldEvents").addEventListener("click", () => {
        showWorldEventsPanel();
      });

      Utils.qs("#closeWorldEventsPanel").addEventListener("click", () => {
        Utils.neonFlash(panel, "#ff007c");
        setTimeout(() => panel.remove(), 250);
      });
    });
  });

  // ===============================================
  // REFRESH
  // ===============================================
  Utils.qs("#refreshWorldEvents").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    showWorldEventsPanel();
  });

  // ===============================================
  // CLOSE
  // ===============================================
  Utils.qs("#closeWorldEventsPanel").addEventListener("click", () => {
    Utils.neonFlash(panel, "#ff007c");
    setTimeout(() => panel.remove(), 250);
  });
}