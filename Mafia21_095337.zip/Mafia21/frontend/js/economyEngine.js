// ===============================================
// MAFIA 21st CENTURY — ECONOMY ENGINE (ULTRA PRO)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ===============================================
// Централна икономическа система:
// ✔ динамични цени
// ✔ supply & demand
// ✔ черен пазар
// ✔ влияние на играча
// ✔ икономически събития
// ✔ синхронизация с AI Economy Expansion
// ✔ синхронизация с Weapon Market & Drug Lab AI
// ===============================================

import { ApiClient } from "./apiClient.js";
import { PlayerStatsCore } from "./playerStatsCore.js";
import { WorldState } from "./worldState.js";
import { Utils } from "./utils.js";
import { EventBus } from "./eventBus.js"; // ⭐ добавено

export const EconomyEngine = {
  interval: null,
  rate: 6000, // 6 секунди — оптимално за икономика

  market: {
    goods: [],
    blackMarket: [],
    prices: {},
    demand: {},
    supply: {}
  },

  async init() {
    Utils.log("EconomyEngine — стартиране...");

    await this.loadMarket();
    this.interval = setInterval(() => this.tick(), this.rate);

    Utils.log("EconomyEngine — активен.");
  },

  // ---------------------------------------------
  // Зареждане на пазара от API
  // ---------------------------------------------
  async loadMarket() {
    this.market.goods = await ApiClient.getMarketGoods();
    this.market.blackMarket = await ApiClient.getBlackMarketItems();

    // Инициализиране на supply/demand
    this.market.goods.forEach(g => {
      this.market.supply[g.id] = Utils.randomInt(50, 150);
      this.market.demand[g.id] = Utils.randomInt(30, 120);
      this.market.prices[g.id] = g.basePrice;
    });

    this.market.blackMarket.forEach(b => {
      this.market.supply[b.id] = Utils.randomInt(10, 60);
      this.market.demand[b.id] = Utils.randomInt(40, 140);
      this.market.prices[b.id] = b.basePrice;
    });
  },

  // ---------------------------------------------
  // Основен икономически tick
  // ---------------------------------------------
  async tick() {
    try {
      EventBus.emit("economy_tick", { market: this.market }); // ⭐

      this.updateSupplyDemand();
      this.updatePrices();
      this.applyPlayerInfluence();
      this.applyWorldEvents();
      this.syncToAPI();

      Utils.log("EconomyEngine — tick завършен.");
    } catch (err) {
      console.error("❌ EconomyEngine ERROR:", err);

      EventBus.emit("economy_error", { error: err }); // ⭐
    }
  },

  // ---------------------------------------------
  // Supply & Demand динамика
  // ---------------------------------------------
  updateSupplyDemand() {
    Object.keys(this.market.supply).forEach(id => {
      this.market.supply[id] += Utils.randomInt(-5, 5);
      this.market.demand[id] += Utils.randomInt(-4, 6);

      this.market.supply[id] = Math.max(10, this.market.supply[id]);
      this.market.demand[id] = Math.max(5, this.market.demand[id]);
    });

    EventBus.emit("supply_demand_update", {
      supply: this.market.supply,
      demand: this.market.demand
    }); // ⭐
  },

  // ---------------------------------------------
  // Динамични цени
  // ---------------------------------------------
  updatePrices() {
    Object.keys(this.market.prices).forEach(id => {
      const supply = this.market.supply[id];
      const demand = this.market.demand[id];

      const oldPrice = this.market.prices[id];
      const price = Math.floor((demand / supply) * 100);

      this.market.prices[id] = Math.max(5, price);

      if (oldPrice !== this.market.prices[id]) {
        EventBus.emit("price_change", {
          id,
          oldPrice,
          newPrice: this.market.prices[id]
        }); // ⭐
      }
    });
  },

  // ---------------------------------------------
  // Влияние на играча върху икономиката
  // ---------------------------------------------
  applyPlayerInfluence() {
    const player = PlayerStatsCore.get();

    if (player.reputation > 300) {
      Object.keys(this.market.prices).forEach(id => {
        this.market.prices[id] *= 0.95;
      });

      EventBus.emit("economy_player_influence", {
        type: "reputation_discount",
        reputation: player.reputation
      }); // ⭐
    }

    if (player.heat > 70) {
      Object.keys(this.market.prices).forEach(id => {
        this.market.prices[id] *= 1.10;
      });

      EventBus.emit("economy_player_influence", {
        type: "heat_increase",
        heat: player.heat
      }); // ⭐
    }
  },

  // ---------------------------------------------
  // Световни събития влияят на икономиката
  // ---------------------------------------------
  applyWorldEvents() {
    const events = WorldState.get().events;

    events.forEach(event => {
      if (event.type === "riot") {
        Object.keys(this.market.supply).forEach(id => {
          this.market.supply[id] *= 0.90;
        });

        EventBus.emit("economy_world_event", {
          event,
          effect: "riot_supply_drop"
        }); // ⭐
      }

      if (event.type === "police_operation") {
        Object.keys(this.market.prices).forEach(id => {
          this.market.prices[id] *= 1.15;
        });

        EventBus.emit("economy_world_event", {
          event,
          effect: "police_price_increase"
        }); // ⭐
      }

      if (event.type === "gang_fight") {
        Object.keys(this.market.demand).forEach(id => {
          this.market.demand[id] *= 1.20;
        });

        EventBus.emit("economy_world_event", {
          event,
          effect: "gang_demand_increase"
        }); // ⭐
      }
    });
  },

  // ---------------------------------------------
  // Синхронизация към API
  // ---------------------------------------------
  async syncToAPI() {
    await ApiClient.updateMarket({
      prices: this.market.prices,
      supply: this.market.supply,
      demand: this.market.demand
    });

    EventBus.emit("market_updated", { market: this.market }); // ⭐
  },

  // ---------------------------------------------
  // Връщане на текущия пазар
  // ---------------------------------------------
  getMarket() {
    return this.market;
  }
};

// Автоматично стартиране
EconomyEngine.init();