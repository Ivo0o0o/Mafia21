// ======================================================
// MAFIA 21st CENTURY — ADMIN PANEL (PRO VERSION)
// Architect: 💶 Ivo Karadzov 🍀🐬🪽☁️ 💶
// ======================================================
// God Mode контролен център:
// - Управление на NPC
// - Управление на райони
// - Управление на света
// - Debug overlay
// - Live AI реакции
// ======================================================

// ======================================================
// CORE API + HELPERS
// ======================================================

const API_BASE = "http://localhost:3000/api";

const DebugState = {
  enabled: false,
  fps: 0,
  lastFrameTime: performance.now(),
  apiLogs: [],
  errorLogs: [],
  infoLogs: [],
  maxEntries: 10,
  playerStatus: {},
  npcStatus: {},
  worldStatus: {},
  missionStatus: {}
};

function debugPush(list, entry) {
  list.unshift(entry);
  if (list.length > DebugState.maxEntries) list.pop();
}

function debugLog(msg) {
  debugPush(DebugState.infoLogs, {
    time: new Date().toLocaleTimeString(),
    msg
  });
  renderDebugOverlay();
}

function debugError(msg) {
  debugPush(DebugState.errorLogs, {
    time: new Date().toLocaleTimeString(),
    msg
  });
  renderDebugOverlay();
}

function debugApi(endpoint, method, latency, ok) {
  debugPush(DebugState.apiLogs, {
    time: new Date().toLocaleTimeString(),
    endpoint,
    method,
    latency,
    ok
  });
  renderDebugOverlay();
}

async function call(endpoint, method = "GET", body = null) {
  const start = performance.now();

  const options = {
    method,
    headers: {
      "Content-Type": "application/json",
      "x-god-key": "ivo_master_key_21vek"
    }
  };
  if (body) options.body = JSON.stringify(body);

  let ok = true;
  try {
    const res = await fetch(`${API_BASE}/${endpoint}`, options);
    const latency = Math.round(performance.now() - start);
    ok = res.ok;
    debugApi(endpoint, method, latency, ok);
    const json = await res.json();
    if (!ok || json.error) {
      debugError(`API error [${method} ${endpoint}]: ${json.error || res.status}`);
    }
    return json;
  } catch (err) {
    const latency = Math.round(performance.now() - start);
    ok = false;
    debugApi(endpoint, method, latency, ok);
    debugError(`Fetch failed [${method} ${endpoint}]: ${err.message}`);
    return { error: err.message || "Network error" };
  }
}

const getEl = id => document.getElementById(id);
const val = id => getEl(id)?.value ?? "";
const num = id => Number(val(id));

// ======================================================
// DEBUG OVERLAY UI
// ======================================================

function createDebugOverlay() {
  if (getEl("debug-overlay")) return;

  const btn = document.createElement("button");
  btn.id = "debug-toggle-btn";
  btn.textContent = "DEBUG";
  btn.style.position = "fixed";
  btn.style.top = "8px";
  btn.style.right = "8px";
  btn.style.zIndex = "9999";
  btn.style.padding = "4px 8px";
  btn.style.fontSize = "12px";
  btn.style.background = "#222";
  btn.style.color = "#0f0";
  btn.style.border = "1px solid #0f0";
  btn.style.borderRadius = "4px";
  btn.style.cursor = "pointer";
  btn.onclick = () => {
    DebugState.enabled = !DebugState.enabled;
    renderDebugOverlay();
  };

  const overlay = document.createElement("div");
  overlay.id = "debug-overlay";
  overlay.style.position = "fixed";
  overlay.style.top = "32px";
  overlay.style.right = "8px";
  overlay.style.width = "280px";
  overlay.style.maxHeight = "60vh";
  overlay.style.overflowY = "auto";
  overlay.style.zIndex = "9998";
  overlay.style.background = "rgba(0,0,0,0.85)";
  overlay.style.color = "#0f0";
  overlay.style.fontFamily = "monospace";
  overlay.style.fontSize = "11px";
  overlay.style.padding = "8px";
  overlay.style.border = "1px solid #0f0";
  overlay.style.borderRadius = "4px";
  overlay.style.display = "none";

  document.body.appendChild(btn);
  document.body.appendChild(overlay);

  startFPSLoop();
}

function startFPSLoop() {
  function loop() {
    const now = performance.now();
    const delta = now - DebugState.lastFrameTime;
    DebugState.lastFrameTime = now;
    DebugState.fps = Math.round(1000 / (delta || 1));
    if (DebugState.enabled) renderDebugOverlay();
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
}

function renderDebugOverlay() {
  const overlay = getEl("debug-overlay");
  if (!overlay) return;
  overlay.style.display = DebugState.enabled ? "block" : "none";
  if (!DebugState.enabled) return;

  const fpsLine = `FPS: ${DebugState.fps}`;
  const apiLines = DebugState.apiLogs
    .map(a => `[${a.time}] ${a.method} ${a.endpoint} (${a.latency}ms) ${a.ok ? "OK" : "ERR"}`)
    .join("\n");
  const errLines = DebugState.errorLogs
    .map(e => `[${e.time}] ${e.msg}`)
    .join("\n");
  const infoLines = DebugState.infoLogs
    .map(i => `[${i.time}] ${i.msg}`)
    .join("\n");

  const playerLine = `Player: ${JSON.stringify(DebugState.playerStatus || {}, null, 0)}`;
  const npcLine = `NPC: ${JSON.stringify(DebugState.npcStatus || {}, null, 0)}`;
  const worldLine = `World: ${JSON.stringify(DebugState.worldStatus || {}, null, 0)}`;
  const missionLine = `Mission: ${JSON.stringify(DebugState.missionStatus || {}, null, 0)}`;

  overlay.textContent =
    fpsLine +
    "\n\n" +
    "=== API ===\n" +
    (apiLines || "No API calls yet.") +
    "\n\n" +
    "=== ERRORS ===\n" +
    (errLines || "No errors.") +
    "\n\n" +
    "=== LOGS ===\n" +
    (infoLines || "No logs.") +
    "\n\n" +
    "=== STATUS ===\n" +
    playerLine +
    "\n" +
    npcLine +
    "\n" +
    worldLine +
    "\n" +
    missionLine;
}

document.addEventListener("DOMContentLoaded", () => {
  createDebugOverlay();
  debugLog("Debug overlay initialized.");
});

// ======================================================
// MAP + DISTRICTS
// ======================================================

let districtPositions = [];

function renderMap(state) {
  const canvas = getEl("mapCanvas");
  if (!canvas) {
    debugError("mapCanvas not found.");
    return;
  }

  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  districtPositions = [];

  if (!state.territory || !Array.isArray(state.territory.districts)) {
    debugError("Invalid territory state for renderMap.");
    return;
  }

  state.territory.districts.forEach(d => {
    const x = d.position?.x ?? Math.random() * 550;
    const y = d.position?.y ?? Math.random() * 350;

    districtPositions.push({
      districtId: d.districtId,
      name: d.name,
      x,
      y,
      w: 40,
      h: 40
    });

    const control = d.controlLevel || 0;
    ctx.fillStyle = `rgb(${control * 2}, 50, 50)`;
    ctx.fillRect(x, y, 40, 40);

    ctx.fillStyle = "#fff";
    ctx.fillText(d.name, x, y - 5);
  });

  DebugState.worldStatus.mapRendered = true;
  DebugState.worldStatus.districtCount = state.territory.districts.length;
  renderDebugOverlay();
}

getEl("mapCanvas")?.addEventListener("click", async (e) => {
  const rect = e.target.getBoundingClientRect();
  const clickX = e.clientX - rect.left;
  const clickY = e.clientY - rect.top;

  for (const d of districtPositions) {
    if (
      clickX >= d.x &&
      clickX <= d.x + d.w &&
      clickY >= d.y &&
      clickY <= d.y + d.h
    ) {
      const info = await call(`districtDetails/${d.districtId}`, "GET");
      renderDistrictInfo(info);
      DebugState.worldStatus.lastDistrict = d.name;
      renderDebugOverlay();
      break;
    }
  }
});

function renderDistrictInfo(d) {
  const panel = getEl("district-info-panel");
  const outEl = getEl("districtInfo");

  if (!panel || !outEl) {
    debugError("District info panel elements missing.");
    return;
  }

  if (!d || d.error) {
    outEl.textContent = "District not found.";
    panel.style.display = "block";
    debugError("District not found in renderDistrictInfo.");
    return;
  }

  outEl.textContent = `
Name: ${d.name}
Crime Level: ${d.crimeLevel}
Economy Level: ${d.economyLevel}
NPC Density: ${d.npcDensity}
Police Presence: ${d.policePresence}
Player Control: ${d.playerControl}%
Position: (${d.position.x}, ${d.position.y})
`;
  panel.style.display = "block";

  DebugState.worldStatus.lastDistrictInfo = {
    name: d.name,
    crime: d.crimeLevel,
    economy: d.economyLevel
  };
  renderDebugOverlay();
}

// ======================================================
// PLAYER ACTIONS LOG
// ======================================================

function renderPlayerActionsLog(text) {
  const el = getEl("playerActionsLog");
  if (!el) return;
  const prev = el.textContent || "";
  const time = new Date().toLocaleTimeString();
  el.textContent = `[${time}] ${text}\n` + prev;
  debugLog(`PlayerActions: ${text}`);
}

// ======================================================
// GOD / PLAYER BASIC
// ======================================================

function setUserRole() {
  call("god/setRole", "POST", {
    userId: val("userId"),
    role: val("userRole")
  }).then(res => {
    debugLog(`setUserRole: ${JSON.stringify(res)}`);
  });
}

function setUserMoney() {
  call("god/setMoney", "POST", {
    userId: val("userId"),
    amount: num("userMoney")
  }).then(res => {
    debugLog(`setUserMoney: ${JSON.stringify(res)}`);
  });
}

function getUser() {
  call(`admin/user/${val("userId")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
    DebugState.playerStatus.lastUser = data?.userId || val("userId");
    renderDebugOverlay();
  });
}

// ======================================================
// PLAYER SYSTEMS
// ======================================================

function psView() {
  call(`playerState/${val("psPlayerId")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
    DebugState.playerStatus.state = data;
    renderDebugOverlay();
  });
}

function addXP() {
  call("level/addXP", "POST", {
    userId: val("xpUserId"),
    amount: num("xpAmount")
  }).then(res => debugLog(`addXP: ${JSON.stringify(res)}`));
}

function setLevel() {
  call("level/setLevel", "POST", {
    userId: val("levelUserId"),
    level: num("levelValue")
  }).then(res => debugLog(`setLevel: ${JSON.stringify(res)}`));
}

function setXP() {
  call("level/setXP", "POST", {
    userId: val("setXPUserId"),
    xp: num("setXPValue")
  }).then(res => debugLog(`setXP: ${JSON.stringify(res)}`));
}

function ecoView() {
  call(`economy/${val("ecoPlayerId")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}

function ecoTick() {
  call("economy/tick", "POST", { playerId: val("ecoPlayerId") }).then(res => {
    debugLog(`ecoTick: ${JSON.stringify(res)}`);
  });
}

function assetsView() {
  call(`assets/${val("assetsPlayerId")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}

function assetsTick() {
  call("assets/tick", "POST", { playerId: val("assetsPlayerId") }).then(res => {
    debugLog(`assetsTick: ${JSON.stringify(res)}`);
  });
}

function crimeDo() {
  call("crime/do", "POST", {
    playerId: val("crimePlayerId"),
    actionId: val("crimeActionId")
  }).then(res => {
    debugLog(`crimeDo: ${JSON.stringify(res)}`);
  });
}

function courtView() {
  call(`court/${val("courtPlayerId")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}

function courtNext() {
  call("court/nextStage", "POST", { playerId: val("courtPlayerId") }).then(res => {
    debugLog(`courtNext: ${JSON.stringify(res)}`);
  });
}

function courtVerdict() {
  call("court/verdict", "POST", { playerId: val("courtPlayerId") }).then(res => {
    debugLog(`courtVerdict: ${JSON.stringify(res)}`);
  });
}

function courtAppeal() {
  call("court/appeal", "POST", { playerId: val("courtPlayerId") }).then(res => {
    debugLog(`courtAppeal: ${JSON.stringify(res)}`);
  });
}

function courtClose() {
  call("court/close", "POST", { playerId: val("courtPlayerId") }).then(res => {
    debugLog(`courtClose: ${JSON.stringify(res)}`);
  });
}

function prisonView() {
  call(`prison/${val("prisonPlayerId")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}

function prisonApply() {
  call("prison/applySentence", "POST", { playerId: val("prisonPlayerId") }).then(res => {
    debugLog(`prisonApply: ${JSON.stringify(res)}`);
  });
}

function prisonTick() {
  call("prison/tick", "POST", { playerId: val("prisonPlayerId") }).then(res => {
    debugLog(`prisonTick: ${JSON.stringify(res)}`);
  });
}

function prisonEscape() {
  call("prison/escape", "POST", { playerId: val("prisonPlayerId") }).then(res => {
    debugLog(`prisonEscape: ${JSON.stringify(res)}`);
  });
}

function prisonRelease() {
  call("prison/release", "POST", { playerId: val("prisonPlayerId") }).then(res => {
    debugLog(`prisonRelease: ${JSON.stringify(res)}`);
  });
}

function terrView() {
  call(`playerTerritory/${val("terrPlayerId")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}

function terrAdd() {
  call("playerTerritory/addDistrict", "POST", {
    playerId: val("terrPlayerId"),
    name: val("terrName")
  }).then(res => debugLog(`terrAdd: ${JSON.stringify(res)}`));
}

function terrInc() {
  call("playerTerritory/increaseControl", "POST", {
    playerId: val("terrPlayerId"),
    districtId: val("terrDistrictId"),
    amount: num("terrAmount")
  }).then(res => debugLog(`terrInc: ${JSON.stringify(res)}`));
}

function terrDec() {
  call("playerTerritory/decreaseControl", "POST", {
    playerId: val("terrPlayerId"),
    districtId: val("terrDistrictId"),
    amount: num("terrAmount")
  }).then(res => debugLog(`terrDec: ${JSON.stringify(res)}`));
}

function rankView() {
  call(`playerRank/${val("rankPlayerId")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}

function rankTick() {
  call("playerRank/tick", "POST", { playerId: val("rankPlayerId") }).then(res => {
    debugLog(`rankTick: ${JSON.stringify(res)}`);
  });
}

// ======================================================
// PLAYER ACTIONS ENGINE
// ======================================================

function actStartMission() {
  const mission = {
    name: "Auto Mission",
    baseReward: 100,
    difficulty: 1,
    risk: 0.1,
    type: "crime"
  };

  call("actions/startMission", "POST", {
    playerId: val("actPlayerId"),
    mission
  }).then(res => {
    getEl("actOutput").textContent = JSON.stringify(res, null, 2);
    DebugState.missionStatus.lastMission = mission.name;
    renderDebugOverlay();
  });
}

function actDayTick() {
  call("actions/dayTick", "POST").then(res => {
    getEl("actOutput").textContent = JSON.stringify(res, null, 2);
  });
}

function actNightTick() {
  call("actions/nightTick", "POST").then(res => {
    getEl("actOutput").textContent = JSON.stringify(res, null, 2);
  });
}

function actRefresh() {
  call(`actions/refresh/${val("actPlayerId")}`, "GET").then(res => {
    getEl("actOutput").textContent = JSON.stringify(res, null, 2);
  });
}

// ======================================================
// NPC SYSTEMS
// ======================================================

function setNPCStrength() {
  call("npc/setStrength", "POST", {
    npcId: val("npcId"),
    value: num("npcStrength")
  }).then(res => debugLog(`setNPCStrength: ${JSON.stringify(res)}`));
}

function setNPCRespect() {
  call("npc/setRespect", "POST", {
    npcId: val("npcId"),
    value: num("npcRespect")
  }).then(res => debugLog(`setNPCRespect: ${JSON.stringify(res)}`));
}

function setNPCMood() {
  call("npc/setMood", "POST", {
    npcId: val("npcId"),
    mood: val("npcMood")
  }).then(res => debugLog(`setNPCMood: ${JSON.stringify(res)}`));
}

function getNPC() {
  call(`npc/${val("npcId")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
    DebugState.npcStatus.lastNPC = data?.npcId || val("npcId");
    renderDebugOverlay();
  });
}

function updateNPCPersonality() {
  let parsed;
  try {
    parsed = JSON.parse(val("npcPersData"));
  } catch (e) {
    debugError("Invalid JSON in npcPersData.");
    return;
  }
  call("npcPersonality/update", "POST", {
    npcId: val("npcPersId"),
    data: parsed
  }).then(res => debugLog(`updateNPCPersonality: ${JSON.stringify(res)}`));
}

function viewNPCPersonality() {
  call(`npcPersonality/${val("npcPersId")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}

function viewNPCLife() {
  call(`npcLife/${val("npcLifeId")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}

function updateNPCLife() {
  call("npcLife/update", "POST", { npcId: val("npcLifeId") }).then(res => {
    debugLog(`updateNPCLife: ${JSON.stringify(res)}`);
  });
}

function addFriend() {
  call("npcSocial/friend", "POST", {
    npcId: val("socialNpcId"),
    targetId: val("socialTargetId")
  }).then(res => debugLog(`addFriend: ${JSON.stringify(res)}`));
}

function addEnemy() {
  call("npcSocial/enemy", "POST", {
    npcId: val("socialNpcId"),
    targetId: val("socialTargetId")
  }).then(res => debugLog(`addEnemy: ${JSON.stringify(res)}`));
}

function addAlly() {
  call("npcSocial/ally", "POST", {
    npcId: val("socialNpcId"),
    targetId: val("socialTargetId")
  }).then(res => debugLog(`addAlly: ${JSON.stringify(res)}`));
}

function addRival() {
  call("npcSocial/rival", "POST", {
    npcId: val("socialNpcId"),
    targetId: val("socialTargetId")
  }).then(res => debugLog(`addRival: ${JSON.stringify(res)}`));
}

function viewSocial() {
  call(`npcSocial/${val("socialNpcId")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}

function addIncome() {
  call("npcEconomy/income", "POST", {
    npcId: val("ecoNpcId"),
    amount: num("ecoAmount"),
    source: val("ecoSource")
  }).then(res => debugLog(`addIncome: ${JSON.stringify(res)}`));
}

function addExpense() {
  call("npcEconomy/expense", "POST", {
    npcId: val("ecoNpcId"),
    amount: num("ecoAmount"),
    type: val("ecoExpenseType")
  }).then(res => debugLog(`addExpense: ${JSON.stringify(res)}`));
}

function economicTick() {
  call("npcEconomy/tick", "POST", { npcId: val("ecoNpcId") }).then(res => {
    debugLog(`economicTick: ${JSON.stringify(res)}`);
  });
}

function viewEconomy() {
  call(`npcEconomy/${val("ecoNpcId")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}// ======================================================
// ORGANIZATION SYSTEMS
// ======================================================

function createOrganization() {
  call("organization/create", "POST", {
    name: val("orgName"),
    type: val("orgType"),
    leaderNpcId: val("orgLeader")
  }).then(res => debugLog(`createOrganization: ${JSON.stringify(res)}`));
}

function addMember() {
  call("organization/addMember", "POST", {
    orgId: val("orgId"),
    npcId: val("orgNpcId"),
    role: val("orgRole")
  }).then(res => debugLog(`addMember: ${JSON.stringify(res)}`));
}

function removeMember() {
  call("organization/removeMember", "POST", {
    orgId: val("orgId"),
    npcId: val("orgNpcId")
  }).then(res => debugLog(`removeMember: ${JSON.stringify(res)}`));
}

function changeRole() {
  call("organization/changeRole", "POST", {
    orgId: val("orgId"),
    npcId: val("orgNpcId"),
    role: val("orgRole")
  }).then(res => debugLog(`changeRole: ${JSON.stringify(res)}`));
}

function changeLeader() {
  call("organization/changeLeader", "POST", {
    orgId: val("orgId"),
    npcId: val("orgNpcId")
  }).then(res => debugLog(`changeLeader: ${JSON.stringify(res)}`));
}

function setTerritory() {
  call("organization/territory", "POST", {
    orgId: val("orgId"),
    name: val("territoryName"),
    influence: num("territoryInfluence"),
    incomeBonus: num("territoryIncomeBonus"),
    dangerLevel: num("territoryDanger")
  }).then(res => debugLog(`setTerritory: ${JSON.stringify(res)}`));
}

function orgDistrictIncome() {
  call("orgEconomy/districtIncome", "POST", {
    orgId: val("orgEcoId")
  }).then(res => debugLog(`orgDistrictIncome: ${JSON.stringify(res)}`));
}

function orgBusinessIncome() {
  call("orgEconomy/businessIncome", "POST", {
    orgId: val("orgEcoId"),
    npcIds: val("orgEcoNpcIds").split(",").map(x => x.trim())
  }).then(res => debugLog(`orgBusinessIncome: ${JSON.stringify(res)}`));
}

function orgNpcTax() {
  call("orgEconomy/npcTax", "POST", {
    orgId: val("orgEcoId"),
    npcIds: val("orgEcoNpcIds").split(",").map(x => x.trim())
  }).then(res => debugLog(`orgNpcTax: ${JSON.stringify(res)}`));
}

function orgEcoTick() {
  call("orgEconomy/tick", "POST", {
    orgId: val("orgEcoId"),
    npcIds: val("orgEcoNpcIds").split(",").map(x => x.trim())
  }).then(res => debugLog(`orgEcoTick: ${JSON.stringify(res)}`));
}

function viewOrgEconomy() {
  call(`orgEconomy/${val("orgEcoId")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}

function startWar() {
  call("orgWarfare/start", "POST", {
    attackerOrgId: val("warAttacker"),
    defenderOrgId: val("warDefender"),
    district: val("warDistrict")
  }).then(res => debugLog(`startWar: ${JSON.stringify(res)}`));
}

function viewWarHistory() {
  call(`orgWarfare/${val("warHistoryOrg")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}

function relChange() {
  call("orgRelations/change", "POST", {
    orgId: val("relOrgId"),
    targetOrgId: val("relTargetOrgId"),
    amount: num("relAmount")
  }).then(res => debugLog(`relChange: ${JSON.stringify(res)}`));
}

function dipCreate() {
  call("orgRelations/diplomacy", "POST", {
    orgId: val("relOrgId"),
    payload: {
      type: val("dipType"),
      targetOrgId: val("dipTargetOrgId"),
      duration: num("dipDuration")
    }
  }).then(res => debugLog(`dipCreate: ${JSON.stringify(res)}`));
}

function dipTick() {
  call("orgRelations/tick", "POST", {
    orgId: val("relOrgId")
  }).then(res => debugLog(`dipTick: ${JSON.stringify(res)}`));
}

function relView() {
  call(`orgRelations/${val("relOrgId")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}

// ======================================================
// WORLD SYSTEMS
// ======================================================

function distCreate() {
  call("districts/create", "POST", {
    name: val("distName"),
    x: num("distX"),
    y: num("distY")
  }).then(res => debugLog(`distCreate: ${JSON.stringify(res)}`));
}

function distList() {
  call("districts", "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}

function getDistrictInfluence() {
  call(`influence/${val("infDistrict")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}

function createWorldEvent() {
  call("worldEvents/create", "POST", {
    district: val("eventDistrict"),
    type: val("eventType"),
    description: val("eventDesc"),
    impact: { crime: 5 }
  }).then(res => debugLog(`createWorldEvent: ${JSON.stringify(res)}`));
}

function viewWorldEvents() {
  call(`worldEvents/${val("eventDistrictView")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}

// ======================================================
// GLOBAL WORLD SIMULATION
// ======================================================

function worldView() {
  call("world/", "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
    DebugState.worldStatus.world = data;
    renderDebugOverlay();
  });
}

function worldCreateWar() {
  call("world/war", "POST", {
    attackerOrgId: val("warAttacker"),
    defenderOrgId: val("warDefender"),
    intensity: num("warIntensity")
  }).then(res => debugLog(`worldCreateWar: ${JSON.stringify(res)}`));
}

function worldTick() {
  call("world/tick", "POST", {}).then(res => {
    debugLog(`worldTick: ${JSON.stringify(res)}`);
    DebugState.worldStatus.lastTick = new Date().toLocaleTimeString();
    renderDebugOverlay();
  });
}

// ======================================================
// CITY SIMULATION
// ======================================================

function cityView() {
  call(`citySim/${val("cityDistrict")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
  });
}

function cityTick() {
  call("citySim/tick", "POST", {
    district: val("cityDistrict")
  }).then(res => debugLog(`cityTick: ${JSON.stringify(res)}`));
}

// ======================================================
// GAME SESSION
// ======================================================

function sessView() {
  call(`gameSession/${val("sessPlayerId")}`, "GET").then(data => {
    getEl("output").textContent = JSON.stringify(data, null, 2);
    DebugState.playerStatus.session = data;
    renderDebugOverlay();
  });
}

function sessDay() {
  call("gameSession/dayTick", "POST", {
    playerId: val("sessPlayerId")
  }).then(res => debugLog(`sessDay: ${JSON.stringify(res)}`));
}

function sessNight() {
  call("gameSession/nightTick", "POST", {
    playerId: val("sessPlayerId")
  }).then(res => debugLog(`sessNight: ${JSON.stringify(res)}`));
}

function sessEnd() {
  call("gameSession/end", "POST", {
    playerId: val("sessPlayerId")
  }).then(res => debugLog(`sessEnd: ${JSON.stringify(res)}`));
}

// ======================================================
// PLAYER ACTIONS PANEL BUTTONS
// ======================================================

getEl("btn-start-mission")?.addEventListener("click", () => {
  const playerId = val("playerIdInput");
  const missionId = val("missionIdInput");

  if (!playerId || !missionId) {
    renderPlayerActionsLog("PlayerId и MissionId са задължителни.");
    return;
  }

  call("playerActions/startMission", "POST", { playerId, missionId })
    .then(res => {
      if (res.error) {
        renderPlayerActionsLog(`Error: ${res.error}`);
      } else {
        renderPlayerActionsLog(`Mission started: ${missionId} for player ${playerId}`);
        DebugState.missionStatus.lastMissionId = missionId;
        DebugState.playerStatus.lastMissionPlayer = playerId;
        renderDebugOverlay();
      }
    });
});

getEl("btn-day-tick")?.addEventListener("click", () => {
  const playerId = val("playerIdInput");
  if (!playerId) {
    renderPlayerActionsLog("PlayerId е задължителен за Day Tick.");
    return;
  }

  call("playerActions/dayTick", "POST", { playerId })
    .then(res => {
      if (res.error) {
        renderPlayerActionsLog(`Error: ${res.error}`);
      } else {
        renderPlayerActionsLog(`Day Tick applied for player ${playerId}`);
      }
    });
});

getEl("btn-night-tick")?.addEventListener("click", () => {
  const playerId = val("playerIdInput");
  if (!playerId) {
    renderPlayerActionsLog("PlayerId е задължителен за Night Tick.");
    return;
  }

  call("playerActions/nightTick", "POST", { playerId })
    .then(res => {
      if (res.error) {
        renderPlayerActionsLog(`Error: ${res.error}`);
      } else {
        renderPlayerActionsLog(`Night Tick applied for player ${playerId}`);
      }
    });
});

// ======================================================
// VIP MODULE
// ======================================================

function buyVIPPack() {
  call("vip/buyPack", "POST", {
    userId: val("vipUserId"),
    pack: val("vipPackName")
  }).then(res => {
    getEl("vipOutput").textContent = JSON.stringify(res, null, 2);
  });
}

// ======================================================
// MODULE EXPORTS (GLOBAL NAMESPACES)
// ======================================================

const PlayerModule = {
  psView, addXP, setLevel, setXP,
  ecoView, ecoTick,
  assetsView, assetsTick,
  crimeDo,
  courtView, courtNext, courtVerdict, courtAppeal, courtClose,
  prisonView, prisonApply, prisonTick, prisonEscape, prisonRelease,
  terrView, terrAdd, terrInc, terrDec,
  rankView, rankTick,
  actStartMission, actDayTick, actNightTick, actRefresh,
  sessView, sessDay, sessNight, sessEnd
};

const NPCModule = {
  setNPCStrength, setNPCRespect, setNPCMood,
  getNPC,
  updateNPCPersonality, viewNPCPersonality,
  viewNPCLife, updateNPCLife,
  addFriend, addEnemy, addAlly, addRival,
  viewSocial,
  addIncome, addExpense,
  economicTick, viewEconomy
};

const OrgModule = {
  createOrganization,
  addMember, removeMember, changeRole, changeLeader,
  setTerritory,
  orgDistrictIncome, orgBusinessIncome, orgNpcTax, orgEcoTick,
  viewOrgEconomy,
  startWar, viewWarHistory,
  relChange, dipCreate, dipTick, relView
};

const WorldModule = {
  distCreate, distList, getDistrictInfluence,
  createWorldEvent, viewWorldEvents,
  worldView, worldCreateWar, worldTick,
  cityView, cityTick
};

const AdminModule = {
  setUserRole, setUserMoney, getUser,
  renderMap, renderDistrictInfo, renderPlayerActionsLog
};

const DebugModule = {
  debugLog, debugError, debugApi, renderDebugOverlay, DebugState
};

// ======================================================
// IMPORTS (MODULE MODE)
// ======================================================

import { ApiClient } from "../frontend/js/apiClient.js";
import { Utils } from "../frontend/js/utils.js";

// ======================================================
// ADMIN PANEL INITIALIZATION
// ======================================================

window.addEventListener("DOMContentLoaded", () => {
  initAdminPanel();
});

function initAdminPanel() {
  const app = document.querySelector("#adminApp");
  if (!app) {
    debugError("adminApp container not found.");
    return;
  }

  const panel = createPanel("Админ контролен център");

  panel.innerHTML += `
    <button class="admin-btn" id="loadDistricts">Зареди райони</button>
    <button class="admin-btn" id="loadNPC">Зареди NPC</button>
    <button class="admin-btn" id="loadWorld">Световни събития</button>
    <button class="admin-btn" id="toggleDebug">Debug Overlay</button>

    <div id="adminOutput" class="admin-log"></div>
  `;

  app.appendChild(panel);

  // -----------------------------------------------
  // Зареждане на райони
  // -----------------------------------------------
  document.querySelector("#loadDistricts").addEventListener("click", async () => {
    const out = document.querySelector("#adminOutput");
    out.innerHTML = "Зареждам райони…";

    const districts = await ApiClient.getDistricts();

    out.innerHTML = `
      <h3>Райони (${districts.length})</h3>
      <table class="admin-table">
        <tr>
          <th>Име</th>
          <th>Тип</th>
          <th>Ниво</th>
          <th>Контрол</th>
        </tr>
        ${districts.map(d => `
          <tr>
            <td>${d.name}</td>
            <td>${d.type}</td>
            <td>${d.level}</td>
            <td>${d.control}%</td>
          </tr>
        `).join("")}
      </table>
    `;
  });

  // -----------------------------------------------
  // Зареждане на NPC
  // -----------------------------------------------
  document.querySelector("#loadNPC").addEventListener("click", async () => {
    const out = document.querySelector("#adminOutput");
    out.innerHTML = "Зареждам NPC…";

    const npc = await ApiClient.getNPC(1); // примерен NPC ID
    const ai = Utils.npcBehaviorAI();

    out.innerHTML = `
      <h3>NPC Профил</h3>
      <div><strong>Име:</strong> ${npc.name}</div>
      <div><strong>Роля:</strong> ${npc.role}</div>
      <div><strong>Локация:</strong> ${npc.location}</div>
      <div><strong>Здраве:</strong> ${npc.health}%</div>

      <h3>AI състояние</h3>
      <div>Емоция: ${ai.emotion}</div>
      <div>Решение: ${ai.decision}</div>
      <div>Интензитет: ${ai.intensity}</div>
    `;
  });

  // -----------------------------------------------
  // Световни събития
  // -----------------------------------------------
  document.querySelector("#loadWorld").addEventListener("click", async () => {
    const out = document.querySelector("#adminOutput");
    out.innerHTML = "Зареждам световни събития…";

    const events = await ApiClient.getWorldEvents();

    out.innerHTML = `
      <h3>Световни събития (${events.length})</h3>
      <ul>
        ${events.map(ev => `
          <li>
            <span class="admin-success-text">${ev.type}</span> —
            <span>${ev.description}</span>
          </li>
        `).join("")}
      </ul>
    `;
  });

  // -----------------------------------------------
  // Debug Overlay Toggle
  // -----------------------------------------------
  document.querySelector("#toggleDebug").addEventListener("click", () => {
    toggleDebugOverlay();
  });
}

// ======================================================
// UI HELPERS
// ======================================================

function createPanel(title) {
  const panel = document.createElement("div");
  panel.className = "admin-panel";
  panel.innerHTML = `<h2>${title}</h2>`;
  return panel;
}

// ======================================================
// CUSTOM DEBUG OVERLAY (ADMIN PANEL)
// ======================================================

function toggleDebugOverlay() {
  let overlay = document.querySelector("#debugOverlay");

  if (!overlay) {
    overlay = document.createElement("div");
    overlay.id = "debugOverlay";
    overlay.style.position = "fixed";
    overlay.style.bottom = "10px";
    overlay.style.right = "10px";
    overlay.style.padding = "15px";
    overlay.style.background = "rgba(0,0,0,0.7)";
    overlay.style.border = "1px solid #00c8ff";
    overlay.style.color = "#fff";
    overlay.style.zIndex = "9999";
    overlay.style.fontFamily = "monospace";

    overlay.innerHTML = `
      <strong>DEBUG OVERLAY</strong><br>
      FPS: ${Utils.rand(55, 144)}<br>
      AI Load: ${Utils.rand(1, 20)}%<br>
      World Tick: ${Utils.rand(100, 500)}ms
    `;

    document.body.appendChild(overlay);
  } else {
    overlay.remove();
  }
}